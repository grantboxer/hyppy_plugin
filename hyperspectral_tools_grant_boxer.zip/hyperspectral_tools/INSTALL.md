# Installation and Quick Start Guide

## Installation

### Method 1: Install from ZIP (Recommended)

1. **Download** the plugin ZIP file (if available from repository)

2. **Open QGIS** and go to:
   ```
   Plugins → Manage and Install Plugins
   ```

3. **Click** "Install from ZIP" tab

4. **Select** the downloaded ZIP file

5. **Click** "Install Plugin"

6. **Enable** the plugin if it's not automatically enabled

### Method 2: Manual Installation

1. **Locate** your QGIS plugins directory:
   
   **Windows:**
   ```
   C:\Users\[YourUsername]\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\
   ```
   
   **Linux:**
   ```
   ~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/
   ```
   
   **macOS:**
   ```
   ~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/
   ```

2. **Copy** the entire `hyperspectral_tools` folder to the plugins directory

3. **Restart** QGIS

4. **Enable** the plugin:
   ```
   Plugins → Manage and Install Plugins → Installed
   ```
   Check "Hyperspectral Analysis Tools"

## Verification

After installation, verify the plugin is working:

1. Open **Processing Toolbox**:
   ```
   Processing → Toolbox
   ```

2. You should see a new group: **"Hyperspectral Tools"**

3. Expand it to see available algorithms:
   - Classification
     - Spectral Angle Mapper (SAM)

## Quick Start: Running SAM Analysis

### Step 1: Prepare Your Data

You need:
- A multi-band hyperspectral image (or any multi-band raster)
- A spectral library file (CSV format)

**Example Spectral Library** (included as `example_spectral_library.csv`):
```csv
wavelength,400,450,500,550,600,650,700
Vegetation,0.05,0.04,0.06,0.25,0.30,0.40,0.45
Water,0.02,0.015,0.01,0.008,0.005,0.003,0.002
Soil,0.15,0.18,0.20,0.22,0.25,0.27,0.28
```

### Step 2: Load Your Hyperspectral Image

1. **Add** your raster to QGIS:
   ```
   Layer → Add Layer → Add Raster Layer
   ```

2. Select your hyperspectral image file (e.g., GeoTIFF, ENVI format)

### Step 3: Run SAM Algorithm

1. Open **Processing Toolbox**

2. Navigate to:
   ```
   Hyperspectral Tools → Classification → Spectral Angle Mapper (SAM)
   ```

3. **Double-click** to open the algorithm dialog

4. **Configure parameters**:
   - **Input Hyperspectral Image:** Select your loaded raster
   - **Spectral Library:** Browse to your CSV spectral library file
   - **Similarity Measure:** Keep default (SAM) or choose another
   - **Output Rule Image:** Specify output path (e.g., `sam_rules.tif`)
   - **Output Classification Image:** (Optional) Specify path for classification

5. **Click "Run"**

### Step 4: View Results

The algorithm produces:

1. **Rule Image** - Multi-band raster where each band shows similarity to one reference spectrum
   - Lower values = better match (for SAM, BC, ED, ID)
   - Each band corresponds to one class from your spectral library

2. **Classification Image** (if requested) - Single-band raster showing best-matching class for each pixel

### Step 5: Visualize Results

**For Rule Image:**
1. Load the output raster
2. Right-click → Properties → Symbology
3. Choose "Singleband gray" or "Singleband pseudocolor"
4. Switch between bands to see different class similarities

**For Classification Image:**
1. Load the classification raster
2. Right-click → Properties → Symbology
3. Choose "Paletted/Unique values"
4. Click "Classify" to see all classes

## Troubleshooting

### Plugin doesn't appear in menu

**Solution:**
1. Check Python console for errors:
   ```
   Plugins → Python Console
   ```
2. Look for error messages related to "hyperspectral_tools"
3. Verify all required files are in the plugins directory

### "Module not found" errors

**Solution:**
1. Ensure you have required Python packages:
   - numpy (included with QGIS)
   - scipy (usually included)
   - gdal (included with QGIS)

2. If scipy is missing, install it:
   ```
   OSGeo4W Shell (Windows):
   python -m pip install scipy
   
   Linux/Mac:
   pip3 install scipy
   ```

### SAM algorithm fails to run

**Possible issues:**

1. **Spectral library format incorrect**
   - Verify CSV format (comma-separated)
   - First line must be wavelengths
   - Following lines: class name, values

2. **Input image not recognized**
   - Try converting to GeoTIFF first
   - Ensure image has multiple bands

3. **Memory errors with large images**
   - Current version loads entire image into memory
   - For very large images (>2GB), consider:
     - Subsetting the image first
     - Processing in smaller tiles
     - Using a computer with more RAM

### Performance tips

- **Smaller images:** Process faster, use for testing
- **Fewer reference spectra:** Faster processing
- **SAM measure:** Generally fastest and most robust
- **Classification output:** Adds extra processing time (optional)

## Creating Your Own Spectral Library

### Format Requirements

```csv
wavelength,band1,band2,band3,...,bandN
ClassName1,value1,value2,value3,...,valueN
ClassName2,value1,value2,value3,...,valueN
```

### Tips:

1. **Wavelength units:** Typically nanometers (nm)
2. **Values:** Reflectance values (0.0 to 1.0 or 0 to 100)
3. **Number of bands:** Should match your image bands
4. **Class names:** No spaces (use underscores: `Green_Vegetation`)

### Example workflow:

1. Collect reference spectra from known areas in your image
2. Use QGIS's "Identify" tool to extract pixel values
3. Format into CSV file
4. Use in SAM analysis

## Next Steps

- Explore different similarity measures (BC, SID, ED, ID)
- Create custom spectral libraries for your study area
- Combine with other QGIS processing tools
- Check for plugin updates (more algorithms coming!)

## Getting Help

- **GitHub Issues:** Report bugs and request features
- **QGIS Community:** https://qgis.org/en/site/forusers/support.html
- **Original HyPy:** Contact Wim Bakker (bakker@itc.nl)

## What's Next?

Future algorithm implementations will include:
- PCA (Principal Component Analysis)
- Linear Spectral Unmixing
- Band Mathematics
- Spectral Filters
- Interactive Spectral Viewer
- And more!

---

**Happy Hyperspectral Analysis!** 🛰️📊
