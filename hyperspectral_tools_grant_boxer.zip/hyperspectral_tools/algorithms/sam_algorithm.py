"""
Spectral Angle Mapper (SAM) Algorithm for QGIS Processing

Ported from HyPy sam.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original Copyright (C) 2010-2022 Wim Bakker

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import os
import numpy as np
from osgeo import gdal, osr

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterFile,
    QgsProcessingParameterEnum,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingException,
    QgsRasterLayer,
    QgsMessageLog,
    Qgis
)

from ..core import (
    spectral_angle,
    bray_curtis_distance,
    spectral_information_divergence,
    euclidean_distance,
    intensity_difference
)


class SpectralAngleMapperAlgorithm(QgsProcessingAlgorithm):
    """
    Spectral Angle Mapper (SAM) Classification Algorithm
    
    SAM is a physically-based spectral classification that uses an n-dimensional
    angle to match pixels to reference spectra. The algorithm determines the
    spectral similarity between two spectra by calculating the angle between
    the spectra, treating them as vectors in a space with dimensionality equal
    to the number of bands.
    
    This implementation supports multiple spectral similarity measures:
    - SAM (Spectral Angle Mapper) - default
    - BC (Bray-Curtis Distance)
    - SID (Spectral Information Divergence)
    - ED (Euclidean Distance)
    - ID (Intensity Difference)
    """

    # Parameter names
    INPUT = 'INPUT'
    SPECLIB = 'SPECLIB'
    MODE = 'MODE'
    OUTPUT_RULES = 'OUTPUT_RULES'
    OUTPUT_CLASS = 'OUTPUT_CLASS'

    def initAlgorithm(self, config=None):
        """Define the inputs and outputs of the algorithm."""
        
        # Input hyperspectral image
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT,
                'Input Hyperspectral Image',
                optional=False
            )
        )
        
        # Spectral library file
        self.addParameter(
            QgsProcessingParameterFile(
                self.SPECLIB,
                'Spectral Library',
                behavior=QgsProcessingParameterFile.File,
                fileFilter='Spectral Library Files (*.sli *.hdr *.txt);;All Files (*.*)',
                optional=False
            )
        )
        
        # Similarity measure mode
        self.addParameter(
            QgsProcessingParameterEnum(
                self.MODE,
                'Similarity Measure',
                options=[
                    'SAM - Spectral Angle Mapper (recommended)',
                    'BC - Bray-Curtis Distance',
                    'SID - Spectral Information Divergence',
                    'ED - Euclidean Distance',
                    'ID - Intensity Difference'
                ],
                defaultValue=0,
                optional=False
            )
        )
        
        # Output rule image (continuous similarity values for each class)
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_RULES,
                'Output Rule Image',
                optional=False
            )
        )
        
        # Output classification image (discrete class assignments)
        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.OUTPUT_CLASS,
                'Output Classification Image (optional)',
                fileFilter='GeoTIFF (*.tif);;ENVI (*.bsq);;All Files (*.*)',
                optional=True
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """Execute the algorithm."""
        
        # Get parameters
        input_layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        speclib_path = self.parameterAsFile(parameters, self.SPECLIB, context)
        mode_idx = self.parameterAsEnum(parameters, self.MODE, context)
        output_rules_path = self.parameterAsOutputLayer(parameters, self.OUTPUT_RULES, context)
        output_class_path = self.parameterAsFileOutput(parameters, self.OUTPUT_CLASS, context)
        
        # Map mode index to function
        modes = ['SAM', 'BC', 'SID', 'ED', 'ID']
        mode = modes[mode_idx]
        
        distance_functions = {
            'SAM': spectral_angle,
            'BC': bray_curtis_distance,
            'SID': spectral_information_divergence,
            'ED': euclidean_distance,
            'ID': intensity_difference
        }
        
        diff_func = distance_functions[mode]
        
        feedback.pushInfo(f'Using {mode} similarity measure')
        
        # Open input raster
        input_ds = gdal.Open(input_layer.source(), gdal.GA_ReadOnly)
        if input_ds is None:
            raise QgsProcessingException(f'Failed to open input raster: {input_layer.source()}')
        
        # Get raster dimensions
        cols = input_ds.RasterXSize
        rows = input_ds.RasterYSize
        bands = input_ds.RasterCount
        
        feedback.pushInfo(f'Input image: {cols} x {rows} pixels, {bands} bands')
        
        # Read all bands into memory (for smaller images)
        # For large images, this should be done in chunks
        feedback.pushInfo('Reading input image...')
        image_data = np.zeros((rows, cols, bands), dtype=np.float32)
        
        for b in range(bands):
            if feedback.isCanceled():
                return {}
            
            band = input_ds.GetRasterBand(b + 1)
            image_data[:, :, b] = band.ReadAsArray()
            
            feedback.setProgress(int((b + 1) / bands * 20))  # 0-20% for reading
        
        # Load spectral library
        feedback.pushInfo(f'Loading spectral library: {speclib_path}')
        spectra, spec_names = self.load_spectral_library(speclib_path, feedback)
        
        if len(spectra) == 0:
            raise QgsProcessingException('No spectra found in spectral library')
        
        num_spectra = len(spectra)
        feedback.pushInfo(f'Loaded {num_spectra} reference spectra')
        
        # Create output rule image
        feedback.pushInfo('Creating output rule image...')
        driver = gdal.GetDriverByName('GTiff')
        rule_ds = driver.Create(
            output_rules_path,
            cols, rows, num_spectra,
            gdal.GDT_Float32
        )
        
        # Copy geotransform and projection
        rule_ds.SetGeoTransform(input_ds.GetGeoTransform())
        rule_ds.SetProjection(input_ds.GetProjection())
        
        # Process each reference spectrum
        for spec_idx, (spectrum, spec_name) in enumerate(zip(spectra, spec_names)):
            if feedback.isCanceled():
                return {}
            
            feedback.pushInfo(f'Processing spectrum {spec_idx + 1}/{num_spectra}: {spec_name}')
            
            # Create similarity map for this spectrum
            similarity_map = np.zeros((rows, cols), dtype=np.float32)
            
            # Process each pixel
            total_pixels = rows * cols
            for row in range(rows):
                if feedback.isCanceled():
                    return {}
                
                for col in range(cols):
                    pixel_spectrum = image_data[row, col, :]
                    similarity_map[row, col] = diff_func(pixel_spectrum, spectrum)
                
                # Update progress (20-100%)
                progress = 20 + int(((spec_idx * rows + row + 1) / (num_spectra * rows)) * 80)
                feedback.setProgress(progress)
            
            # Write this band to the output
            out_band = rule_ds.GetRasterBand(spec_idx + 1)
            out_band.WriteArray(similarity_map)
            out_band.SetDescription(spec_name)
            out_band.FlushCache()
        
        # Clean up
        rule_ds = None
        input_ds = None
        
        feedback.pushInfo('SAM analysis complete!')
        
        # If classification output is requested, create it
        if output_class_path:
            feedback.pushInfo('Creating classification image...')
            self.create_classification(output_rules_path, output_class_path, 
                                      spec_names, mode, feedback)
        
        return {self.OUTPUT_RULES: output_rules_path}

    def load_spectral_library(self, speclib_path, feedback):
        """
        Load spectral library from file.
        
        Supports simple text format with wavelengths and spectra.
        Format expected:
        - First line: wavelengths
        - Following lines: spectrum_name, values...
        
        For ENVI spectral library format (.sli), this needs to be expanded.
        """
        spectra = []
        spec_names = []
        
        try:
            with open(speclib_path, 'r') as f:
                lines = f.readlines()
                
                if len(lines) < 2:
                    raise QgsProcessingException('Spectral library file is too short')
                
                # First line should be wavelengths (for future use)
                # wavelengths = [float(x) for x in lines[0].strip().split(',')]
                
                # Read spectra
                for i, line in enumerate(lines[1:]):
                    parts = line.strip().split(',')
                    if len(parts) < 2:
                        continue
                    
                    spec_name = parts[0].strip()
                    try:
                        spectrum = np.array([float(x) for x in parts[1:]])
                        spectra.append(spectrum)
                        spec_names.append(spec_name)
                    except ValueError:
                        feedback.reportError(f'Skipping invalid spectrum at line {i+2}')
                        continue
        
        except Exception as e:
            raise QgsProcessingException(f'Failed to load spectral library: {str(e)}')
        
        return spectra, spec_names

    def create_classification(self, rules_path, output_path, class_names, mode, feedback):
        """
        Create classification image from rule image.
        
        Assigns each pixel to the class with minimum distance (for SAM, ED, etc.)
        or maximum similarity (depending on the measure).
        """
        feedback.pushInfo('Generating classification from rules...')
        
        # Open rule image
        rules_ds = gdal.Open(rules_path, gdal.GA_ReadOnly)
        cols = rules_ds.RasterXSize
        rows = rules_ds.RasterYSize
        num_classes = rules_ds.RasterCount
        
        # Read all rule bands
        rules_data = np.zeros((rows, cols, num_classes), dtype=np.float32)
        for b in range(num_classes):
            band = rules_ds.GetRasterBand(b + 1)
            rules_data[:, :, b] = band.ReadAsArray()
        
        # Find best class for each pixel (minimum distance for SAM, ED, BC, etc.)
        # Note: For some measures, we want minimum; for others, maximum
        reverse = mode in ['max']  # Adjust based on similarity measure
        
        if reverse:
            best_class = np.argmax(rules_data, axis=2) + 1  # +1 to reserve 0 for unclassified
        else:
            best_class = np.argmin(rules_data, axis=2) + 1
        
        # Create classification image
        driver = gdal.GetDriverByName('GTiff')
        class_ds = driver.Create(output_path, cols, rows, 1, gdal.GDT_Byte)
        class_ds.SetGeoTransform(rules_ds.GetGeoTransform())
        class_ds.SetProjection(rules_ds.GetProjection())
        
        # Write classification
        class_band = class_ds.GetRasterBand(1)
        class_band.WriteArray(best_class.astype(np.uint8))
        class_band.SetDescription('Classification')
        
        # Set class names as metadata
        class_band.SetCategoryNames(['Unclassified'] + class_names)
        
        class_band.FlushCache()
        class_ds = None
        rules_ds = None
        
        feedback.pushInfo(f'Classification saved to {output_path}')

    def name(self):
        """Algorithm name for use in the processing framework."""
        return 'sam'

    def displayName(self):
        """Human-readable algorithm name."""
        return 'Spectral Angle Mapper (SAM)'

    def group(self):
        """Group for the algorithm in the Processing toolbox."""
        return 'Classification'

    def groupId(self):
        """Group ID for the algorithm."""
        return 'classification'

    def shortHelpString(self):
        """Short help/description of the algorithm."""
        return """
        <b>Spectral Angle Mapper (SAM) Classification</b>
        
        <p>SAM is a physically-based spectral classification that uses an n-dimensional 
        angle to match pixels to reference spectra. The algorithm determines the 
        spectral similarity between two spectra by calculating the angle between 
        the spectra, treating them as vectors in a space with dimensionality equal 
        to the number of bands.</p>
        
        <p><b>Inputs:</b></p>
        <ul>
        <li><b>Input Hyperspectral Image:</b> Multi-band raster (typically >10 bands)</li>
        <li><b>Spectral Library:</b> Text file with reference spectra (CSV format)</li>
        <li><b>Similarity Measure:</b> Method for comparing spectra</li>
        </ul>
        
        <p><b>Outputs:</b></p>
        <ul>
        <li><b>Rule Image:</b> Multi-band raster with similarity values for each reference spectrum</li>
        <li><b>Classification Image (optional):</b> Single-band raster with class assignments</li>
        </ul>
        
        <p><b>Similarity Measures:</b></p>
        <ul>
        <li><b>SAM:</b> Spectral Angle Mapper (angle between spectra) - insensitive to illumination</li>
        <li><b>BC:</b> Bray-Curtis Distance</li>
        <li><b>SID:</b> Spectral Information Divergence</li>
        <li><b>ED:</b> Euclidean Distance</li>
        <li><b>ID:</b> Intensity Difference</li>
        </ul>
        
        <p><b>Reference:</b> Kruse et al. (1993) "The Spectral Image Processing System (SIPS)"</p>
        
        <p><i>Ported from HyPy by Wim Bakker, University of Twente</i></p>
        """

    def createInstance(self):
        """Create a new instance of the algorithm."""
        return SpectralAngleMapperAlgorithm()
