"""
Wavelength of Minimum Algorithm for QGIS Processing

Determines wavelength of absorption features and their characteristics.

Ported from HyPy minwavelength.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original Copyright (C) 2010-2022 Wim Bakker

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import numpy as np
from osgeo import gdal
from scipy.optimize import leastsq

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterEnum,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis
)

from ..core.convex_hull import hull_resampled


class WavelengthOfMinimumAlgorithm(QgsProcessingAlgorithm):
    """
    Wavelength of Minimum Algorithm
    
    Determines the wavelength position, depth, and shape characteristics of 
    absorption features in hyperspectral data. Uses convex hull removal to 
    isolate absorption features, then fits parabolas to find precise minimum 
    wavelengths and feature characteristics.
    
    Outputs include:
    - Minimum wavelength (band position)
    - Interpolated minimum wavelength (parabola fit)
    - Interpolated depth
    - Feature narrowness (parabola curvature)
    - Characteristics of up to 3 local minima
    """

    INPUT = 'INPUT'
    START_WAVELENGTH = 'START_WAVELENGTH'
    END_WAVELENGTH = 'END_WAVELENGTH'
    MODE = 'MODE'
    OUTPUT = 'OUTPUT'

    def initAlgorithm(self, config=None):
        """Define inputs and outputs."""
        
        # Input hyperspectral image
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT,
                'Input Hyperspectral Image',
                optional=False
            )
        )
        
        # Wavelength range
        self.addParameter(
            QgsProcessingParameterNumber(
                self.START_WAVELENGTH,
                'Start Wavelength (nm)',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=2000.0,
                optional=False
            )
        )
        
        self.addParameter(
            QgsProcessingParameterNumber(
                self.END_WAVELENGTH,
                'End Wavelength (nm)',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=2500.0,
                optional=False
            )
        )
        
        # Processing mode
        self.addParameter(
            QgsProcessingParameterEnum(
                self.MODE,
                'Continuum Removal Mode',
                options=[
                    'Division (recommended)',
                    'Subtraction',
                    'None (use original spectrum)'
                ],
                defaultValue=0,
                optional=False
            )
        )
        
        # Output
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                'Output Wavelength Features',
                optional=False
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """Execute the algorithm."""
        
        # Get parameters
        input_layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        start_wav = self.parameterAsDouble(parameters, self.START_WAVELENGTH, context)
        end_wav = self.parameterAsDouble(parameters, self.END_WAVELENGTH, context)
        mode_idx = self.parameterAsEnum(parameters, self.MODE, context)
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        
        modes = ['div', 'sub', 'none']
        mode = modes[mode_idx]
        
        feedback.pushInfo(f'Using {mode} continuum removal mode')
        feedback.pushInfo(f'Wavelength range: {start_wav} - {end_wav} nm')
        
        # Open input raster
        input_ds = gdal.Open(input_layer.source(), gdal.GA_ReadOnly)
        if input_ds is None:
            raise QgsProcessingException(f'Failed to open input raster')
        
        cols = input_ds.RasterXSize
        rows = input_ds.RasterYSize
        num_bands = input_ds.RasterCount
        
        # Get wavelengths from metadata if available
        wavelengths = self.get_wavelengths(input_ds, num_bands, feedback)
        
        if wavelengths is None:
            raise QgsProcessingException(
                'No wavelength information found. Image must have wavelength metadata.'
            )
        
        # Find band range
        start_band = self.wavelength_to_index(wavelengths, start_wav)
        end_band = self.wavelength_to_index(wavelengths, end_wav) + 1
        
        if start_band >= end_band:
            raise QgsProcessingException('Invalid wavelength range')
        
        wavs = wavelengths[start_band:end_band]
        feedback.pushInfo(f'Using bands {start_band} to {end_band-1} ({len(wavs)} bands)')
        
        # Read data
        feedback.pushInfo('Reading input data...')
        image_data = np.zeros((rows, cols, num_bands), dtype=np.float32)
        for b in range(num_bands):
            if feedback.isCanceled():
                return {}
            band = input_ds.GetRasterBand(b + 1)
            image_data[:, :, b] = band.ReadAsArray()
            feedback.setProgress(int((b + 1) / num_bands * 10))
        
        # Output band names
        band_names = [
            'minimum wavelength',
            'interpolated min. wav.',
            'interpolated depth',
            'interpolated narrowness',
            'wavelength of 1st local min',
            'depth of 1st local min',
            'int wav of local min 1',
            'int depth of local min 1',
            'int narrowness of local min 1',
            'wavelength of 2nd local min',
            'depth of 2nd local min',
            'int wav of local min 2',
            'int depth of local min 2',
            'int narrowness of local min 2',
            'wavelength of 3rd local min',
            'depth of 3rd local min',
            'int wav of local min 3',
            'int depth of local min 3',
            'int narrowness of local min 3'
        ]
        
        num_output_bands = len(band_names)
        
        # Create output
        feedback.pushInfo('Creating output raster...')
        driver = gdal.GetDriverByName('GTiff')
        output_ds = driver.Create(
            output_path,
            cols, rows, num_output_bands,
            gdal.GDT_Float32
        )
        
        output_ds.SetGeoTransform(input_ds.GetGeoTransform())
        output_ds.SetProjection(input_ds.GetProjection())
        
        # Set band descriptions
        for b, name in enumerate(band_names):
            band = output_ds.GetRasterBand(b + 1)
            band.SetDescription(name)
        
        # Process each pixel
        feedback.pushInfo('Processing pixels...')
        output_data = np.full((rows, cols, num_output_bands), np.nan, dtype=np.float32)
        
        total_pixels = rows * cols
        processed = 0
        
        for row in range(rows):
            if feedback.isCanceled():
                return {}
            
            for col in range(cols):
                spec = image_data[row, col, start_band:end_band]
                
                # Check if spectrum is valid
                if np.all(np.isfinite(spec)):
                    # Compute convex hull
                    points = np.column_stack((wavs, spec))
                    spec_hull = hull_resampled(points)[:, 1]
                    
                    # Apply continuum removal
                    if mode == 'div':
                        hull_removed = spec / spec_hull
                    elif mode == 'sub':
                        hull_removed = 1 + (spec - spec_hull)
                    else:
                        hull_removed = spec
                    
                    # Find minimum
                    min_idx = np.argmin(hull_removed)
                    min_wav = wavs[min_idx]
                    min_val = hull_removed[min_idx]
                    
                    # Store minimum wavelength
                    output_data[row, col, 0] = min_wav
                    
                    # Fit parabola for interpolation
                    if min_idx > 0 and min_idx < len(wavs) - 1:
                        x = np.array([wavs[min_idx-1], min_wav, wavs[min_idx+1]])
                        y = np.array([hull_removed[min_idx-1], min_val, hull_removed[min_idx+1]])
                        
                        try:
                            (zx, zy), (a, b, c) = self.fit_parabola(x, y)
                            output_data[row, col, 1] = zx  # interpolated wavelength
                            output_data[row, col, 2] = 1 - zy  # interpolated depth
                            output_data[row, col, 3] = a  # narrowness (curvature)
                        except:
                            output_data[row, col, 1] = min_wav
                            output_data[row, col, 2] = 1 - min_val
                            output_data[row, col, 3] = 0
                    else:
                        output_data[row, col, 1] = min_wav
                        output_data[row, col, 2] = 1 - min_val
                        output_data[row, col, 3] = 0
                    
                    # Find local minima
                    local_mins = self.find_local_minima(hull_removed, wavs)
                    
                    # Store up to 3 local minima
                    band_idx = 4
                    for i, (val, wav, idx) in enumerate(local_mins[:3]):
                        output_data[row, col, band_idx] = wav
                        band_idx += 1
                        output_data[row, col, band_idx] = 1 - val
                        band_idx += 1
                        
                        # Interpolate local minimum
                        if idx > 0 and idx < len(wavs) - 1:
                            x = np.array([wavs[idx-1], wav, wavs[idx+1]])
                            y = np.array([hull_removed[idx-1], val, hull_removed[idx+1]])
                            try:
                                (zx, zy), (a, b, c) = self.fit_parabola(x, y)
                                output_data[row, col, band_idx] = zx
                                band_idx += 1
                                output_data[row, col, band_idx] = 1 - zy
                                band_idx += 1
                                output_data[row, col, band_idx] = a
                                band_idx += 1
                            except:
                                band_idx += 3
                
                processed += 1
                if processed % 1000 == 0:
                    progress = 10 + int((processed / total_pixels) * 90)
                    feedback.setProgress(progress)
        
        # Write output bands
        feedback.pushInfo('Writing output...')
        for b in range(num_output_bands):
            if feedback.isCanceled():
                return {}
            band = output_ds.GetRasterBand(b + 1)
            band.WriteArray(output_data[:, :, b])
            band.FlushCache()
        
        # Cleanup
        output_ds = None
        input_ds = None
        
        feedback.pushInfo('Complete!')
        
        return {self.OUTPUT: output_path}

    def get_wavelengths(self, dataset, num_bands, feedback):
        """Extract wavelength information from dataset metadata."""
        
        # Try ENVI metadata first
        metadata = dataset.GetMetadata('ENVI')
        if metadata and 'wavelength' in metadata:
            wl_str = metadata['wavelength']
            # Remove curly braces if present
            wl_str = wl_str.strip('{}')
            try:
                wavelengths = np.array([float(w.strip()) for w in wl_str.split(',')])
                if len(wavelengths) == num_bands:
                    feedback.pushInfo(f'Found {len(wavelengths)} wavelengths in ENVI metadata')
                    return wavelengths
            except:
                pass
        
        # Try band descriptions
        wavelengths = []
        for b in range(num_bands):
            band = dataset.GetRasterBand(b + 1)
            desc = band.GetDescription()
            try:
                # Try to extract number from description
                wav = float(desc)
                wavelengths.append(wav)
            except:
                wavelengths.append(None)
        
        if None not in wavelengths and len(wavelengths) == num_bands:
            feedback.pushInfo(f'Found wavelengths in band descriptions')
            return np.array(wavelengths)
        
        # Fallback: create sequential band numbers
        feedback.reportError('No wavelength metadata found. Using band numbers.')
        return None

    def wavelength_to_index(self, wavelengths, target_wavelength):
        """Find band index closest to target wavelength."""
        return np.argmin(np.abs(wavelengths - target_wavelength))

    def fit_parabola(self, x, y):
        """
        Fit a parabola to three points and find the minimum.
        
        Returns:
            ((min_x, min_y), (a, b, c)) - minimum point and parabola coefficients
        """
        def model(params, x):
            a, b, c = params
            return a * x * x + b * x + c
        
        def residuals(p, y, x):
            return y - model(p, x)
        
        params = leastsq(residuals, [1, 1, 1], args=(y, x))[0]
        a, b, c = params
        
        # Find minimum of parabola
        zx = -b / (2 * a)
        zy = model(params, zx)
        
        return ((zx, zy), (a, b, c))

    def find_local_minima(self, y, x):
        """
        Find local minima in a 1D array.
        
        Returns:
            List of (value, wavelength, index) tuples, sorted by value
        """
        result = []
        for i in range(1, len(y) - 1):
            if y[i] < y[i-1] and y[i] < y[i+1]:
                result.append((y[i], x[i], i))
        return sorted(result)

    def name(self):
        return 'wavelength_of_minimum'

    def displayName(self):
        return 'Wavelength of Minimum'

    def group(self):
        return 'Spectral Analysis'

    def groupId(self):
        return 'spectral_analysis'

    def shortHelpString(self):
        return """
        <b>Wavelength of Minimum</b>
        
        <p>Determines the wavelength position, depth, and shape characteristics of 
        absorption features in hyperspectral data.</p>
        
        <p><b>Process:</b></p>
        <ol>
        <li>Applies convex hull removal to isolate absorption features</li>
        <li>Finds minimum wavelength in the specified range</li>
        <li>Fits parabola to refine minimum position and calculate depth</li>
        <li>Identifies up to 3 local minima with their characteristics</li>
        </ol>
        
        <p><b>Inputs:</b></p>
        <ul>
        <li><b>Input Image:</b> Hyperspectral image with wavelength metadata</li>
        <li><b>Start/End Wavelength:</b> Analysis range (e.g., 2000-2500 nm for minerals)</li>
        <li><b>Mode:</b> Continuum removal method
            <ul>
            <li><b>Division:</b> Divide by hull (recommended, preserves shape)</li>
            <li><b>Subtraction:</b> Subtract hull (additive features)</li>
            <li><b>None:</b> Use original spectrum (no continuum removal)</li>
            </ul>
        </li>
        </ul>
        
        <p><b>Outputs (19 bands):</b></p>
        <ul>
        <li>Band 1: Minimum wavelength (band position)</li>
        <li>Band 2: Interpolated minimum wavelength (parabola fit)</li>
        <li>Band 3: Interpolated depth</li>
        <li>Band 4: Feature narrowness (parabola curvature, higher = narrower)</li>
        <li>Bands 5-19: Characteristics of 1st, 2nd, and 3rd local minima</li>
        </ul>
        
        <p><b>Applications:</b></p>
        <ul>
        <li>Mineral identification (absorption positions)</li>
        <li>Vegetation stress detection (chlorophyll absorption)</li>
        <li>Water content mapping (2000-2500 nm range)</li>
        <li>Material classification</li>
        </ul>
        
        <p><b>Tips:</b></p>
        <ul>
        <li>Use Band 2 (interpolated wavelength) for most accurate feature position</li>
        <li>Use Band 3 (depth) to map feature strength</li>
        <li>Combine wavelength and depth for mapping (see Wavelength Mapping tool)</li>
        </ul>
        
        <p><i>Ported from HyPy by Wim Bakker, University of Twente</i></p>
        """

    def createInstance(self):
        return WavelengthOfMinimumAlgorithm()
