# Hyperspectral Analysis Tools for QGIS

A comprehensive QGIS plugin for hyperspectral image analysis, ported from the HyPy (Hyperspectral Python) toolkit.

## About

This plugin brings advanced hyperspectral image analysis capabilities to QGIS, originally developed as HyPy by **Wim Bakker** at the **University of Twente, Faculty ITC**.

### Original HyPy Credits
- **Author:** Wim Bakker
- **Institution:** University of Twente, Faculty ITC
- **Contact:** bakker@itc.nl
- **Location:** Hengelosestraat 99, 7514 AE Enschede, Netherlands
- **License:** GPL v3

## Features

### Currently Available:
- **Spectral Angle Mapper (SAM)** - Spectral classification algorithm
  - Multiple similarity measures (SAM, Bray-Curtis, SID, Euclidean, Intensity Difference)
  - Works with spectral libraries
  - Generates both rule images and classification maps
  
- **Wavelength of Minimum** - Absorption feature analysis
  - Finds wavelength position of absorption features
  - Calculates feature depth and narrowness
  - Identifies up to 3 local minima
  - Essential for mineral identification
  
- **Wavelength Mapping** - Feature visualization
  - Creates color-coded RGB maps from wavelength features
  - Hue represents wavelength, brightness represents depth
  - Intuitive visualization of absorption features
  - Perfect for mineral and material mapping

### Coming Soon:
- Principal Component Analysis (PCA)
- Linear Spectral Unmixing
- Band Mathematics and Ratios
- Spectral Filters (Median, Gradient, Edge)
- Convex Hull Removal
- Preprocessing Tools (Destriping, Normalization)
- Spectral Library Viewer (Interactive GUI)
- Interactive Spectral Display
- Mars/Planetary Science Tools

## Installation

### From ZIP File:
1. Download the plugin ZIP file
2. In QGIS, go to **Plugins → Manage and Install Plugins**
3. Click **Install from ZIP**
4. Select the downloaded ZIP file
5. Click **Install Plugin**

### Manual Installation:
1. Extract the plugin to your QGIS plugins directory:
   - **Windows:** `C:\Users\YourName\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`
   - **Linux:** `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
   - **macOS:** `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`

2. Restart QGIS
3. Enable the plugin in **Plugins → Manage and Install Plugins**

## Usage

### Spectral Angle Mapper (SAM)

1. Open QGIS Processing Toolbox (**Processing → Toolbox**)
2. Navigate to **Hyperspectral Tools → Classification → Spectral Angle Mapper (SAM)**
3. Configure parameters:
   - **Input Hyperspectral Image:** Your multi-band raster
   - **Spectral Library:** CSV file with reference spectra
   - **Similarity Measure:** Choose from SAM, BC, SID, ED, or ID
   - **Output Rule Image:** Path for similarity values output
   - **Output Classification Image (optional):** Path for classified output

4. Click **Run**

### Spectral Library Format

The spectral library should be a CSV file with the following format:

```csv
wavelength,400,450,500,550,600,650,700
Vegetation,0.05,0.04,0.06,0.25,0.30,0.40,0.45
Water,0.02,0.015,0.01,0.008,0.005,0.003,0.002
Soil,0.15,0.18,0.20,0.22,0.25,0.27,0.28
```

- **First line:** Wavelengths in nanometers
- **Following lines:** Class name, followed by reflectance values

## Requirements

- QGIS 3.16 or higher
- Python packages (usually included with QGIS):
  - numpy
  - scipy
  - gdal

## Development

### Project Structure

```
hyperspectral_tools/
├── __init__.py                 # Plugin initialization
├── metadata.txt               # Plugin metadata
├── hyperspectral_plugin.py    # Main plugin class
├── hyppy_provider.py          # Processing provider
├── algorithms/                # Processing algorithms
│   ├── __init__.py
│   └── sam_algorithm.py       # SAM implementation
├── core/                      # Core spectral functions
│   └── __init__.py            # Spectral math library
├── ui/                        # Future: Custom UI widgets
└── resources/                 # Icons and resources
```

### Adding New Algorithms

To add a new algorithm from HyPy:

1. Create a new file in `algorithms/` (e.g., `pca_algorithm.py`)
2. Implement a class inheriting from `QgsProcessingAlgorithm`
3. Import and register it in `hyppy_provider.py`
4. Port the core logic from the corresponding HyPy module

Example template:

```python
from qgis.core import QgsProcessingAlgorithm

class MyAlgorithm(QgsProcessingAlgorithm):
    def initAlgorithm(self, config=None):
        # Define parameters
        pass
    
    def processAlgorithm(self, parameters, context, feedback):
        # Implement algorithm
        pass
    
    def name(self):
        return 'my_algorithm'
    
    def displayName(self):
        return 'My Algorithm'
    
    def createInstance(self):
        return MyAlgorithm()
```

## Contributing

Contributions are welcome! This is an open-source port of HyPy to QGIS.

### How to Contribute:
1. Fork the repository
2. Create a feature branch
3. Port an algorithm from HyPy
4. Test thoroughly
5. Submit a pull request

### Priority Algorithms to Port:
- [ ] PCA (Principal Component Analysis)
- [ ] Linear Spectral Unmixing
- [ ] Band Math
- [ ] Convex Hull Removal
- [ ] Spectral Filters
- [ ] Normalization
- [ ] Destriping

## License

This program is free software: you can redistribute it and/or modify it under the terms of the **GNU General Public License** as published by the Free Software Foundation, either **version 3** of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but **WITHOUT ANY WARRANTY**; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

## Acknowledgments

- **Original HyPy Development:** Wim Bakker, University of Twente
- **QGIS Port:** Grant Boxer (boxerg@iinet.net.au)
- **Community Contributors:** [List contributors]

## Support

- **Issues:** Report bugs and request features on GitHub
- **Original HyPy:** Contact Wim Bakker at bakker@itc.nl
- **QGIS Plugin:** Contact Grant Boxer at boxerg@iinet.net.au

## References

### SAM (Spectral Angle Mapper):
- Kruse, F. A., et al. (1993). "The Spectral Image Processing System (SIPS)—Interactive Visualization and Analysis of Imaging Spectrometer Data." *Remote Sensing of Environment*, 44, 145-163.

### Hyperspectral Analysis:
- For more background on hyperspectral analysis techniques, refer to the original HyPy documentation and academic literature on imaging spectroscopy.

---

**Made with ❤️ for the hyperspectral remote sensing community**
