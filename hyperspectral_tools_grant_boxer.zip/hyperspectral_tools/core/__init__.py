"""
Core Spectral Mathematics Functions

Ported from HyPy spectrum.py and envi2.spectral modules
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original Copyright (C) 2010-2022 Wim Bakker

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import numpy as np


def spectral_angle(spectrum1, spectrum2):
    """
    Calculate Spectral Angle Mapper (SAM) between two spectra.
    
    SAM measures the spectral similarity by calculating the angle between
    two spectra treated as vectors in n-dimensional space.
    
    Args:
        spectrum1: numpy array of spectral values
        spectrum2: numpy array of spectral values (same length as spectrum1)
    
    Returns:
        float: Spectral angle in radians (0 = identical, π/2 = orthogonal)
    
    Reference:
        Kruse et al. (1993) "The Spectral Image Processing System (SIPS)"
    """
    # Remove any NaN values
    mask = ~(np.isnan(spectrum1) | np.isnan(spectrum2))
    s1 = spectrum1[mask]
    s2 = spectrum2[mask]
    
    if len(s1) == 0:
        return np.nan
    
    # Normalize vectors
    norm1 = np.linalg.norm(s1)
    norm2 = np.linalg.norm(s2)
    
    if norm1 == 0 or norm2 == 0:
        return np.nan
    
    # Calculate cosine of angle
    cos_angle = np.dot(s1, s2) / (norm1 * norm2)
    
    # Clip to valid range [-1, 1] to handle floating point errors
    cos_angle = np.clip(cos_angle, -1.0, 1.0)
    
    # Return angle in radians
    return np.arccos(cos_angle)


def euclidean_distance(spectrum1, spectrum2):
    """
    Calculate Euclidean distance between two spectra.
    
    Args:
        spectrum1: numpy array of spectral values
        spectrum2: numpy array of spectral values
    
    Returns:
        float: Euclidean distance
    """
    mask = ~(np.isnan(spectrum1) | np.isnan(spectrum2))
    s1 = spectrum1[mask]
    s2 = spectrum2[mask]
    
    if len(s1) == 0:
        return np.nan
    
    return np.linalg.norm(s1 - s2)


def bray_curtis_distance(spectrum1, spectrum2):
    """
    Calculate Bray-Curtis distance between two spectra.
    
    The Bray-Curtis distance is a statistic used to quantify compositional
    dissimilarity between two samples.
    
    Args:
        spectrum1: numpy array of spectral values
        spectrum2: numpy array of spectral values
    
    Returns:
        float: Bray-Curtis distance [0, 1]
    """
    mask = ~(np.isnan(spectrum1) | np.isnan(spectrum2))
    s1 = spectrum1[mask]
    s2 = spectrum2[mask]
    
    if len(s1) == 0:
        return np.nan
    
    numerator = np.sum(np.abs(s1 - s2))
    denominator = np.sum(np.abs(s1 + s2))
    
    if denominator == 0:
        return np.nan
    
    return numerator / denominator


def spectral_information_divergence(spectrum1, spectrum2):
    """
    Calculate Spectral Information Divergence (SID) between two spectra.
    
    SID measures the divergence between probability distributions derived
    from spectral data.
    
    Args:
        spectrum1: numpy array of spectral values
        spectrum2: numpy array of spectral values
    
    Returns:
        float: Spectral information divergence
    
    Reference:
        Chang (2000) "An information-theoretic approach to spectral variability"
    """
    mask = ~(np.isnan(spectrum1) | np.isnan(spectrum2))
    s1 = spectrum1[mask]
    s2 = spectrum2[mask]
    
    if len(s1) == 0 or np.any(s1 < 0) or np.any(s2 < 0):
        return np.nan
    
    # Convert to probability distributions
    p1 = s1 / np.sum(s1) if np.sum(s1) > 0 else s1
    p2 = s2 / np.sum(s2) if np.sum(s2) > 0 else s2
    
    # Avoid division by zero
    epsilon = 1e-10
    p1 = np.maximum(p1, epsilon)
    p2 = np.maximum(p2, epsilon)
    
    # Calculate SID
    sid = np.sum(p1 * np.log(p1 / p2)) + np.sum(p2 * np.log(p2 / p1))
    
    return sid


def intensity_difference(spectrum1, spectrum2):
    """
    Calculate intensity difference between two spectra.
    
    Simple sum of absolute differences.
    
    Args:
        spectrum1: numpy array of spectral values
        spectrum2: numpy array of spectral values
    
    Returns:
        float: Sum of absolute differences
    """
    mask = ~(np.isnan(spectrum1) | np.isnan(spectrum2))
    s1 = spectrum1[mask]
    s2 = spectrum2[mask]
    
    if len(s1) == 0:
        return np.nan
    
    return np.sum(np.abs(s1 - s2))


def normalize_spectrum(spectrum):
    """
    Normalize a spectrum to unit length (L2 normalization).
    
    Args:
        spectrum: numpy array of spectral values
    
    Returns:
        numpy array: Normalized spectrum
    """
    mask = ~np.isnan(spectrum)
    if not np.any(mask):
        return spectrum
    
    norm = np.linalg.norm(spectrum[mask])
    if norm == 0:
        return spectrum
    
    result = spectrum.copy()
    result[mask] = spectrum[mask] / norm
    return result


def resample_spectrum(spectrum, old_wavelengths, new_wavelengths, method='linear'):
    """
    Resample a spectrum to new wavelengths.
    
    Args:
        spectrum: numpy array of spectral values
        old_wavelengths: numpy array of original wavelengths
        new_wavelengths: numpy array of target wavelengths
        method: interpolation method ('linear', 'cubic', etc.)
    
    Returns:
        numpy array: Resampled spectrum
    """
    from scipy.interpolate import interp1d
    
    # Remove NaN values
    mask = ~np.isnan(spectrum)
    if not np.any(mask):
        return np.full(len(new_wavelengths), np.nan)
    
    clean_wl = old_wavelengths[mask]
    clean_spec = spectrum[mask]
    
    # Create interpolation function
    f = interp1d(clean_wl, clean_spec, kind=method, 
                 bounds_error=False, fill_value=np.nan)
    
    return f(new_wavelengths)
