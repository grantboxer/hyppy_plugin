"""
Spectra Math Algorithm for QGIS Processing

Applies a per-pixel spectral expression to one or more input images.
Each pixel spectrum is available as S1, S2, ... in the expression.
Spectra objects expose .spectrum (1-D array) and .wavelength (1-D array).

Ported from HyPy specmath.py / tkSpecMath.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original Copyright (C) 2010-2022 Wim Bakker

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterString,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis
)


# ── spectrum helper ────────────────────────────────────────────────────────────

class Spectrum:
    """
    Simple spectrum container compatible with HyPy specmath expressions.

    Attributes:
        spectrum   (np.ndarray) : 1-D reflectance / value array
        wavelength (np.ndarray) : 1-D wavelength array (or index array)

    Supports element-wise arithmetic with scalars and other Spectrum objects.
    """

    def __init__(self, spectrum, wavelength=None):
        self.spectrum = np.asarray(spectrum, dtype=np.float64)
        if wavelength is not None:
            self.wavelength = np.asarray(wavelength, dtype=np.float64)
        else:
            self.wavelength = np.arange(len(self.spectrum), dtype=np.float64)

    # ── arithmetic ──
    def _binop(self, other, op):
        if isinstance(other, Spectrum):
            return Spectrum(op(self.spectrum, other.spectrum), self.wavelength)
        return Spectrum(op(self.spectrum, other), self.wavelength)

    def __add__(self, other): return self._binop(other, lambda a, b: a + b)
    def __radd__(self, other): return self._binop(other, lambda a, b: b + a)
    def __sub__(self, other): return self._binop(other, lambda a, b: a - b)
    def __rsub__(self, other): return self._binop(other, lambda a, b: b - a)
    def __mul__(self, other): return self._binop(other, lambda a, b: a * b)
    def __rmul__(self, other): return self._binop(other, lambda a, b: b * a)
    def __truediv__(self, other): return self._binop(other, lambda a, b: a / b)
    def __rtruediv__(self, other): return self._binop(other, lambda a, b: b / a)
    def __pow__(self, other): return self._binop(other, lambda a, b: a ** b)
    def __neg__(self): return Spectrum(-self.spectrum, self.wavelength)
    def __abs__(self): return Spectrum(np.abs(self.spectrum), self.wavelength)

    # ── slicing / indexing ──
    def __len__(self): return len(self.spectrum)
    def __getitem__(self, idx): return self.spectrum[idx]

    # ── numpy ufunc support ──
    def __array__(self, dtype=None):
        return self.spectrum if dtype is None else self.spectrum.astype(dtype)

    def __array_ufunc__(self, ufunc, method, *inputs, **kwargs):
        new_inputs = [x.spectrum if isinstance(x, Spectrum) else x for x in inputs]
        result = getattr(ufunc, method)(*new_inputs, **kwargs)
        wav = next((x.wavelength for x in inputs if isinstance(x, Spectrum)), None)
        return Spectrum(result, wav)

    def wavelength2index(self, w):
        return int(np.argmin(np.abs(self.wavelength - w)))

    def __repr__(self):
        return f'Spectrum(bands={len(self.spectrum)}, wav=[{self.wavelength[0]:.1f}…{self.wavelength[-1]:.1f}])'


# ── algorithm ──────────────────────────────────────────────────────────────────

class SpectraMathAlgorithm(QgsProcessingAlgorithm):
    """
    Spectra Math Algorithm

    For every pixel, builds a Spectrum object from each input image
    (S1, S2, ...) and evaluates the user-supplied expression.
    The result (another Spectrum or a scalar) is written to the output raster.

    Spectrum attributes available in expressions:
        S1.spectrum     - 1-D float64 array of band values
        S1.wavelength   - 1-D float64 wavelength array
        S1[n]           - value at band index n (0-based)
        S1.wavelength2index(w) - nearest band index for wavelength w

    Standard NumPy ufuncs work directly on Spectrum objects (sqrt, log, abs, ...).
    Arithmetic between Spectrum objects operates element-wise on .spectrum.

    Examples:
        Continuum-normalised:
            from numpy import ...  # functions are pre-imported
            S1 / Spectrum(np.interp(S1.wavelength, [S1.wavelength[0], S1.wavelength[-1]],
                                    [S1.spectrum[0], S1.spectrum[-1]]), S1.wavelength)

        Simple reflectance ratio per pixel:
            Spectrum(S1.spectrum / S2.spectrum, S1.wavelength)

        Log spectrum:
            Spectrum(np.log(S1.spectrum), S1.wavelength)

        Sum of two spectra:
            S1 + S2
    """

    INPUT_LAYERS = 'INPUT_LAYERS'
    EXPRESSION = 'EXPRESSION'
    MASK_LAYER = 'MASK_LAYER'
    OUTPUT = 'OUTPUT'

    def initAlgorithm(self, config=None):
        """Define inputs and outputs."""

        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT_LAYERS,
                'Input Raster Layer(s)  (S1, S2, ... in expression)',
                layerType=QgsProcessing.TypeRaster,
                optional=False
            )
        )

        self.addParameter(
            QgsProcessingParameterString(
                self.EXPRESSION,
                'Spectra Math Expression (Python/NumPy)',
                defaultValue='S1 + S2',
                multiLine=True,
                optional=False
            )
        )

        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.MASK_LAYER,
                'Mask Layer (optional – only non-zero pixels are processed)',
                optional=True
            )
        )

        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                'Output Spectra Math Image'
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """Execute the spectra math algorithm."""

        layers = self.parameterAsLayerList(parameters, self.INPUT_LAYERS, context)
        expression = self.parameterAsString(parameters, self.EXPRESSION, context).strip()
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        mask_layer = self.parameterAsRasterLayer(parameters, self.MASK_LAYER, context)

        if not layers:
            raise QgsProcessingException('No input layers provided')
        if not expression:
            raise QgsProcessingException('No expression provided')

        feedback.pushInfo(f'Expression: {expression}')
        feedback.pushInfo(f'Input layers: {len(layers)}')

        # Open all datasets
        ds_list = []
        wavelengths_list = []
        nodatas = []

        for layer in layers[:20]:
            ds = gdal.Open(layer.source())
            if ds is None:
                raise QgsProcessingException(f'Cannot open raster: {layer.source()}')
            ds_list.append(ds)
            wavelengths_list.append(self._get_wavelengths(ds, ds.RasterCount))
            nodatas.append(ds.GetRasterBand(1).GetNoDataValue())

        ref_ds = ds_list[0]
        n_rows = ref_ds.RasterYSize
        n_cols = ref_ds.RasterXSize
        n_bands_in = ref_ds.RasterCount

        # Pre-load all bands into memory as float32 to save RAM
        feedback.pushInfo('Loading input bands into memory...')
        all_data = []
        for k, ds in enumerate(ds_list):
            arr = np.zeros((ds.RasterCount, n_rows, n_cols), dtype=np.float32)
            for b in range(ds.RasterCount):
                band_arr = ds.GetRasterBand(b + 1).ReadAsArray().astype(np.float32)
                if nodatas[k] is not None:
                    band_arr[band_arr == nodatas[k]] = np.nan
                arr[b] = band_arr
            all_data.append(arr)

        # Load mask if provided
        mask_arr = None
        if mask_layer is not None:
            mask_ds = gdal.Open(mask_layer.source())
            if mask_ds is not None:
                mask_arr = mask_ds.GetRasterBand(1).ReadAsArray()
                del mask_ds

        # Trial evaluation on first pixel to determine output shape
        def make_spectrum(k, j, i):
            spec = all_data[k][:, j, i].astype(np.float64)
            wav = wavelengths_list[k] if wavelengths_list[k] is not None else np.arange(len(spec), dtype=np.float64)
            return Spectrum(spec, wav)

        # Build namespace for eval
        _np_funcs = {
            name: getattr(np, name) for name in [
                'sqrt', 'log', 'log2', 'log10', 'exp',
                'sin', 'cos', 'tan', 'arcsin', 'arccos', 'arctan', 'arctan2',
                'abs', 'minimum', 'maximum', 'clip', 'where',
                'isnan', 'isinf', 'nan', 'inf', 'pi',
                'zeros', 'ones', 'array', 'linspace', 'arange', 'interp'
            ]
        }
        _np_funcs['np'] = np
        _np_funcs['Spectrum'] = Spectrum

        def build_namespace(j, i):
            ns = dict(_np_funcs)
            for k in range(len(ds_list)):
                ns[f'S{k+1}'] = make_spectrum(k, j, i)
            return ns

        # Trial run
        trial_ns = build_namespace(0, 0)
        old_settings = np.seterr(all='ignore')
        try:
            trial_result = eval(expression, {"__builtins__": {}}, trial_ns)
        except Exception as exc:
            np.seterr(**old_settings)
            raise QgsProcessingException(f'Expression evaluation failed on trial pixel: {exc}')

        if isinstance(trial_result, Spectrum):
            n_out_bands = len(trial_result)
            out_wavelengths = trial_result.wavelength
        elif np.ndim(trial_result) == 1:
            n_out_bands = len(trial_result)
            out_wavelengths = None
        elif np.ndim(trial_result) == 0:
            n_out_bands = 1
            out_wavelengths = None
        else:
            np.seterr(**old_settings)
            raise QgsProcessingException(
                'Expression must return a Spectrum, 1-D array, or scalar per pixel.'
            )

        feedback.pushInfo(f'Output bands per pixel: {n_out_bands}')

        # Create output
        driver = gdal.GetDriverByName('GTiff')
        out_ds = driver.Create(output_path, n_cols, n_rows, n_out_bands, gdal.GDT_Float64)
        out_ds.SetGeoTransform(ref_ds.GetGeoTransform())
        out_ds.SetProjection(ref_ds.GetProjection())

        # Pre-allocate output buffer (bands × rows × cols)
        out_data = np.full((n_out_bands, n_rows, n_cols), np.nan, dtype=np.float64)

        step = max(1, n_rows // 100)
        for j in range(n_rows):
            if feedback.isCanceled():
                break
            if j % step == 0:
                feedback.setProgress(int(j * 100 / n_rows))

            for i in range(n_cols):
                if mask_arr is not None and not mask_arr[j, i]:
                    continue

                ns = build_namespace(j, i)
                try:
                    res = eval(expression, {"__builtins__": {}}, ns)
                    if isinstance(res, Spectrum):
                        res = res.spectrum
                    arr = np.atleast_1d(np.asarray(res, dtype=np.float64)).flatten()
                    n = min(len(arr), n_out_bands)
                    out_data[:n, j, i] = arr[:n]
                except Exception:
                    pass  # leave as NaN

        np.seterr(**old_settings)

        # Write bands
        for b in range(n_out_bands):
            out_band = out_ds.GetRasterBand(b + 1)
            out_band.WriteArray(out_data[b])
            out_band.SetNoDataValue(np.nan)
            if out_wavelengths is not None and b < len(out_wavelengths):
                out_band.SetDescription(f'{out_wavelengths[b]:.2f} nm')

        # Metadata
        meta = {'spectra_math_expression': expression}
        if out_wavelengths is not None:
            meta['wavelength'] = '{' + ', '.join([f'{w:.4f}' for w in out_wavelengths]) + '}'
            meta['wavelength_units'] = 'Nanometers'
        out_ds.SetMetadata(meta)
        out_ds.FlushCache()

        for ds in ds_list:
            del ds
        del out_ds

        feedback.pushInfo('Spectra math completed successfully.')
        return {self.OUTPUT: output_path}

    def _get_wavelengths(self, ds, n_bands):
        """Extract wavelength array from GDAL ENVI metadata or band descriptions."""
        # Try ENVI metadata domain first (works for ENVI-format rasters)
        metadata = ds.GetMetadata('ENVI')
        if metadata:
            for key in ['wavelength', 'Wavelength', 'WAVELENGTH']:
                if key in metadata:
                    wav_str = metadata[key].strip('{}').strip()
                    try:
                        wavs = [float(w.strip()) for w in wav_str.split(',') if w.strip()]
                        if len(wavs) >= n_bands:
                            return np.array(wavs[:n_bands])
                        elif len(wavs) > 0:
                            return np.array(wavs)
                    except ValueError:
                        pass
        # Fallback: default metadata domain
        metadata = ds.GetMetadata()
        for key in ['wavelength', 'Wavelength', 'WAVELENGTH']:
            if key in metadata:
                wav_str = metadata[key].strip('{}').strip()
                try:
                    wavs = [float(w.strip()) for w in wav_str.split(',') if w.strip()]
                    if len(wavs) >= n_bands:
                        return np.array(wavs[:n_bands])
                    elif len(wavs) > 0:
                        return np.array(wavs)
                except ValueError:
                    pass
        # Fallback: band descriptions (numeric wavelength values)
        wavs = []
        for b in range(n_bands):
            band = ds.GetRasterBand(b + 1)
            desc = band.GetDescription()
            try:
                wavs.append(float(desc))
            except (ValueError, TypeError):
                wavs.append(None)
        if None not in wavs and len(wavs) == n_bands:
            return np.array(wavs, dtype=float)
        return None
    def name(self):
        return 'spectramath'

    def displayName(self):
        return 'Spectra Math'

    def group(self):
        return 'Spectral Processing'

    def groupId(self):
        return 'spectralprocessing'

    def shortHelpString(self):
        return (
            'Applies a per-pixel spectral expression to one or more input images.\n\n'
            'Each input pixel spectrum is available as S1, S2, ... in the expression.\n\n'
            'Spectrum attributes:\n'
            '  S1.spectrum    - 1-D float64 array of band values\n'
            '  S1.wavelength  - 1-D wavelength array\n'
            '  S1[n]          - value at band index n (0-based)\n'
            '  S1.wavelength2index(w) - nearest band index for wavelength w\n\n'
            'Standard NumPy ufuncs (sqrt, log, abs, …) work directly on Spectrum objects.\n'
            'Arithmetic between Spectrum objects is element-wise.\n\n'
            'The expression must return a Spectrum, 1-D array, or scalar for each pixel.\n'
            'Output bands = length of the returned spectrum/array.\n\n'
            'Examples:\n'
            '  Sum of two spectra:   S1 + S2\n'
            '  Ratio spectra:        Spectrum(S1.spectrum / S2.spectrum, S1.wavelength)\n'
            '  Log spectrum:         Spectrum(np.log(S1.spectrum), S1.wavelength)\n'
        )

    def createInstance(self):
        return SpectraMathAlgorithm()
