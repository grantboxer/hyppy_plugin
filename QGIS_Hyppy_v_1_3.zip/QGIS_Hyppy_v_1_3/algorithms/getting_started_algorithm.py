"""
Getting Started / Workflow Guide for the HyPpy QGIS Plugin.

Displays the recommended workflow and data requirements for using
the HyPpy decision tree classification algorithms.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterBoolean,
)


class GettingStartedAlgorithm(QgsProcessingAlgorithm):

    CONFIRM = 'CONFIRM'

    def initAlgorithm(self, config=None):
        # Dummy parameter so the algorithm can be "run" to display the help
        self.addParameter(QgsProcessingParameterBoolean(
            self.CONFIRM,
            'I have read the workflow guide (tick to acknowledge)',
            defaultValue=False))

    def processAlgorithm(self, parameters, context, feedback):
        feedback.pushInfo('')
        feedback.pushInfo('══════════════════════════════════════════════════')
        feedback.pushInfo('  HyPpy Plugin — Workflow Guide')
        feedback.pushInfo('══════════════════════════════════════════════════')
        feedback.pushInfo('')
        feedback.pushInfo('REQUIRED INPUT DATA')
        feedback.pushInfo('───────────────────')
        feedback.pushInfo('  1. Hyperspectral spectral cube')
        feedback.pushInfo('     The original radiance/reflectance image with')
        feedback.pushInfo('     full spectral range and wavelength metadata.')
        feedback.pushInfo('')
        feedback.pushInfo('  2. Three Wavelength of Minimum (WoM) rasters')
        feedback.pushInfo('     Run Step 1 - Wavelength of Minimum three times:')
        feedback.pushInfo('')
        feedback.pushInfo('     WoM-A:  750 – 1300 nm')
        feedback.pushInfo('             Used by: (future classifiers)')
        feedback.pushInfo('')
        feedback.pushInfo('     WoM-B:  1850 – 2100 nm')
        feedback.pushInfo('             Used by: dt_illcryst (denominator)')
        feedback.pushInfo('                      dt_ill_kaol (denominator)')
        feedback.pushInfo('')
        feedback.pushInfo('     WoM-C:  2100 – 2400 nm')
        feedback.pushInfo('             Used by: dt_2100_2400, dt_fedrop,')
        feedback.pushInfo('                      dt_illcryst, dt_ill_kaol')
        feedback.pushInfo('')
        feedback.pushInfo('RECOMMENDED WORKFLOW')
        feedback.pushInfo('────────────────────')
        feedback.pushInfo('  Step 1a  Run Wavelength of Minimum (750-1300 nm)')
        feedback.pushInfo('  Step 1b  Run Wavelength of Minimum (1850-2100 nm)')
        feedback.pushInfo('  Step 1c  Run Wavelength of Minimum (2100-2400 nm)')
        feedback.pushInfo('  Step 2   Run Convex Hull Removal if required')
        feedback.pushInfo('  Step 3   Run DT classifiers using the outputs above')
        feedback.pushInfo('')
        feedback.pushInfo('DECISION TREE INPUTS SUMMARY')
        feedback.pushInfo('────────────────────────────')
        feedback.pushInfo('  dt_2100_2400  WoM-C only')
        feedback.pushInfo('  dt_albedo     Hyperspectral cube only')
        feedback.pushInfo('  dt_fedrop     Hyperspectral cube + WoM-C')
        feedback.pushInfo('  dt_illcryst   WoM-B + WoM-C')
        feedback.pushInfo('  dt_ill_kaol   WoM-B + WoM-C')
        feedback.pushInfo('')
        feedback.pushInfo('══════════════════════════════════════════════════')
        return {}

    def name(self):        return 'getting_started'
    def displayName(self): return '00 Getting Started — Workflow Guide'
    def group(self):       return 'Step 0 - Getting Started'
    def groupId(self):     return 'step0_getting_started'

    def shortHelpString(self):
        return """
        <b>HyPpy Plugin — Workflow Guide</b>

        <p>This guide describes the data requirements and recommended workflow
        for using the HyPpy decision tree classification algorithms.</p>

        <hr/>
        <b>Required Input Data</b>

        <p><b>1. Hyperspectral spectral cube</b><br/>
        The original reflectance image with full spectral range and
        wavelength metadata (ENVI format or equivalent).</p>

        <p><b>2. Three Wavelength of Minimum (WoM) rasters</b><br/>
        Run <i>Step 1 — Wavelength of Minimum</i> three times over
        the following wavelength ranges:</p>

        <table border="1" cellpadding="4" cellspacing="0">
          <tr><th>WoM</th><th>Range</th><th>Used by</th></tr>
          <tr><td><b>WoM-A</b></td><td>750 – 1300 nm</td>
              <td>Future classifiers</td></tr>
          <tr><td><b>WoM-B</b></td><td>1850 – 2100 nm</td>
              <td>dt_illcryst, dt_ill_kaol (denominator)</td></tr>
          <tr><td><b>WoM-C</b></td><td>2100 – 2400 nm</td>
              <td>dt_2100_2400, dt_fedrop, dt_illcryst, dt_ill_kaol</td></tr>
        </table>

        <hr/>
        <b>Recommended Workflow</b>
        <ol>
          <li>Run Wavelength of Minimum for each of the three ranges above</li>
          <li>Run Convex Hull Removal if required</li>
          <li>Run the desired DT classifier(s) using the outputs</li>
        </ol>

        <hr/>
        <b>Decision Tree Inputs Summary</b>
        <table border="1" cellpadding="4" cellspacing="0">
          <tr><th>Algorithm</th><th>Inputs required</th></tr>
          <tr><td>dt_2100_2400</td><td>WoM-C</td></tr>
          <tr><td>dt_albedo</td><td>Hyperspectral cube</td></tr>
          <tr><td>dt_fedrop</td><td>Hyperspectral cube + WoM-C</td></tr>
          <tr><td>dt_illcryst</td><td>WoM-B + WoM-C</td></tr>
          <tr><td>dt_ill_kaol</td><td>WoM-B + WoM-C</td></tr>
        </table>

        <p><i>HyPpy plugin by Grant Boxer, 2025.</i></p>
        """

    def flags(self):
        # Mark as non-destructive and not requiring any inputs to be useful
        return super().flags() | QgsProcessingAlgorithm.FlagNoThreading

    def createInstance(self): return GettingStartedAlgorithm()
