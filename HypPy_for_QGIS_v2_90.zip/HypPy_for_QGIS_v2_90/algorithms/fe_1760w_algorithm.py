"""
Feature Extraction — 1760W

WoM range 1730-1790 nm, wavelength map stretch 1751-1764 nm.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe1760WAlgorithm(FEWomBase):
    WOM_START = 1730.0
    WOM_END   = 1790.0
    MAP_MIN   = 1751.0
    MAP_MAX   = 1764.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2
    def name(self):        return 'fe_1760w'

    def displayName(self): return 'FE06 - 1760W'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 1760W  (Carbonate CO₃ combination)</b>

        <p>Targets the carbonate CO₃ combination absorption near <b>~1760 nm</b>,
        present in calcite, dolomite, and magnesite. This is the last useful atmospheric
        window before the 1780–1960 nm water vapour zone.
        Derived from USGS GMEX reference spectra for calcite and dolomite.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>1730-1790 nm</b>.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>1751-1764 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>1730-1790 nm</td></tr>
          <tr><td>Colour stretch min</td><td>1751 nm</td></tr>
          <tr><td>Colour stretch max</td><td>1764 nm</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>~1760 nm feature — mineral associations (GMEX):</b></p>
        <ul>
          <li><b>Calcite</b> CaCO₃ — CO₃ combination at ~1750–1755 nm; weaker absorptions
              at 1880/1992 nm do NOT persist in mixtures; only ~2340–2345 nm persists (GMEX)</li>
          <li><b>Dolomite</b> CaMg(CO₃)₂ — CO₃ combination at ~1760–1765 nm; slightly
              longward of calcite; only ~2320–2328 nm persists in mixtures (GMEX)</li>
          <li><b>Magnesite</b> MgCO₃ — CO₃ combination near ~1760 nm; only ~2302 nm
              persists — shortest-wave diagnostic carbonate feature (GMEX)</li>
          <li><b>Siderite</b> FeCO₃ — CO₃ combination at ~1755 nm; confirm with 2320–2340 nm</li>
          <li><b>Alunite</b> (K,Na)Al₃(SO₄)₂(OH)₆ — strong SO₄/OH at <b>~1760 nm</b>
              very characteristic (GMEX); combine with 1436/1474–1480 nm OH doublet to
              confirm. Use this WoM as input to <b>DT Sulphate Group</b> classifier.</li>
          <li><b>Gypsum</b> CaSO₄·2H₂O — SO₄/OH feature at ~1750 nm alongside triple
              water absorptions at 1449/1490/1535 nm (GMEX)</li>
        </ul>

        <p>The small wavelength separation within the stretch range (~1751–1764 nm)
        can discriminate calcite from dolomite in high-SNR data. Use together with
        FE16-2320W and FE17-2350W for full carbonate suite characterisation.</p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, calcite and dolomite entries.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe1760WAlgorithm()
