"""
Feature Extraction — 2200W

WoM range 2120-2245 nm, wavelength map stretch 2185-2215 nm.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe2200WAlgorithm(FEWomBase):
    WOM_START = 2120.0
    WOM_END   = 2245.0
    MAP_MIN   = 2185.0
    MAP_MAX   = 2215.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2

    def _post_map_log(self, feedback):
        feedback.pushInfo('')
        feedback.pushInfo('─' * 60)
        feedback.pushInfo('GSWA Report 261 Table 4 — 2200D recommended display stretch:')
        feedback.pushInfo('  Gascoyne / Pilbara:  min = 0.04, max = 0.16')
        feedback.pushInfo('  (4th order polynomial fit reference: 2140–2240 nm)')
        feedback.pushInfo('  Targeted minerals: White mica, kaolinite, Al-smectite, tourmaline')
        feedback.pushInfo('  Use as Red channel in FE-GSWA-RGB Mineral Groups composite')
        feedback.pushInfo('─' * 60)

    def name(self):        return 'fe_2200w'

    def displayName(self): return 'FE12 - 2200W'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2200W  (Al-OH broad survey)</b>

        <p>Provides a broad survey of the entire Al-OH mineral suite across
        <b>2185–2215 nm</b>. The wide WoM search range (2120–2245 nm) captures all
        major Al-OH minerals in a single pass, making this the recommended first-pass
        tool before running targeted tools such as FE10, FE11, or FE13.
        Derived from USGS GMEX reference spectra for the Al-OH mineral group.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>2120-2245 nm</b>.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>2185-2215 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>2120-2245 nm</td></tr>
          <tr><td>Colour stretch min</td><td>2185 nm</td></tr>
          <tr><td>Colour stretch max</td><td>2215 nm</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>2185–2215 nm colour stretch — mineral positions (GMEX):</b></p>
        <ul>
          <li><b>Blue (~2185–2193 nm)</b> — Pyrophyllite (~2166 nm primary, but broad wing extends here), Alunite</li>
          <li><b>Cyan–Green (~2193–2203 nm)</b> — Illite / Muscovite / Phengite Al-OH</li>
          <li><b>Green (~2203–2207 nm)</b> — Kaolinite (well-ordered, ~2206 nm)</li>
          <li><b>Yellow–Red (~2207–2215 nm)</b> — Smectite / disordered kaolinite / mixed-layer clays</li>
        </ul>

        <p>Use this tool as a scene-wide Al-OH survey. Follow with FE10-2160D,
        FE11-2178D, and FE13-2206W for targeted mineral discrimination, and with
        the DT decision-tree classifiers for final mapping.</p>

        <p style="background-color:#e8f5e9; padding:6px; border-left:4px solid #388e3c;">
        <b>GSWA Report 261, Table 4 — Recommended stretch (Gascoyne/Pilbara):</b><br/>
        4th order polynomial fit, continuum removal range: <b>2140–2240 nm</b><br/>
        Gascoyne / Pilbara: min = 0.04, max = 0.16<br/>
        Use as <b>Red channel</b> in the FE-GSWA-RGB Mineral Groups composite
        (R=2200D, G=2250D, B=2160D).
        </p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, Al-OH mineral group.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe2200WAlgorithm()
