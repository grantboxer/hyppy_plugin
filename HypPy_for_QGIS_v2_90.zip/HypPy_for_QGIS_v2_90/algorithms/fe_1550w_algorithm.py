"""
Feature Extraction — 1550W

WoM range 1510-1610 nm, wavelength map stretch 1520-1563 nm.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe1550WAlgorithm(FEWomBase):
    WOM_START = 1510.0
    WOM_END   = 1610.0
    MAP_MIN   = 1520.0
    MAP_MAX   = 1563.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2
    def name(self):        return 'fe_1550w'

    def displayName(self): return 'FE05 - 1550W'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 1550W  (Amphibole / Epidote OH)</b>

        <p>Targets OH combination absorptions near <b>~1530–1560 nm</b> present in
        amphiboles, epidote group minerals, and some chlorites. This is an atmospheric
        window between the 1340–1445 nm and 1780–1960 nm water vapour zones.
        Derived from USGS GMEX reference spectra for actinolite and epidote.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>1510-1610 nm</b>.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>1520-1563 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>1510-1610 nm</td></tr>
          <tr><td>Colour stretch min</td><td>1520 nm</td></tr>
          <tr><td>Colour stretch max</td><td>1563 nm</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>~1550 nm feature — mineral associations (GMEX):</b></p>
        <ul>
          <li><b>Actinolite / Tremolite</b> — OH combination near ~1530 nm; shifts with Fe content</li>
          <li><b>Epidote / Zoisite</b> — OH feature near ~1540–1550 nm; useful in skarn settings</li>
          <li><b>Chlorite</b> — weak Mg-OH feature in this region; confirm with 2250–2320 nm</li>
          <li><b>Phlogopite</b> — OH combination band near ~1540 nm</li>
        </ul>

        <p>Wavelength position within the stretch range reflects mineral composition:
        shorter-wave features (blue) tend toward Fe-poor / Mg-rich end-members;
        longer-wave features (red) toward Fe-bearing varieties.</p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, actinolite and epidote entries.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe1550WAlgorithm()
