"""
Feature Extraction — Carbonate Band-Depth Index (CA01)
=======================================================
Discriminates limestone (calcite), dolomite and magnesite in EnMAP and
other hyperspectral SWIR data using continuum-removed band depths at the
diagnostic CO₃ combination absorptions in the 2290–2395 nm region.

The primary CO₃ combination band shifts systematically longward with
increasing cation mass (USGS GMEX / AusSpec 2005; Clark et al. 2007):

    Magnesite  MgCO₃          ~2302–2315 nm   (lightest cation)
    Dolomite   CaMg(CO₃)₂     ~2320–2328 nm   (intermediate)
    Ankerite   Ca(Fe,Mg)(CO₃)₂ ~2330–2340 nm  (Fe-bearing dolomite)
    Calcite    CaCO₃           ~2338–2345 nm   (heaviest cation)
    Limestone                  ~2338–2345 nm   (calcite-dominated rock)

Secondary (shorter-wave) CO₃ features also shift, providing confirmatory
discrimination:
    ~2135 nm  Magnesite second feature
    ~2145 nm  Dolomite second feature
    ~2155 nm  Calcite second feature

Outputs
-------
    BD2315   Band depth at ~2315 nm (magnesite primary)
    BD2328   Band depth at ~2328 nm (dolomite primary)
    BD2342   Band depth at ~2342 nm (calcite/limestone primary)
    BD2160   Band depth at ~2160 nm (secondary feature — position
             shifts ~10 nm between Mg and Ca end-members)
    CPI      Carbonate Position Index — interpolated wavelength of the
             absorption minimum within 2295–2360 nm (nm value raster).
             Pixels with no carbonate signal are set to NaN.
             Interpretation:
               CPI < 2318 nm   → magnesite
               2318–2333 nm    → dolomite / ankerite
               > 2333 nm       → calcite / limestone

Discrimination summary (USGS splib07 / GMEX AusSpec 2005):
    Mineral     BD2315  BD2328  BD2342  BD2160 position  CPI
    Magnesite   HIGH    low     low     ~2135 nm          <2318
    Dolomite    low     HIGH    low     ~2145 nm          2318-2333
    Ankerite    low     mod     mod     ~2153 nm          2328-2340
    Calcite     low     low     HIGH    ~2155 nm          >2333
    Limestone   low     low     HIGH    ~2155 nm          >2333

Cross-validation: compare CPI output against DT 2100-2400 classification
(magnesite / dolomite / ankerite / calcite classes) for confidence.

Suitable sensors: EnMAP, PRISMA, AVIRIS, AVIRIS-NG, HyMap, EMIT
                  (requires coverage to ~2400 nm)

Limitations
-----------
- Dolomite-calcite intergrowths produce intermediate CPI values; use
  Tetracorder for unmixing.
- Ankerite (~2330-2340 nm) overlaps the dolomite/calcite boundary.
- Atmospheric residuals near 2300-2400 nm can shift CPI by ~5 nm;
  good atmospheric correction (ATCOR/QUAC) is essential.
- Limestone is spectrally equivalent to calcite; rock-scale mixing
  at 30 m (EnMAP) may produce mixed dolomite-calcite pixels.

Reference
---------
Clark, R.N. et al. (2007). USGS Digital Spectral Library splib07a.
  USGS Data Series 231.  calcite_WS272, dolomite_HS102.3B,
  magnesite_LACB02A.
AusSpec International (2005). GMEX Hyperspectral Mineral Map —
  Expert System Reference Spectra.
van Ruitenbeek et al. (2025). Remote Sensing 17(15), 2555.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset


# ── Constants ──────────────────────────────────────────────────────────────────

# Default wavelengths (nm): (centre, left_shoulder, right_shoulder)
_FEATURE_DEFAULTS = {
    'BD2315': (2315.0, 2270.0, 2370.0),   # magnesite primary CO3
    'BD2328': (2328.0, 2270.0, 2380.0),   # dolomite primary CO3
    'BD2342': (2342.0, 2290.0, 2395.0),   # calcite/limestone primary CO3
    'BD2160': (2160.0, 2100.0, 2220.0),   # secondary feature (position-sensitive)
}

# CPI search range (nm) — minimum within this window gives the carbonate position
CPI_START_DEFAULT = 2295.0
CPI_END_DEFAULT   = 2360.0

# CPI mineral boundaries (nm)
CPI_MAG_DOLO  = 2318.0   # magnesite / dolomite boundary
CPI_DOLO_CALC = 2333.0   # dolomite / calcite boundary


WORKFLOW_NOTE = """\
        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with SWIR coverage (≥ 2100–2400 nm)
        and wavelength metadata (ENVI format).<br/>
        Suitable sensors: EnMAP, PRISMA, AVIRIS, AVIRIS-NG, HyMap, EMIT.
        Good atmospheric correction (ATCOR/QUAC) is <b>essential</b> — residual
        water vapour near 2300–2400 nm can shift the CPI by ~5 nm.
        </p>
"""

CARBONATE_NOTE = """\
        <p style="background-color:#e8f4fd; padding:6px; border-left:4px solid #1565c0;">
        <b>Key principle:</b> The CO₃ combination absorption near 2300–2345 nm
        shifts <b>longward with increasing cation mass</b>: magnesite (Mg) → dolomite
        (Ca+Mg) → calcite (Ca). The <b>Carbonate Position Index (CPI)</b> maps this
        shift directly as a continuous wavelength raster, allowing quantitative
        mineral discrimination at EnMAP's 6.5 nm sampling.
        </p>
"""


# ── Helpers ────────────────────────────────────────────────────────────────────

def _nearest(wavelengths: np.ndarray, target_nm: float) -> int:
    """Return 0-based index of band nearest to target_nm."""
    return int(np.argmin(np.abs(wavelengths - target_nm)))


def _read_band_float(ds, band_idx: int, nodata) -> np.ndarray:
    """Read one 0-based band as float32, replacing nodata with NaN."""
    arr = ds.GetRasterBand(band_idx + 1).ReadAsArray().astype(np.float32)
    if nodata is not None:
        arr[arr == float(nodata)] = np.nan
    return arr


def _band_depth(Rc: np.ndarray,
                Rl: np.ndarray,
                Rr: np.ndarray,
                wc: float, wl: float, wr: float) -> np.ndarray:
    """
    Continuum-removed band depth.

    BD = 1 - R_centre / R_continuum
    R_continuum is linearly interpolated between left and right shoulder bands.

    Returns float32 array clipped to [0, 1]; NaN where continuum <= 0.
    """
    t = float(np.clip((wc - wl) / (wr - wl) if wr != wl else 0.5, 0.0, 1.0))
    R_cont = Rl + t * (Rr - Rl)
    with np.errstate(invalid='ignore', divide='ignore'):
        bd = np.where(R_cont > 0,
                      1.0 - Rc / R_cont,
                      np.nan).astype(np.float32)
    return np.clip(bd, 0.0, 1.0).astype(np.float32)


def _carbonate_position_index(refl_window: np.ndarray,
                               wvl_window: np.ndarray,
                               min_depth: float = 0.01) -> np.ndarray:
    """
    Compute the Carbonate Position Index.

    Finds the wavelength of the reflectance minimum within the search
    window for each pixel, using parabolic interpolation between the
    three bands nearest the minimum for sub-pixel accuracy.

    Parameters
    ----------
    refl_window : float32 array (n_rows, n_cols, n_window_bands)
                  reflectance values for bands within the CPI search range
    wvl_window  : 1-D array of wavelengths for those bands (nm)
    min_depth   : minimum band depth required for a valid CPI value;
                  pixels below this are set to NaN (no carbonate signal)

    Returns
    -------
    cpi : float32 array (n_rows, n_cols) — wavelength in nm, or NaN
    """
    n_rows, n_cols, n_bands = refl_window.shape

    # Argmin across band axis → index of minimum reflectance
    argmin = np.argmin(refl_window, axis=2)          # (rows, cols)

    # Gather minimum and flanking reflectance for parabolic fit
    rows_idx = np.arange(n_rows)[:, None]
    cols_idx = np.arange(n_cols)[None, :]

    # Clip so flanking indices are always valid
    idx_m = np.clip(argmin - 1, 0, n_bands - 1)
    idx_0 = argmin
    idx_p = np.clip(argmin + 1, 0, n_bands - 1)

    ym = refl_window[rows_idx, cols_idx, idx_m]
    y0 = refl_window[rows_idx, cols_idx, idx_0]
    yp = refl_window[rows_idx, cols_idx, idx_p]

    wm = wvl_window[idx_m]
    w0 = wvl_window[idx_0]
    wp = wvl_window[idx_p]

    # Parabolic interpolation: vertex at x = x0 - 0.5*(yp-ym)/(yp-2*y0+ym)
    denom = yp - 2.0 * y0 + ym
    with np.errstate(invalid='ignore', divide='ignore'):
        delta_idx = -0.5 * (yp - ym) / np.where(np.abs(denom) > 1e-9, denom, np.nan)

    # Convert fractional index delta to nm (assume uniform spacing at centre)
    dw = np.where(delta_idx >= 0,
                  (wp - w0) * np.abs(delta_idx),
                  (w0 - wm) * np.abs(delta_idx))
    cpi = (w0 + dw).astype(np.float32)

    # Compute continuum depth at minimum to gate weak/no-carbonate pixels
    # Use the global shoulders (first and last band of window)
    Rl = refl_window[:, :, 0]
    Rr = refl_window[:, :, -1]
    wl = float(wvl_window[0])
    wr = float(wvl_window[-1])
    t  = ((w0 - wl) / (wr - wl)).astype(np.float32)
    R_cont = Rl + t * (Rr - Rl)
    with np.errstate(invalid='ignore', divide='ignore'):
        depth_at_min = np.where(R_cont > 0, 1.0 - y0 / R_cont, 0.0)

    # Mask pixels with insufficient carbonate absorption
    cpi = np.where(depth_at_min >= min_depth, cpi, np.nan).astype(np.float32)

    # Mask pixels where the minimum is at the window edge (likely atmospheric artefact)
    edge_mask = (argmin == 0) | (argmin == n_bands - 1)
    cpi[edge_mask] = np.nan

    return cpi


def _write_single_band_tif(path: str, arr: np.ndarray,
                            geo, proj, description: str = '') -> None:
    """Write a single-band float32 GeoTIFF with LZW compression."""
    driver = gdal.GetDriverByName('GTiff')
    n_rows, n_cols = arr.shape
    out_ds = driver.Create(path, n_cols, n_rows, 1, gdal.GDT_Float32,
                           ['COMPRESS=LZW', 'TILED=YES'])
    out_ds.SetGeoTransform(geo)
    out_ds.SetProjection(proj)
    b = out_ds.GetRasterBand(1)
    b.WriteArray(arr.astype(np.float32))
    b.SetNoDataValue(float('nan'))
    b.SetDescription(description)
    out_ds.FlushCache()
    out_ds = None


# ── Algorithm ──────────────────────────────────────────────────────────────────

class CarbonateIndexAlgorithm(QgsProcessingAlgorithm):
    """
    CA01 — Carbonate Band-Depth Index
    (BD2315 / BD2328 / BD2342 / BD2160 / CPI)

    Discriminates magnesite, dolomite, ankerite and calcite/limestone
    using the systematic longward wavelength shift of the CO₃ combination
    absorption near 2300–2345 nm with increasing cation mass.
    """

    INPUT   = 'INPUT'
    USE_BBL = 'USE_BBL'

    # Band depth wavelength controls (centre, left, right for each feature)
    BD2315_L = 'BD2315_L';  BD2315_C = 'BD2315_C';  BD2315_R = 'BD2315_R'
    BD2328_L = 'BD2328_L';  BD2328_C = 'BD2328_C';  BD2328_R = 'BD2328_R'
    BD2342_L = 'BD2342_L';  BD2342_C = 'BD2342_C';  BD2342_R = 'BD2342_R'
    BD2160_L = 'BD2160_L';  BD2160_C = 'BD2160_C';  BD2160_R = 'BD2160_R'

    # CPI search range
    CPI_START    = 'CPI_START'
    CPI_END      = 'CPI_END'
    CPI_MIN_DEPTH = 'CPI_MIN_DEPTH'

    # Outputs
    OUTPUT_BD2315 = 'OUTPUT_BD2315'
    OUTPUT_BD2328 = 'OUTPUT_BD2328'
    OUTPUT_BD2342 = 'OUTPUT_BD2342'
    OUTPUT_BD2160 = 'OUTPUT_BD2160'
    OUTPUT_CPI    = 'OUTPUT_CPI'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT,
            'Hyperspectral cube (SWIR, ≥2100–2400 nm)'))

        self.addParameter(QgsProcessingParameterBoolean(
            self.USE_BBL, 'Use Bad Band List (BBL) from metadata',
            defaultValue=True))

        # Wavelength parameters — left / centre / right for each band depth
        wav_params = [
            # BD2315 (magnesite)
            (self.BD2315_L, 'BD2315 left shoulder [nm]',  2270.0, 2100.0, 2310.0),
            (self.BD2315_C, 'BD2315 centre [nm]',          2315.0, 2290.0, 2330.0),
            (self.BD2315_R, 'BD2315 right shoulder [nm]',  2370.0, 2320.0, 2420.0),
            # BD2328 (dolomite)
            (self.BD2328_L, 'BD2328 left shoulder [nm]',  2270.0, 2100.0, 2315.0),
            (self.BD2328_C, 'BD2328 centre [nm]',          2328.0, 2310.0, 2345.0),
            (self.BD2328_R, 'BD2328 right shoulder [nm]',  2380.0, 2330.0, 2430.0),
            # BD2342 (calcite / limestone)
            (self.BD2342_L, 'BD2342 left shoulder [nm]',  2290.0, 2150.0, 2330.0),
            (self.BD2342_C, 'BD2342 centre [nm]',          2342.0, 2325.0, 2360.0),
            (self.BD2342_R, 'BD2342 right shoulder [nm]',  2395.0, 2350.0, 2450.0),
            # BD2160 (secondary feature)
            (self.BD2160_L, 'BD2160 left shoulder [nm]',  2100.0, 2050.0, 2140.0),
            (self.BD2160_C, 'BD2160 centre [nm]',          2160.0, 2130.0, 2180.0),
            (self.BD2160_R, 'BD2160 right shoulder [nm]',  2220.0, 2170.0, 2280.0),
        ]
        for pid, label, default, mn, mx in wav_params:
            self.addParameter(QgsProcessingParameterNumber(
                pid, label,
                type=QgsProcessingParameterNumber.Double,
                defaultValue=default, minValue=mn, maxValue=mx))

        # CPI parameters
        self.addParameter(QgsProcessingParameterNumber(
            self.CPI_START,
            'CPI search window start [nm]',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=CPI_START_DEFAULT, minValue=2260.0, maxValue=2330.0))

        self.addParameter(QgsProcessingParameterNumber(
            self.CPI_END,
            'CPI search window end [nm]',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=CPI_END_DEFAULT, minValue=2320.0, maxValue=2420.0))

        self.addParameter(QgsProcessingParameterNumber(
            self.CPI_MIN_DEPTH,
            'CPI minimum band depth threshold (pixels below → NaN, no carbonate)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.01, minValue=0.0, maxValue=0.5))

        # Outputs
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_BD2315,
            'Output BD2315 — band depth at ~2315 nm (magnesite primary CO₃)'))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_BD2328,
            'Output BD2328 — band depth at ~2328 nm (dolomite primary CO₃)'))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_BD2342,
            'Output BD2342 — band depth at ~2342 nm (calcite/limestone primary CO₃)'))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_BD2160,
            'Output BD2160 — band depth at ~2160 nm (secondary CO₃ feature)'))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_CPI,
            'Output CPI — Carbonate Position Index (wavelength in nm; '
            'NaN = no carbonate signal)'))

    def processAlgorithm(self, parameters, context, feedback):
        cube    = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        use_bbl = self.parameterAsBoolean(parameters, self.USE_BBL, context)

        if cube is None:
            raise QgsProcessingException('Invalid input layer')

        ds = gdal.Open(cube.source())
        if ds is None:
            raise QgsProcessingException(f'Cannot open raster: {cube.source()}')

        n_bands = ds.RasterCount
        n_rows  = ds.RasterYSize
        n_cols  = ds.RasterXSize
        nodata  = ds.GetRasterBand(1).GetNoDataValue()
        geo     = ds.GetGeoTransform()
        proj    = ds.GetProjection()

        raster_path = cube.source()
        wavelengths = get_wavelengths_from_dataset(ds, n_bands, raster_path, feedback)
        if wavelengths is None:
            raise QgsProcessingException(
                'No wavelength metadata found. Input must have ENVI wavelength information.')

        wmin, wmax = float(wavelengths[0]), float(wavelengths[-1])
        feedback.pushInfo(f'Cube: {n_bands} bands, {n_rows}×{n_cols} px, '
                          f'{wmin:.0f}–{wmax:.0f} nm')

        # ── Sensor coverage checks ─────────────────────────────────────────
        if wmax < 2350:
            raise QgsProcessingException(
                f'Sensor maximum wavelength is {wmax:.0f} nm. '
                'CA01 requires coverage to ~2395 nm — cannot proceed.')

        if wmax < 2400:
            feedback.pushWarning(
                f'CA01: sensor maximum wavelength is {wmax:.0f} nm. '
                'BD2342 right shoulder (default 2395 nm) may be at the edge '
                'of valid data — check output carefully.')

        # ── BBL ───────────────────────────────────────────────────────────
        bbl = None
        if use_bbl:
            bbl = get_bbl_from_dataset(ds, n_bands, raster_path)
            if bbl is not None:
                feedback.pushInfo(f'BBL: {int(np.sum(bbl))}/{n_bands} good bands')

        # ── Collect wavelength parameters from user ────────────────────────
        features = {
            'BD2315': (
                self.parameterAsDouble(parameters, self.BD2315_C, context),
                self.parameterAsDouble(parameters, self.BD2315_L, context),
                self.parameterAsDouble(parameters, self.BD2315_R, context),
            ),
            'BD2328': (
                self.parameterAsDouble(parameters, self.BD2328_C, context),
                self.parameterAsDouble(parameters, self.BD2328_L, context),
                self.parameterAsDouble(parameters, self.BD2328_R, context),
            ),
            'BD2342': (
                self.parameterAsDouble(parameters, self.BD2342_C, context),
                self.parameterAsDouble(parameters, self.BD2342_L, context),
                self.parameterAsDouble(parameters, self.BD2342_R, context),
            ),
            'BD2160': (
                self.parameterAsDouble(parameters, self.BD2160_C, context),
                self.parameterAsDouble(parameters, self.BD2160_L, context),
                self.parameterAsDouble(parameters, self.BD2160_R, context),
            ),
        }
        cpi_start     = self.parameterAsDouble(parameters, self.CPI_START, context)
        cpi_end       = self.parameterAsDouble(parameters, self.CPI_END, context)
        cpi_min_depth = self.parameterAsDouble(parameters, self.CPI_MIN_DEPTH, context)

        # ── Resolve band indices, log assignments, check BBL ───────────────
        feedback.pushInfo('')
        feedback.pushInfo('Band assignments (nearest available band):')
        band_idx = {}   # key → (ic, il, ir)
        for key, (wc, wl, wr) in features.items():
            ic = _nearest(wavelengths, wc)
            il = _nearest(wavelengths, wl)
            ir = _nearest(wavelengths, wr)
            for label, idx, target in (
                    (f'{key} centre', ic, wc),
                    (f'{key} left',   il, wl),
                    (f'{key} right',  ir, wr)):
                bad = ''
                if bbl is not None and not bbl[idx]:
                    bad = '  ⚠ flagged bad in BBL'
                feedback.pushInfo(f'  {label}: target {target:.0f} nm → '
                                  f'band {idx+1} ({wavelengths[idx]:.1f} nm){bad}')
            if ic == il or ic == ir:
                feedback.pushWarning(
                    f'{key}: centre band equals a shoulder band — '
                    'band depth will be zero. Adjust wavelength parameters.')
            band_idx[key] = (ic, il, ir)

        # CPI window bands
        cpi_mask  = (wavelengths >= cpi_start) & (wavelengths <= cpi_end)
        cpi_bands = np.where(cpi_mask)[0]
        if len(cpi_bands) < 3:
            raise QgsProcessingException(
                f'CPI search window {cpi_start:.0f}–{cpi_end:.0f} nm contains '
                f'only {len(cpi_bands)} bands. Widen the window or check sensor coverage.')
        feedback.pushInfo(f'\nCPI search window: {cpi_start:.0f}–{cpi_end:.0f} nm '
                          f'({len(cpi_bands)} bands)')
        feedback.pushInfo(f'CPI mineral boundaries: '
                          f'<{CPI_MAG_DOLO:.0f} nm = magnesite, '
                          f'{CPI_MAG_DOLO:.0f}–{CPI_DOLO_CALC:.0f} nm = dolomite/ankerite, '
                          f'>{CPI_DOLO_CALC:.0f} nm = calcite/limestone')
        feedback.pushInfo('')
        feedback.setProgress(10)

        # ── Read required bands (deduplicated) ─────────────────────────────
        needed_bd = set()
        for ic, il, ir in band_idx.values():
            needed_bd.update([ic, il, ir])
        needed_all = needed_bd | set(cpi_bands.tolist())

        feedback.pushInfo(f'Reading {len(needed_all)} unique band arrays …')
        band_data = {}
        for idx in sorted(needed_all):
            if feedback.isCanceled():
                return {}
            band_data[idx] = _read_band_float(ds, idx, nodata)

        ds = None  # close input
        feedback.setProgress(35)

        # Normalise to 0–1 if integer-scaled
        sample = next(iter(band_data.values()))
        if np.nanmax(sample) > 2.0:
            feedback.pushInfo('Reflectance appears integer-scaled — normalising ÷ 10000')
            band_data = {k: v / 10000.0 for k, v in band_data.items()}

        if feedback.isCanceled():
            return {}

        # ── Compute band depths ────────────────────────────────────────────
        feedback.pushInfo('Computing band depths …')
        bd_arrays = {}
        for key, (ic, il, ir) in band_idx.items():
            wc = float(wavelengths[ic])
            wl = float(wavelengths[il])
            wr = float(wavelengths[ir])
            bd_arrays[key] = _band_depth(
                band_data[ic], band_data[il], band_data[ir],
                wc, wl, wr)

        feedback.setProgress(55)

        # ── Compute CPI ────────────────────────────────────────────────────
        feedback.pushInfo('Computing Carbonate Position Index (CPI) …')
        wvl_window = wavelengths[cpi_bands].astype(np.float32)

        # Stack CPI window bands into (rows, cols, n_window_bands)
        refl_window = np.stack(
            [band_data[idx] for idx in cpi_bands], axis=2)

        # Replace NaN with a high value so argmin ignores them
        refl_window_safe = np.where(np.isfinite(refl_window),
                                    refl_window, np.finfo(np.float32).max)

        cpi = _carbonate_position_index(refl_window_safe, wvl_window, cpi_min_depth)

        feedback.setProgress(70)

        # ── Statistics log ─────────────────────────────────────────────────
        feedback.pushInfo('')
        feedback.pushInfo('Output statistics:')
        for key, arr in list(bd_arrays.items()) + [('CPI (nm)', cpi)]:
            valid = arr[np.isfinite(arr)]
            if valid.size:
                feedback.pushInfo(
                    f'  {key}: min={float(valid.min()):.4f}  '
                    f'max={float(valid.max()):.4f}  '
                    f'mean={float(valid.mean()):.4f}  '
                    f'valid px={valid.size}')

        # CPI mineral class counts
        feedback.pushInfo('')
        feedback.pushInfo('CPI mineral classification (valid carbonate pixels):')
        cpi_valid = cpi[np.isfinite(cpi)]
        if cpi_valid.size > 0:
            n_mag  = int(np.sum(cpi_valid < CPI_MAG_DOLO))
            n_dolo = int(np.sum((cpi_valid >= CPI_MAG_DOLO) & (cpi_valid < CPI_DOLO_CALC)))
            n_calc = int(np.sum(cpi_valid >= CPI_DOLO_CALC))
            total  = cpi_valid.size
            feedback.pushInfo(f'  Magnesite  (CPI < {CPI_MAG_DOLO:.0f} nm): '
                              f'{n_mag} px ({100*n_mag/total:.1f}%)')
            feedback.pushInfo(f'  Dolomite/ankerite ({CPI_MAG_DOLO:.0f}–{CPI_DOLO_CALC:.0f} nm): '
                              f'{n_dolo} px ({100*n_dolo/total:.1f}%)')
            feedback.pushInfo(f'  Calcite/limestone (CPI > {CPI_DOLO_CALC:.0f} nm): '
                              f'{n_calc} px ({100*n_calc/total:.1f}%)')

        if feedback.isCanceled():
            return {}

        # ── Write outputs ──────────────────────────────────────────────────
        feedback.setProgress(75)
        out_paths = {
            self.OUTPUT_BD2315: self.parameterAsOutputLayer(
                parameters, self.OUTPUT_BD2315, context),
            self.OUTPUT_BD2328: self.parameterAsOutputLayer(
                parameters, self.OUTPUT_BD2328, context),
            self.OUTPUT_BD2342: self.parameterAsOutputLayer(
                parameters, self.OUTPUT_BD2342, context),
            self.OUTPUT_BD2160: self.parameterAsOutputLayer(
                parameters, self.OUTPUT_BD2160, context),
            self.OUTPUT_CPI:    self.parameterAsOutputLayer(
                parameters, self.OUTPUT_CPI, context),
        }

        writes = [
            (self.OUTPUT_BD2315, bd_arrays['BD2315'],
             'BD2315 — band depth ~2315 nm (magnesite primary CO3)'),
            (self.OUTPUT_BD2328, bd_arrays['BD2328'],
             'BD2328 — band depth ~2328 nm (dolomite primary CO3)'),
            (self.OUTPUT_BD2342, bd_arrays['BD2342'],
             'BD2342 — band depth ~2342 nm (calcite/limestone primary CO3)'),
            (self.OUTPUT_BD2160, bd_arrays['BD2160'],
             'BD2160 — band depth ~2160 nm (secondary CO3; position shifts Mg→Ca)'),
            (self.OUTPUT_CPI,    cpi,
             f'CPI — Carbonate Position Index (nm); '
             f'<{CPI_MAG_DOLO:.0f}=magnesite, '
             f'{CPI_MAG_DOLO:.0f}-{CPI_DOLO_CALC:.0f}=dolomite/ankerite, '
             f'>{CPI_DOLO_CALC:.0f}=calcite/limestone; NaN=no carbonate'),
        ]

        for param_id, arr, desc in writes:
            path = out_paths[param_id]
            feedback.pushInfo(f'Writing {desc.split(" —")[0]} → {path}')
            _write_single_band_tif(path, arr, geo, proj, desc)

        feedback.setProgress(95)
        feedback.pushInfo('')
        feedback.pushInfo('CA01 Carbonate Band-Depth Index complete.')
        feedback.pushInfo('')
        feedback.pushInfo('Display guidance:')
        feedback.pushInfo('  BD2315 — stretch 0 → 0.15 (magnesite; high = Mg-carbonate present)')
        feedback.pushInfo('  BD2328 — stretch 0 → 0.15 (dolomite)')
        feedback.pushInfo('  BD2342 — stretch 0 → 0.15 (calcite/limestone)')
        feedback.pushInfo('  BD2160 — stretch 0 → 0.10 (secondary feature)')
        feedback.pushInfo(f'  CPI    — stretch {CPI_START_DEFAULT:.0f} → {CPI_END_DEFAULT:.0f} nm')
        feedback.pushInfo('             Use a diverging colour ramp (e.g. RdYlGn):')
        feedback.pushInfo(f'             Blue/cool = magnesite (<{CPI_MAG_DOLO:.0f} nm)')
        feedback.pushInfo(f'             Green/mid = dolomite ({CPI_MAG_DOLO:.0f}–{CPI_DOLO_CALC:.0f} nm)')
        feedback.pushInfo(f'             Red/warm  = calcite (>{CPI_DOLO_CALC:.0f} nm)')
        feedback.pushInfo('')
        feedback.pushInfo('Cross-validation: compare CPI output with DT 2100-2400')
        feedback.pushInfo('classification (magnesite/dolomite/ankerite/calcite classes).')
        feedback.setProgress(100)

        return out_paths

    # ── Algorithm metadata ─────────────────────────────────────────────────────

    def name(self):        return 'ca01_carbonate_index'
    def displayName(self): return 'CA01 Carbonate Band-Depth Index  (BD2315/BD2328/BD2342/CPI)'
    def group(self):       return '8 - Gypsum & Carbonate Indices'
    def groupId(self):     return 'eight_gypsum_carbonate_indices'

    def shortHelpString(self):
        return WORKFLOW_NOTE + CARBONATE_NOTE + """
        <b>CA01 — Carbonate Band-Depth Index</b>

        <p>Discriminates magnesite, dolomite, ankerite and calcite/limestone
        using the systematic longward shift of the CO₃ combination absorption
        near 2300–2345 nm with increasing cation mass.</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Output</th><th>Wavelength</th><th>Target mineral</th><th>Shoulders</th>
          </tr>
          <tr><td><b>BD2315</b></td><td>~2315 nm</td>
              <td>Magnesite MgCO₃ (primary CO₃)</td>
              <td>2270 / 2370 nm</td></tr>
          <tr><td><b>BD2328</b></td><td>~2328 nm</td>
              <td>Dolomite CaMg(CO₃)₂ (primary CO₃)</td>
              <td>2270 / 2380 nm</td></tr>
          <tr><td><b>BD2342</b></td><td>~2342 nm</td>
              <td>Calcite CaCO₃ / limestone (primary CO₃)</td>
              <td>2290 / 2395 nm</td></tr>
          <tr><td><b>BD2160</b></td><td>~2160 nm</td>
              <td>Secondary CO₃ (position shifts ~10 nm Mg→Ca)</td>
              <td>2100 / 2220 nm</td></tr>
          <tr><td><b>CPI</b></td><td>2295–2360 nm</td>
              <td>Carbonate Position Index (wavelength in nm)</td>
              <td>—</td></tr>
        </table>

        <p><b>CPI mineral boundaries:</b></p>
        <table border="1" cellpadding="3" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>CPI value (nm)</th><th>Mineral</th><th>Formula</th>
          </tr>
          <tr><td>&lt; 2318 nm</td><td>Magnesite</td><td>MgCO₃</td></tr>
          <tr><td>2318–2333 nm</td><td>Dolomite / Ankerite</td>
              <td>CaMg(CO₃)₂ / Ca(Fe,Mg)(CO₃)₂</td></tr>
          <tr><td>&gt; 2333 nm</td><td>Calcite / Limestone</td><td>CaCO₃</td></tr>
          <tr><td>NaN</td><td>No carbonate signal</td><td>—</td></tr>
        </table>

        <p><b>Full discrimination table (USGS splib07 / GMEX AusSpec 2005):</b></p>
        <table border="1" cellpadding="3" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Mineral</th><th>BD2315</th><th>BD2328</th>
            <th>BD2342</th><th>BD2160 pos.</th><th>CPI</th>
          </tr>
          <tr><td><b>Magnesite</b></td>
              <td>HIGH</td><td>low</td><td>low</td>
              <td>~2135 nm</td><td>&lt;2318</td></tr>
          <tr><td><b>Dolomite</b></td>
              <td>low</td><td>HIGH</td><td>low</td>
              <td>~2145 nm</td><td>2318–2333</td></tr>
          <tr><td><b>Ankerite</b></td>
              <td>low</td><td>mod</td><td>mod</td>
              <td>~2153 nm</td><td>2328–2340</td></tr>
          <tr><td><b>Calcite / Limestone</b></td>
              <td>low</td><td>low</td><td>HIGH</td>
              <td>~2155 nm</td><td>&gt;2333</td></tr>
        </table>

        <p><b>CPI display:</b> Apply a diverging colour ramp (e.g. RdYlBu reversed)
        stretched from 2295 to 2360 nm.  Cool colours → magnesite; warm colours →
        calcite/limestone; mid-tones → dolomite.</p>

        <p><b>Limitations:</b></p>
        <ul>
          <li>Dolomite-calcite intergrowths produce intermediate CPI values (2328–2342 nm).
              Use Tetracorder for spectral unmixing in mixed carbonate terranes.</li>
          <li>Ankerite Ca(Fe,Mg)(CO₃)₂ overlaps the dolomite-calcite boundary
              (~2330–2340 nm); BD2160 position and Fe indices help distinguish it.</li>
          <li>Limestone is spectrally equivalent to calcite — rock-scale mixing at
              EnMAP's 30 m pixel may produce intermediate dolomite-calcite values.</li>
          <li>Atmospheric residuals near 2300–2400 nm can shift CPI by ~5 nm;
              good atmospheric correction (ATCOR/QUAC) is essential.</li>
          <li>Cross-validate CPI against the <b>DT 2100–2400</b> decision tree
              (magnesite/dolomite/ankerite/calcite outputs).</li>
        </ul>

        <p><b>Reference:</b><br/>
        Clark, R.N. et al. (2007). USGS Digital Spectral Library splib07a.
        USGS Data Series 231.  calcite_WS272, dolomite_HS102.3B,
        magnesite_LACB02A.<br/>
        AusSpec International (2005). GMEX Expert System Reference Spectra.<br/>
        van Ruitenbeek et al. (2025). Remote Sensing 17(15), 2555.</p>
        """

    def createInstance(self):
        return CarbonateIndexAlgorithm()
