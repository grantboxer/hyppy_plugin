"""
Feature Extraction — 1480W

WoM range 1440-1520 nm, wavelength map stretch 1471-1491 nm.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe1480WAlgorithm(FEWomBase):
    WOM_START = 1440.0
    WOM_END   = 1520.0
    MAP_MIN   = 1471.0
    MAP_MAX   = 1491.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2
    def name(self):        return 'fe_1480w'

    def displayName(self): return 'FE04 - 1480W'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + BOUNDARY_NOTE + """
        <b>Feature Extraction — 1480W  (Amphibole / Chlorite OH)</b>

        <p>Targets the OH combination absorption near <b>~1480 nm</b>, present in
        amphiboles and chlorites, immediately longward of the atmospheric water vapour
        zone. Derived from USGS GMEX reference spectra for tremolite and chlorite.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>1440-1520 nm</b>.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>1471-1491 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>1440-1520 nm</td></tr>
          <tr><td>Colour stretch min</td><td>1471 nm</td></tr>
          <tr><td>Colour stretch max</td><td>1491 nm</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>~1480 nm feature — mineral associations (GMEX):</b></p>
        <ul>
          <li><b>Tremolite / Actinolite</b> — OH combination at ~1480 nm; amphibole group</li>
          <li><b>Chlorite</b> — Mg-OH combination absorption in this range</li>
          <li><b>Phlogopite / Biotite</b> — OH feature near 1480 nm (mica group)</li>
          <li><b>Epidote</b> — weak OH feature; confirm with longer-wave features</li>
        </ul>

        <p>This window immediately follows the atmospheric water vapour zone (1340–1445 nm).
        On AVIRIS-NG data with BBL masking active, the first few bands (1440–1445 nm)
        may be masked — the WoM will shift slightly longward but remain valid from ~1445 nm.</p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, tremolite and chlorite entries.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe1480WAlgorithm()
