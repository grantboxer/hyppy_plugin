"""
Feature Extraction — 1396W  (Pyrophyllite OH Absorption)

Targets the single sharp OH absorption of pyrophyllite at ~1396 nm.

From GMEX pyrophyllite (AusSpec International 2005):
  ~1396 nm — OH stretch.
    GMEX annotation: "Single sharp absorption."
    Pyrophyllite shows a single OH band here, in contrast to kaolinite's
    diagnostic doublet at ~1400/1412 nm and dickite's doublet at
    ~1384/1418 nm.  The single-peak character and slightly shorter
    position (~1396 nm) distinguish pyrophyllite from the kandite group.

WoM range:  1380-1420 nm  (tightly focused on the single pyrophyllite peak)
Stretch:    1388-1406 nm  (resolves position vs kaolinite ~1400-1412 nm)

Note: This range overlaps with FE03-1400D (kaolinite doublet 1385-1430 nm)
and FE01-1384D (dickite doublet 1370-1435 nm).  This tool uses a narrower
range and tighter stretch to resolve the pyrophyllite single-peak character.
All three tools are useful together for kandite + pyrophyllite discrimination
from satellite data (atmospheric water vapour absorption typically masks
this region in airborne data).

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe1396WAlgorithm(FEWomBase):
    WOM_START = 1350.0
    WOM_END   = 1450.0
    MAP_MIN   = 1385.0
    MAP_MAX   = 1410.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.15
    def name(self):        return 'fe_1396w'

    def displayName(self): return 'FE02 - 1396W  (Pyrophyllite OH)'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + BBL_NOTE + """
        <b>Feature Extraction — 1396W  (Pyrophyllite OH Absorption)</b>

        <p>Targets the single sharp OH absorption of pyrophyllite at <b>~1396 nm</b>,
        derived from the USGS GMEX pyrophyllite reference spectrum
        (AusSpec International 2005).</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>1380-1420 nm</b>.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>1388-1406 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>1380-1420 nm</td></tr>
          <tr><td>Colour stretch min</td><td>1388 nm</td></tr>
          <tr><td>Colour stretch max</td><td>1406 nm</td></tr>
          <tr><td>Default features</td><td>1 (single pyrophyllite peak)</td></tr>
          <tr><td>Depth max scale</td><td>0.15</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>~1396 nm OH character comparison (GMEX):</b></p>
        <ul>
          <li><b>Pyrophyllite</b> — single peak ~1396 nm; "Single sharp absorption"</li>
          <li><b>Kaolinite</b> — doublet ~1400/1412 nm (wider, longer wavelength)</li>
          <li><b>Dickite</b> — doublet ~1384/1418 nm (wider separation, shorter short-wave peak)</li>
        </ul>

        <p>The single-peak character at ~1396 nm and the absence of a longer-wavelength
        companion peak distinguishes pyrophyllite from the kandite group in satellite data.
        Pair with <b>FE08-2066D</b> (doublet) and <b>DT Pyrophyllite</b> for comprehensive
        pyrophyllite mapping.</p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength ~1396 nm, Band 2: depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, pyrophyllite entry
        (AusSpec International 2005). Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe1396WAlgorithm()
