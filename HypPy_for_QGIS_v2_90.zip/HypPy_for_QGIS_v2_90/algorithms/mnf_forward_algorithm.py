"""
MNF Forward Transform
=====================
Minimum Noise Fraction (MNF) forward transform for hyperspectral images.

Noise covariance is estimated from the spatial shift-difference image
(Green et al. 1988).  Signal covariance is computed in the same single
pass using Welford's online algorithm, so the image is read only twice
total (once for stats, once for the output MNF cube).

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import os
import pickle

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis,
)

from ..core.envi_header import (
    get_wavelengths_from_dataset,
    get_bbl_from_dataset,
    find_hdr,
    parse_hdr,
)

gdal.UseExceptions()

WORKFLOW_NOTE = """\
        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with wavelength metadata (ENVI format).<br/>
        Run <b>MNF Forward</b> → inspect SNR log → optionally run
        <b>FFT Stripe Filter</b> → run <b>MNF Inverse</b> with chosen band count.
        </p>
"""


def _log(msg, feedback=None):
    if feedback:
        feedback.pushInfo(msg)
    QgsMessageLog.logMessage(msg, 'HypPy MNF', Qgis.Info)


def _write_envi_hdr(path, lines, samples, bands, interleave='bil',
                    dtype_str='float32', band_names=None, wavelengths=None,
                    map_info=None, coord_sys=None, description=''):
    gdal_to_envi = {'float32': 4, 'float64': 5}
    envi_dt = gdal_to_envi.get(dtype_str, 4)
    out = ['ENVI']
    if description:
        out.append(f'description = {{{description}}}')
    out += [
        f'samples = {samples}',
        f'lines   = {lines}',
        f'bands   = {bands}',
        f'header offset = 0',
        f'file type = ENVI Standard',
        f'data type = {envi_dt}',
        f'interleave = {interleave}',
        f'byte order = 0',
    ]
    if band_names:
        out.append('band names = {' + ', '.join(band_names) + '}')
    if wavelengths:
        out.append('wavelength = {' + ', '.join(f'{w:.4f}' for w in wavelengths) + '}')
        out.append('wavelength units = Nanometers')
    if map_info:
        out.append(f'map info = {map_info}')
    if coord_sys:
        out.append(f'coordinate system string = {coord_sys}')
    hdr_path = path + '.hdr'
    with open(hdr_path, 'w') as f:
        f.write('\n'.join(out) + '\n')
    return hdr_path


class MnfForwardAlgorithm(QgsProcessingAlgorithm):
    """MNF Forward Transform — orders bands by signal-to-noise ratio."""

    INPUT        = 'INPUT'
    N_COMPONENTS = 'N_COMPONENTS'
    USE_BBL      = 'USE_BBL'
    OUTPUT       = 'OUTPUT'
    OUTPUT_STATS = 'OUTPUT_STATS'

    def __init__(self):
        super().__init__()
        self._bil_path = None   # set in processAlgorithm, used in postProcessAlgorithm

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Input hyperspectral cube (ENVI format)'))

        self.addParameter(QgsProcessingParameterNumber(
            self.N_COMPONENTS,
            'Number of MNF components to output  (0 = all bands)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=0, minValue=0))

        self.addParameter(QgsProcessingParameterBoolean(
            self.USE_BBL,
            'Exclude bad bands (use Bad Band List from ENVI header)',
            defaultValue=True))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT, 'Output MNF cube'))

        self.addParameter(QgsProcessingParameterFileDestination(
            self.OUTPUT_STATS,
            'Output MNF statistics file  (.mnf_stats)',
            fileFilter='MNF Stats (*.mnf_stats)',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        layer      = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n_comp_req = self.parameterAsInt(parameters, self.N_COMPONENTS, context)
        use_bbl    = self.parameterAsBoolean(parameters, self.USE_BBL, context)
        out_path   = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        stats_path = self.parameterAsFileOutput(parameters, self.OUTPUT_STATS, context)
        # stats_path is resolved after bil_path is determined (below)

        raster_path = layer.source()
        _log('=== HypPy MNF Forward ===', feedback)
        _log(f'Input: {raster_path}', feedback)

        ds = gdal.Open(raster_path, gdal.GA_ReadOnly)
        if ds is None:
            raise QgsProcessingException(f'Cannot open raster: {raster_path}')

        n_bands_raw = ds.RasterCount
        n_lines     = ds.RasterYSize
        n_samps     = ds.RasterXSize
        gt          = ds.GetGeoTransform()
        proj        = ds.GetProjection()

        wavelengths = get_wavelengths_from_dataset(ds, n_bands_raw, raster_path, feedback)
        bbl_raw     = get_bbl_from_dataset(ds, n_bands_raw, raster_path, feedback)

        # Band order: wavelength sort + BBL filter
        order = list(range(n_bands_raw))
        if wavelengths is not None:
            order = sorted(order, key=lambda i: wavelengths[i])
        if use_bbl and bbl_raw is not None:
            order = [i for i in order if bbl_raw[i]]
        n_bands    = len(order)
        n_comp     = n_comp_req if 0 < n_comp_req <= n_bands else n_bands
        wav_ord    = [wavelengths[i] for i in order] if wavelengths is not None else None
        gdal_bands = [b + 1 for b in order]

        _log(f'Image: {n_bands_raw} raw bands -> {n_bands} used, '
             f'{n_lines} lines x {n_samps} samples', feedback)
        _log(f'Outputting {n_comp} MNF components', feedback)

        # Map info
        map_info_str = coord_sys_str = None
        hdr = find_hdr(raster_path)
        if hdr:
            h = parse_hdr(hdr)
            map_info_str  = h.get('map info')
            coord_sys_str = h.get('coordinate system string')

        # Chunk size: target ~256 MB per chunk (float64)
        bytes_per_line = n_samps * n_bands * 8
        chunk_lines    = max(1, (256 * 1024 * 1024) // bytes_per_line)
        chunk_lines    = min(chunk_lines, n_lines)
        _log(f'Chunk size: {chunk_lines} lines '
             f'({bytes_per_line * chunk_lines / 1e6:.0f} MB)', feedback)

        # ── Pass 1: single-pass noise + signal covariance ─────────────────────
        # Noise cov (Cn): right-neighbour difference per chunk
        # Signal cov (Cs): Welford online mean+scatter, same loop
        feedback.setProgress(5)
        _log('Pass 1/2  Computing noise and signal covariance …', feedback)

        Cn      = np.zeros((n_bands, n_bands), dtype=np.float64)
        n_diff  = 0
        Xm      = np.zeros(n_bands, dtype=np.float64)
        Cs      = np.zeros((n_bands, n_bands), dtype=np.float64)
        n_valid = 0

        report_every = max(1, n_lines // 20)   # report ~20 times total
        lines_done   = 0

        while lines_done < n_lines:
            if feedback.isCanceled():
                return {}

            n_this = min(chunk_lines, n_lines - lines_done)
            raw = ds.ReadAsArray(
                xoff=0, yoff=lines_done,
                xsize=n_samps, ysize=n_this,
                band_list=gdal_bands,
            ).astype(np.float64)   # (n_bands, n_this, n_samps)

            # --- Noise covariance: right-neighbour differences ---------------
            D       = raw[:, :, 1:] - raw[:, :, :-1]   # (n_bands, n_this, n_samps-1)
            finite  = np.isfinite(raw)
            # column valid if both neighbours finite in all bands
            valid_c = (finite[:, :, 1:] & finite[:, :, :-1]).all(axis=0)  # (n_this, n_samps-1)
            D_safe  = np.where(np.isfinite(D), D, 0.0)

            for li in range(n_this):
                d = D_safe[:, li, valid_c[li]]   # (n_bands, n_valid_cols)
                if d.shape[1] > 0:
                    Cn     += d @ d.T
                    n_diff += d.shape[1]

            # --- Signal covariance: Welford online update --------------------
            pix = raw.reshape(n_bands, -1).T   # (n_this*n_samps, n_bands)
            valid_px = np.isfinite(pix).all(axis=1)
            pix_v    = pix[valid_px]

            if pix_v.shape[0] > 0:
                n_new   = pix_v.shape[0]
                delta   = pix_v - Xm
                Xm     += delta.sum(axis=0) / (n_valid + n_new)
                delta2  = pix_v - Xm
                Cs     += delta.T @ delta2
                n_valid += n_new

            lines_done += n_this

            if lines_done // report_every > (lines_done - n_this) // report_every \
                    or lines_done >= n_lines:
                pct = 5 + int(40 * lines_done / n_lines)
                feedback.setProgress(pct)
                _log(f'  {lines_done}/{n_lines} lines …', feedback)

        if n_diff == 0:
            raise QgsProcessingException('No valid pixel pairs for noise estimation.')
        if n_valid == 0:
            raise QgsProcessingException('No valid pixels for signal covariance.')

        Cn /= (2.0 * n_diff)
        Cs /= max(n_valid - 1, 1)
        _log(f'  Noise cov: {n_diff} diff pairs  |  Signal cov: {n_valid} pixels',
             feedback)

        # ── MNF eigenvectors ──────────────────────────────────────────────────
        feedback.setProgress(46)
        _log('Computing MNF eigenvectors (noise-whitened SVD) …', feedback)

        reg    = max(1e-10 * np.trace(Cn) / n_bands, 1e-15)
        Cn_reg = Cn + reg * np.eye(n_bands)
        try:
            L = np.linalg.cholesky(Cn_reg)
        except np.linalg.LinAlgError:
            _log('  Cholesky fallback to eigendecomposition', feedback)
            ev, evec = np.linalg.eigh(Cn_reg)
            ev = np.maximum(ev, 1e-12)
            L  = evec @ np.diag(np.sqrt(ev))

        L_inv     = np.linalg.inv(L)
        Cs_w      = L_inv @ Cs @ L_inv.T
        evals, evecs = np.linalg.eigh(Cs_w)
        idx       = np.argsort(evals)[::-1]
        evals     = evals[idx]
        evecs     = evecs[:, idx]
        A         = evecs.T @ L_inv   # (n_bands, n_bands) forward transform
        snr       = np.maximum(evals, 0.0)

        _log(f'SNR for first {min(20, n_comp)} MNF bands:', feedback)
        for i in range(min(20, n_comp)):
            _log(f'  MNF{i+1:3d}: SNR = {snr[i]:.4f}', feedback)
        if n_comp > 20:
            _log(f'  (showing first 20 of {n_comp})', feedback)

        feedback.setProgress(50)

        # ── Pass 2: write MNF cube as ENVI BIL ───────────────────────────────
        # Use the declared output path but ensure .bil extension so QGIS / ENVI
        # can identify the format from the extension alone.
        bil_path = os.path.splitext(out_path)[0] + '.bil'
        # Resolve stats path now that bil_path is known
        if not stats_path or 'TEMPORARY' in stats_path.upper():
            stats_path = os.path.splitext(bil_path)[0] + '.mnf_stats'
        _log(f'Pass 2/2  Writing MNF cube ({n_comp} bands) as ENVI BIL …', feedback)
        _log(f'  Output: {bil_path}', feedback)
        A_sub = A[:n_comp, :]

        # Allocate file via ENVI driver (sets geotransform / projection in the
        # GDAL-managed .hdr), then close and write BIL bytes directly so the
        # physical interleave matches the header.
        drv = gdal.GetDriverByName('ENVI')
        if drv is None:
            raise QgsProcessingException('GDAL ENVI driver not available.')
        ds_out = drv.Create(bil_path, n_samps, n_lines, n_comp, gdal.GDT_Float32)
        if ds_out is None:
            raise QgsProcessingException(f'Cannot create output: {bil_path}')
        ds_out.SetGeoTransform(gt)
        ds_out.SetProjection(proj)
        ds_out.FlushCache()
        del ds_out   # close — we write raw BIL bytes next

        lines_done = 0
        with open(bil_path, 'wb') as raw_f:
            while lines_done < n_lines:
                if feedback.isCanceled():
                    raise QgsProcessingException('Cancelled by user.')

                n_this = min(chunk_lines, n_lines - lines_done)
                chunk = ds.ReadAsArray(
                    xoff=0, yoff=lines_done,
                    xsize=n_samps, ysize=n_this,
                    band_list=gdal_bands,
                ).astype(np.float64)   # (n_bands, n_this, n_samps)

                pix      = chunk.reshape(n_bands, -1).T    # (pixels, n_bands)
                nan_mask = ~np.isfinite(pix).all(axis=1)
                pix      = np.where(np.isfinite(pix), pix, 0.0)
                pix     -= Xm
                scores   = (A_sub @ pix.T).T               # (pixels, n_comp)
                scores[nan_mask] = np.nan

                # BIL layout: (line, band, sample)
                # scores shape: (n_this*n_samps, n_comp)
                # → reshape to (n_this, n_samps, n_comp) → transpose (n_this, n_comp, n_samps)
                s_bil = scores.reshape(n_this, n_samps, n_comp).transpose(0, 2, 1)
                raw_f.write(s_bil.astype(np.float32).tobytes())

                lines_done += n_this
                if lines_done // report_every > (lines_done - n_this) // report_every \
                        or lines_done >= n_lines:
                    feedback.setProgress(50 + int(44 * lines_done / n_lines))
                    _log(f'  {lines_done}/{n_lines} lines written …', feedback)

        del ds

        # Overwrite the GDAL-generated .hdr with a complete ENVI header
        _write_envi_hdr(
            bil_path, n_lines, n_samps, n_comp,
            interleave='bil',
            band_names=[f'MNF{i+1}' for i in range(n_comp)],
            map_info=map_info_str, coord_sys=coord_sys_str,
            description=f'MNF of {os.path.basename(raster_path)} ({n_comp} components)',
        )

        out_path = bil_path   # return the actual .bil path to QGIS
        self._bil_path = bil_path

        # ── Save stats ────────────────────────────────────────────────────────
        feedback.setProgress(96)
        _log(f'Writing MNF stats -> {stats_path}', feedback)
        with open(stats_path, 'wb') as f:
            pickle.dump({
                'Xm':          Xm,
                'A':           A,
                'snr':         snr,
                'order':       order,
                'wavelengths': wav_ord,
                'n_bands':     n_bands,
                'n_lines':     n_lines,
                'n_samps':     n_samps,
                'gt':          gt,
                'proj':        proj,
                'map_info':    map_info_str,
                'coord_sys':   coord_sys_str,
                'src_path':    raster_path,
            }, f)

        feedback.setProgress(100)
        _log('MNF Forward complete.', feedback)
        _log(f'  MNF cube:  {out_path}', feedback)
        _log(f'  Stats:     {stats_path}', feedback)
        _log('Next steps:', feedback)
        _log('  1. Load MNF cube — inspect first bands (coherent) vs last (noise).', feedback)
        _log('  2. Choose cutoff where SNR ~ 1.0 from log above.', feedback)
        _log('  3. Optionally run MNF FFT Stripe Filter (non-orthorectified only).', feedback)
        _log('  4. Run MNF Inverse with chosen band count.', feedback)

        return {self.OUTPUT: out_path, self.OUTPUT_STATS: stats_path}

    def postProcessAlgorithm(self, context, feedback):
        """Load the MNF cube into the QGIS map canvas.
        Runs on the main GUI thread after processAlgorithm completes."""
        try:
            from qgis.core import QgsRasterLayer, QgsProject
            from qgis.utils import iface

            if iface is None or not self._bil_path:
                return {}

            layer_name = os.path.splitext(os.path.basename(self._bil_path))[0]
            feedback.pushInfo('Loading into map canvas: %s' % layer_name)
            layer = QgsRasterLayer(self._bil_path, layer_name)

            if not layer.isValid():
                feedback.pushWarning(
                    'Layer not valid, cannot load: %s' % self._bil_path)
                return {}

            QgsProject.instance().addMapLayer(layer)
            iface.mapCanvas().setExtent(layer.extent())
            iface.mapCanvas().refresh()
            feedback.pushInfo('MNF cube added to map canvas.')

        except Exception as e:
            feedback.pushWarning('Could not load layer into QGIS: %s' % str(e))

        return {}

    def name(self):        return 'mnf_forward'
    def displayName(self): return 'MNF - Forward'
    def group(self):       return '6 - Spectral Processing Tools'
    def groupId(self):     return '6_spectral_processing'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>MNF Forward Transform</b>

        <p>Computes the Minimum Noise Fraction (MNF) transform (Green et al. 1988),
        ordering all spectral bands by decreasing signal-to-noise ratio (SNR).
        The image is read only twice — once for statistics, once for the output
        cube — keeping processing time reasonable for large scenes.</p>

        <p><b>Algorithm:</b></p>
        <ol>
          <li>Noise and signal covariance computed in a single pass:
              noise from right-neighbour spatial differences;
              signal from Welford&#x2019;s online algorithm.</li>
          <li>Noise-whitened SVD (Cholesky decomposition + eigendecomposition
              of whitened signal covariance).</li>
          <li>MNF cube written in a second pass.</li>
        </ol>

        <p><b>Choosing the inverse band count:</b> inspect the SNR log.
        Choose the band number where SNR drops below ~1.0.
        Typical values: EnMAP / PRISMA 40&#x2013;60 bands;
        AVIRIS-NG 80&#x2013;120 bands.</p>

        <p><b>Reference:</b><br/>
        Green, A.A. et al., 1988. IEEE TGRS 26(1), pp.65&#x2013;74.</p>
        """

    def createInstance(self):
        return MnfForwardAlgorithm()
