"""
Feature Extraction — 1900W  (Halloysite Interlayer Water)

Targets the broad H2O combination band of halloysite at ~1900 nm.

From GMEX kandite group comparison (USGS Spectral Library):
  Halloysite (hydrated) — deep, broad absorption centred ~1900 nm due to
    interlayer water molecules.  This feature is the primary spectral
    discriminator distinguishing halloysite from all other kandite-group
    minerals (kaolinite, dickite, nacrite) which show little or no 1900 nm
    absorption.
  Halloysite (dehydrated) — reduced but still present ~1900 nm feature,
    weaker than hydrated form.
  Kaolinite, Dickite, Nacrite — essentially absent or very weak ~1900 nm.

The 1900 nm feature is caused by H2O stretch+bend combination (v1+v2)
in interlayer water unique to the halloysite (10Å) polytype.
Dehydration collapses the interlayer to 7Å, reducing the water band.

WoM range:  1850-1960 nm  (full width of the halloysite water band)
Stretch:    1870-1940 nm  (resolves depth and wavelength shift of water band)

Note: Kaolinite also shows a minor ~1830 nm feature (noted in GMEX kaolinite2)
but this is much shallower than halloysite's 1900 nm band and at shorter
wavelengths.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe1900WAlgorithm(FEWomBase):
    WOM_START = 1850.0
    WOM_END   = 1960.0
    MAP_MIN   = 1870.0
    MAP_MAX   = 1940.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.35

    def _extra_wom_params(self, parameters, context):
        return {'BROAD': True}

    def _post_map_log(self, feedback):
        feedback.pushInfo('  Colour depth (Band 2) distinguishes halloysite from dry kandite minerals')

    def name(self):        return 'fe_1900w'

    def displayName(self): return 'FE07 - 1900W  (Halloysite Water Band)'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + AVIRIS_NOTE + """
        <b>Feature Extraction — 1900W  (Halloysite Interlayer Water)</b>

        <p>Targets the broad H₂O combination absorption of halloysite at <b>~1900 nm</b>,
        the primary spectral discriminator separating halloysite from all other kandite
        group minerals, derived from the USGS GMEX kandite group comparison spectra.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>1850-1960 nm</b>
              with <b>broad feature fitting</b> (the water band is wide).</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>1870-1940 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>1850-1960 nm</td></tr>
          <tr><td>Colour stretch min</td><td>1870 nm</td></tr>
          <tr><td>Colour stretch max</td><td>1940 nm</td></tr>
          <tr><td>Feature fitting</td><td>Broad (suited to wide water band)</td></tr>
          <tr><td>Depth max scale</td><td>0.35 (accommodates deep water band)</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>GMEX kandite group — 1900 nm feature by mineral:</b></p>
        <ul>
          <li><b>Halloysite (hydrated)</b> — deep broad ~1900 nm band; primary identifier</li>
          <li><b>Halloysite (dehydrated)</b> — reduced ~1900 nm band, still distinguishable</li>
          <li><b>Kaolinite</b> — essentially absent (minor ~1830 nm feature only)</li>
          <li><b>Dickite</b> — absent</li>
          <li><b>Nacrite</b> — absent</li>
        </ul>

        <p>The Band 2 (depth) output from this tool is the key input for
        <b>DT Kandite Classification</b> — deep 1900 nm = halloysite gate.</p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength ~1900 nm, Band 2: water band depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, kandite group spectra.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe1900WAlgorithm()
