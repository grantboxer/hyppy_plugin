"""
Feature Extraction — Shared Base Class
=======================================
FEWomBase provides the optional pre-computed WoM input pattern shared by
all standard Feature Extraction tools (FE01–FE18, FE-REE, FE-WOM-1440-1520).

Each subclass defines:
    WOM_START, WOM_END   — wavelength range for the WoM algorithm
    MAP_MIN, MAP_MAX     — colour stretch for the wavelength map
    DEPTH_MIN, DEPTH_MAX — depth stretch for the wavelength map
    _NUM_FEATURES_DEFAULT — default number of features (usually 1)

and implements:
    name(), displayName(), group(), groupId(), shortHelpString(),
    createInstance(), _legend_filename()  (e.g. '2200W_legend.png')

Optionally overrides:
    _extra_wom_params(parameters, context)  — dict of extra params for WoM call
    _post_map_log(feedback)                 — pushInfo lines after map step
    _wom_alg_id()                           — defaults to 'hyppy:wavelength_of_minimum'

Usage pattern
-------------
All subclasses gain two new parameters automatically:

  INPUT_WOM  (optional RasterLayer)
      A pre-computed WoM raster for this tool's wavelength range.
      When supplied, Step 1 (the WoM run) is skipped entirely.
      Leave blank to compute the WoM from the hyperspectral cube as before.

  OUTPUT_WOM (RasterDestination, optional)
      Where to save the WoM raster.  Only written when the WoM is actually
      computed (i.e. INPUT_WOM was not supplied).  If INPUT_WOM is
      supplied this output is ignored.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import os
import processing

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
)


class FEWomBase(QgsProcessingAlgorithm):
    """
    Abstract base for WoM-based Feature Extraction tools.

    Subclasses must define class attributes:
        WOM_START, WOM_END, MAP_MIN, MAP_MAX, DEPTH_MIN, DEPTH_MAX
    and implement the standard QgsProcessingAlgorithm abstract methods.
    """

    # ── Parameter IDs ─────────────────────────────────────────────────────────
    INPUT         = 'INPUT'
    INPUT_WOM     = 'INPUT_WOM'
    NUM_FEATURES  = 'NUM_FEATURES'
    OUTPUT_WOM    = 'OUTPUT_WOM'
    OUTPUT_MAP    = 'OUTPUT_MAP'
    LEGEND_OUTPUT = 'LEGEND_OUTPUT'

    # ── Defaults (override in subclass if needed) ──────────────────────────────
    _NUM_FEATURES_DEFAULT = 1

    # ── Hooks subclasses may override ─────────────────────────────────────────

    def _wom_alg_id(self):
        """Algorithm ID for the WoM step.  Override to use a different provider."""
        return 'hyppy:wavelength_of_minimum'

    def _extra_wom_params(self, parameters, context):
        """
        Extra parameters merged into the WoM call dict.
        Override to pass sensor-specific flags (e.g. BROAD=True).
        """
        return {}

    def _post_map_log(self, feedback):
        """
        Called after the colour map step completes.
        Override to push tool-specific stretch guidance or mineral notes.
        """
        pass

    def _legend_filename(self):
        """
        Basename of the auto-generated legend PNG when no path is supplied.
        Override in each subclass, e.g. return '2200W_legend.png'.
        """
        return f'{self.name()}_legend.png'

    # ── initAlgorithm ─────────────────────────────────────────────────────────

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT,
            'Hyperspectral cube'))

        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT_WOM,
            f'Pre-computed WoM raster ({self.WOM_START:.0f}–{self.WOM_END:.0f} nm)'
            '  — leave blank to compute from the cube',
            optional=True))

        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract (1–9)'
            '  [only used when computing the WoM]',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=self._NUM_FEATURES_DEFAULT,
            minValue=1, maxValue=9))

        p = QgsProcessingParameterRasterDestination(
            self.OUTPUT_WOM,
            f'Output WoM raster ({self.WOM_START:.0f}–{self.WOM_END:.0f} nm)'
            '  [only written when computed from the cube]',
            optional=True,
            createByDefault=False)
        self.addParameter(p)

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_MAP,
            f'Output Wavelength Map RGB ({self.MAP_MIN:.0f}–{self.MAP_MAX:.0f} nm stretch)'))

        self.addParameter(QgsProcessingParameterFileDestination(
            self.LEGEND_OUTPUT,
            'Output Colour Legend (PNG)',
            fileFilter='PNG Files (*.png)',
            optional=True))

    # ── processAlgorithm ──────────────────────────────────────────────────────

    def processAlgorithm(self, parameters, context, feedback):
        cube      = self.parameterAsRasterLayer(parameters, self.INPUT,     context)
        wom_layer = self.parameterAsRasterLayer(parameters, self.INPUT_WOM,  context)
        n         = self.parameterAsInt(parameters,        self.NUM_FEATURES, context)
        out_wom   = self.parameterAsOutputLayer(parameters, self.OUTPUT_WOM,  context)
        out_map   = self.parameterAsOutputLayer(parameters, self.OUTPUT_MAP,  context)
        legend_path = self.parameterAsFileOutput(parameters, self.LEGEND_OUTPUT, context)

        self._legend_path    = None
        wom_was_computed     = False

        # ── Step 1: Obtain WoM ───────────────────────────────────────────────
        if wom_layer is not None:
            # Pre-computed WoM supplied — skip the WoM run
            wom_path = wom_layer.source()
            feedback.pushInfo(
                f'Using pre-computed WoM: {wom_path}')
            feedback.pushInfo(
                f'  (Expected range: {self.WOM_START:.0f}–{self.WOM_END:.0f} nm)')
        else:
            # Compute WoM from the hyperspectral cube
            feedback.setProgress(5)
            feedback.pushInfo(
                f'Step 1/2  Wavelength of Minimum  '
                f'{self.WOM_START:.0f}–{self.WOM_END:.0f} nm …')

            extra = self._extra_wom_params(parameters, context)
            wom_params = {
                'INPUT':            cube,
                'START_WAVELENGTH': self.WOM_START,
                'END_WAVELENGTH':   self.WOM_END,
                'MODE':             0,
                'NUM_FEATURES':     n,
                'BROAD':            False,
                'USE_BBL':          True,
                'OUTPUT':           out_wom or 'TEMPORARY_OUTPUT',
                **extra,
            }

            wom_result = processing.run(
                self._wom_alg_id(),
                wom_params,
                context=context,
                feedback=feedback,
                is_child_algorithm=True,
            )
            if feedback.isCanceled():
                return {}

            wom_path        = wom_result['OUTPUT']
            wom_was_computed = True
            feedback.pushInfo(f'  WoM raster saved: {wom_path}')

        if feedback.isCanceled():
            return {}

        # ── Step 2: Wavelength Map ────────────────────────────────────────────
        feedback.setProgress(55)
        feedback.pushInfo(
            f'Step 2/2  Wavelength Mapping  '
            f'{self.MAP_MIN:.0f}–{self.MAP_MAX:.0f} nm stretch …')

        from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
        wma     = WavelengthMappingAlgorithm()
        palette = wma.create_rainbow_palette()

        map_path = wma._run_colour_mapping(
            wom_path, palette,
            self.MAP_MIN, self.MAP_MAX,
            self.DEPTH_MIN, self.DEPTH_MAX,
            out_map, feedback,
        )

        feedback.setProgress(88)
        feedback.pushInfo(f'  Wavelength map saved: {map_path}')

        # ── Step 3: Legend ────────────────────────────────────────────────────
        if not legend_path:
            legend_path = os.path.join(
                os.path.dirname(map_path), self._legend_filename())
        try:
            saved = wma.create_legend(
                legend_path, palette,
                self.MAP_MIN, self.MAP_MAX,
                self.DEPTH_MIN, self.DEPTH_MAX,
                feedback,
            )
            if saved:
                self._legend_path = saved
                feedback.pushInfo(f'  Colour legend saved: {saved}')
        except Exception as e:
            feedback.pushWarning(f'Legend generation failed: {e}')

        # ── Post-map log (tool-specific guidance) ─────────────────────────────
        self._post_map_log(feedback)

        feedback.setProgress(100)
        feedback.pushInfo(f'{self.displayName()} complete.')

        result = {
            self.OUTPUT_MAP:    map_path,
            self.LEGEND_OUTPUT: self._legend_path or '',
        }
        if wom_was_computed and out_wom:
            result[self.OUTPUT_WOM] = wom_path

        return result

    # ── postProcessAlgorithm ──────────────────────────────────────────────────

    def postProcessAlgorithm(self, context, feedback):
        if getattr(self, '_legend_path', None):
            from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
            WavelengthMappingAlgorithm()._show_legend_dock(
                self._legend_path, feedback)
        return {}
