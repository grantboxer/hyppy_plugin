"""
Feature Extraction — 2250W

WoM range 2230-2280 nm, wavelength map stretch 2248-2268 nm.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe2250WAlgorithm(FEWomBase):
    WOM_START = 2230.0
    WOM_END   = 2280.0
    MAP_MIN   = 2248.0
    MAP_MAX   = 2268.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2

    def _post_map_log(self, feedback):
        feedback.pushInfo('')
        feedback.pushInfo('─' * 60)
        feedback.pushInfo('GSWA Report 261 Table 4 — 2250D recommended display stretch:')
        feedback.pushInfo('  Gascoyne:  min = 0.01, max = 0.04')
        feedback.pushInfo('  Pilbara:   min = 0.02, max = 0.65')
        feedback.pushInfo('  (4th order polynomial fit reference: 2230–2280 nm)')
        feedback.pushInfo('  Targeted minerals: Chlorite, dark mica, epidote, jarosite, tourmaline')
        feedback.pushInfo('  Use as Green channel in FE-GSWA-RGB Mineral Groups composite')
        feedback.pushInfo('─' * 60)

    def name(self):        return 'fe_2250w'

    def displayName(self): return 'FE14 - 2250W'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2250W  (Chlorite / Serpentine Mg-OH)</b>

        <p>Targets Mg-OH combination absorptions near <b>~2248–2268 nm</b>,
        the primary diagnostic window for chlorite and serpentine group minerals.
        Derived from USGS GMEX reference spectra for chlorite and serpentine.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>2230-2280 nm</b>.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>2248-2268 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>2230-2280 nm</td></tr>
          <tr><td>Colour stretch min</td><td>2248 nm</td></tr>
          <tr><td>Colour stretch max</td><td>2268 nm</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>~2250 nm feature — mineral associations (GMEX):</b></p>
        <ul>
          <li><b>Chlorite</b> — Mg-OH combination at ~2250–2254 nm; shifts with Fe/Mg ratio (Fe-rich chlorite longer-wave)</li>
          <li><b>Antigorite / Lizardite (Serpentine)</b> — Mg-OH combination near ~2320 nm, but wing extends to ~2250 nm</li>
          <li><b>Talc</b> — Mg-OH feature at ~2248 nm; confirm with 2400 nm (FE18)</li>
          <li><b>Prehnite</b> — Ca-Al-OH feature near ~2250–2260 nm</li>
          <li><b>Epidote</b> — OH feature near ~2254 nm</li>
        </ul>

        <p>Position within the colour stretch encodes Mg/Fe substitution in chlorite:
        Blue (~2248 nm) = Mg-rich (clinochlore); Red (~2268 nm) = Fe-bearing (chamosite).
        Use together with FE15-2290W and FE16-2320W for full chlorite characterisation.</p>

        <p style="background-color:#e8f5e9; padding:6px; border-left:4px solid #388e3c;">
        <b>GSWA Report 261, Table 4 — Recommended stretch:</b><br/>
        4th order polynomial fit, continuum removal range: <b>2230–2280 nm</b><br/>
        Gascoyne: min = 0.01, max = 0.04 &nbsp;|&nbsp; Pilbara: min = 0.02, max = 0.65<br/>
        Note: the wide Pilbara range reflects strong chlorite/epidote signatures in
        mafic/ultramafic units of the Pilbara Craton.<br/>
        Use as <b>Green channel</b> in the FE-GSWA-RGB Mineral Groups composite
        (R=2200D, G=2250D, B=2160D).
        </p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, chlorite and serpentine entries.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe2250WAlgorithm()
