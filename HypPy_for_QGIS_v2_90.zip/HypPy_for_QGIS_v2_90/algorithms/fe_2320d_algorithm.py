"""
Feature Extraction — 2320D  (Amphibole / Talc / Biotite)

WoM range 2295-2400 nm, wavelength map stretch 2305-2385 nm.

Targets the diagnostic Mg-OH combination absorption doublet at
~2320 nm and ~2380 nm characteristic of amphiboles (actinolite,
tremolite), talc, and tri-octahedral micas (biotite/phlogopite).

Background (GSWA Report 261, §8.1, Figure 46-47):
    "Due to the high quality of EnMAP's reflectance spectra in the
    2300 to 2400 nm wavelength region, it was possible to identify
    amphibole-related spectral signatures characterised by strong
    absorption features at 2320 nm and 2380 nm, which could be used
    to map mafic and ultramafic rocks."
    — Laukamp et al. (2025) GSWA Report 261, §8.1

    A separate 'amphibole-talc abundance index' (EnMAP-derived) was
    produced in this study to identify known pegmatites of the Sisters
    Supersuite and highlight new potential pegmatite targets in the
    Tambourah area.

    SENSOR NOTE: PRISMA hyperspectral imagery has insufficient SNR
    in the 2300–2450 nm region for reliable amphibole mapping.
    This tool is recommended for EnMAP and EMIT data only.
    Use with PRISMA data is experimental — results may show strong
    noise artefacts.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe2320DAlgorithm(FEWomBase):
    WOM_START = 2295.0
    WOM_END   = 2400.0
    MAP_MIN   = 2305.0
    MAP_MAX   = 2385.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.15

    def _post_map_log(self, feedback):
        feedback.pushInfo('')
        feedback.pushInfo('─' * 60)
        feedback.pushInfo('GSWA Report 261 — recommended stretch:')
        feedback.pushInfo('  Map stretch: 2305–2385 nm (rainbow colour scheme)')
        feedback.pushInfo('  Blue = shorter wavelength (actinolite/tremolite ~2310 nm)')
        feedback.pushInfo('  Red  = longer wavelength  (biotite/phlogopite ~2380 nm)')
        feedback.pushInfo('─' * 60)

    def name(self):        return 'fe_2320d'

    def displayName(self): return 'FE-2320D  (Amphibole / Talc)  [EnMAP/EMIT recommended]'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2320D  (Amphibole / Talc)</b>

        <p>Targets the Mg-OH combination absorption doublet at <b>~2320 nm</b>
        and <b>~2380 nm</b> characteristic of amphiboles, talc, and tri-octahedral
        micas.  This wavelength range is particularly diagnostic for mafic and
        ultramafic rocks — greenstone belts, ultramafic sills, and amphibolites.</p>

        <p style="background-color:#fff3cd; padding:6px; border-left:4px solid #ffc107;">
        <b>⚠ Sensor note:</b> PRISMA hyperspectral imagery has insufficient SNR
        in the 2300–2450 nm range for reliable amphibole/talc mapping.
        EnMAP and EMIT are recommended for this feature
        (GSWA Report 261, §3.2 and §8.1, Figure 46–47).
        </p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>2295–2400 nm</td></tr>
          <tr><td>Map stretch min</td><td>2305 nm  (cool blue)</td></tr>
          <tr><td>Map stretch max</td><td>2385 nm  (warm red)</td></tr>
          <tr><td>Recommended sensor</td><td>EnMAP, EMIT</td></tr>
        </table>

        <p><b>Mineral associations:</b></p>
        <ul>
          <li><b>Actinolite / Tremolite</b> — ~2310–2320 nm + ~2380 nm doublet;
              mafic/ultramafic country rocks to pegmatites</li>
          <li><b>Talc</b> — strong ~2320 nm primary feature; Mg-rich ultramafics</li>
          <li><b>Phlogopite / Biotite</b> — ~2345 nm + ~2380 nm; dark mica in granites
              and pegmatites</li>
          <li><b>Hornblende</b> — broad ~2320 nm absorption; amphibolites</li>
        </ul>

        <p><b>Geological applications (GSWA Report 261, §8.1):</b></p>
        <ul>
          <li>Mapping greenstone belt mafic/ultramafic sequences</li>
          <li>Identifying pegmatite-hosting ultramafic rocks (e.g. Sisters Supersuite,
              Tambourah area)</li>
          <li>Distinguishing prehnite from white mica in metamorphic terranes</li>
          <li>Mapping amphibolites and dolerites (complement to CBEai)</li>
        </ul>

        <p>Combine with FE14-2250W (chlorite/epidote) and FE15-2290W (chlorite
        long-wave) for a comprehensive Mg-OH mineral suite.</p>

        <p><i>Background: Laukamp, C., Miles, A.J. et al. (2025) GSWA Report 261,
        §8.1, Figure 46–47 (EnMAP amphibole-talc abundance index).</i></p>
        """

    def createInstance(self): return Fe2320DAlgorithm()
