"""
MNF FFT Stripe Filter
=====================
Removes along-track striping artefacts from an MNF cube using a 2D FFT
low-pass filter in the along-track (line) direction.

This is the optional Step 3 in the MNF workflow described by Gadea et al.
(2024), applied between MNF Forward and MNF Inverse:

    Reflectance cube → MNF Forward → [FFT Stripe Filter] → MNF Inverse
                                              ↑
                                     this tool

The filter works per MNF band:
  1. Compute the 2D FFT of the MNF band.
  2. Zero out high-frequency components in the along-track (row/line)
     direction beyond a user-specified cutoff frequency.
  3. Inverse FFT to recover the filtered band.

The cutoff is expressed as a fraction of the Nyquist frequency (0–1):
  0.0 = no filtering (pass-through)
  1.0 = block all frequencies (zeroes output — not useful)
  0.05–0.15 = typical range for moderate stripe removal

Only apply this step if the un-filtered MNF cube shows visible striping.
For orthorectified data, stripes become sinuous rather than linear and
this filter is less effective (skip it in that case).

Reference:
  Gadea, O.C.A. and Khan, S.D., 2024. Identification of a Potential
  Rare Earth Element Deposit at Ivanpah Dry Lake, California Through
  the Bastnäsite Indices. Remote Sensing, 16, 4540.

  Pande-Chhetri, R. and Abd-Elrahman, A., 2013. Filtering high-resolution
  hyperspectral imagery in a maximum noise fraction transform domain
  using wavelet-based de-striping. International Journal of Remote Sensing,
  34(7), pp.2216-2235.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import os
import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis,
)

gdal.UseExceptions()

WORKFLOW_NOTE = """\
        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Optional step</b> between <b>MNF Forward</b> and <b>MNF Inverse</b>.<br/>
        Only apply if the MNF cube shows visible along-track striping artefacts.<br/>
        Skip for orthorectified data (stripes become sinuous, not linear).
        </p>
"""


def _log(msg, feedback=None):
    if feedback:
        feedback.pushInfo(msg)
    QgsMessageLog.logMessage(msg, 'HypPy MNF', Qgis.Info)


class MnfFftStripeFilterAlgorithm(QgsProcessingAlgorithm):
    """MNF FFT Stripe Filter — removes along-track striping in MNF domain."""

    INPUT      = 'INPUT'
    CUTOFF     = 'CUTOFF'
    N_BANDS    = 'N_BANDS'
    OUTPUT     = 'OUTPUT'

    def __init__(self):
        super().__init__()
        self._bil_path = None   # set in processAlgorithm, used in postProcessAlgorithm

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT,
            'MNF cube  (from MNF Forward)'))

        self.addParameter(QgsProcessingParameterNumber(
            self.CUTOFF,
            'Along-track high-frequency cutoff  (fraction of Nyquist, 0.0–1.0)\n'
            '  0.05–0.15 = moderate stripe removal;  0.0 = no filtering',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.05, minValue=0.0, maxValue=1.0))

        self.addParameter(QgsProcessingParameterNumber(
            self.N_BANDS,
            'Number of MNF bands to filter  (0 = all bands)\n'
            '  Only coherent-signal bands need filtering — noise bands\n'
            '  will be discarded in MNF Inverse anyway',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=0, minValue=0))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT,
            'Output filtered MNF cube'))

    def processAlgorithm(self, parameters, context, feedback):
        layer     = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        cutoff    = self.parameterAsDouble(parameters, self.CUTOFF, context)
        n_req     = self.parameterAsInt(parameters, self.N_BANDS, context)
        out_path  = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        _log('=== HypPy MNF FFT Stripe Filter ===', feedback)

        ds = gdal.Open(layer.source(), gdal.GA_ReadOnly)
        if ds is None:
            raise QgsProcessingException(f'Cannot open raster: {layer.source()}')

        n_bands = ds.RasterCount
        n_lines = ds.RasterYSize
        n_samps = ds.RasterXSize
        gt      = ds.GetGeoTransform()
        proj    = ds.GetProjection()

        n_filter = n_req if 0 < n_req <= n_bands else n_bands
        _log(f'MNF cube: {n_bands} bands, {n_lines} lines × {n_samps} samples', feedback)
        _log(f'Filtering {n_filter} bands with cutoff = {cutoff:.3f} × Nyquist', feedback)

        if cutoff <= 0.0:
            _log('Cutoff = 0 — copying input unchanged', feedback)

        # Build the 1D frequency mask for the along-track (line) direction.
        # FFT frequencies for n_lines points: 0, 1/n, 2/n, ..., (n/2-1)/n, -n/2/n, ...
        # We zero out frequencies where |freq| > cutoff * 0.5 (Nyquist = 0.5)
        freqs   = np.fft.fftfreq(n_lines)          # cycles per sample
        mask_1d = (np.abs(freqs) <= cutoff * 0.5).astype(np.float32)  # (n_lines,)

        # Broadcast to 2D: (n_lines, n_samps) — same filter for every column
        mask_2d = mask_1d[:, np.newaxis] * np.ones(n_samps, dtype=np.float32)

        # Create output as ENVI BIL
        bil_path = os.path.splitext(out_path)[0] + '.bil'
        drv = gdal.GetDriverByName('ENVI')
        if drv is None:
            raise QgsProcessingException('GDAL ENVI driver not available.')
        ds_out = drv.Create(bil_path, n_samps, n_lines, n_bands, gdal.GDT_Float32)
        if ds_out is None:
            raise QgsProcessingException(f'Cannot create output: {bil_path}')
        ds_out.SetGeoTransform(gt)
        ds_out.SetProjection(proj)

        # Collect all filtered bands in BSQ order, then write as BIL
        all_bands   = []
        all_descs   = []
        for band_idx in range(n_bands):
            if feedback.isCanceled():
                del ds_out
                raise QgsProcessingException('Cancelled by user.')

            band_data = ds.GetRasterBand(band_idx + 1).ReadAsArray().astype(np.float32)
            desc      = ds.GetRasterBand(band_idx + 1).GetDescription()
            all_descs.append(desc)

            if band_idx < n_filter and cutoff > 0.0:
                nan_mask = ~np.isfinite(band_data)
                if nan_mask.any():
                    col_means = np.nanmean(band_data, axis=0)
                    col_means = np.where(np.isfinite(col_means), col_means, 0.0)
                    band_data = np.where(nan_mask, col_means[np.newaxis, :], band_data)
                fft2     = np.fft.fft2(band_data)
                fft2    *= mask_2d
                filtered = np.fft.ifft2(fft2).real.astype(np.float32)
                if nan_mask.any():
                    filtered[nan_mask] = np.nan
                _log(f'  Band {band_idx+1} ({desc}) — filtered', feedback)
            else:
                filtered = band_data

            all_bands.append(filtered)
            feedback.setProgress(int(90 * (band_idx + 1) / n_bands))

        del ds

        # Write BIL: flush GDAL metadata, then write raw bytes
        ds_out.FlushCache()
        del ds_out

        stacked = np.stack(all_bands, axis=0)   # (n_bands, n_lines, n_samps)
        # BIL layout: (line, band, sample) → transpose axes
        bil_data = stacked.transpose(1, 0, 2)   # (n_lines, n_bands, n_samps)
        with open(bil_path, 'wb') as raw_f:
            raw_f.write(bil_data.astype(np.float32).tobytes())

        # Write complete .hdr
        hdr_path = bil_path + '.hdr'
        with open(hdr_path, 'w') as f:
            f.write('ENVI\n')
            f.write(f'samples = {n_samps}\n')
            f.write(f'lines   = {n_lines}\n')
            f.write(f'bands   = {n_bands}\n')
            f.write('header offset = 0\n')
            f.write('file type = ENVI Standard\n')
            f.write('data type = 4\n')
            f.write('interleave = bil\n')
            f.write('byte order = 0\n')
            if all_descs:
                f.write('band names = {' + ', '.join(all_descs) + '}\n')
            if gt:
                f.write(f'map info = {{UTM, 1, 1, {gt[0]:.4f}, {gt[3]:.4f}, '
                        f'{abs(gt[1]):.4f}, {abs(gt[5]):.4f}}}\n')

        feedback.setProgress(100)
        _log('MNF FFT Stripe Filter complete.', feedback)
        _log(f'  Output (ENVI BIL): {bil_path}', feedback)
        _log('  Next: run MNF Inverse on this filtered cube.', feedback)

        self._bil_path = bil_path
        return {self.OUTPUT: bil_path}

    def postProcessAlgorithm(self, context, feedback):
        """Load the filtered MNF cube into the QGIS map canvas."""
        try:
            from qgis.core import QgsRasterLayer, QgsProject
            from qgis.utils import iface

            if iface is None or not self._bil_path:
                return {}

            layer_name = os.path.splitext(os.path.basename(self._bil_path))[0]
            feedback.pushInfo('Loading into map canvas: %s' % layer_name)
            layer = QgsRasterLayer(self._bil_path, layer_name)

            if not layer.isValid():
                feedback.pushWarning(
                    'Layer not valid, cannot load: %s' % self._bil_path)
                return {}

            QgsProject.instance().addMapLayer(layer)
            iface.mapCanvas().setExtent(layer.extent())
            iface.mapCanvas().refresh()
            feedback.pushInfo('MNF filtered cube added to map canvas.')

        except Exception as e:
            feedback.pushWarning('Could not load layer into QGIS: %s' % str(e))

        return {}

    def name(self):        return 'mnf_fft_stripe_filter'
    def displayName(self): return 'MNF - FFT Stripe Filter'
    def group(self):       return '6 - Spectral Processing Tools'
    def groupId(self):     return '6_spectral_processing'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>MNF FFT Stripe Filter</b>

        <p>Removes along-track striping artefacts from an MNF cube using a 1D
        low-pass filter applied in the along-track (line) direction via 2D FFT.
        This is an <b>optional step</b> between MNF Forward and MNF Inverse.</p>

        <p><b>When to use:</b></p>
        <ul>
          <li>When the MNF cube shows visible striping patterns running along
              the sensor's flight direction (columns of alternating bright/dark
              in individual MNF bands).</li>
          <li>For non-orthorectified data only — after orthorectification,
              stripes become sinuous and this filter is less effective.</li>
          <li>Typical sensors affected: PRISMA, DESIS, some HISUI scenes.</li>
        </ul>

        <p><b>Cutoff frequency:</b></p>
        <ul>
          <li>Expressed as a fraction of the Nyquist frequency (0.0–1.0).</li>
          <li>0.05 = block frequencies above 5% of Nyquist — strong filtering.</li>
          <li>0.10–0.15 = moderate filtering, good starting point.</li>
          <li>0.0 = no filtering (pass-through — useful for testing).</li>
          <li>Start with 0.05 and increase if stripes remain; decrease if
              spatial detail is being lost.</li>
        </ul>

        <p><b>N bands to filter:</b></p>
        <ul>
          <li>Only coherent-signal MNF bands need filtering.</li>
          <li>Set this to the same cutoff band count you plan to use in
              MNF Inverse — noise-dominated bands will be discarded anyway.</li>
          <li>0 = filter all bands (safe but unnecessary for noise bands).</li>
        </ul>

        <p><b>Reference:</b><br/>
        Pande-Chhetri, R. and Abd-Elrahman, A., 2013. Filtering
        high-resolution hyperspectral imagery in a maximum noise fraction
        transform domain using wavelet-based de-striping.
        <i>International Journal of Remote Sensing</i>, 34(7), pp.2216–2235.</p>
        """

    def createInstance(self):
        return MnfFftStripeFilterAlgorithm()
