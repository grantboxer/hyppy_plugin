"""
Feature Extraction — 2206W  (Kaolinite Primary Al-OH)

Targets the primary Al-OH absorption of kaolinite at ~2206 nm.

From GMEX kaolinite2 (USGS Spectral Library):
  ~2206 nm — deepest absorption; the main diagnostic feature of kaolinite.
  The 2162/2206 doublet is characteristic of kaolinite spectra.
  Variations in crystallinity shift and broaden this feature.
  Wavelength distinguishes kaolinite (~2206 nm) from illite (~2200 nm)
  and smectite (~2207-2210 nm).

WoM range:  2162-2245 nm  (captures the full 2162/2206 doublet)
Stretch:    2197-2215 nm  (resolves kaolinite vs illite vs smectite)

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe2206WAlgorithm(FEWomBase):
    WOM_START = 2120.0
    WOM_END   = 2245.0
    MAP_MIN   = 2197.0
    MAP_MAX   = 2215.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2

    def _post_map_log(self, feedback):
        feedback.pushInfo('  Blue = kaolinite (~2197 nm)  Red = smectite/shifted (~2215 nm)')

    def name(self):        return 'fe_2206w'

    def displayName(self): return 'FE13 - 2206W  (Kaolinite Al-OH)'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2206W  (Kaolinite Primary Al-OH)</b>

        <p>Targets the primary diagnostic absorption of kaolinite at <b>~2206 nm</b>
        derived from the USGS GMEX kaolinite2 reference spectrum.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>2162-2245 nm</b>
              (the full kaolinite 2162/2206 doublet region).</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>2197-2215 nm</b>
              to resolve kaolinite from illite and smectite.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>2162-2245 nm</td></tr>
          <tr><td>Colour stretch min</td><td>2197 nm (kaolinite)</td></tr>
          <tr><td>Colour stretch max</td><td>2215 nm (smectite / shifted)</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue = kaolinite, Red = shifted)</td></tr>
        </table>

        <p><b>GMEX kaolinite2 diagnostic features (USGS Spectral Library):</b></p>
        <ul>
          <li>~1400 + 1412 nm — OH stretch doublet (crystallinity indicator)</li>
          <li>~1830 nm — H₂O/OH (present in highly crystalline kaolinites)</li>
          <li>~2162 nm — Al-OH combination shoulder</li>
          <li><b>~2206 nm — Primary Al-OH (deepest, main diagnostic)</b></li>
          <li>~2312, ~2350, ~2380 nm — weaker Al-OH features</li>
        </ul>

        <p><b>Mineral discrimination (colour stretch 2197-2215 nm):</b></p>
        <ul>
          <li><b>Blue (~2197-2203 nm)</b> — well-ordered kaolinite</li>
          <li><b>Green (~2203-2207 nm)</b> — kaolinite / mixed</li>
          <li><b>Yellow-Red (~2207-2215 nm)</b> — smectite or disordered kaolinite</li>
        </ul>

        <p><i>Use FE13 together with FE10-2160D to compute the kaolinite crystallinity
        index (DT-Kaol-Cryst tool). See also dt_ill_kaol for illite/kaolinite
        discrimination.</i></p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, kaolinite2 entry.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe2206WAlgorithm()
