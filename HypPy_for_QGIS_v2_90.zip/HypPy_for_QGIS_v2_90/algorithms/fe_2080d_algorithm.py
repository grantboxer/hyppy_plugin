"""
Feature Extraction — 2080D

WoM range 2060.0-2100.0 nm, wavelength map stretch 2075.0-2090.0 nm.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe2080DAlgorithm(FEWomBase):
    WOM_START = 2060.0
    WOM_END   = 2100.0
    MAP_MIN   = 2075.0
    MAP_MAX   = 2090.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2
    def name(self):        return 'fe_2080d'

    def displayName(self): return 'FE09 - 2080D'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2080D  (Illite / Muscovite Al-OH)</b>

        <p>Targets the Al-OH combination absorption near <b>~2080 nm</b>, present in
        illite, muscovite, and phengite. This feature is broader and less structured
        than the pyrophyllite doublet at 2066/2078 nm (FE08), and is the primary
        2080 nm indicator for white micas. Derived from USGS GMEX reference spectra
        for illite and muscovite.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>2060-2100 nm</b>.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>2075-2085 nm</b>
              (narrow, to resolve single-peak position within the mica group).</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>2060-2100 nm</td></tr>
          <tr><td>Colour stretch min</td><td>2075 nm</td></tr>
          <tr><td>Colour stretch max</td><td>2085 nm</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>~2080 nm feature — mineral associations (GMEX):</b></p>
        <ul>
          <li><b>Illite</b> — broad Al-OH feature centred ~2080 nm; width distinguishes from pyrophyllite doublet</li>
          <li><b>Muscovite</b> — Al-OH combination at ~2080 nm; confirm with strong 2200 nm feature</li>
          <li><b>Phengite</b> — Al-OH feature shifts slightly with Si substitution; use with 2200 nm</li>
          <li><b>Pyrophyllite</b> — doublet at ~2066/2078 nm (see FE08-2066D for cleaner separation)</li>
        </ul>

        <p>The narrow colour stretch (2075–2085 nm) resolves subtle position shifts within
        the white mica group. Use FE08-2066D alongside this tool to separate pyrophyllite
        (doublet character) from illite/muscovite (single broad absorption).</p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, illite and muscovite entries.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe2080DAlgorithm()
