"""
Feature Extraction — 2160D

WoM range 2138-2179 nm, wavelength map stretch 2159-2166 nm.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe2160DAlgorithm(FEWomBase):
    WOM_START = 2138.0
    WOM_END   = 2179.0
    MAP_MIN   = 2159.0
    MAP_MAX   = 2166.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2

    def _post_map_log(self, feedback):
        feedback.pushInfo('')
        feedback.pushInfo('─' * 60)
        feedback.pushInfo('GSWA Report 261 Table 4 — 2160D recommended display stretch:')
        feedback.pushInfo('  Gascoyne:  min = 0.04, max = 0.15')
        feedback.pushInfo('  Pilbara:   min = 0.02, max = 0.15')
        feedback.pushInfo('  (4th order polynomial fit reference: 2140–2200 nm)')
        feedback.pushInfo('  Targeted minerals: Kaolinite, pyrophyllite, alunite')
        feedback.pushInfo('─' * 60)

    def name(self):        return 'fe_2160d'

    def displayName(self): return 'FE10 - 2160D'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2160D  (Pyrophyllite / Kaolinite Al-OH shoulder)</b>

        <p>Targets the Al-OH combination shoulder near <b>~2160–2166 nm</b>,
        the primary diagnostic feature of pyrophyllite and the companion shoulder
        to kaolinite's main 2206 nm absorption. The very narrow colour stretch
        (2159–2166 nm) is designed to resolve pyrophyllite from kaolinite on this
        feature alone. Derived from USGS GMEX reference spectra for pyrophyllite
        (AusSpec International 2005) and kaolinite.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>2138-2179 nm</b>.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>2159-2166 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>2138-2179 nm</td></tr>
          <tr><td>Colour stretch min</td><td>2159 nm (pyrophyllite)</td></tr>
          <tr><td>Colour stretch max</td><td>2166 nm (kaolinite shoulder)</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue = pyrophyllite, Red = kaolinite)</td></tr>
        </table>

        <p><b>~2160 nm feature — mineral associations (GMEX):</b></p>
        <ul>
          <li><b>Pyrophyllite</b> — primary Al-OH at ~2166 nm; \"single sharp absorption\"; main diagnostic feature</li>
          <li><b>Kaolinite</b> — Al-OH shoulder at ~2162 nm alongside the main 2206 nm peak</li>
          <li><b>Dickite</b> — Al-OH shoulder at ~2178 nm (longward; see FE11-2178D)</li>
          <li><b>Alunite</b> — Al-OH feature in this region; confirm with 2170 nm features</li>
        </ul>

        <p>The Band 2 (depth) output from this tool is used directly by
        <b>DT Pyrophyllite</b> as the primary detection gate.
        Use together with FE13-2206W to compute the kaolinite crystallinity index
        (ratio of 2162 nm shoulder to 2206 nm main feature).</p>

        <p style="background-color:#e8f5e9; padding:6px; border-left:4px solid #388e3c;">
        <b>GSWA Report 261, Table 4 — Recommended stretch (Gascoyne/Pilbara):</b><br/>
        4th order polynomial fit, continuum removal range: <b>2140–2200 nm</b><br/>
        Gascoyne: min = 0.04, max = 0.15 &nbsp;|&nbsp; Pilbara: min = 0.02, max = 0.15<br/>
        Use as <b>Blue channel</b> in the FE-GSWA-RGB Mineral Groups composite
        (R=2200D, G=2250D, B=2160D).
        </p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, pyrophyllite entry
        (AusSpec International 2005) and kaolinite2 entry.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe2160DAlgorithm()
