"""
Feature Extraction — 2320W

WoM range 2295-2345 nm, wavelength map stretch 2300-2340 nm.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe2320WAlgorithm(FEWomBase):
    WOM_START = 2295.0
    WOM_END   = 2345.0
    MAP_MIN   = 2300.0
    MAP_MAX   = 2340.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2
    def name(self):        return 'fe_2320w'

    def displayName(self): return 'FE16 - 2320W'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2320W  (Carbonate / Serpentine CO₃ &amp; Mg-OH)</b>

        <p>Targets carbonate CO₃ and serpentine Mg-OH combination absorptions near
        <b>~2300–2340 nm</b>. This is a key window for separating calcite, dolomite,
        and magnesite, and for detecting serpentine group minerals.
        Derived from USGS GMEX reference spectra for calcite, dolomite, and serpentine.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>2295-2345 nm</b>.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>2300-2340 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>2295-2345 nm</td></tr>
          <tr><td>Colour stretch min</td><td>2300 nm</td></tr>
          <tr><td>Colour stretch max</td><td>2340 nm</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>2300–2340 nm colour stretch — mineral positions (GMEX):</b></p>
        <ul>
          <li><b>Blue (~2295–2308 nm)</b> — <b>Magnesite</b> MgCO₃ (~2302 nm CO₃;
              GMEX: "note wavelength position which is diagnostic of Magnesite";
              <u>only absorption to persist in mixtures</u>)</li>
          <li><b>Cyan (~2308–2322 nm)</b> — <b>Dolomite</b> CaMg(CO₃)₂ (~2320–2328 nm CO₃;
              GMEX: "wavelength position diagnostic of dolomite;
              <u>this absorption is the only one to persist in mixtures</u>");
              also Phlogopite/Mg-chlorite/Serpentine Mg-OH</li>
          <li><b>Green (~2322–2328 nm)</b> — Pyrophyllite (~2319 nm Al-OH overtone;
              "persists in mixtures"); Saponite Mg-OH; Talc Mg-OH</li>
          <li><b>Yellow (~2328–2335 nm)</b> — <b>Ankerite</b> Ca(Mg,Fe²⁺,Mn)(CO₃)₂
              (~2330–2340 nm; GMEX: "only absorption that persists in mixtures")</li>
          <li><b>Red (~2335–2345 nm)</b> — <b>Calcite</b> CaCO₃ (~2340–2345 nm CO₃;
              GMEX: "diagnostic carbonate absorption;
              <u>this is the only absorption that persists in mixtures</u>")</li>
        </ul>

        <p><b>Key GMEX finding for carbonates:</b> Each carbonate has exactly one
        absorption that survives into mixed-mineral pixels. The WoM minimum wavelength
        in this range directly identifies the dominant carbonate species.</p>

        <p>This tool is one of the most mineral-rich in the suite. Use together with
        FE06-1760W and FE17-2350W for robust carbonate identification, and FE14-2250W
        for serpentine/Mg-OH confirmation. See also <b>DT 2100–2400</b> classifier.</p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, calcite, dolomite, and
        serpentine entries. Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe2320WAlgorithm()
