"""
Feature Extraction — Wavelength of Minimum 1440-1520 nm

Runs the Wavelength of Minimum algorithm over the 1440-1520 nm range
(water / hydroxyl combination band), saves the WoM raster, then
generates a wavelength map with a colour stretch of 1471-1491 nm and
displays the colour legend in a floating dock widget.

The colour mapping and legend are performed by calling the helper methods
directly on a WavelengthMappingAlgorithm instance so that postProcessAlgorithm
on THIS algorithm fires the dock — which works correctly when the FE tool
is run from the Processing Toolbox.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class FeWom1440_1520Algorithm(FEWomBase):
    WOM_START = 1440.0
    WOM_END   = 1520.0
    MAP_MIN   = 1471.0
    MAP_MAX   = 1491.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2
    def name(self):        return 'fe_wom_1440_1520'

    def displayName(self): return 'FE1 - Wavelength of Minimum 1440-1520 nm'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return '7_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + BOUNDARY_NOTE + """
        <b>Feature Extraction — Wavelength of Minimum 1440-1520 nm</b>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over the <b>1440-1520 nm</b>
              range (water / hydroxyl combination band).</li>
          <li>Generates a <b>Wavelength Map</b> with a colour stretch of
              <b>1471-1491 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <p><b>Spectral context (1440-1520 nm) — mineral associations (GMEX):</b></p>
        <ul>
          <li><b>Gypsum</b> CaSO₄·2H₂O — triple H₂O absorptions at ~1449, ~1490,
              ~1535 nm; three-band signature is unique to gypsum (GMEX)</li>
          <li><b>Alunite</b> (K,Na)Al₃(SO₄)₂(OH)₆ — OH doublet at ~1436/~1440 nm
              (short-wave) and ~1474–1480 nm (long-wave); the doublet separation
              and wavelength position distinguish alunite from kandite clays</li>
          <li><b>Jarosite</b> KFe₃(SO₄)₂(OH)₆ — FeOH doublet at ~1468–1477 nm
              and ~1512–1544 nm; longward position and doublet shape unique (GMEX)</li>
          <li><b>All OH-bearing sheet silicates</b> — broad OH overtone ~1400 nm
              (kaolinite, illite, chlorite etc.) extending into this window</li>
          <li><b>Gibbsite</b> Al(OH)₃ — OH absorptions at ~1452, ~1521, ~1549 nm;
              diagnostic triple absorption (GMEX)</li>
        </ul>

        <p><b>Use as input to DT Sulphate Group classifier:</b> The WoM output from
        this tool (Band 1 = wavelength, Band 2 = depth) is used as the
        <i>WoM 1440–1550 nm</i> input to the <b>DT Sulphate Group</b> algorithm.
        Note: extend the WoM range to 1550 nm when running for sulphate classification
        to capture the full jarosite FeOH doublet range (use Wavelength of Minimum
        directly with range 1440–1550 nm).</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>1440-1520 nm</td></tr>
          <tr><td>Colour stretch min</td><td>1471 nm</td></tr>
          <tr><td>Colour stretch max</td><td>1491 nm</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> - Band 1: wavelength of minimum,
              Band 2: feature depth (plus additional bands if N > 1).</li>
          <li><b>Wavelength Map RGB</b> - colour-coded map ready for
              display in QGIS.</li>
          <li><b>Colour Legend PNG</b> - 2-D legend showing hue vs depth;
              auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Mineral associations from USGS GMEX Spectral Library (AusSpec International
        2005), alunite, jarosite, gypsum and gibbsite entries.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return FeWom1440_1520Algorithm()
