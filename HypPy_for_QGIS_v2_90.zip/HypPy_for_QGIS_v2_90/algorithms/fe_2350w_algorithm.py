"""
Feature Extraction — 2350W

WoM range 2310-2370 nm, wavelength map stretch 2320-2366 nm.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe2350WAlgorithm(FEWomBase):
    WOM_START = 2310.0
    WOM_END   = 2370.0
    MAP_MIN   = 2320.0
    MAP_MAX   = 2366.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2
    def name(self):        return 'fe_2350w'

    def displayName(self): return 'FE17 - 2350W'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2350W  (Pyrophyllite / Calcite / Phengite Al-OH &amp; CO₃)</b>

        <p>Targets the pyrophyllite Al-OH overtone at <b>~2319 nm</b> plus the calcite
        CO₃ absorption at <b>~2335 nm</b> and phengite / muscovite Al-OH features near
        <b>~2345–2365 nm</b>. The pyrophyllite feature at ~2319 nm is noted in GMEX as
        persisting in mixed spectra. Derived from USGS GMEX reference spectra for
        pyrophyllite (AusSpec International 2005), calcite, and muscovite.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>2310-2370 nm</b>.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>2320-2366 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>2310-2370 nm</td></tr>
          <tr><td>Colour stretch min</td><td>2320 nm</td></tr>
          <tr><td>Colour stretch max</td><td>2366 nm</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>2320–2366 nm colour stretch — mineral positions (GMEX):</b></p>
        <ul>
          <li><b>Blue (~2320–2328 nm)</b> — Pyrophyllite Al-OH overtone (~2319 nm;
              GMEX: "persists in mixtures"); <b>Dolomite</b> CaMg(CO₃)₂ (~2320–2328 nm;
              GMEX: "only one to persist in mixtures")</li>
          <li><b>Cyan (~2328–2338 nm)</b> — <b>Ankerite</b> Ca(Mg,Fe²⁺)(CO₃)₂
              (~2330–2340 nm; GMEX: between dolomite and calcite, "only absorption
              that persists in mixtures"); Epidote FeOH (~2335–2342 nm)</li>
          <li><b>Green (~2338–2345 nm)</b> — <b>Calcite</b> CaCO₃ (~2340–2345 nm;
              GMEX: "diagnostic carbonate absorption; this is the only absorption
              that persists in mixtures"); Illite/Muscovite Al-OH secondary (~2347 nm)</li>
          <li><b>Yellow (~2345–2352 nm)</b> — Phlogopite Mg-OH (~2345 nm);
              Muscovite Al-OH secondary (~2342 nm; "two diagnostics persist in
              mixed spectra" — GMEX)</li>
          <li><b>Red (~2352–2366 nm)</b> — Phengite / Muscovite Al-OH overtone
              (~2350–2360 nm); Illite secondary (~2440 nm range, partially captured)</li>
        </ul>

        <p><b>Carbonate discrimination summary (GMEX):</b> In this stretch,
        dolomite (2320–2328 nm, blue) and calcite (2340–2345 nm, green) are
        clearly separated. Ankerite fills the gap between them (cyan).
        Combine with FE16-2320W and FE06-1760W for robust identification.</p>

        <p>Use this tool together with FE02-1396W, FE08-2066D, and FE10-2160D for
        comprehensive pyrophyllite mapping, and with FE06-1760W and FE16-2320W for
        carbonate suite discrimination.</p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, pyrophyllite entry
        (AusSpec International 2005), calcite, and muscovite entries.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe2350WAlgorithm()
