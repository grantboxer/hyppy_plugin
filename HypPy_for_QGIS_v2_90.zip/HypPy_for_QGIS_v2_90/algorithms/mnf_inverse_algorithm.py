"""
MNF Inverse Transform
=====================
Reconstructs a noise-reduced hyperspectral cube from a subset of MNF bands.

Output is written as ENVI BIL format (band-interleaved-by-line) with full
wavelength metadata preserved from the source cube, making it directly
compatible with HypPy Feature Extraction tools, WoM algorithms, Decision
Tree classifiers, and the Spectrum Viewer.

Requires the MNF cube (from MNF Forward or MNF FFT Stripe Filter) and
the .mnf_stats file produced by MNF Forward.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import os
import pickle

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterFile,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis,
)

gdal.UseExceptions()

WORKFLOW_NOTE = """\
        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required inputs:</b> MNF cube from <b>MNF Forward</b> and the
        corresponding <b>.mnf_stats</b> file.<br/>
        Output: ENVI BIL cube with wavelength metadata preserved — ready for
        Feature Extraction, WoM, and Decision Tree tools.
        </p>
"""


def _log(msg, feedback=None):
    if feedback:
        feedback.pushInfo(msg)
    QgsMessageLog.logMessage(msg, 'HypPy MNF', Qgis.Info)


def _write_envi_hdr(path, lines, samples, bands, interleave='bil',
                    band_names=None, wavelengths=None,
                    map_info=None, coord_sys=None, description=''):
    """Write ENVI .hdr sidecar with interleave field."""
    out = ['ENVI']
    if description:
        out.append(f'description = {{{description}}}')
    out += [
        f'samples = {samples}',
        f'lines   = {lines}',
        f'bands   = {bands}',
        f'header offset = 0',
        f'file type = ENVI Standard',
        f'data type = 4',    # float32
        f'interleave = {interleave}',
        f'byte order = 0',
    ]
    if band_names:
        out.append('band names = {' + ', '.join(band_names) + '}')
    if wavelengths:
        out.append('wavelength = {' + ', '.join(f'{w:.4f}' for w in wavelengths) + '}')
        out.append('wavelength units = Nanometers')
    if map_info:
        out.append(f'map info = {map_info}')
    if coord_sys:
        out.append(f'coordinate system string = {coord_sys}')
    hdr_path = path + '.hdr'
    with open(hdr_path, 'w') as f:
        f.write('\n'.join(out) + '\n')
    return hdr_path


class MnfInverseAlgorithm(QgsProcessingAlgorithm):
    """MNF Inverse Transform — noise-reduced ENVI BIL output."""

    INPUT_MNF   = 'INPUT_MNF'
    INPUT_STATS = 'INPUT_STATS'
    N_BANDS     = 'N_BANDS'
    OUTPUT      = 'OUTPUT'

    def __init__(self):
        super().__init__()
        self._bil_path = None   # set in processAlgorithm, used in postProcessAlgorithm

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT_MNF,
            'MNF cube  (from MNF Forward or MNF FFT Stripe Filter)'))

        self.addParameter(QgsProcessingParameterFile(
            self.INPUT_STATS,
            'MNF statistics file  (.mnf_stats)',
            extension='mnf_stats'))

        self.addParameter(QgsProcessingParameterNumber(
            self.N_BANDS,
            'Number of MNF bands to use for reconstruction\n'
            '(choose where SNR ≈ 1.0 from the MNF Forward log; 0 = all bands)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=0, minValue=0))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT,
            'Output noise-reduced hyperspectral cube  (ENVI BIL)'))

    def processAlgorithm(self, parameters, context, feedback):
        mnf_layer  = self.parameterAsRasterLayer(parameters, self.INPUT_MNF, context)
        stats_path = self.parameterAsFile(parameters, self.INPUT_STATS, context)
        n_keep_req = self.parameterAsInt(parameters, self.N_BANDS, context)
        out_path   = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        _log('=== HypPy MNF Inverse ===', feedback)

        # ── Load stats ────────────────────────────────────────────────────────
        if not os.path.isfile(stats_path):
            raise QgsProcessingException(f'Stats file not found: {stats_path}')
        with open(stats_path, 'rb') as f:
            stats = pickle.load(f)

        Xm          = stats['Xm']           # (n_bands,)
        A           = stats['A']            # (n_bands, n_bands)
        snr         = stats['snr']
        wavelengths = stats.get('wavelengths')
        n_bands     = stats['n_bands']
        n_lines     = stats['n_lines']
        n_samps     = stats['n_samps']
        gt          = stats['gt']
        proj        = stats['proj']
        map_info    = stats.get('map_info')
        coord_sys   = stats.get('coord_sys')
        src_path    = stats.get('src_path', '')

        n_keep = n_keep_req if 0 < n_keep_req <= n_bands else n_bands
        _log(f'Source cube:       {src_path}', feedback)
        _log(f'Spectral bands:    {n_bands}', feedback)
        _log(f'MNF bands to keep: {n_keep} / {n_bands}', feedback)
        if n_keep < n_bands:
            _log(f'Discarding MNF{n_keep+1}–MNF{n_bands} as noise', feedback)
        if n_keep <= len(snr):
            _log(f'SNR at cutoff (MNF{n_keep}):  {snr[n_keep-1]:.4f}', feedback)
        if n_keep < len(snr):
            _log(f'SNR just beyond  (MNF{n_keep+1}): {snr[n_keep]:.4f}', feedback)

        # ── Inverse transform ─────────────────────────────────────────────────
        # Forward: y = A @ (x - Xm)
        # Inverse using first n_keep bands (zero-fill rest):
        #   x_recon = A_inv @ y_trunc + Xm
        A_inv = np.linalg.pinv(A)   # (n_bands, n_bands)

        ds_mnf = gdal.Open(mnf_layer.source(), gdal.GA_ReadOnly)
        if ds_mnf is None:
            raise QgsProcessingException(f'Cannot open MNF cube: {mnf_layer.source()}')
        n_mnf_bands = ds_mnf.RasterCount
        n_use = min(n_keep, n_mnf_bands)
        if n_use < n_keep:
            _log(f'Warning: MNF cube has only {n_mnf_bands} bands — using {n_use}',
                 feedback)

        feedback.setProgress(10)

        # ── Create ENVI BIL output ────────────────────────────────────────────
        # GDAL ENVI driver allocates the file; we then write BIL bytes directly.
        drv = gdal.GetDriverByName('ENVI')
        if drv is None:
            raise QgsProcessingException('GDAL ENVI driver not available.')

        # The QGIS destination path will have a .tif extension; change to .bil
        bil_path = os.path.splitext(out_path)[0] + '_mnf_denoised.bil'

        ds_out = drv.Create(bil_path, n_samps, n_lines, n_bands, gdal.GDT_Float32)
        if ds_out is None:
            raise QgsProcessingException(f'Cannot create output: {bil_path}')
        ds_out.SetGeoTransform(gt)
        ds_out.SetProjection(proj)
        # Flush and close — we'll write BIL bytes directly
        ds_out.FlushCache()
        del ds_out

        # Chunk size: target ~256 MB
        bytes_per_line = n_samps * n_bands * 4   # float32
        chunk_lines    = max(1, (256 * 1024 * 1024) // bytes_per_line)
        chunk_lines    = min(chunk_lines, n_lines)
        report_every   = max(1, n_lines // 20)

        _log(f'Writing ENVI BIL: {n_bands} bands, {n_lines} lines, {n_samps} samples',
             feedback)
        _log(f'Chunk size: {chunk_lines} lines', feedback)

        lines_done = 0
        with open(bil_path, 'wb') as raw:
            while lines_done < n_lines:
                if feedback.isCanceled():
                    raise QgsProcessingException('Cancelled by user.')

                n_this = min(chunk_lines, n_lines - lines_done)

                # Read n_use MNF bands
                mnf_chunk = ds_mnf.ReadAsArray(
                    xoff=0, yoff=lines_done,
                    xsize=n_samps, ysize=n_this,
                    band_list=list(range(1, n_use + 1)),
                ).astype(np.float64).reshape(n_use, -1).T  # (pixels, n_use)

                nan_mask  = ~np.isfinite(mnf_chunk).all(axis=1)
                mnf_chunk = np.where(np.isfinite(mnf_chunk), mnf_chunk, 0.0)

                # Zero-pad discarded MNF bands
                if n_use < n_bands:
                    pad = np.zeros((mnf_chunk.shape[0], n_bands - n_use),
                                   dtype=np.float64)
                    y = np.concatenate([mnf_chunk, pad], axis=1)
                else:
                    y = mnf_chunk

                # Inverse transform: x = A_inv @ y.T + Xm
                x_recon = (A_inv @ y.T).T + Xm   # (pixels, n_bands)
                x_recon[nan_mask] = np.nan

                # Write BIL: (line, band, sample) order
                # x_recon shape: (n_this*n_samps, n_bands)
                # Reshape to (n_this, n_samps, n_bands) then transpose to
                # (n_this, n_bands, n_samps) for BIL layout
                x_3d = x_recon.reshape(n_this, n_samps, n_bands)   # (lines, samps, bands)
                x_bil = x_3d.transpose(0, 2, 1).astype(np.float32)  # (lines, bands, samps)
                raw.write(x_bil.tobytes())

                lines_done += n_this
                if lines_done // report_every > (lines_done - n_this) // report_every \
                        or lines_done >= n_lines:
                    feedback.setProgress(10 + int(85 * lines_done / n_lines))
                    _log(f'  {lines_done}/{n_lines} lines …', feedback)

        del ds_mnf

        # ── Write ENVI .hdr with wavelengths ──────────────────────────────────
        band_names = ([f'{w:.1f} nm' for w in wavelengths]
                      if wavelengths else [f'Band {i+1}' for i in range(n_bands)])
        _write_envi_hdr(
            bil_path, n_lines, n_samps, n_bands,
            interleave='bil',
            band_names=band_names,
            wavelengths=wavelengths,
            map_info=map_info, coord_sys=coord_sys,
            description=(f'MNF Inverse ({n_keep}/{n_bands} bands) '
                         f'of {os.path.basename(src_path)}'),
        )

        feedback.setProgress(100)
        _log('MNF Inverse complete.', feedback)
        _log(f'  Output (ENVI BIL): {bil_path}', feedback)
        _log(f'  Header:            {bil_path}.hdr', feedback)
        _log(f'  Bands: {n_bands}  (wavelengths preserved from source cube)', feedback)
        _log('Load the .bil file into QGIS and use as input to FE/WoM/DT tools.', feedback)

        # Return the .bil path — QGIS can load ENVI BIL as a raster layer
        self._bil_path = bil_path
        return {self.OUTPUT: bil_path}

    def postProcessAlgorithm(self, context, feedback):
        """Load the denoised cube into the QGIS map canvas."""
        try:
            from qgis.core import QgsRasterLayer, QgsProject
            from qgis.utils import iface

            if iface is None or not self._bil_path:
                return {}

            layer_name = os.path.splitext(os.path.basename(self._bil_path))[0]
            feedback.pushInfo('Loading into map canvas: %s' % layer_name)
            layer = QgsRasterLayer(self._bil_path, layer_name)

            if not layer.isValid():
                feedback.pushWarning(
                    'Layer not valid, cannot load: %s' % self._bil_path)
                return {}

            QgsProject.instance().addMapLayer(layer)
            iface.mapCanvas().setExtent(layer.extent())
            iface.mapCanvas().refresh()
            feedback.pushInfo('MNF denoised cube added to map canvas.')

        except Exception as e:
            feedback.pushWarning('Could not load layer into QGIS: %s' % str(e))

        return {}

    def name(self):        return 'mnf_inverse'
    def displayName(self): return 'MNF - Inverse'
    def group(self):       return '6 - Spectral Processing Tools'
    def groupId(self):     return '6_spectral_processing'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>MNF Inverse Transform</b>

        <p>Reconstructs a noise-reduced hyperspectral cube from a selected
        subset of MNF bands. Bands beyond the chosen cutoff are zero-filled
        before inversion, removing their noise contribution.</p>

        <p><b>Output format:</b> ENVI BIL (band-interleaved-by-line) with
        full wavelength metadata preserved from the source cube. The .bil file
        can be loaded directly into QGIS and used as input to all HypPy
        Feature Extraction, WoM, and Decision Tree tools. It is also
        compatible with the Spectrum Viewer for per-pixel spectrum display.</p>

        <p><b>Choosing the band count:</b></p>
        <ul>
          <li>Inspect the SNR values in the MNF Forward log.</li>
          <li>Choose N where SNR drops to approximately 1.0.</li>
          <li>Typical: EnMAP 40&#x2013;60, PRISMA 40&#x2013;60,
              AVIRIS-NG 80&#x2013;120.</li>
          <li>0 = use all bands (no noise removal).</li>
        </ul>
        """

    def createInstance(self):
        return MnfInverseAlgorithm()
