"""
Feature Extraction — 2290W

WoM range 2270.0-2320.0 nm, wavelength map stretch 2279.0-2338.0 nm.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe2290WAlgorithm(FEWomBase):
    WOM_START = 2270.0
    WOM_END   = 2320.0
    MAP_MIN   = 2279.0
    MAP_MAX   = 2338.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2
    def name(self):        return 'fe_2290w'

    def displayName(self): return 'FE15 - 2290W'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2290W  (Chlorite long-wave / Epidote Mg-OH)</b>

        <p>Targets Mg-OH and Fe-OH combination absorptions near <b>~2280–2315 nm</b>,
        present in Fe-bearing chlorites, epidote, and amphiboles. This window
        complements FE14-2250W by capturing the longer-wave Mg-OH feature that
        shifts with increasing Fe content. Derived from USGS GMEX reference spectra
        for chlorite, epidote, and actinolite.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>2270-2320 nm</b>.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>2279-2315 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>2270-2320 nm</td></tr>
          <tr><td>Colour stretch min</td><td>2279 nm</td></tr>
          <tr><td>Colour stretch max</td><td>2315 nm</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>~2290 nm feature — mineral associations (GMEX):</b></p>
        <ul>
          <li><b>Chlorite (Fe-bearing)</b> — Mg-OH/Fe-OH long-wave feature shifts toward ~2300–2315 nm</li>
          <li><b>Epidote</b> — Fe-OH combination near ~2285–2295 nm</li>
          <li><b>Actinolite / Tremolite</b> — Mg-OH combination near ~2310 nm</li>
          <li><b>Dolomite</b> — CO₃ combination at ~2314 nm; may overlap in carbonate settings</li>
        </ul>

        <p>The wide colour stretch (2279–2315 nm) captures the Fe/Mg compositional
        trend in chlorite: Blue = more Mg-rich; Red = more Fe-bearing.
        Use alongside FE14-2250W and FE16-2320W for chlorite vs carbonate discrimination.</p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, chlorite and epidote entries.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe2290WAlgorithm()
