"""
Wavelength of Minimum v2 Algorithm for QGIS Processing

Determines interpolated wavelength of minimum and depth of the deepest
absorption features in hyperspectral data.

Ported from HyPy minwavelength2.py / tkMinWavelength2.py
Original Author: Wim Bakker, University of Twente (w.h.bakker@utwente.nl)

Copyright (C) 2025 Grant Boxer
Original Copyright (C) 2018 Wim Bakker

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

v2.88: Parallelised via ThreadPoolExecutor (Windows-safe, no pickling required).
       Threads share memory — no inter-process data copying overhead.
       numpy/polyfit release the GIL so real parallel speedup is achieved.
"""

import os
import numpy as np
from concurrent.futures import ThreadPoolExecutor, as_completed
from osgeo import gdal

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterEnum,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis
)

from ..core.convex_hull import hull_resampled
from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset


# Band names for up to 9 features (wavelength, depth pairs)
BAND_NAMES = [
    'interpolated min. wav.',   'interpolated depth',
    'interpolated min. wav. 2', 'interpolated depth 2',
    'interpolated min. wav. 3', 'interpolated depth 3',
    'interpolated min. wav. 4', 'interpolated depth 4',
    'interpolated min. wav. 5', 'interpolated depth 5',
    'interpolated min. wav. 6', 'interpolated depth 6',
    'interpolated min. wav. 7', 'interpolated depth 7',
    'interpolated min. wav. 8', 'interpolated depth 8',
    'interpolated min. wav. 9', 'interpolated depth 9'
]


# ── Pure-function helpers (no QGIS references — safe to call from threads) ────

def _nohull(wavelengths, spectrum, mode):
    """Apply continuum removal using convex hull."""
    if mode == 'none':
        return spectrum.copy()
    try:
        points = np.column_stack((wavelengths, spectrum))
        hull_values = hull_resampled(points)[:, 1]
        if mode == 'div':
            hull_safe = np.where(hull_values != 0, hull_values, 1e-10)
            return spectrum / hull_safe
        elif mode == 'sub':
            return 1.0 + (spectrum - hull_values)
        else:
            return spectrum.copy()
    except Exception:
        return None


def _localminidx(spectrum, n=None):
    """Find indices of the n smallest local minima."""
    a = spectrum
    idx = np.where((a[1:-1] < a[:-2]) & (a[1:-1] < a[2:]))[0] + 1
    if n and len(idx):
        s = spectrum[idx]
        pairs = sorted(zip(s, idx))[:n]
        pairs = sorted(pairs, key=lambda x: x[1])
        if pairs:
            _, idx = zip(*pairs)
            idx = list(idx)
        else:
            idx = []
    return np.array(idx)


def _fitparabola(wavelengths, spectrum, idx, poly_degree=2):
    """Fit polynomial through points surrounding each local minimum."""
    results = []
    n = len(wavelengths)
    for i in idx:
        half = poly_degree // 2
        lo = max(0, i - half)
        hi = min(n - 1, i + half)
        while (hi - lo + 1) < poly_degree + 1 and (lo > 0 or hi < n - 1):
            if lo > 0:
                lo -= 1
            if hi < n - 1 and (hi - lo + 1) < poly_degree + 1:
                hi += 1
        x = wavelengths[lo:hi + 1]
        y = spectrum[lo:hi + 1]
        if len(x) < poly_degree + 1:
            results.append((wavelengths[i], spectrum[i]))
            continue
        try:
            coef = np.polyfit(x, y, poly_degree)
            if poly_degree == 2:
                a, b, c = coef
                if a != 0:
                    x_ext = -b / (2.0 * a)
                    results.append((x_ext, np.polyval(coef, x_ext)))
                else:
                    results.append((wavelengths[i], spectrum[i]))
            else:
                deriv_coef = np.polyder(coef)
                roots = np.roots(deriv_coef)
                real_roots = roots[np.isreal(roots)].real
                window_roots = real_roots[
                    (real_roots >= float(x[0])) & (real_roots <= float(x[-1]))
                ]
                if len(window_roots) > 0:
                    y_vals = np.polyval(coef, window_roots)
                    best = window_roots[np.argmin(y_vals)]
                    results.append((float(best), float(np.polyval(coef, best))))
                else:
                    results.append((wavelengths[i], spectrum[i]))
        except Exception:
            results.append((wavelengths[i], spectrum[i]))
    return results


def _fitparabola_broad(wavelengths, spectrum, idx, poly_degree=2):
    """Fit polynomial within half-depth window of each minimum."""
    results = []
    s = spectrum
    w = wavelengths
    for i in idx:
        lowidx = i - 1
        while lowidx - 1 > 0 and s[lowidx - 1] <= (s[i] + 1) / 2:
            lowidx -= 1
        highidx = i + 1
        while highidx + 1 < len(s) - 1 and s[highidx + 1] <= (s[i] + 1) / 2:
            highidx += 1
        x = w[lowidx:highidx + 1]
        y = s[lowidx:highidx + 1]
        if len(x) < poly_degree + 1:
            results.append((w[i], s[i]))
            continue
        try:
            coef = np.polyfit(x, y, poly_degree)
            if poly_degree == 2:
                a, b, c = coef
                if a != 0:
                    x_ext = -b / (2.0 * a)
                    results.append((x_ext, np.polyval(coef, x_ext)))
                else:
                    results.append((w[i], s[i]))
            else:
                deriv_coef = np.polyder(coef)
                roots = np.roots(deriv_coef)
                real_roots = roots[np.isreal(roots)].real
                window_roots = real_roots[
                    (real_roots >= float(x[0])) & (real_roots <= float(x[-1]))
                ]
                if len(window_roots) > 0:
                    y_vals = np.polyval(coef, window_roots)
                    best = window_roots[np.argmin(y_vals)]
                    results.append((float(best), float(np.polyval(coef, best))))
                else:
                    results.append((w[i], s[i]))
        except Exception:
            results.append((w[i], s[i]))
    return results


def _minwav(wavelengths, hull_removed, num_features, broad, poly_degree=2):
    """Calculate minimum wavelength positions and depths."""
    local_min_idx = _localminidx(hull_removed, num_features)
    if len(local_min_idx) == 0:
        return []
    if broad:
        fitted = _fitparabola_broad(wavelengths, hull_removed, local_min_idx, poly_degree)
    else:
        fitted = _fitparabola(wavelengths, hull_removed, local_min_idx, poly_degree)
    return sorted([(w, 1.0 - s) for w, s in fitted], key=lambda x: x[1], reverse=True)


def _process_row_chunk(row_start, row_end, image_data, wavs, bbl_mask,
                       mode, num_features, broad, poly_degree, output_data):
    """
    Process rows [row_start, row_end) and write results directly into output_data.

    Called from a thread — shares memory with the main thread, no pickling needed.
    numpy operations release the GIL so multiple threads run concurrently.

    Returns the number of rows processed (for progress tracking).
    """
    cols = image_data.shape[1]
    num_output_bands = output_data.shape[2]

    if bbl_mask is not None:
        bbl_bool = bbl_mask.astype(bool)
        working_wavs = wavs[bbl_bool]
    else:
        bbl_bool = None
        working_wavs = wavs

    for row in range(row_start, row_end):
        for col in range(cols):
            spec = image_data[row, col, :]
            if not (np.all(np.isfinite(spec)) and not np.all(spec == 0)):
                continue
            working_spec = spec[bbl_bool] if bbl_bool is not None else spec
            if len(working_wavs) < 3:
                continue
            hull_removed = _nohull(working_wavs, working_spec, mode)
            if hull_removed is None:
                continue
            minwavs = _minwav(working_wavs, hull_removed, num_features, broad, poly_degree)
            for k in range(len(minwavs)):
                output_data[row, col, 2 * k]     = minwavs[k][0]
                output_data[row, col, 2 * k + 1] = minwavs[k][1]

    return row_end - row_start


# ── Algorithm class ────────────────────────────────────────────────────────────

class WavelengthOfMinimumAlgorithm(QgsProcessingAlgorithm):
    """
    Wavelength of Minimum v2 Algorithm

    v2.88: ThreadPoolExecutor parallelism (Windows-safe).
    Threads share the image array — no inter-process data copying.
    numpy/polyfit release the GIL so real parallel speedup is achieved.
    """

    INPUT            = 'INPUT'
    START_WAVELENGTH = 'START_WAVELENGTH'
    END_WAVELENGTH   = 'END_WAVELENGTH'
    MODE             = 'MODE'
    NUM_FEATURES     = 'NUM_FEATURES'
    BROAD            = 'BROAD'
    USE_BBL          = 'USE_BBL'
    POLY_ORDER       = 'POLY_ORDER'
    OUTPUT           = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Input Hyperspectral Image'))
        self.addParameter(QgsProcessingParameterNumber(
            self.START_WAVELENGTH, 'Start Wavelength (nm)  [0 = use first band]',
            type=QgsProcessingParameterNumber.Double, defaultValue=0.0, minValue=0.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.END_WAVELENGTH, 'End Wavelength (nm)  [0 = use last band]',
            type=QgsProcessingParameterNumber.Double, defaultValue=0.0, minValue=0.0))
        self.addParameter(QgsProcessingParameterEnum(
            self.MODE, 'Continuum Removal Mode',
            options=['Division (recommended)', 'Subtraction', 'None (use original spectrum)'],
            defaultValue=0))
        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES, 'Number of features to match (1-9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=1, minValue=1, maxValue=9))
        self.addParameter(QgsProcessingParameterBoolean(
            self.BROAD, 'Broad feature fitting', defaultValue=False))
        self.addParameter(QgsProcessingParameterEnum(
            self.POLY_ORDER, 'Polynomial fit order',
            options=[
                '2nd order (quadratic)  — default, fast, suited to narrow/symmetric features',
                '4th order (quartic)    — improved fit for asymmetric or broad features',
            ], defaultValue=0))
        self.addParameter(QgsProcessingParameterBoolean(
            self.USE_BBL, 'Use Bad Band List (BBL)', defaultValue=True))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT, 'Output Wavelength Features'))

    def processAlgorithm(self, parameters, context, feedback):
        input_layer    = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        start_wav      = self.parameterAsDouble(parameters, self.START_WAVELENGTH, context)
        end_wav        = self.parameterAsDouble(parameters, self.END_WAVELENGTH, context)
        mode_idx       = self.parameterAsEnum(parameters, self.MODE, context)
        num_features   = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        broad          = self.parameterAsBool(parameters, self.BROAD, context)
        poly_order_idx = self.parameterAsEnum(parameters, self.POLY_ORDER, context)
        use_bbl        = self.parameterAsBool(parameters, self.USE_BBL, context)
        output_path    = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        modes = ['div', 'sub', 'none']
        mode = modes[mode_idx]
        poly_degree = 2 if poly_order_idx == 0 else 4

        feedback.pushInfo(f'Continuum removal mode: {mode}')
        feedback.pushInfo(f'Number of features: {num_features}')
        feedback.pushInfo(f'Broad feature fitting: {broad}')
        feedback.pushInfo(f'Polynomial fit order: {poly_degree}')

        input_ds = gdal.Open(input_layer.source(), gdal.GA_ReadOnly)
        if input_ds is None:
            raise QgsProcessingException('Failed to open input raster')

        cols      = input_ds.RasterXSize
        rows      = input_ds.RasterYSize
        num_bands = input_ds.RasterCount

        raster_path = input_layer.source()
        wavelengths = get_wavelengths_from_dataset(input_ds, num_bands, raster_path, feedback)
        if wavelengths is None:
            raise QgsProcessingException(
                'No wavelength information found. Image must have wavelength metadata '
                'in the ENVI domain, a sidecar .hdr file, or numeric band descriptions.'
            )

        if start_wav == 0.0:
            start_wav = float(wavelengths[0])
        if end_wav == 0.0:
            end_wav = float(wavelengths[-1])
        feedback.pushInfo(f'Wavelength range: {start_wav:.1f} - {end_wav:.1f} nm')

        bbl = None
        if use_bbl:
            bbl = get_bbl_from_dataset(input_ds, num_bands, raster_path, feedback)

        start_band = self._wavelength_to_index(wavelengths, start_wav)
        end_band   = self._wavelength_to_index(wavelengths, end_wav) + 1

        if start_band >= end_band:
            raise QgsProcessingException('Invalid wavelength range')

        wavs = wavelengths[start_band:end_band]

        bbl_mask = None
        if bbl is not None:
            bbl_mask = bbl[start_band:end_band]
            good_count = int(np.sum(bbl_mask))
            feedback.pushInfo(f'BBL: {good_count} of {len(bbl_mask)} bands are good in range')
            if good_count < 3:
                feedback.pushWarning(
                    f'Only {good_count} good band(s) remain in the {start_wav:.0f}-{end_wav:.0f} nm '
                    f'range after BBL masking (minimum required is 3). '
                    f'Output will be entirely NaN/fill values.'
                )

        feedback.pushInfo(f'Using bands {start_band} to {end_band-1} ({len(wavs)} bands)')

        num_output_bands = num_features * 2
        band_names = BAND_NAMES[:num_output_bands]

        feedback.pushInfo('Creating output raster...')
        driver = gdal.GetDriverByName('GTiff')
        output_ds = driver.Create(
            output_path, cols, rows, num_output_bands, gdal.GDT_Float64)
        output_ds.SetGeoTransform(input_ds.GetGeoTransform())
        output_ds.SetProjection(input_ds.GetProjection())
        for b, name in enumerate(band_names):
            band = output_ds.GetRasterBand(b + 1)
            band.SetDescription(name)
            band.SetNoDataValue(np.nan)

        feedback.pushInfo('Reading input data...')
        subset_bands = end_band - start_band
        image_data = np.zeros((rows, cols, subset_bands), dtype=np.float64)
        for b in range(subset_bands):
            if feedback.isCanceled():
                return {}
            image_data[:, :, b] = input_ds.GetRasterBand(start_band + b + 1).ReadAsArray()
            feedback.setProgress(int((b + 1) / subset_bands * 10))

        # ── Thread-parallel row processing ─────────────────────────────────────
        # ThreadPoolExecutor: threads share memory (no pickling), Windows-safe.
        # numpy and polyfit release the GIL so real parallel speedup is achieved.
        cpu_count = os.cpu_count() or 1
        n_workers = max(1, min(cpu_count - 1, 16))
        feedback.pushInfo(f'Processing pixels using {n_workers} threads '
                          f'(cpu_count={cpu_count})...')

        # Output array shared across all threads (each writes to non-overlapping rows)
        output_data = np.full((rows, cols, num_output_bands), np.nan, dtype=np.float64)

        # Divide rows evenly across workers
        row_boundaries = np.linspace(0, rows, n_workers + 1, dtype=int)
        chunks = [(int(row_boundaries[i]), int(row_boundaries[i + 1]))
                  for i in range(n_workers)
                  if row_boundaries[i] < row_boundaries[i + 1]]
        n_chunks = len(chunks)
        completed = 0

        with ThreadPoolExecutor(max_workers=n_workers) as executor:
            futures = {
                executor.submit(
                    _process_row_chunk,
                    r0, r1, image_data, wavs, bbl_mask,
                    mode, num_features, broad, poly_degree, output_data
                ): (r0, r1)
                for r0, r1 in chunks
            }
            for future in as_completed(futures):
                if feedback.isCanceled():
                    executor.shutdown(wait=False, cancel_futures=True)
                    return {}
                r0, r1 = futures[future]
                try:
                    future.result()
                except Exception as e:
                    feedback.pushWarning(f'Thread error for rows {r0}-{r1}: {e}')
                completed += 1
                feedback.setProgress(10 + int(completed / n_chunks * 85))
                feedback.pushInfo(f'  Chunk {completed}/{n_chunks} done '
                                  f'(rows {r0}-{r1-1})')

        feedback.pushInfo('Writing output...')
        for b in range(num_output_bands):
            if feedback.isCanceled():
                return {}
            output_ds.GetRasterBand(b + 1).WriteArray(output_data[:, :, b])
            output_ds.GetRasterBand(b + 1).FlushCache()

        output_ds = None
        input_ds = None
        feedback.setProgress(100)
        feedback.pushInfo('Complete!')
        return {self.OUTPUT: output_path}

    # ── Instance method wrappers (backward compatibility) ─────────────────────
    def nohull(self, wavelengths, spectrum, mode):
        return _nohull(wavelengths, spectrum, mode)

    def minwav(self, wavelengths, hull_removed, num_features, broad, poly_degree=2):
        return _minwav(wavelengths, hull_removed, num_features, broad, poly_degree)

    def localminidx(self, spectrum, n=None):
        return _localminidx(spectrum, n)

    def fitparabola(self, wavelengths, spectrum, idx, poly_degree=2):
        return _fitparabola(wavelengths, spectrum, idx, poly_degree)

    def fitparabola_broad(self, wavelengths, spectrum, idx, poly_degree=2):
        return _fitparabola_broad(wavelengths, spectrum, idx, poly_degree)

    def _wavelength_to_index(self, wavelengths, target):
        return int(np.argmin(np.abs(wavelengths - target)))

    def wavelength_to_index(self, wavelengths, target):
        return self._wavelength_to_index(wavelengths, target)

    def name(self):        return 'wavelength_of_minimum'
    def displayName(self): return 'Step 2b - Wavelength of Minimum (custom range)'
    def group(self):       return '3 - Generate WoM Rasters'
    def groupId(self):     return '3_generate_wom'

    def shortHelpString(self):
        return """
        <b>Wavelength of Minimum v2</b>

        <p>Determines the interpolated wavelength position and depth of absorption
        features in hyperspectral data. Based on HyPy minwavelength2.py by
        Wim Bakker, University of Twente.</p>

        <p style="background-color:#e8f5e9; padding:6px; border-left:4px solid #388e3c;">
        <b>v2.88 — Parallel processing:</b> Uses ThreadPoolExecutor (Windows-safe,
        no inter-process data copying). Threads share the image array in memory.
        numpy and polyfit release the GIL so real parallel speedup is achieved.
        Typical speedup: 3–6× on a 6–8 core machine.</p>

        <p><b>Process:</b></p>
        <ol>
        <li>Applies convex hull continuum removal to isolate absorption features</li>
        <li>Finds local minima in the specified wavelength range</li>
        <li>Fits parabolas to refine minimum positions and calculate depths</li>
        <li>Returns results sorted by depth (deepest feature first)</li>
        </ol>

        <p><b>Inputs:</b></p>
        <ul>
        <li><b>Input Image:</b> Hyperspectral image with wavelength metadata</li>
        <li><b>Start/End Wavelength:</b> Analysis range in nm (0 = use full range)</li>
        <li><b>Mode:</b> Division (recommended), Subtraction, or None</li>
        <li><b>Number of features:</b> 1–9 absorption features per pixel</li>
        <li><b>Broad feature fitting:</b> Wider window for broad absorptions</li>
        <li><b>Polynomial fit order:</b> 2nd order (fast, default) or 4th order</li>
        <li><b>Use BBL:</b> Apply bad band list from ENVI metadata</li>
        </ul>

        <p><b>Outputs (2 bands per feature):</b> Interpolated minimum wavelength + depth,
        sorted deepest first.</p>

        <p><i>Ported from HyPy by Wim Bakker, University of Twente</i></p>
        """

    def createInstance(self):
        return WavelengthOfMinimumAlgorithm()
