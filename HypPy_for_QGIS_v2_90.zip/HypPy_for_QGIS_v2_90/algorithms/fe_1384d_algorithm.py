"""
Feature Extraction — 1384D  (Dickite OH Doublet)

Targets the dickite OH stretch doublet at ~1384 and ~1418 nm.

From GMEX dickite (USGS Spectral Library):
  ~1384 + 1418 nm — "Diagnostic doublet. Note difference in wavelengths
  and intensities relative to Kaolinite and Halloysite."
  "Dickites may not always display as intense absorptions for the doublets,
  especially that around 1400nm."

  Compared to kaolinite (~1400/1412 nm):
    - Dickite shorter-wave peak shifts to ~1384 nm  (kaolinite ~1400 nm)
    - Dickite longer-wave peak shifts to ~1418 nm   (kaolinite ~1412 nm)
    - Intensity ratio differs: the ~1384 nm peak is typically stronger
      relative to the ~1418 nm peak in dickite vs kaolinite

WoM range:  1370-1435 nm  (captures both doublet peaks for dickite)
Stretch:    1378-1425 nm  (wider than kaolinite 1400D to resolve ~1384 nm)

Note: The 1400 nm region overlaps with atmospheric water vapour absorption.
In airborne data this region may be masked by BBL.  In well-corrected
satellite data (EnMAP, PRISMA) the doublet is often resolvable.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe1384DAlgorithm(FEWomBase):
    WOM_START = 1350.0
    WOM_END   = 1450.0
    MAP_MIN   = 1375.0
    MAP_MAX   = 1425.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.15
    _NUM_FEATURES_DEFAULT = 2

    def _post_map_log(self, feedback):
        feedback.pushInfo('  Blue = ~1378 nm (dickite shorter peak)  Red = ~1425 nm (longer peak)')

    def name(self):        return 'fe_1384d'

    def displayName(self): return 'FE01 - 1384D  (Dickite OH Doublet)'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + WATER_NOTE + """
        <b>Feature Extraction — 1384D  (Dickite OH Doublet)</b>

        <p>Targets the dickite OH stretch doublet at <b>~1384 and ~1418 nm</b>,
        derived from the USGS GMEX dickite reference spectrum.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>1370-1435 nm</b>
              (wider range than kaolinite 1400D to capture ~1384 nm short-wave peak).</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>1378-1425 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>1370-1435 nm</td></tr>
          <tr><td>Colour stretch min</td><td>1378 nm (dickite short-wave peak)</td></tr>
          <tr><td>Colour stretch max</td><td>1425 nm (dickite long-wave peak)</td></tr>
          <tr><td>Default features</td><td>2 (to detect both doublet peaks)</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>GMEX dickite — 1384D doublet characteristics:</b></p>
        <ul>
          <li><b>"Diagnostic doublet. Note difference in wavelengths and intensities
              relative to Kaolinite and Halloysite."</b></li>
          <li><b>"Dickites may not always display as intense absorptions for the doublets,
              especially that around 1400 nm."</b></li>
          <li>Shorter-wave peak at <b>~1384 nm</b> (kaolinite at ~1400 nm — 16 nm shorter)</li>
          <li>Longer-wave peak at <b>~1418 nm</b> (kaolinite at ~1412 nm — 6 nm longer)</li>
          <li>Total doublet separation (~34 nm) wider than kaolinite (~12 nm)</li>
        </ul>

        <p><b>Kaolin-group mineral discrimination using 1400 nm region doublets:</b></p>
        <ul>
          <li><b>Dickite</b>  — doublet at ~1384 + 1418 nm, wider separation</li>
          <li><b>Kaolinite</b> — doublet at ~1400 + 1412 nm, narrower separation</li>
          <li><b>Halloysite</b> — doublet weakened or absent due to interlayer water</li>
        </ul>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, dickite entry.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe1384DAlgorithm()
