"""
Feature Extraction — 2178D  (Dickite Al-OH Shoulder)

Targets the Al-OH combination shoulder of dickite at ~2178 nm.

From GMEX dickite (USGS Spectral Library):
  ~2178 nm — "Diagnostic doublet. Note difference in wavelength position
  and intensity of 2178 nm absorption relative to kaolinite."
  "This absorption persists in mixed spectra."

  Dickite's 2178 nm feature is shifted to LONGER wavelengths compared to
  kaolinite's ~2162 nm shoulder.  This ~16 nm shift is the primary
  spectral discriminator between the two minerals in the 2100-2250 nm
  region.

  The 2178/2206 nm pair in dickite corresponds to the 2162/2206 nm pair
  in kaolinite — same fundamental Al-OH doublet structure but shifted.

WoM range:  2155-2196 nm  (isolates the 2178 nm dickite feature,
                            excluding the longer-wave 2206 nm peak)
Stretch:    2168-2190 nm  (resolves dickite ~2178 nm from kaolinite ~2162 nm)

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe2178DAlgorithm(FEWomBase):
    WOM_START = 2138.0
    WOM_END   = 2210.0
    MAP_MIN   = 2162.0
    MAP_MAX   = 2196.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2

    def _post_map_log(self, feedback):
        feedback.pushInfo('  Blue = kaolinite shoulder (~2162 nm)  Red = dickite shoulder (~2178 nm)')

    def name(self):        return 'fe_2178d'

    def displayName(self): return 'FE11 - 2178D  (Dickite Al-OH Shoulder)'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2178D  (Dickite Al-OH Shoulder)</b>

        <p>Targets the Al-OH combination shoulder of dickite at <b>~2178 nm</b>,
        derived from the USGS GMEX dickite reference spectrum.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>2155-2196 nm</b>
              (isolates the 2178 nm dickite feature).</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>2168-2190 nm</b>
              to separate dickite from kaolinite.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>2155-2196 nm</td></tr>
          <tr><td>Colour stretch min</td><td>2168 nm (kaolinite-side)</td></tr>
          <tr><td>Colour stretch max</td><td>2190 nm (dickite-side)</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue = kaolinite, Red = dickite)</td></tr>
        </table>

        <p><b>GMEX dickite — 2178D diagnostic notes:</b></p>
        <ul>
          <li><b>"Diagnostic doublet. Note difference in wavelength position and
              intensity of 2178 nm absorption relative to kaolinite."</b></li>
          <li><b>"This absorption persists in mixed spectra"</b> — useful even
              in kaolinite/dickite mixtures.</li>
          <li>Dickite shoulder at ~2178 nm vs kaolinite shoulder at ~2162 nm —
              a ~16 nm shift that is the primary 2100-2250 nm discriminator.</li>
        </ul>

        <p><b>Kaolin-group mineral discrimination (2168-2190 nm stretch):</b></p>
        <ul>
          <li><b>Blue (~2168-2172 nm)</b> — kaolinite-dominant</li>
          <li><b>Green (~2172-2181 nm)</b> — mixed / transitional</li>
          <li><b>Red (~2181-2190 nm)</b> — dickite-dominant</li>
        </ul>

        <p><i>Use FE11 together with FE10-2160D and FE13-2206W to run the
        DT Dick-Kaol Classification for dickite vs kaolinite mapping.</i></p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, dickite entry.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe2178DAlgorithm()
