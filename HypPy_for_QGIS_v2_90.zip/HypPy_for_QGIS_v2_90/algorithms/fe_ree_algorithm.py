"""
Feature Extraction — REE  (Rare Earth Element — Neodymium absorptions)
=======================================================================
Targets four characteristic VNIR absorption features associated with
neodymium (Nd³⁺) in REE-bearing minerals, principally monazite,
and carbonatite host rocks.

Absorption bands (Boesche et al. 2015, Figure 1):
  ~580 nm   — Nd³⁺ absorption  (⁴G₅/₂ + ⁴G₇/₂  Stark-split group)
  ~740 nm   — Nd³⁺ absorption  (⁴F₇/₂ + ⁴S₃/₂)
  ~800 nm   — Nd³⁺ absorption  (⁴F₅/₂ + ²H₉/₂)
  ~870 nm   — Nd³⁺ absorption  (⁴F₃/₂)

References:
  Boesche, N.K., Rogass, C., Lubitz, C., Brell, M., Herrmann, S.,
  Mielke, C., Tonn, S., Appelt, O., Altenberger, U., Kaufmann, H.,
  2015. Hyperspectral REE (Rare Earth Element) Mapping of Outcrops—
  Applications for Neodymium Detection. Remote Sensing, 7(5), 5160-5186.
  https://doi.org/10.3390/rs70505160

  Boesche et al. 2014 (graph source, modified in 2015 publication):
  Two reference spectra for monazite and a monazite-rich carbonatite
  (Fen complex) showing Nd absorptions at 580, 740, 800, 870 nm.

  Gadea, O.C.A., Khan, S.D., Sisson, V.B., 2024. Estimating rare earth
  elements at various scales with Bastnäsite Indices for Mountain Pass.
  Ore Geology Reviews, 173, 106254.
  https://doi.org/10.1016/j.oregeorev.2024.106254

  Gadea, O.C.A., Khan, S.D., 2024. Identification of a Potential Rare
  Earth Element Deposit at Ivanpah Dry Lake, California Through the
  Bastnäsite Indices. Remote Sensing, 16, 4540.
  https://doi.org/10.3390/rs16234540

WoM range:  530–910 nm  (covers all four Nd absorption bands)
Map stretch: 560–900 nm  (places the four features in colour space)
Colour:      Rainbow (Blue ~560 nm → Red ~900 nm)

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

WORKFLOW_NOTE = """\
        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with VNIR coverage (≥ 530–910 nm)
        and wavelength metadata (ENVI format).<br/>
        Sensors: <b>EnMAP, PRISMA, HySpex, AVIRIS, ASD FieldSpec</b>.
        Sentinel-2 does not have sufficient spectral resolution for this analysis.
        </p>
"""

REE_NOTE = """\
        <p style="background-color:#e8f4fd; padding:6px; border-left:4px solid #1565c0;">
        <b>Neodymium (Nd³⁺) absorption features:</b>
        The four absorption bands at ~580, ~740, ~800, and ~870 nm are characteristic
        electronic transitions of the Nd³⁺ ion in the crystal field of host minerals.
        These are the same bands marked on Figure 1 of Boesche et al. (2015).
        </p>
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class FeReeAlgorithm(FEWomBase):
    WOM_START = 530.0
    WOM_END   = 910.0
    MAP_MIN   = 560.0
    MAP_MAX   = 900.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.05   # Nd absorptions are typically shallow (< 5 % depth)
    _NUM_FEATURES_DEFAULT = 4

    def _legend_filename(self):
        return 'REE_Nd_legend.png'

    def _post_map_log(self, feedback):
        feedback.pushInfo('')
        feedback.pushInfo('Colour key:')
        feedback.pushInfo('  ~580 nm  — violet/blue  (Nd³⁺ ⁴G₅/₂ + ⁴G₇/₂ transitions)')
        feedback.pushInfo('  ~740 nm  — cyan         (Nd³⁺ ⁴F₇/₂ + ⁴S₃/₂ transitions)')
        feedback.pushInfo('  ~800 nm  — green        (Nd³⁺ ⁴F₅/₂ + ²H₉/₂ transitions)')
        feedback.pushInfo('  ~870 nm  — orange/red   (Nd³⁺ ⁴F₃/₂ transitions)')

    def name(self):        return 'fe_ree_nd'

    def displayName(self): return 'FE-REE  Neodymium VNIR  (580/740/800/870 nm)'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + REE_NOTE + """
        <b>Feature Extraction — REE Neodymium VNIR Absorptions</b>

        <p>Targets four characteristic VNIR absorption bands of the Nd³⁺ ion as
        described in <b>Boesche et al. (2015)</b>, which demonstrated these features
        in reflectance spectra of monazite and monazite-rich carbonatites:</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Band (nm)</th><th>Ion Transition</th><th>Map Colour</th><th>Mineral context</th>
          </tr>
          <tr><td>~580</td><td>Nd³⁺ ⁴G₅/₂ + ⁴G₇/₂</td><td>Blue/violet</td>
              <td>Monazite, allanite, apatite</td></tr>
          <tr><td>~740</td><td>Nd³⁺ ⁴F₇/₂ + ⁴S₃/₂</td><td>Cyan</td>
              <td>Monazite, bastnäsite</td></tr>
          <tr><td>~800</td><td>Nd³⁺ ⁴F₅/₂ + ²H₉/₂</td><td>Green</td>
              <td>Monazite, xenotime (weak)</td></tr>
          <tr><td>~870</td><td>Nd³⁺ ⁴F₃/₂</td><td>Orange/red</td>
              <td>Monazite, carbonatite matrix</td></tr>
        </table>

        <p><b>WoM search range:</b> 530–910 nm  (covers all four bands)<br/>
        <b>Colour stretch:</b> 560–900 nm<br/>
        <b>Default features:</b> 4  (to detect all four Nd absorption bands)<br/>
        <b>Typical absorption depth:</b> shallow (&lt;5 %); use low depth threshold</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>530–910 nm</b>.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>560–900 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <p><b>Minerals detectable via Nd³⁺ absorptions:</b></p>
        <ul>
          <li><b>Monazite</b> — (Ce,La,Nd,Th)PO₄ — primary REE phosphate</li>
          <li><b>Bastnäsite</b> — (Ce,La,Nd)CO₃F — primary REE fluorocarbonate</li>
          <li><b>Allanite</b> — Ca(Ce,La,Y,Nd)Al₂Fe(Si₂O₇)(SiO₄)O(OH) — REE epidote</li>
          <li><b>Apatite</b> — Ca₅(PO₄)₃(OH,F,Cl) with REE substitution</li>
          <li><b>Carbonatite host rocks</b> — Nd features visible in matrix reflectance</li>
        </ul>

        <p><b>Interpretation notes:</b></p>
        <ul>
          <li>The Nd absorptions are shallow (&lt;5 % depth) compared to SWIR
              clay/carbonate features — good atmospheric correction is essential.</li>
          <li>All four bands present simultaneously strongly indicates Nd-bearing phases.</li>
          <li>The ~580 nm band can be masked by ferric iron absorption (goethite, hematite)
              — check the 740 and 870 nm bands as confirmatory features.</li>
          <li>Carbonatite and alkaline intrusive terranes are the primary targets.</li>
          <li>For quantitative REE detection using spectral indices based on these same
              absorption features, see the companion tool
              <b>FE-REE-BI  Bastnäsite Indices</b> (Gadea &amp; Khan 2024).</li>
        </ul>

        <p><b>References:</b><br/>
        Boesche, N.K. et al. (2015). Hyperspectral REE Mapping of Outcrops—
        Applications for Neodymium Detection.
        <i>Remote Sensing</i>, 7(5), 5160–5186.
        <a href="https://doi.org/10.3390/rs70505160">doi:10.3390/rs70505160</a><br/><br/>
        Gadea, O.C.A.; Khan, S.D.; Sisson, V.B. (2024). Estimating rare earth
        elements at various scales with Bastnäsite Indices for Mountain Pass.
        <i>Ore Geology Reviews</i>, 173, 106254.
        <a href="https://doi.org/10.1016/j.oregeorev.2024.106254">doi:10.1016/j.oregeorev.2024.106254</a><br/><br/>
        Gadea, O.C.A.; Khan, S.D. (2024). Identification of a Potential Rare Earth
        Element Deposit at Ivanpah Dry Lake, California Through the Bastnäsite Indices.
        <i>Remote Sensing</i>, 16, 4540.
        <a href="https://doi.org/10.3390/rs16234540">doi:10.3390/rs16234540</a></p>
        """

    def createInstance(self):
        return FeReeAlgorithm()
