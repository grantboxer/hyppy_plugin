"""
Feature Extraction — Gypsum Band-Depth Index (BD1750 / BD2217 / BD1944)
========================================================================
Computes continuum-removed band depths at the three diagnostic gypsum
absorption features and combines them into a Gypsum Confidence Index.

    BD1750  ~1750 nm  S-O overtone          — primary gypsum discriminator;
                                               essentially absent in alunite,
                                               clays and carbonates
    BD2217  ~2217 nm  SO4 + H2O combination — shared with some sulphate clays
    BD1944  ~1944 nm  H2O combination       — confirms hydration state

    GYP_CI = BD1750 × BD2217 × BD1944
             High values are highly selective for gypsum because all three
             features must co-occur.

Shoulder wavelengths for the continuum removal:
    BD1750 : left 1690 nm, right 1810 nm
    BD2217 : left 2140 nm, right 2290 nm
    BD1944 : left 1860 nm, right 2020 nm

Mineral discrimination table (USGS splib07):
    Gypsum    CaSO4·2H2O  — BD1750 strong, BD2217 strong, BD1944 strong
    Alunite                — BD1750 absent, BD2217 strong, BD1944 weak
    Jarosite               — BD1750 absent, ~2265 nm, BD1944 weak
    Kaolinite              — BD1750 absent, ~2208 nm, BD1944 absent
    Calcite                — BD1750 absent, ~2340 nm, BD1944 absent
    Anhydrite  CaSO4       — BD1750 weak/shifted ~1730 nm

Suitable sensors: EnMAP, PRISMA, AVIRIS, AVIRIS-NG, HyMap, EMIT
                  (requires coverage to ~2300 nm for full GYP_CI)

Reference: Clark et al. (2007) USGS splib07a — gypsum_HS333.3B, gypsum_WS272

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset


# ── Constants ──────────────────────────────────────────────────────────────────

# (centre_nm, left_shoulder_nm, right_shoulder_nm)
_FEATURES = {
    'BD1750': (1750.0, 1690.0, 1810.0),
    'BD2217': (2217.0, 2140.0, 2290.0),
    'BD1944': (1944.0, 1860.0, 2020.0),
}

WORKFLOW_NOTE = """\
        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with SWIR coverage (≥ 1650–2300 nm)
        and wavelength metadata (ENVI format).<br/>
        Suitable sensors: EnMAP, PRISMA, AVIRIS, AVIRIS-NG, HyMap, EMIT.
        Sentinel-2 cannot resolve the 1750 nm feature.
        </p>
"""

GYPSUM_NOTE = """\
        <p style="background-color:#e8f4fd; padding:6px; border-left:4px solid #1565c0;">
        <b>Key discriminator:</b> The <b>1750 nm S-O overtone</b> is essentially absent
        in alunite, jarosite, kaolinite and calcite — making it the single most
        diagnostic feature for gypsum in hyperspectral data.
        </p>
"""


# ── Helpers ────────────────────────────────────────────────────────────────────

def _nearest(wavelengths: np.ndarray, target_nm: float) -> int:
    """Return 0-based index of band nearest to target_nm."""
    return int(np.argmin(np.abs(wavelengths - target_nm)))


def _read_band_float(ds, band_idx: int, nodata) -> np.ndarray:
    """Read one 0-based band as float32, replacing nodata with NaN."""
    arr = ds.GetRasterBand(band_idx + 1).ReadAsArray().astype(np.float32)
    if nodata is not None:
        arr[arr == float(nodata)] = np.nan
    return arr


def _band_depth(Rc: np.ndarray,
                Rl: np.ndarray,
                Rr: np.ndarray,
                wc: float, wl: float, wr: float) -> np.ndarray:
    """
    Continuum-removed band depth.

    BD = 1 - R_centre / R_continuum
    R_continuum is linearly interpolated between left and right shoulder bands.

    Returns float32 array clipped to [0, 1]; NaN where continuum ≤ 0.
    """
    t = float(np.clip((wc - wl) / (wr - wl) if wr != wl else 0.5, 0.0, 1.0))
    R_cont = Rl + t * (Rr - Rl)
    with np.errstate(invalid='ignore', divide='ignore'):
        bd = np.where(R_cont > 0,
                      1.0 - Rc / R_cont,
                      np.nan).astype(np.float32)
    return np.clip(bd, 0.0, 1.0).astype(np.float32)


def _write_single_band_tif(path: str, arr: np.ndarray,
                            geo, proj, description: str = '') -> None:
    """Write a single-band float32 GeoTIFF with LZW compression."""
    driver = gdal.GetDriverByName('GTiff')
    n_rows, n_cols = arr.shape
    out_ds = driver.Create(path, n_cols, n_rows, 1, gdal.GDT_Float32,
                           ['COMPRESS=LZW', 'TILED=YES'])
    out_ds.SetGeoTransform(geo)
    out_ds.SetProjection(proj)
    b = out_ds.GetRasterBand(1)
    b.WriteArray(arr.astype(np.float32))
    b.SetNoDataValue(float('nan'))
    b.SetDescription(description)
    out_ds.FlushCache()
    out_ds = None


# ── Algorithm ──────────────────────────────────────────────────────────────────

class GypsumIndexAlgorithm(QgsProcessingAlgorithm):
    """
    GY01 — Gypsum Band-Depth Index (BD1750 / BD2217 / BD1944 / GYP_CI)

    Four output rasters:
        BD1750  band depth at ~1750 nm  (primary gypsum discriminator)
        BD2217  band depth at ~2217 nm
        BD1944  band depth at ~1944 nm
        GYP_CI  Gypsum Confidence Index = BD1750 × BD2217 × BD1944
    """

    INPUT       = 'INPUT'
    USE_BBL     = 'USE_BBL'
    # Shoulder wavelength overrides
    BD1750_L    = 'BD1750_L';  BD1750_C = 'BD1750_C';  BD1750_R = 'BD1750_R'
    BD2217_L    = 'BD2217_L';  BD2217_C = 'BD2217_C';  BD2217_R = 'BD2217_R'
    BD1944_L    = 'BD1944_L';  BD1944_C = 'BD1944_C';  BD1944_R = 'BD1944_R'
    # Outputs
    OUTPUT_BD1750 = 'OUTPUT_BD1750'
    OUTPUT_BD2217 = 'OUTPUT_BD2217'
    OUTPUT_BD1944 = 'OUTPUT_BD1944'
    OUTPUT_GYPCI  = 'OUTPUT_GYPCI'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube (SWIR, ≥1650–2300 nm)'))

        self.addParameter(QgsProcessingParameterBoolean(
            self.USE_BBL, 'Use Bad Band List (BBL) from metadata',
            defaultValue=True))

        # Wavelength controls — one row per feature: left, centre, right
        wav_params = [
            # BD1750
            (self.BD1750_L, 'BD1750 left shoulder [nm]',   1690.0, 1400.0, 1900.0),
            (self.BD1750_C, 'BD1750 centre [nm]',           1750.0, 1680.0, 1820.0),
            (self.BD1750_R, 'BD1750 right shoulder [nm]',   1810.0, 1700.0, 1950.0),
            # BD2217
            (self.BD2217_L, 'BD2217 left shoulder [nm]',   2140.0, 2000.0, 2200.0),
            (self.BD2217_C, 'BD2217 centre [nm]',           2217.0, 2180.0, 2260.0),
            (self.BD2217_R, 'BD2217 right shoulder [nm]',   2290.0, 2220.0, 2400.0),
            # BD1944
            (self.BD1944_L, 'BD1944 left shoulder [nm]',   1860.0, 1750.0, 1950.0),
            (self.BD1944_C, 'BD1944 centre [nm]',           1944.0, 1900.0, 1990.0),
            (self.BD1944_R, 'BD1944 right shoulder [nm]',   2020.0, 1950.0, 2100.0),
        ]
        for pid, label, default, mn, mx in wav_params:
            self.addParameter(QgsProcessingParameterNumber(
                pid, label,
                type=QgsProcessingParameterNumber.Double,
                defaultValue=default, minValue=mn, maxValue=mx))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_BD1750,
            'Output BD1750 — band depth at ~1750 nm (primary gypsum discriminator)'))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_BD2217,
            'Output BD2217 — band depth at ~2217 nm (SO4 + H2O)'))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_BD1944,
            'Output BD1944 — band depth at ~1944 nm (H2O combination)'))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_GYPCI,
            'Output GYP_CI — Gypsum Confidence Index (BD1750 × BD2217 × BD1944)'))

    def processAlgorithm(self, parameters, context, feedback):
        cube    = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        use_bbl = self.parameterAsBoolean(parameters, self.USE_BBL, context)

        if cube is None:
            raise QgsProcessingException('Invalid input layer')

        ds = gdal.Open(cube.source())
        if ds is None:
            raise QgsProcessingException(f'Cannot open raster: {cube.source()}')

        n_bands = ds.RasterCount
        n_rows  = ds.RasterYSize
        n_cols  = ds.RasterXSize
        nodata  = ds.GetRasterBand(1).GetNoDataValue()
        geo     = ds.GetGeoTransform()
        proj    = ds.GetProjection()

        raster_path = cube.source()
        wavelengths = get_wavelengths_from_dataset(ds, n_bands, raster_path, feedback)
        if wavelengths is None:
            raise QgsProcessingException(
                'No wavelength metadata found. Input must have ENVI wavelength information.')

        wmin, wmax = float(wavelengths[0]), float(wavelengths[-1])
        feedback.pushInfo(f'Cube: {n_bands} bands, {n_rows}×{n_cols} px, '
                          f'{wmin:.0f}–{wmax:.0f} nm')

        # ── Sensor coverage checks ─────────────────────────────────────────
        if wmax < 1780:
            raise QgsProcessingException(
                f'Sensor maximum wavelength is {wmax:.0f} nm. '
                'BD1750 requires coverage to ~1810 nm — cannot proceed.')

        if wmax < 2250:
            feedback.pushWarning(
                f'GY01: sensor maximum wavelength is {wmax:.0f} nm. '
                'BD2217 requires ~2290 nm — this output may be unreliable.')

        if wmax < 2050:
            feedback.pushWarning(
                f'GY01: sensor maximum wavelength is {wmax:.0f} nm. '
                'BD1944 requires ~2020 nm — this output may be unreliable.')

        # ── BBL ───────────────────────────────────────────────────────────
        bbl = None
        if use_bbl:
            bbl = get_bbl_from_dataset(ds, n_bands, raster_path)
            if bbl is not None:
                feedback.pushInfo(f'BBL: {int(np.sum(bbl))}/{n_bands} good bands')

        # ── Collect wavelength parameters from user ────────────────────────
        features = {
            'BD1750': (
                self.parameterAsDouble(parameters, self.BD1750_C, context),
                self.parameterAsDouble(parameters, self.BD1750_L, context),
                self.parameterAsDouble(parameters, self.BD1750_R, context),
            ),
            'BD2217': (
                self.parameterAsDouble(parameters, self.BD2217_C, context),
                self.parameterAsDouble(parameters, self.BD2217_L, context),
                self.parameterAsDouble(parameters, self.BD2217_R, context),
            ),
            'BD1944': (
                self.parameterAsDouble(parameters, self.BD1944_C, context),
                self.parameterAsDouble(parameters, self.BD1944_L, context),
                self.parameterAsDouble(parameters, self.BD1944_R, context),
            ),
        }

        # ── Resolve band indices, log assignments, check BBL ───────────────
        feedback.pushInfo('')
        feedback.pushInfo('Band assignments (nearest available band):')
        band_idx = {}   # key → (ic, il, ir)
        for key, (wc, wl, wr) in features.items():
            ic = _nearest(wavelengths, wc)
            il = _nearest(wavelengths, wl)
            ir = _nearest(wavelengths, wr)
            for label, idx, target in (
                    (f'{key} centre', ic, wc),
                    (f'{key} left',   il, wl),
                    (f'{key} right',  ir, wr)):
                bad = ''
                if bbl is not None and not bbl[idx]:
                    bad = '  ⚠ flagged bad in BBL'
                feedback.pushInfo(f'  {label}: target {target:.0f} nm → '
                                  f'band {idx+1} ({wavelengths[idx]:.1f} nm){bad}')
            if ic == il or ic == ir:
                feedback.pushWarning(
                    f'{key}: centre band equals a shoulder band — '
                    'band depth will be zero. Adjust wavelength parameters.')
            band_idx[key] = (ic, il, ir)

        feedback.pushInfo('')
        feedback.setProgress(10)

        # ── Read the unique bands required (avoid duplicate reads) ─────────
        needed = set()
        for ic, il, ir in band_idx.values():
            needed.update([ic, il, ir])

        feedback.pushInfo(f'Reading {len(needed)} band arrays …')
        band_data = {}
        for idx in sorted(needed):
            if feedback.isCanceled():
                return {}
            band_data[idx] = _read_band_float(ds, idx, nodata)

        ds = None  # close input
        feedback.setProgress(35)

        # Normalise to 0–1 if data appear to be integer-scaled (0–10000)
        sample_band = next(iter(band_data.values()))
        if np.nanmax(sample_band) > 2.0:
            feedback.pushInfo('Reflectance appears integer-scaled — normalising ÷ 10000')
            band_data = {k: v / 10000.0 for k, v in band_data.items()}

        if feedback.isCanceled():
            return {}

        # ── Compute band depths ────────────────────────────────────────────
        feedback.pushInfo('Computing band depths …')
        bd_arrays = {}
        for key, (ic, il, ir) in band_idx.items():
            wc = float(wavelengths[ic])
            wl = float(wavelengths[il])
            wr = float(wavelengths[ir])
            bd_arrays[key] = _band_depth(
                band_data[ic], band_data[il], band_data[ir],
                wc, wl, wr)

        feedback.setProgress(60)

        # ── Gypsum Confidence Index ────────────────────────────────────────
        with np.errstate(invalid='ignore'):
            gyp_ci = (bd_arrays['BD1750'] *
                      bd_arrays['BD2217'] *
                      bd_arrays['BD1944']).astype(np.float32)

        # ── Statistics log ─────────────────────────────────────────────────
        feedback.pushInfo('')
        feedback.pushInfo('Output statistics:')
        for key, arr in list(bd_arrays.items()) + [('GYP_CI', gyp_ci)]:
            valid = arr[np.isfinite(arr)]
            if valid.size:
                feedback.pushInfo(
                    f'  {key}: min={float(valid.min()):.4f}  '
                    f'max={float(valid.max()):.4f}  '
                    f'mean={float(valid.mean()):.4f}  '
                    f'non-zero={int(np.sum(valid > 0))} px')

        if feedback.isCanceled():
            return {}

        # ── Write outputs ──────────────────────────────────────────────────
        feedback.setProgress(70)
        out_paths = {
            self.OUTPUT_BD1750: self.parameterAsOutputLayer(
                parameters, self.OUTPUT_BD1750, context),
            self.OUTPUT_BD2217: self.parameterAsOutputLayer(
                parameters, self.OUTPUT_BD2217, context),
            self.OUTPUT_BD1944: self.parameterAsOutputLayer(
                parameters, self.OUTPUT_BD1944, context),
            self.OUTPUT_GYPCI:  self.parameterAsOutputLayer(
                parameters, self.OUTPUT_GYPCI,  context),
        }

        writes = [
            (self.OUTPUT_BD1750, bd_arrays['BD1750'],
             'BD1750 — band depth ~1750 nm (S-O overtone; primary gypsum discriminator)'),
            (self.OUTPUT_BD2217, bd_arrays['BD2217'],
             'BD2217 — band depth ~2217 nm (SO4 + H2O combination)'),
            (self.OUTPUT_BD1944, bd_arrays['BD1944'],
             'BD1944 — band depth ~1944 nm (H2O combination)'),
            (self.OUTPUT_GYPCI,  gyp_ci,
             'GYP_CI — Gypsum Confidence Index (BD1750 × BD2217 × BD1944)'),
        ]

        for param_id, arr, desc in writes:
            path = out_paths[param_id]
            feedback.pushInfo(f'Writing {desc.split(" —")[0]} → {path}')
            _write_single_band_tif(path, arr, geo, proj, desc)

        feedback.setProgress(95)
        feedback.pushInfo('')
        feedback.pushInfo('GY01 Gypsum Band-Depth Index complete.')
        feedback.pushInfo('Display guidance:')
        feedback.pushInfo('  BD1750 — stretch 0 → 0.15 (gypsum absorptions rarely exceed 15 %)')
        feedback.pushInfo('  BD2217 — stretch 0 → 0.20')
        feedback.pushInfo('  BD1944 — stretch 0 → 0.25')
        feedback.pushInfo('  GYP_CI — stretch 0 → its maximum; high values = gypsum')
        feedback.pushInfo('')
        feedback.pushInfo('Discrimination tip:')
        feedback.pushInfo('  Gypsum   → BD1750 HIGH, BD2217 HIGH, BD1944 HIGH')
        feedback.pushInfo('  Alunite  → BD1750 LOW,  BD2217 HIGH, BD1944 LOW')
        feedback.pushInfo('  Kaolinite→ BD1750 LOW,  BD2217 MOD,  BD1944 LOW')
        feedback.pushInfo('  Calcite  → BD1750 LOW,  BD2217 LOW,  BD1944 LOW')
        feedback.setProgress(100)

        return out_paths

    # ── Algorithm metadata ─────────────────────────────────────────────────────

    def name(self):        return 'gy01_gypsum_index'
    def displayName(self): return 'GY01 Gypsum Band-Depth Index  (BD1750/BD2217/BD1944)'
    def group(self):       return '8 - Gypsum & Carbonate Indices'
    def groupId(self):     return 'eight_gypsum_carbonate_indices'

    def shortHelpString(self):
        return WORKFLOW_NOTE + GYPSUM_NOTE + """
        <b>GY01 — Gypsum Band-Depth Index</b>

        <p>Computes continuum-removed band depths at the three diagnostic gypsum
        absorption features and combines them into a Gypsum Confidence Index.</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Output</th><th>Wavelength</th><th>Feature</th><th>Shoulders</th>
          </tr>
          <tr><td><b>BD1750</b></td><td>~1750 nm</td>
              <td>S-O overtone <em>(primary discriminator)</em></td>
              <td>1690 / 1810 nm</td></tr>
          <tr><td><b>BD2217</b></td><td>~2217 nm</td>
              <td>SO₄ + H₂O combination</td>
              <td>2140 / 2290 nm</td></tr>
          <tr><td><b>BD1944</b></td><td>~1944 nm</td>
              <td>H₂O combination</td>
              <td>1860 / 2020 nm</td></tr>
          <tr><td><b>GYP_CI</b></td><td>—</td>
              <td>BD1750 × BD2217 × BD1944</td>
              <td>—</td></tr>
        </table>

        <p><b>Mineral discrimination (USGS splib07):</b></p>
        <table border="1" cellpadding="3" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Mineral</th><th>BD1750</th><th>BD2217</th><th>BD1944</th>
          </tr>
          <tr><td><b>Gypsum</b> CaSO₄·2H₂O</td>
              <td>Strong</td><td>Strong</td><td>Strong</td></tr>
          <tr><td>Alunite (K,Na)Al₃(SO₄)₂(OH)₆</td>
              <td>Absent</td><td>Strong</td><td>Weak</td></tr>
          <tr><td>Jarosite KFe₃(SO₄)₂(OH)₆</td>
              <td>Absent</td><td>~2265 nm</td><td>Weak</td></tr>
          <tr><td>Kaolinite Al₂Si₂O₅(OH)₄</td>
              <td>Absent</td><td>~2208 nm</td><td>Absent</td></tr>
          <tr><td>Calcite CaCO₃</td>
              <td>Absent</td><td>~2340 nm</td><td>Absent</td></tr>
          <tr><td>Anhydrite CaSO₄</td>
              <td>Weak/shifted ~1730 nm</td><td>Moderate</td><td>Absent</td></tr>
        </table>

        <p><b>Usage notes:</b></p>
        <ul>
          <li>The <b>BD1750</b> output alone is the most powerful first-pass gypsum
              screening tool — a strong signal here immediately excludes alunite,
              kaolinite and carbonates.</li>
          <li>Use <b>GYP_CI</b> for the most selective final map — high values only
              where all three co-occur, minimising false positives from anhydrite
              or smectite.</li>
          <li>For field validation, cross-check BD1750 detections against the
              <b>DT Sulphate</b> decision tree output.</li>
          <li>Wavelength shoulder parameters can be adjusted for sensors with
              different spectral sampling or to avoid atmospheric artefacts.</li>
          <li>Stretch BD1750 from 0 to ~0.15, BD2217 from 0 to ~0.20,
              BD1944 from 0 to ~0.25, GYP_CI from 0 to its maximum.</li>
        </ul>

        <p><b>Reference:</b><br/>
        Clark, R.N. et al. (2007). USGS Digital Spectral Library splib07a.
        US Geological Survey Data Series 231.
        Gypsum spectra: gypsum_HS333.3B, gypsum_WS272.</p>
        """

    def createInstance(self):
        return GypsumIndexAlgorithm()
