"""
Feature Extraction — 2390W

WoM range 2375-2435 nm, wavelength map stretch 2377-2406 nm.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe2390WAlgorithm(FEWomBase):
    WOM_START = 2375.0
    WOM_END   = 2435.0
    MAP_MIN   = 2377.0
    MAP_MAX   = 2406.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2
    def name(self):        return 'fe_2390w'

    def displayName(self): return 'FE18 - 2390W'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2390W  (Talc / Amphibole / Carbonate long-wave Mg-OH)</b>

        <p>Targets long-wave Mg-OH and CO₃ combination absorptions near <b>~2377–2406 nm</b>,
        present in talc, actinolite / tremolite, and carbonates. This is the longest-wave
        SWIR feature window in the suite and is particularly useful for talc identification,
        which has its primary feature here. Derived from USGS GMEX reference spectra for
        talc, actinolite, and carbonate minerals.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>2375-2435 nm</b>.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>2377-2406 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>2375-2435 nm</td></tr>
          <tr><td>Colour stretch min</td><td>2377 nm</td></tr>
          <tr><td>Colour stretch max</td><td>2406 nm</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>2377–2406 nm colour stretch — mineral positions (GMEX):</b></p>
        <ul>
          <li><b>Blue (~2377–2386 nm)</b> — Actinolite / Tremolite Mg-OH long-wave (~2380 nm)</li>
          <li><b>Cyan–Green (~2386–2398 nm)</b> — Talc primary Mg-OH feature (~2395 nm); diagnostic for talc</li>
          <li><b>Yellow–Red (~2398–2406 nm)</b> — Serpentine long-wave Mg-OH; Magnesite CO₃ overtone</li>
        </ul>

        <p>Talc identification: confirm a strong feature in this window with the absence of
        Al-OH features (FE10–FE13) and the presence of 2250 nm Mg-OH (FE14).
        Use together with FE14-2250W and FE15-2290W for a complete Mg-OH mineral suite.</p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, talc and actinolite entries.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe2390WAlgorithm()
