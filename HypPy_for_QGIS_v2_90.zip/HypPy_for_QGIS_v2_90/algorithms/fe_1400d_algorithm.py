"""
Feature Extraction — 1400D  (Kaolinite OH Doublet)

Targets the kaolinite OH stretch doublet at ~1400 and ~1412 nm.

From GMEX kaolinite2 (USGS Spectral Library):
  ~1400 + 1412 nm — OH stretch overtone doublet.
  Present in highly crystalline kaolinites.
  Double absorption note: different intensities and wavelength positions
  compared to Dickite and Halloysite.
  Variations in crystallinity affect this doublet.

WoM range:  1385-1430 nm  (captures both peaks of the doublet)
Stretch:    1395-1420 nm  (resolves kaolinite doublet positions)

Note: The 1400 nm region overlaps with atmospheric water vapour absorption.
In airborne data this region may be masked by BBL. In well-corrected data
(EnMAP, PRISMA) the doublet is resolvable.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe1400DAlgorithm(FEWomBase):
    WOM_START = 1350.0
    WOM_END   = 1450.0
    MAP_MIN   = 1387.0
    MAP_MAX   = 1445.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.15
    _NUM_FEATURES_DEFAULT = 2

    def _post_map_log(self, feedback):
        feedback.pushInfo('  Blue = ~1395 nm (shorter-wave peak)  Red = ~1420 nm (longer-wave peak)')

    def name(self):        return 'fe_1400d'

    def displayName(self): return 'FE03 - 1400D  (Kaolinite OH Doublet)'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + WATER_NOTE + """
        <b>Feature Extraction — 1400D  (Kaolinite OH Doublet)</b>

        <p>Targets the kaolinite OH stretch overtone doublet at <b>~1400 and ~1412 nm</b>,
        derived from the USGS GMEX kaolinite2 reference spectrum.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>1385-1430 nm</b>
              (captures both peaks of the OH doublet).</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>1395-1420 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>1385-1430 nm</td></tr>
          <tr><td>Colour stretch min</td><td>1395 nm</td></tr>
          <tr><td>Colour stretch max</td><td>1420 nm</td></tr>
          <tr><td>Default features</td><td>2 (to detect both doublet peaks)</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>GMEX kaolinite2 — 1400D doublet characteristics:</b></p>
        <ul>
          <li>Present in <b>highly crystalline kaolinites</b>.</li>
          <li>Different intensities and wavelength positions compared to
              <b>Dickite</b> and <b>Halloysite</b>.</li>
          <li>Variations in crystallinity affect doublet shape and separation.</li>
          <li>Use <b>2 features</b> in WoM to resolve both ~1400 and ~1412 nm peaks.</li>
        </ul>

        <p><b>Mineral discrimination using doublet characteristics:</b></p>
        <ul>
          <li><b>Kaolinite</b> — doublet at ~1400 + 1412 nm, variable intensity ratio</li>
          <li><b>Dickite</b> — doublet at slightly different positions, more equal intensities</li>
          <li><b>Halloysite</b> — weakened or absent doublet due to interlayer water</li>
        </ul>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, kaolinite2 entry.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe1400DAlgorithm()
