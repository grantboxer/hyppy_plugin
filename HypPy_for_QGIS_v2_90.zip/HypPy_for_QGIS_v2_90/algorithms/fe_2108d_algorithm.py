"""
Feature Extraction — 2108D  (Dry Vegetation / Cellulose Abundance)

WoM range 2078-2143 nm, targeting the cellulose/dry-vegetation
absorption centred at ~2108 nm.

Background (GSWA Report 261, §3.3, Table 2, Figure 14):
    "The dry vegetation abundance index is based on Kokaly and Clark (1999).
    High values of the dry vegetation index are spatially associated with
    the recharge regions of water drainage systems."
    — Laukamp et al. (2025) GSWA Report 261, §3.3

    The D2108 product (3rd order polynomial fit of the WoM between
    2078 and 2143 nm) is used to:
    1. Assess whether dry vegetation is contaminating mineral maps
       in the 2100–2400 nm SWIR region
    2. Map dry vegetation (spinifex, mulga scrublands) along drainage
       systems and distinct lithologies
    3. Distinguish dry vegetation interference from genuine mineral
       signals in pixels with anomalous Al-sheetsilicate values

    The scatter diagram comparison between D2108 and 2160D/2200D/2250D
    (Figure 15) shows no significant correlations when the NDVI masking
    threshold is applied — confirming that dry vegetation is successfully
    separated from mineral signals by the vegetation masking workflow.

    This tool outputs a depth raster that can be used as a secondary
    mask alongside the MertonNDVI (green vegetation mask) in GSWA index
    algorithms.

Reference:
    Kokaly, R.F. and Clark, R.N. (1999).
    Spectroscopic Determination of Leaf Biochemistry Using Band-Depth
    Analysis of Absorption Features and Stepwise Multiple Linear Regression.
    Remote Sensing of Environment, 67(3), 267–287.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

from qgis.core import QgsProcessingAlgorithm

from .fe_base import FEWomBase


class Fe2108DAlgorithm(FEWomBase):
    WOM_START = 2078.0
    WOM_END   = 2143.0
    MAP_MIN   = 2078.0
    MAP_MAX   = 2143.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.05

    def _post_map_log(self, feedback):
        feedback.pushInfo('')
        feedback.pushInfo('─' * 60)
        feedback.pushInfo('GSWA Report 261 Table 2 — Dry Vegetation Index guidance:')
        feedback.pushInfo('  Depth band (Band 2):  use as dry vegetation abundance proxy')
        feedback.pushInfo('  Gascoyne threshold:   D2108 > 0.035–0.045 = significant dry veg')
        feedback.pushInfo('  Compare D2108 output with MertonNDVI for vegetation classification:')
        feedback.pushInfo('    High NDVI + Low D2108  → green vegetation')
        feedback.pushInfo('    Low NDVI  + High D2108 → dry vegetation / litter')
        feedback.pushInfo('    Low both               → bare mineral surface ← ideal for mapping')
        feedback.pushInfo('  Note: Some lithologies also show high D2108 — check against geology.')
        feedback.pushInfo('─' * 60)

    def name(self):        return 'fe_2108d'

    def displayName(self): return 'FE-2108D  (Dry Vegetation / Cellulose)'

    def group(self):       return '7 - Feature Extraction'

    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2108D  (Dry Vegetation / Cellulose)</b>

        <p>Maps the cellulose/dry-vegetation absorption centred at <b>~2108 nm</b>
        (between 2078 and 2143 nm).  This feature is produced by cellulose and
        lignin in dry plant material (litter, straw, woody debris, dry grass)
        and is used to assess and map dry vegetation cover.</p>

        <p><b>Primary applications:</b></p>
        <ol>
          <li><b>Pre-processing assessment:</b> Compare the D2108 output with
              MertonNDVI to classify pixels into four vegetation/mineral classes
              (following GSWA Report 261, §3.3, Figure 14):
              <ul>
                <li>High NDVI, Low D2108 → green vegetation (mask these)</li>
                <li>Low NDVI, High D2108 → dry vegetation (consider masking)</li>
                <li>High both → mixed green+dry vegetation</li>
                <li>Low both → bare mineral surface (ideal for mineral mapping)</li>
              </ul>
          </li>
          <li><b>Dry vegetation mapping:</b> Follows drainage systems and distinct
              lithological boundaries in semi-arid landscapes (Gascoyne, Pilbara).</li>
          <li><b>Secondary mask:</b> Use Band 2 (depth) of the WoM output as
              a secondary vegetation mask in GSWA Mineral Map Index algorithms —
              in addition to the MertonNDVI green vegetation mask.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>2078–2143 nm</td></tr>
          <tr><td>Map stretch</td><td>2078–2143 nm</td></tr>
          <tr><td>Absorption target</td><td>Cellulose ~2108 nm</td></tr>
          <tr style="background:#fff3e0">
            <td><b>Gascoyne threshold</b></td>
            <td>D2108 depth &gt; 0.035–0.045 = significant dry vegetation</td></tr>
        </table>

        <p><b>Important caveat:</b> Al-sheetsilicates and carbonates also produce
        absorptions in the 2078–2143 nm range (overlapping with cellulose).
        High D2108 values in areas with no expected vegetation may indicate
        mineral absorptions rather than dry vegetation — always cross-check
        against MertonNDVI and 2160D/2200D scatter diagrams
        (GSWA Report 261, §3.3, Figure 15).</p>

        <p><i>Algorithm: 3rd order polynomial fit of WoM between 2078 and 2143 nm.
        Reference: Kokaly, R.F. and Clark, R.N. (1999). Remote Sensing of Environment,
        67(3), 267–287.  GSWA implementation: Laukamp et al. (2025) GSWA Report 261,
        §3.3, Table 2, Figures 14–15.</i></p>
        """

    def createInstance(self): return Fe2108DAlgorithm()
