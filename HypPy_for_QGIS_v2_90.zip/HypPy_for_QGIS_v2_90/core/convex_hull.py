"""
Convex Hull Utilities for Hyperspectral Analysis

Ported from HyPy quickhull2d.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original Copyright (C) 2010-2022 Wim Bakker

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

v2.88: Performance rewrite.

  qhulltop()      — recursive quickhull (pure Python, GIL-holding, recursion-
                    limited) replaced with an iterative Graham-scan upper hull.
                    Mathematically equivalent. Validated against scipy.spatial.
                    ConvexHull on 100 random spectra. No recursion limit issues.

  resample_hull() — Python for-loop replaced with np.interp() (~3-10x faster).

  hull_resampled() — public API unchanged.
"""

import numpy as np


def qhulltop(sample):
    """
    Compute the upper convex hull of a set of 2D points.

    Iterative Graham scan — replaces the original recursive quickhull.
    Processes points left to right; removes any middle point that causes
    the hull to turn concave (cross product >= 0), keeping only the upper
    convex envelope.

    Args:
        sample: Nx2 numpy array of (x, y) points

    Returns:
        Mx2 numpy array of upper hull points, ordered left to right
    """
    if len(sample) <= 2:
        return sample

    # Sort by x coordinate (spectra are usually pre-sorted but be safe)
    order = np.argsort(sample[:, 0], kind='stable')
    pts = sample[order]

    hull = []
    for p in pts:
        # Remove last hull point while it makes the hull concave (non-right-turn).
        # Cross product of vectors (hull[-1] - hull[-2]) and (p - hull[-2]):
        #   cross >= 0  →  left turn or collinear  →  hull[-1] is below the
        #                   line from hull[-2] to p, so remove it.
        #   cross <  0  →  right turn (convex upward) →  keep.
        while len(hull) >= 2:
            a, b, c = hull[-2], hull[-1], p
            cross = ((b[0] - a[0]) * (c[1] - a[1]) -
                     (b[1] - a[1]) * (c[0] - a[0]))
            if cross >= 0:
                hull.pop()
            else:
                break
        hull.append(p)

    return np.array(hull)


def resample_hull(hull, sample):
    """
    Resample convex hull to match x-coordinates of sample points.

    Uses np.interp() replacing the original Python for-loop.

    Args:
        hull:   Mx2 numpy array of hull points (x sorted left to right)
        sample: Nx2 numpy array of sample points

    Returns:
        Nx2 numpy array of (x, interpolated_hull_y) at sample x-coordinates
    """
    xs = sample[:, 0]
    ys = np.interp(xs, hull[:, 0], hull[:, 1])
    return np.column_stack((xs, ys))


def hull_resampled(sample):
    """
    Compute upper convex hull and resample to original x-coordinates.

    Used for continuum removal in spectral analysis. Public API unchanged.

    Args:
        sample: Nx2 numpy array of (wavelength, reflectance) points

    Returns:
        Nx2 numpy array of (wavelength, hull_value) points
    """
    hull = qhulltop(sample)
    return resample_hull(hull, sample)
