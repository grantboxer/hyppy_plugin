"""
Spectral Plot Widget
====================
A lightweight spectral chart widget built on pure QPainter — no matplotlib,
no pyqtgraph, no QtChart dependency.  Works in any QGIS 3.x installation.

Y-axis scaling
--------------
The pixel spectrum is plotted on the left Y axis (min=0, max=data max).
Library reference spectra are independently normalised to the same plot
height so they are always visible regardless of the units of the input
image (DN, scaled reflectance 0-10000, fractional reflectance 0-1, etc.).
Each library entry is labelled "(norm)" in the legend to indicate this.

Features
--------
- Pixel spectrum plotted in navy with a light filled area
- Up to 10 library reference spectra overlaid in distinct colours,
  each independently scaled to fill the plot height
- Auto-scaling X axis across all loaded data
- Mouse hover shows crosshair + wavelength/value tooltip
- Right-click context menu: Copy pixel spectrum as CSV, Clear all

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np

from qgis.PyQt.QtWidgets import QWidget, QToolTip, QMenu, QAction, QApplication
from qgis.PyQt.QtCore    import Qt, QRect, QPoint, QPointF, QSize
from qgis.PyQt.QtGui     import (QPainter, QPen, QBrush, QColor, QFont,
                                  QFontMetrics, QPolygonF, QPainterPath,
                                  QCursor)


_LIB_COLORS = [
    QColor('#e74c3c'),
    QColor('#27ae60'),
    QColor('#2980b9'),
    QColor('#f39c12'),
    QColor('#8e44ad'),
    QColor('#16a085'),
    QColor('#c0392b'),
    QColor('#1abc9c'),
    QColor('#d35400'),
    QColor('#7f8c8d'),
]

_PIXEL_COLOR = QColor('#1B3A5C')
_BACKGROUND  = QColor('#FAFAFA')
_GRID_COLOR  = QColor('#E0E0E0')
_AXIS_COLOR  = QColor('#404040')
_MARGIN      = {'l': 72, 'r': 24, 't': 24, 'b': 52}


def _norm_to_range(val_array, target_min, target_max):
    """Scale val_array to fill [target_min, target_max] (for library display)."""
    v = np.asarray(val_array, dtype=float)
    finite = v[np.isfinite(v)]
    if len(finite) == 0:
        return v
    lo, hi = finite.min(), finite.max()
    if hi == lo:
        mid = (target_min + target_max) / 2.0
        return np.where(np.isfinite(v), mid, np.nan)
    span = target_max - target_min
    t_lo = target_min + span * 0.05
    t_hi = target_min + span * 0.95
    return t_lo + (v - lo) / (hi - lo) * (t_hi - t_lo)


class SpectrumPlotWidget(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(QSize(320, 200))
        self.setMouseTracking(True)
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._context_menu)

        self._pixel_wav   = None
        self._pixel_val   = None
        self._pixel_label = ''
        self._lib_spectra = []   # list of (wav, val, name, QColor)  — raw values

        self._mouse_x = None
        self._mouse_y = None

        self._x_min = self._x_max = None
        self._y_min = self._y_max = None
        self._legend_visible = True

    # ── Public API ────────────────────────────────────────────────────────────

    def set_pixel_spectrum(self, wavelengths, values, label='',
                           legend_visible=True):
        self._pixel_wav    = np.asarray(wavelengths, dtype=float)
        self._pixel_val    = np.asarray(values,      dtype=float)
        self._pixel_label  = label
        self._legend_visible = legend_visible
        self._recompute_limits()
        self.update()

    def add_library_spectrum(self, wavelengths, values, name='',
                             legend_visible=True):
        if len(self._lib_spectra) >= len(_LIB_COLORS):
            return
        color = _LIB_COLORS[len(self._lib_spectra)]
        self._lib_spectra.append((
            np.asarray(wavelengths, dtype=float),
            np.asarray(values,      dtype=float),
            name, color
        ))
        self._legend_visible = legend_visible
        self._recompute_limits()
        self.update()

    def set_legend_visible(self, visible):
        """Toggle legend on/off (mirrors HypPy legend_state)."""
        self._legend_visible = visible
        self.update()

    def clear_library_spectra(self):
        self._lib_spectra.clear()
        self._recompute_limits()
        self.update()

    def clear_all(self):
        self._pixel_wav   = None
        self._pixel_val   = None
        self._pixel_label = ''
        self._lib_spectra.clear()
        self._x_min = self._x_max = None
        self._y_min = self._y_max = None
        self.update()

    def has_pixel_spectrum(self):
        return self._pixel_wav is not None and len(self._pixel_wav) > 0

    # ── Axis limits ───────────────────────────────────────────────────────────

    def _resample_lib_to_pixel(self, lib_wav, lib_val):
        """Resample a library spectrum onto the current pixel wavelength grid.

        Called at paint time so it works correctly whether the library was
        loaded before or after a pixel was picked.
        Returns (wav, val) — either resampled to pixel_wav, or the original
        arrays if no pixel wavelength grid is available.
        """
        pixel_wav = self._pixel_wav
        if (pixel_wav is None or len(pixel_wav) == 0 or len(lib_wav) == 0):
            return lib_wav, lib_val

        # Skip resampling if grids already match
        if (len(lib_wav) == len(pixel_wav) and
                np.allclose(lib_wav, pixel_wav, atol=0.5)):
            return lib_wav, lib_val

        try:
            from scipy.interpolate import interp1d
            f   = interp1d(lib_wav, lib_val, kind="linear",
                           bounds_error=False, fill_value=np.nan)
            return pixel_wav, f(pixel_wav)
        except Exception:
            return lib_wav, lib_val   # scipy unavailable — original grid

    def _recompute_limits(self):
        """X range anchored to pixel wavelengths; Y range from pixel spectrum."""
        all_x = []

        # Y axis driven by pixel spectrum
        if self._pixel_wav is not None:
            m = np.isfinite(self._pixel_wav) & np.isfinite(self._pixel_val)
            if m.any():
                all_x.append(self._pixel_wav[m])
                pmax = self._pixel_val[m].max()
                pad  = pmax * 0.05 if pmax > 0 else 0.01
                self._y_min = 0.0
                self._y_max = pmax + pad
            else:
                self._y_min = self._y_max = None
        else:
            self._y_min = self._y_max = None

        # X axis: use pixel wavelengths as the anchor when available.
        # Library spectra are resampled to pixel_wav at paint time, so their
        # raw (possibly wider) wavelength range should NOT expand the x axis.
        if not all_x:
            # No pixel spectrum yet — fall back to library wavelength range
            for wav, val, *_ in self._lib_spectra:
                w, _ = self._resample_lib_to_pixel(wav, val)
                m = np.isfinite(w)
                if m.any():
                    all_x.append(w[m])

        if not all_x:
            self._x_min = self._x_max = None
            return

        xs  = np.concatenate(all_x)
        xr  = xs.max() - xs.min()
        pad = xr * 0.02 if xr > 0 else 1.0
        self._x_min = xs.min() - pad
        self._x_max = xs.max() + pad

        if self._y_min is None:
            self._y_min, self._y_max = 0.0, 1.0

    # ── Coordinate helpers ────────────────────────────────────────────────────

    def _plot_rect(self):
        m = _MARGIN
        return QRect(m['l'], m['t'],
                     self.width()  - m['l'] - m['r'],
                     self.height() - m['t']  - m['b'])

    def _data_to_canvas(self, wav, val):
        r  = self._plot_rect()
        cx = (r.x() + (np.asarray(wav, float) - self._x_min)
              / (self._x_max - self._x_min) * r.width()
              if self._x_max != self._x_min
              else np.full(len(wav), r.x() + r.width() / 2.0))
        cy = (r.bottom() - (np.asarray(val, float) - self._y_min)
              / (self._y_max - self._y_min) * r.height()
              if self._y_max != self._y_min
              else np.full(len(val), r.y() + r.height() / 2.0))
        return cx, cy

    def _canvas_to_data(self, cx, cy):
        r = self._plot_rect()
        if r.width() <= 0 or r.height() <= 0:
            return None, None
        wav = self._x_min + (cx - r.x()) / r.width()  * (self._x_max - self._x_min)
        val = self._y_min + (r.bottom() - cy) / r.height() * (self._y_max - self._y_min)
        return wav, val

    # ── Paint ─────────────────────────────────────────────────────────────────

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), _BACKGROUND)

        if self._x_min is None:
            p.setPen(QPen(QColor('#AAAAAA')))
            p.setFont(QFont('Arial', 10))
            p.drawText(self.rect(), Qt.AlignCenter,
                       'Click a pixel on the map to display its spectrum')
            return

        self._draw_grid(p)
        self._draw_axes(p)

        # Library spectra: resampled to pixel wavelength grid at paint time,
        # then independently normalised to the pixel Y range for display.
        for wav, val, name, color in self._lib_spectra:
            wav, val = self._resample_lib_to_pixel(wav, val)
            display_val = _norm_to_range(val, self._y_min, self._y_max)
            self._draw_line(p, wav, display_val, color, lw=1.5)

        # Pixel spectrum on top with fill
        if self._pixel_wav is not None:
            self._draw_line(p, self._pixel_wav, self._pixel_val,
                            _PIXEL_COLOR, lw=2.0, fill=True)

        if self._legend_visible:
            self._draw_legend(p)

        if self._mouse_x is not None and self._plot_rect().contains(
                QPoint(self._mouse_x, self._mouse_y)):
            self._draw_crosshair(p)

    def _draw_grid(self, p):
        r = self._plot_rect()
        p.setPen(QPen(_GRID_COLOR, 1, Qt.DotLine))
        for i in range(1, 6):
            x = r.x() + int(i * r.width() / 6)
            p.drawLine(x, r.top(), x, r.bottom())
        for i in range(1, 5):
            y = r.top() + int(i * r.height() / 5)
            p.drawLine(r.left(), y, r.right(), y)

    def _draw_axes(self, p):
        r  = self._plot_rect()
        p.setPen(QPen(_AXIS_COLOR, 1))
        p.drawRect(r)
        font = QFont('Arial', 8)
        p.setFont(font)
        fm = QFontMetrics(font)
        p.setPen(_AXIS_COLOR)

        # X ticks
        for i in range(7):
            wav = self._x_min + (self._x_max - self._x_min) * i / 6
            x   = r.x() + int(i * r.width() / 6)
            p.drawLine(x, r.bottom(), x, r.bottom() + 4)
            lbl = f'{wav:.0f}'
            tw  = fm.horizontalAdvance(lbl)
            p.drawText(x - tw // 2, r.bottom() + 15, lbl)
        xt = 'Wavelength (nm)'
        p.drawText(r.x() + (r.width() - fm.horizontalAdvance(xt)) // 2,
                   self.height() - 4, xt)

        # Y ticks (pixel spectrum scale)
        for i in range(6):
            val = self._y_min + (self._y_max - self._y_min) * i / 5
            y   = r.bottom() - int(i * r.height() / 5)
            p.drawLine(r.left() - 4, y, r.left(), y)
            lbl = f'{val:.4g}'
            tw  = fm.horizontalAdvance(lbl)
            p.drawText(r.left() - tw - 6, y + fm.ascent() // 2, lbl)
        p.save()
        p.translate(12, r.y() + r.height() // 2)
        p.rotate(-90)
        yt = 'Reflectance'
        p.drawText(-fm.horizontalAdvance(yt) // 2, 0, yt)
        p.restore()

    def _draw_line(self, p, wav, val, color, lw=1.5, fill=False):
        r    = self._plot_rect()
        wav  = np.asarray(wav,  dtype=float)
        val  = np.asarray(val,  dtype=float)
        mask = np.isfinite(wav) & np.isfinite(val)
        if mask.sum() < 2:
            return

        cx, cy = self._data_to_canvas(wav[mask], val[mask])

        p.save()
        p.setClipRect(r)

        if fill:
            yb   = float(r.bottom())
            path = QPainterPath()
            path.moveTo(QPointF(float(cx[0]), yb))
            for x, y in zip(cx, cy):
                path.lineTo(QPointF(float(x), float(y)))
            path.lineTo(QPointF(float(cx[-1]), yb))
            path.closeSubpath()
            fc = QColor(color)
            fc.setAlpha(30)
            p.fillPath(path, QBrush(fc))

        pen = QPen(color, lw)
        pen.setCapStyle(Qt.RoundCap)
        pen.setJoinStyle(Qt.RoundJoin)
        p.setPen(pen)
        poly = QPolygonF()
        for x, y in zip(cx, cy):
            poly.append(QPointF(float(x), float(y)))
        p.drawPolyline(poly)
        p.restore()

    def _draw_legend(self, p):
        r = self._plot_rect()
        entries = []
        if self._pixel_wav is not None and len(self._pixel_wav) > 0:
            entries.append((_PIXEL_COLOR,
                             self._pixel_label or 'Pixel spectrum',
                             False))
        for _, _, name, color in self._lib_spectra:
            entries.append((color, name, True))

        if not entries:
            return

        font = QFont('Arial', 8)
        p.setFont(font)
        fm = QFontMetrics(font)
        lh = fm.height() + 3
        sw = 18

        labels = [f'{n}  (norm)' if norm else n for _, n, norm in entries]
        max_tw = max(fm.horizontalAdvance(l) for l in labels)
        box_w  = sw + 10 + max_tw + 6
        box_h  = len(entries) * lh + 6
        bx = r.right() - box_w - 4
        by = r.top() + 6

        p.fillRect(bx, by, box_w, box_h, QColor(255, 255, 255, 210))
        p.setPen(QPen(QColor('#CCCCCC'), 1))
        p.drawRect(bx, by, box_w, box_h)

        for i, ((color, _, norm), lbl) in enumerate(zip(entries, labels)):
            y = by + 4 + i * lh
            p.fillRect(bx + 4, y + 2, sw, lh - 4, QBrush(color))
            p.setPen(_AXIS_COLOR)
            disp = lbl
            while fm.horizontalAdvance(disp) > max_tw and len(disp) > 8:
                disp = disp[:-4] + '…'
            p.drawText(bx + sw + 8, y + fm.ascent(), disp)

    def _draw_crosshair(self, p):
        r = self._plot_rect()
        p.setPen(QPen(QColor(150, 150, 150, 180), 1, Qt.DashLine))
        p.drawLine(self._mouse_x, r.top(),  self._mouse_x, r.bottom())
        p.drawLine(r.left(), self._mouse_y, r.right(),     self._mouse_y)

    # ── Mouse ─────────────────────────────────────────────────────────────────

    def mouseMoveEvent(self, event):
        self._mouse_x = event.x()
        self._mouse_y = event.y()
        if self._x_min is not None and self._plot_rect().contains(event.pos()):
            wav, val = self._canvas_to_data(event.x(), event.y())
            QToolTip.showText(event.globalPos(),
                              f'{wav:.1f} nm  /  {val:.5g}', self)
        else:
            QToolTip.hideText()
        self.update()

    def leaveEvent(self, event):
        self._mouse_x = None
        self._mouse_y = None
        self.update()

    # ── Context menu ──────────────────────────────────────────────────────────

    def _context_menu(self, pos):
        menu = QMenu(self)
        a_csv   = QAction('Copy pixel spectrum as CSV', self)
        a_clear = QAction('Clear library spectra', self)
        a_all   = QAction('Clear all', self)
        a_csv.setEnabled(self._pixel_wav is not None)
        a_clear.setEnabled(bool(self._lib_spectra))
        menu.addAction(a_csv)
        menu.addSeparator()
        menu.addAction(a_clear)
        menu.addAction(a_all)
        a_csv.triggered.connect(self._copy_csv)
        a_clear.triggered.connect(self.clear_library_spectra)
        a_all.triggered.connect(self.clear_all)
        menu.exec_(self.mapToGlobal(pos))

    def _copy_csv(self):
        if self._pixel_wav is None:
            return
        lines = ['wavelength_nm,value']
        for w, v in zip(self._pixel_wav, self._pixel_val):
            lines.append(f'{w:.4f},{v:.6g}')
        QApplication.clipboard().setText('\n'.join(lines))
