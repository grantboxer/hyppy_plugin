"""
Spectrum Viewer Dock + Map Tool
================================
Interactive pixel-click spectral viewer for HypPy for QGIS.

Modelled on the HypPy 3.0.1 Spectral Library Viewer (tkSpecLib.py)
by Wim Bakker, University of Twente.

Key features (matching HypPy tkSpecLib):
  - Multi-select spectrum list with extended selection
  - Convex Hull (continuum) removal — divide or subtract modes
  - Plot / Clear / Average / View Values buttons
  - Legend on / off toggle
  - Spectrum description text area
  - Math expression on spectrum S

Components
----------
PixelSpectrumTool   – QgsMapTool that intercepts map clicks, reads the
                       pixel spectrum from the active raster layer, and
                       pushes it to the dock.

SpectrumViewerDock  – QDockWidget containing:
                       • the SpectrumPlotWidget chart
                       • active layer indicator
                       • "Pick pixel" toggle button
                       • Spectral Library section:
                           - File browser (ENVI / CSV)
                           - Multi-select spectrum list
                           - Convex Hull removal checkbox (divide/subtract)
                           - Plot / Average / Clear / View Values buttons
                           - Legend on/off toggle
                           - Math expression entry
                       • Values table tab (wavelength | value)
                       • Status bar

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
Original HypPy tkSpecLib concept: Copyright (C) Wim Bakker, Univ. of Twente.
"""

import os
import numpy as np

from qgis.PyQt.QtCore    import Qt, QSize
from qgis.PyQt.QtGui     import QIcon, QColor, QCursor, QFont
from qgis.PyQt.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QComboBox, QFileDialog,
    QSizePolicy, QFrame, QApplication, QListWidget,
    QListWidgetItem, QAbstractItemView, QTextEdit,
    QLineEdit, QCheckBox, QRadioButton, QButtonGroup,
    QTabWidget, QTableWidget, QTableWidgetItem,
    QGroupBox, QHeaderView, QMessageBox, QScrollArea,
    QSplitter
)
from qgis.core           import (
    QgsMapLayer, QgsRasterLayer, QgsPointXY, QgsProject
)
from qgis.gui            import QgsMapTool

try:
    from osgeo import gdal
    _GDAL = True
except ImportError:
    _GDAL = False

from ..core.envi_header         import get_wavelengths_from_dataset
from ..core.spectral_library_io import load_spectral_library
from ..core.convex_hull         import hull_resampled
from ..core.spectrum            import Spectrum
from .spectrum_plot_widget      import SpectrumPlotWidget


# ── Helper: thin horizontal rule ─────────────────────────────────────────────
def _hrule():
    f = QFrame()
    f.setFrameShape(QFrame.HLine)
    f.setFrameShadow(QFrame.Sunken)
    return f


# ══════════════════════════════════════════════════════════════════════════════
# Map Tool
# ══════════════════════════════════════════════════════════════════════════════

class PixelSpectrumTool(QgsMapTool):
    """
    Custom map tool.  Left-click -> read spectrum -> push to dock.
    Right-click or Escape -> deactivate and restore previous tool.
    """

    def __init__(self, canvas, dock):
        super().__init__(canvas)
        self._dock      = dock
        self._prev_tool = None
        self.setCursor(QCursor(Qt.CrossCursor))

    def activate(self):
        super().activate()
        self._dock._on_tool_activated()

    def deactivate(self):
        super().deactivate()
        self._dock._on_tool_deactivated()

    def canvasReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            point = self.toMapCoordinates(event.pos())
            self._dock._read_pixel(point)
        elif event.button() == Qt.RightButton:
            self.canvas().unsetMapTool(self)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.canvas().unsetMapTool(self)


# ══════════════════════════════════════════════════════════════════════════════
# Dock Widget
# ══════════════════════════════════════════════════════════════════════════════

class SpectrumViewerDock(QDockWidget):
    """
    Dockable Spectrum Viewer panel, modelled on HypPy tkSpecLib.
    """

    def __init__(self, iface):
        super().__init__('Spectrum Viewer', iface.mainWindow())
        self._iface  = iface
        self._canvas = iface.mapCanvas()
        self._tool   = PixelSpectrumTool(self._canvas, self)
        self._prev_tool = None

        # Spectral library state
        self._lib_path         = None
        self._lib_spectra      = []
        self._lib_names        = []
        self._lib_wavs         = None
        self._lib_descriptions = []

        # Settings (mirroring HypPy options)
        self._remove_hull = False
        self._hull_mode   = 'div'   # 'div' or 'sub'
        self._legend_on   = True

        self._build_ui()

        QgsProject.instance().layersAdded.connect(self._refresh_layer_label)
        QgsProject.instance().layersRemoved.connect(self._refresh_layer_label)
        self._canvas.currentLayerChanged.connect(self._refresh_layer_label)

    # ══════════════════════════════════════════════════════════════════════════
    # UI construction
    # ══════════════════════════════════════════════════════════════════════════

    def _build_ui(self):
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea |
                             Qt.BottomDockWidgetArea)
        self.setMinimumWidth(380)
        self.setMinimumHeight(420)

        root = QWidget()
        root.setStyleSheet('QWidget { font-family: Arial; font-size: 9pt; }')
        main_vbox = QVBoxLayout(root)
        main_vbox.setSpacing(4)
        main_vbox.setContentsMargins(6, 6, 6, 6)

        # Tabs: Plot | Values
        self._tabs = QTabWidget()
        main_vbox.addWidget(self._tabs)

        # ── TAB 1: Plot ───────────────────────────────────────────────────────
        tab_plot = QWidget()
        vbox = QVBoxLayout(tab_plot)
        vbox.setSpacing(4)
        vbox.setContentsMargins(4, 4, 4, 4)

        # Section 1 — Pixel spectrum
        vbox.addWidget(QLabel('<b>Pixel Spectrum</b>'))

        row1 = QHBoxLayout()
        self._lbl_layer = QLabel('Active layer: (none)')
        self._lbl_layer.setWordWrap(True)
        self._lbl_layer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        row1.addWidget(self._lbl_layer)
        vbox.addLayout(row1)

        row2 = QHBoxLayout()
        self._btn_pick = QPushButton('Play  Pick pixel')
        self._btn_pick.setCheckable(True)
        self._btn_pick.setToolTip(
            'Click to activate the pixel picker, then click on the map.\n'
            'Right-click on the map or press Escape to deactivate.')
        self._btn_pick.toggled.connect(self._toggle_tool)
        self._btn_pick.setMinimumHeight(26)
        row2.addWidget(self._btn_pick)
        self._btn_clear_pixel = QPushButton('Clear pixel')
        self._btn_clear_pixel.clicked.connect(self._clear_pixel)
        row2.addWidget(self._btn_clear_pixel)
        vbox.addLayout(row2)

        self._lbl_pixel = QLabel('')
        self._lbl_pixel.setStyleSheet('color:#555555; font-style:italic;')
        vbox.addWidget(self._lbl_pixel)

        vbox.addWidget(_hrule())

        # Plot widget (stretchy)
        self._plot = SpectrumPlotWidget()
        self._plot.setMinimumHeight(200)
        self._plot.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        vbox.addWidget(self._plot, stretch=1)

        vbox.addWidget(_hrule())

        # Section 2 — Spectral Library
        vbox.addWidget(QLabel('<b>Spectral Library</b>'))

        row3 = QHBoxLayout()
        self._lbl_lib = QLabel('No library loaded')
        self._lbl_lib.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self._lbl_lib.setWordWrap(True)
        row3.addWidget(self._lbl_lib)
        btn_browse = QPushButton('Browse...')
        btn_browse.setMaximumWidth(70)
        btn_browse.clicked.connect(self._browse_library)
        row3.addWidget(btn_browse)
        vbox.addLayout(row3)

        # Multi-select spectrum list (mirrors HypPy EXTENDED listbox)
        self._listbox = QListWidget()
        self._listbox.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self._listbox.setMinimumHeight(90)
        self._listbox.setMaximumHeight(150)
        self._listbox.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self._listbox.itemSelectionChanged.connect(self._on_selection_changed)
        vbox.addWidget(self._listbox)

        # Convex Hull removal — mirrors HypPy exactly
        hull_row = QHBoxLayout()
        self._chk_hull = QCheckBox('Continuum Removal')
        self._chk_hull.setChecked(False)
        self._chk_hull.toggled.connect(self._on_hull_toggled)
        hull_row.addWidget(self._chk_hull)
        self._rb_div = QRadioButton('divide')
        self._rb_div.setChecked(True)
        self._rb_div.toggled.connect(self._on_hull_mode_changed)
        hull_row.addWidget(self._rb_div)
        self._rb_sub = QRadioButton('subtract')
        self._rb_sub.toggled.connect(self._on_hull_mode_changed)
        hull_row.addWidget(self._rb_sub)
        hull_row.addStretch()
        vbox.addLayout(hull_row)

        # Description text (mirrors HypPy description Text widget)
        self._description = QTextEdit()
        self._description.setReadOnly(True)
        self._description.setMaximumHeight(56)
        self._description.setPlaceholderText('Spectrum description...')
        self._description.setStyleSheet('font-size:8pt; color:#444444;')
        vbox.addWidget(self._description)

        # Plot / Average / View Values / Clear buttons (mirrors HypPy button row)
        btn_row = QHBoxLayout()
        self._btn_plot = QPushButton('Plot')
        self._btn_plot.setEnabled(False)
        self._btn_plot.setToolTip('Plot selected spectra')
        self._btn_plot.clicked.connect(self._plot_selected)
        btn_row.addWidget(self._btn_plot)

        self._btn_average = QPushButton('Average')
        self._btn_average.setEnabled(False)
        self._btn_average.setToolTip('Plot average of selected spectra')
        self._btn_average.clicked.connect(self._average_selected)
        btn_row.addWidget(self._btn_average)

        self._btn_view_vals = QPushButton('View Values')
        self._btn_view_vals.setEnabled(False)
        self._btn_view_vals.setToolTip('Show wavelength/value table in the Values tab')
        self._btn_view_vals.clicked.connect(self._view_values)
        btn_row.addWidget(self._btn_view_vals)

        self._btn_clear_lib = QPushButton('Clear')
        self._btn_clear_lib.setEnabled(False)
        self._btn_clear_lib.setToolTip('Clear all library overlays from chart')
        self._btn_clear_lib.clicked.connect(self._clear_library_overlays)
        btn_row.addWidget(self._btn_clear_lib)
        vbox.addLayout(btn_row)

        # Legend on / off (mirrors HypPy)
        leg_row = QHBoxLayout()
        self._rb_leg_on  = QRadioButton('legend on')
        self._rb_leg_off = QRadioButton('legend off')
        self._rb_leg_on.setChecked(True)
        self._rb_leg_on.toggled.connect(self._on_legend_toggled)
        leg_row.addWidget(self._rb_leg_on)
        leg_row.addWidget(self._rb_leg_off)
        leg_row.addStretch()
        vbox.addLayout(leg_row)

        # Math expression (mirrors HypPy "Math Expression on Spectrum S:")
        vbox.addWidget(_hrule())
        math_grp = QGroupBox('Math Expression on Spectrum  S:')
        math_vbox = QVBoxLayout(math_grp)
        math_vbox.setSpacing(3)
        self._expression = QLineEdit()
        self._expression.setPlaceholderText('e.g.  S.nohull()  or  S[2200.0]  or  S.mean()')
        self._expression.returnPressed.connect(self._run_bandmath)
        math_row2 = QHBoxLayout()
        math_row2.addWidget(self._expression)
        self._btn_go = QPushButton('Go')
        self._btn_go.clicked.connect(self._run_bandmath)
        math_row2.addWidget(self._btn_go)
        math_vbox.addLayout(math_row2)
        self._math_result = QLabel('')
        self._math_result.setWordWrap(True)
        self._math_result.setStyleSheet('color:#1B3A5C; font-size:8pt;')
        math_vbox.addWidget(self._math_result)
        vbox.addWidget(math_grp)

        # Status bar
        vbox.addWidget(_hrule())
        self._status = QLabel('Ready')
        self._status.setStyleSheet('color:#666666; font-size:8pt;')
        vbox.addWidget(self._status)

        self._tabs.addTab(tab_plot, 'Plot')

        # ── TAB 2: Values table ───────────────────────────────────────────────
        tab_vals = QWidget()
        val_vbox = QVBoxLayout(tab_vals)
        val_vbox.setContentsMargins(4, 4, 4, 4)
        val_vbox.addWidget(QLabel('<b>Wavelength / Value table</b>  (for selected spectrum)'))

        self._vals_table = QTableWidget(0, 2)
        self._vals_table.setHorizontalHeaderLabels(['Wavelength (nm)', 'Value'])
        self._vals_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self._vals_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._vals_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        val_vbox.addWidget(self._vals_table, stretch=1)

        btn_copy = QPushButton('Copy as CSV')
        btn_copy.clicked.connect(self._copy_vals_csv)
        val_vbox.addWidget(btn_copy)

        self._tabs.addTab(tab_vals, 'Values')

        self.setWidget(root)
        self._refresh_layer_label()

    # ══════════════════════════════════════════════════════════════════════════
    # Pick tool
    # ══════════════════════════════════════════════════════════════════════════

    def _toggle_tool(self, checked):
        if checked:
            self._prev_tool = self._canvas.mapTool()
            self._canvas.setMapTool(self._tool)
        else:
            if self._canvas.mapTool() is self._tool:
                self._canvas.unsetMapTool(self._tool)
            if self._prev_tool:
                self._canvas.setMapTool(self._prev_tool)

    def _on_tool_activated(self):
        self._btn_pick.setChecked(True)
        self._btn_pick.setText('Stop  Picking... (Esc to stop)')
        self._status.setText('Click on the map to read a pixel spectrum')

    def _on_tool_deactivated(self):
        self._btn_pick.setChecked(False)
        self._btn_pick.setText('Play  Pick pixel')
        self._status.setText('Ready')

    # ══════════════════════════════════════════════════════════════════════════
    # Layer label
    # ══════════════════════════════════════════════════════════════════════════

    def _refresh_layer_label(self, *args):
        layer = self._canvas.currentLayer()
        if layer and isinstance(layer, QgsRasterLayer):
            self._lbl_layer.setText(f'Active layer: <b>{layer.name()}</b>')
            self._lbl_layer.setStyleSheet('color:#1B3A5C;')
        elif layer:
            self._lbl_layer.setText(
                f'Active layer: {layer.name()}'
                ' <span style="color:orange;">(not a raster)</span>')
        else:
            self._lbl_layer.setText('Active layer: (none)')

    # ══════════════════════════════════════════════════════════════════════════
    # Pixel reading
    # ══════════════════════════════════════════════════════════════════════════

    def _read_pixel(self, map_point):
        layer = self._canvas.currentLayer()
        if not layer or not isinstance(layer, QgsRasterLayer):
            self._status.setText('Warning  Please select a raster layer in the Layers panel')
            return

        source = layer.source()

        if not _GDAL:
            self._status.setText('Warning  GDAL not available')
            return

        ds = gdal.Open(source, gdal.GA_ReadOnly)
        if ds is None:
            self._status.setText(f'Warning  Cannot open raster: {source}')
            return

        n_bands = ds.RasterCount
        geo     = ds.GetGeoTransform()

        if geo[1] == 0:
            ds = None
            self._status.setText('Warning  Raster has no valid geotransform')
            return

        col = int((map_point.x() - geo[0]) / geo[1])
        row = int((map_point.y() - geo[3]) / geo[5])

        if col < 0 or row < 0 or col >= ds.RasterXSize or row >= ds.RasterYSize:
            ds = None
            self._status.setText('Warning  Click is outside the raster extent')
            return

        values     = np.zeros(n_bands, dtype=np.float64)
        nodata_val = ds.GetRasterBand(1).GetNoDataValue()
        for b in range(n_bands):
            band_data = ds.GetRasterBand(b + 1).ReadAsArray(col, row, 1, 1)
            if band_data is not None:
                values[b] = float(band_data[0, 0])
            else:
                values[b] = np.nan

        if nodata_val is not None:
            values[np.isclose(values, nodata_val)] = np.nan

        wavelengths = get_wavelengths_from_dataset(ds, n_bands, source)
        ds = None

        if wavelengths is None:
            wavelengths = np.arange(1, n_bands + 1, dtype=float)
            wav_label   = 'Band number'
        else:
            wav_label = 'Wavelength (nm)'

        label = f'{layer.name()}  row {row}, col {col}'
        self._plot.set_pixel_spectrum(wavelengths, values, label=label,
                                      legend_visible=self._legend_on)
        self._lbl_pixel.setText(
            f'<span style="color:#1B3A5C;">{label}</span><br/>'
            f'X={map_point.x():.2f}, Y={map_point.y():.2f}  |  '
            f'{n_bands} bands')
        self._status.setText(f'Pixel read: {n_bands} bands  ({wav_label})')

    def _clear_pixel(self):
        self._plot.set_pixel_spectrum(np.array([]), np.array([]))
        self._lbl_pixel.setText('')
        self._status.setText('Pixel spectrum cleared')

    # ══════════════════════════════════════════════════════════════════════════
    # Spectral library loading
    # ══════════════════════════════════════════════════════════════════════════

    def _browse_library(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            'Open Spectral Library',
            '',
            'Spectral Libraries (*.sli *.hdr *.csv *.txt);;All files (*)'
        )
        if not path:
            return
        self._load_library(path)

    def _load_library(self, path):
        self._status.setText('Loading spectral library...')
        QApplication.processEvents()
        try:
            spectra, names, wavs = load_spectral_library(
                path, log=lambda m: self._status.setText(m))
        except Exception as e:
            self._status.setText(f'Warning  Failed to load library: {e}')
            return

        self._lib_path         = path
        self._lib_spectra      = spectra
        self._lib_names        = names
        self._lib_wavs         = wavs
        self._lib_descriptions = [''] * len(names)

        fname = os.path.basename(path)
        self._lbl_lib.setText(f'<b>{fname}</b>  ({len(spectra)} spectra)')

        self._listbox.clear()
        for name in names:
            self._listbox.addItem(name)

        self._plot.clear_library_spectra()
        self._btn_clear_lib.setEnabled(False)
        self._description.clear()
        self._status.setText(f'Library loaded: {len(spectra)} spectra from {fname}')

    # ══════════════════════════════════════════════════════════════════════════
    # Convex Hull helpers
    # ══════════════════════════════════════════════════════════════════════════

    def _apply_hull(self, wav, spec, name):
        """Apply continuum removal matching HypPy Spectrum.nohull() logic."""
        if not self._remove_hull:
            return wav, spec, name

        try:
            wav_arr  = np.asarray(wav,  dtype=float)
            spec_arr = np.asarray(spec, dtype=float)

            mask = np.isfinite(wav_arr) & np.isfinite(spec_arr)
            if mask.sum() < 3:
                return wav, spec, name

            pts  = np.column_stack((wav_arr[mask], spec_arr[mask]))
            hull = hull_resampled(pts)

            from scipy.interpolate import interp1d
            f_hull   = interp1d(hull[:, 0], hull[:, 1], kind='linear',
                                bounds_error=False, fill_value=np.nan)
            hull_full = f_hull(wav_arr)

            if self._hull_mode == 'div':
                out    = np.where(hull_full > 0, spec_arr / hull_full, np.nan)
                suffix = ' / CH'
            else:
                out    = 1.0 + (spec_arr - hull_full)
                suffix = ' - CH + 1'

            return wav_arr, out, name + suffix

        except Exception:
            return wav, spec, name

    def _make_spectrum_obj(self, idx):
        """Build a Spectrum object (with optional hull removal) for library index idx."""
        wav  = self._lib_wavs
        spec = self._lib_spectra[idx]
        name = self._lib_names[idx]

        if wav is None:
            wav = np.arange(1, len(spec) + 1, dtype=float)

        wav, spec, name = self._apply_hull(wav, spec, name)
        return Spectrum(wavelength=wav, spectrum=spec, name=name)

    # ══════════════════════════════════════════════════════════════════════════
    # Plot / Average / View Values — mirroring HypPy button actions
    # ══════════════════════════════════════════════════════════════════════════

    def _selected_indices(self):
        return [self._listbox.row(item) for item in self._listbox.selectedItems()]

    def _on_selection_changed(self):
        has = bool(self._listbox.selectedItems())
        self._btn_plot.setEnabled(has)
        self._btn_average.setEnabled(has)
        self._btn_view_vals.setEnabled(has)

        sel = self._selected_indices()
        if len(sel) == 1 and sel[0] < len(self._lib_descriptions):
            self._description.setText(self._lib_descriptions[sel[0]])
        else:
            self._description.clear()

    def _plot_selected(self):
        """Plot selected spectra — replaces current library overlays."""
        indices = self._selected_indices()
        if not indices:
            self._status.setText('Warning  No spectrum selected')
            return

        self._plot.clear_library_spectra()

        for idx in indices:
            wav  = self._lib_wavs
            spec = self._lib_spectra[idx]
            name = self._lib_names[idx]

            if wav is None:
                wav = np.arange(1, len(spec) + 1, dtype=float)

            wav, spec, name = self._apply_hull(wav, spec, name)
            self._plot.add_library_spectrum(wav, spec, name=name,
                                            legend_visible=self._legend_on)

        self._btn_clear_lib.setEnabled(True)
        self._status.setText(f'Plotted {len(indices)} spectrum(a)')

    def _average_selected(self):
        """Compute and plot the average of selected spectra (HypPy average_spec)."""
        indices = self._selected_indices()
        if not indices:
            return

        try:
            S_list = [self._make_spectrum_obj(i) for i in indices]
            result = S_list[0]
            for S in S_list[1:]:
                result = result + S
            result = result / len(S_list)
        except Exception as e:
            self._status.setText(f'Warning  Average failed: {e}')
            return

        self._plot.add_library_spectrum(
            result.w, result.s, name='Average',
            legend_visible=self._legend_on)
        self._btn_clear_lib.setEnabled(True)
        self._status.setText(f'Average of {len(indices)} spectra plotted')

        self._populate_values_table(result.w, result.s, 'Average')
        self._tabs.setCurrentIndex(1)

    def _view_values(self):
        """Populate the Values tab with the first selected spectrum."""
        indices = self._selected_indices()
        if not indices:
            return

        idx  = indices[0]
        wav  = self._lib_wavs
        spec = self._lib_spectra[idx]
        name = self._lib_names[idx]

        if wav is None:
            wav = np.arange(1, len(spec) + 1, dtype=float)

        wav, spec, name = self._apply_hull(wav, spec, name)
        self._populate_values_table(wav, spec, name)
        self._tabs.setCurrentIndex(1)
        self._status.setText(f'Values: {name}')

    def _populate_values_table(self, wav, spec, name=''):
        wav  = np.asarray(wav,  dtype=float)
        spec = np.asarray(spec, dtype=float)
        self._vals_table.setRowCount(0)
        self._vals_table.setRowCount(len(wav))
        for i, (w, v) in enumerate(zip(wav, spec)):
            self._vals_table.setItem(i, 0, QTableWidgetItem(f'{w:.4f}'))
            self._vals_table.setItem(i, 1, QTableWidgetItem(f'{v:.6g}'))

    def _copy_vals_csv(self):
        rows = self._vals_table.rowCount()
        if rows == 0:
            return
        lines = ['wavelength_nm,value']
        for i in range(rows):
            w = self._vals_table.item(i, 0)
            v = self._vals_table.item(i, 1)
            if w and v:
                lines.append(f'{w.text()},{v.text()}')
        QApplication.clipboard().setText('\n'.join(lines))
        self._status.setText('Values copied to clipboard as CSV')

    def _clear_library_overlays(self):
        self._plot.clear_library_spectra()
        self._btn_clear_lib.setEnabled(False)
        self._status.setText('Library overlays cleared')

    # ══════════════════════════════════════════════════════════════════════════
    # Convex Hull / Legend controls
    # ══════════════════════════════════════════════════════════════════════════

    def _on_hull_toggled(self, checked):
        self._remove_hull = checked

    def _on_hull_mode_changed(self):
        self._hull_mode = 'div' if self._rb_div.isChecked() else 'sub'

    def _on_legend_toggled(self, checked):
        self._legend_on = self._rb_leg_on.isChecked()
        self._plot.set_legend_visible(self._legend_on)

    # ══════════════════════════════════════════════════════════════════════════
    # Math expression (mirrors HypPy bandmath_spec)
    # ══════════════════════════════════════════════════════════════════════════

    def _run_bandmath(self):
        """
        Evaluate a Python expression where S is the selected Spectrum object.
        Mirrors HypPy bandmath_spec().  Results shown in the status / math result label.
        If the result is a Spectrum it is also plotted.
        """
        exp = self._expression.text().strip()
        if not exp:
            return

        indices = self._selected_indices()
        if not indices:
            self._status.setText('Warning  Select a spectrum first')
            return

        results = []
        for idx in indices:
            S = self._make_spectrum_obj(idx)   # noqa: F841 (used in eval below)
            try:
                result = eval(exp)   # S available in local scope
            except Exception as e:
                self._math_result.setText(f'Error: {e}')
                self._status.setText(f'Warning  Expression error: {e}')
                return

            name_out = f'{S.name}  ->  {exp}'

            if isinstance(result, Spectrum):
                self._plot.add_library_spectrum(
                    result.w, result.s, name=name_out,
                    legend_visible=self._legend_on)
                self._btn_clear_lib.setEnabled(True)
                results.append(f'{S.name}: <Spectrum>')
                self._populate_values_table(result.w, result.s, name_out)
            elif isinstance(result, np.ndarray):
                wav = self._lib_wavs
                if wav is None:
                    wav = np.arange(1, len(result) + 1, dtype=float)
                if len(result) == len(wav):
                    self._plot.add_library_spectrum(
                        wav, result, name=name_out,
                        legend_visible=self._legend_on)
                    self._btn_clear_lib.setEnabled(True)
                results.append(f'{S.name}: array len={len(result)}')
            else:
                results.append(f'{S.name}: {result}')

        self._math_result.setText('\n'.join(results))
        self._status.setText('Expression evaluated')

    # ══════════════════════════════════════════════════════════════════════════
    # Public convenience
    # ══════════════════════════════════════════════════════════════════════════

    def show_and_raise(self):
        self.show()
        self.raise_()

    def load_library_from_path(self, path):
        self._load_library(path)

    # ══════════════════════════════════════════════════════════════════════════
    # Cleanup
    # ══════════════════════════════════════════════════════════════════════════

    def closeEvent(self, event):
        if self._canvas.mapTool() is self._tool:
            self._canvas.unsetMapTool(self._tool)
        super().closeEvent(event)
