"""
HypPy for QGIS — Main Plugin Class

Registers the Processing provider and creates a toolbar with:
  - Spectrum Viewer toggle button (left, checkable)
  - HypPy dropdown menu button (right) mirroring the Processing Toolbox groups

Each menu item calls processing.execAlgorithmDialog() with the correct
fully-qualified algorithm ID  (provider_id:algorithm_name).

Copyright (C) 2025 Grant Boxer
Original HyPy Copyright (C) 2010-2022 Wim Bakker, University of Twente
GPL v3 or later.
"""

import os
from qgis.PyQt.QtCore    import Qt
from qgis.PyQt.QtGui     import QIcon, QFont
from qgis.PyQt.QtWidgets import (
    QAction, QToolBar, QToolButton, QMenu
)
from qgis.core import QgsApplication

from .hyppy_provider import HyppyProvider


# ── Menu structure ────────────────────────────────────────────────────────────
# Each tuple: (display_name, 'providerid:algorithm_name')
# Group headers are non-clickable bold labels; None inserts a separator.

_MENU_STRUCTURE = [
    # ── Group 1 ───────────────────────────────────────────────────────────────
    '1 - Workflow Guide',
    ('Open Workflow Guide',                     'hyppy:getting_started'),

    None,  # separator

    # ── Group 2 ───────────────────────────────────────────────────────────────
    '2 - Generate WoM Rasters',
    ('Generate All Three WoM Rasters',          'hyppy:generate_all_wom'),
    ('Generate WoM-A  (750–1300 nm)',           'hyppy:generate_wom_a'),
    ('Generate WoM-B  (1850–2100 nm)',          'hyppy:generate_wom_b'),
    ('Generate WoM-C  (2100–2400 nm)',          'hyppy:generate_wom_c'),
    ('Wavelength of Minimum (custom range)',    'hyppy:wavelength_of_minimum'),
    ('Wavelength Mapping',                      'hyppy:wavelength_mapping'),

    None,

    # ── Group 3 ───────────────────────────────────────────────────────────────
    '3 - Decision Tree Classification',
    ('DT Mineral Map',                          'hyppy:dt_mineral_map'),
    ('DT 2100–2400 Mineral',                    'hyppy:dt_2100_2400'),
    ('DT Albedo',                               'hyppy:dt_albedo'),
    ('DT Fedrop',                               'hyppy:dt_fedrop'),
    ('DT Illcryst',                             'hyppy:dt_illcryst'),
    ('DT Ill-Kaol',                             'hyppy:dt_ill_kaol'),

    None,

    # ── Group 4 ───────────────────────────────────────────────────────────────
    '4 - SAM Classification',
    ('Spectral Angle Mapper (SAM)',             'hyppy:sam'),

    None,

    # ── Group 5 ───────────────────────────────────────────────────────────────
    '5 - Spectral Processing Tools',
    ('Convex Hull Removal',                     'hyppy:convexhullremoval'),
    ('Band Ratio',                              'hyppy:bandratio'),
    ('Band Ratios (Sequential)',                'hyppy:bandratios'),
    ('Band Depths',                             'hyppy:banddepths'),
    ('Band Math',                               'hyppy:bandmathfull'),
    ('Spectra Math',                            'hyppy:spectramathfull'),
    ('Log Residuals',                           'hyppy:logresiduals'),

    None,

    # ── Group 6 ───────────────────────────────────────────────────────────────
    '6 - Feature Extraction',
    ('FE0 - Run All Feature Extractions (FE1-FE11)', 'hyppy:fe_all'),
    ('FE1  - 1480W',                            'hyppy:fe_1480w'),
    ('FE2  - 1550W',                            'hyppy:fe_1550w'),
    ('FE3  - 1760W',                            'hyppy:fe_1760w'),
    ('FE4  - 2080D',                            'hyppy:fe_2080d'),
    ('FE5  - 2160D',                            'hyppy:fe_2160d'),
    ('FE6  - 2200W',                            'hyppy:fe_2200w'),
    ('FE7  - 2250W',                            'hyppy:fe_2250w'),
    ('FE8  - 2290W',                            'hyppy:fe_2290w'),
    ('FE9  - 2320W',                            'hyppy:fe_2320w'),
    ('FE10 - 2350W',                            'hyppy:fe_2350w'),
    ('FE11 - 2390W',                            'hyppy:fe_2390w'),
]


class HyperspectralPlugin:
    """QGIS Plugin Implementation for HypPy for QGIS."""

    def __init__(self, iface):
        self.iface      = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.provider   = None
        self._dock      = None
        self._toolbar   = None

    # ── Processing provider ───────────────────────────────────────────────────

    def initProcessing(self):
        self.provider = HyppyProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    # ── GUI ───────────────────────────────────────────────────────────────────

    def initGui(self):
        self.initProcessing()

        # Spectrum Viewer dock
        try:
            from .ui.spectrum_viewer_dock import SpectrumViewerDock
            self._dock = SpectrumViewerDock(self.iface)
            self.iface.mainWindow().addDockWidget(
                Qt.RightDockWidgetArea, self._dock)
            self._dock.hide()
        except Exception as e:
            self.iface.messageBar().pushWarning(
                'HypPy', f'Spectrum Viewer could not be loaded: {e}')

        # Toolbar
        self._toolbar = QToolBar('HypPy', self.iface.mainWindow())
        self._toolbar.setObjectName('HyppyToolbar')
        self.iface.mainWindow().addToolBar(self._toolbar)

        icon_path = os.path.join(self.plugin_dir, 'icon.svg')
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        # ── Spectrum Viewer toggle (left button, checkable) ───────────────
        self._act_viewer = QAction(icon, 'Spectrum Viewer',
                                   self.iface.mainWindow())
        self._act_viewer.setToolTip(
            'Toggle the HypPy Spectrum Viewer\n'
            'Click pixels on the map to display and compare spectra.')
        self._act_viewer.setCheckable(True)
        self._act_viewer.triggered.connect(self._toggle_viewer)
        self._toolbar.addAction(self._act_viewer)

        # Keep the toggle button in sync with the dock
        if self._dock:
            self._dock.visibilityChanged.connect(self._act_viewer.setChecked)

        self._toolbar.addSeparator()

        # ── HypPy dropdown menu button (right) ────────────────────────────
        self._menu_btn = QToolButton()
        self._menu_btn.setIcon(icon)
        self._menu_btn.setText(' HypPy ▾')
        self._menu_btn.setToolTip('Run HypPy algorithms')
        self._menu_btn.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._menu_btn.setPopupMode(QToolButton.InstantPopup)
        self._menu_btn.setMenu(self._build_menu())
        self._toolbar.addWidget(self._menu_btn)

    # ── Menu construction ─────────────────────────────────────────────────────

    def _build_menu(self):
        menu = QMenu(self.iface.mainWindow())

        bold_font = QFont()
        bold_font.setBold(True)

        for item in _MENU_STRUCTURE:
            if item is None:
                menu.addSeparator()

            elif isinstance(item, str):
                # Group header — disabled bold label
                act = QAction(item, menu)
                act.setFont(bold_font)
                act.setEnabled(False)
                menu.addAction(act)

            else:
                # (display_name, alg_id) — clickable algorithm entry
                display_name, alg_id = item
                act = QAction(f'    {display_name}', menu)
                act.triggered.connect(lambda checked, aid=alg_id: self._run_algorithm(aid))
                menu.addAction(act)

        return menu

    # ── Slots ─────────────────────────────────────────────────────────────────

    def _toggle_viewer(self, checked=None):
        if self._dock is None:
            return
        if checked is None:
            checked = not self._dock.isVisible()
        if checked:
            self._dock.show_and_raise()
        else:
            self._dock.hide()

    def _run_algorithm(self, alg_id):
        try:
            import processing
            processing.execAlgorithmDialog(alg_id)
        except Exception as e:
            self.iface.messageBar().pushWarning(
                'HypPy', f'Could not open "{alg_id}": {e}')

    # ── Public API ────────────────────────────────────────────────────────────

    def show_spectrum_viewer(self):
        """Called from Getting Started algorithm."""
        if self._dock:
            self._dock.show_and_raise()
            self._act_viewer.setChecked(True)

    # ── Cleanup ───────────────────────────────────────────────────────────────

    def unload(self):
        if self._dock:
            self._dock.close()
            self.iface.mainWindow().removeDockWidget(self._dock)
            self._dock.deleteLater()
            self._dock = None

        if self._toolbar:
            self.iface.mainWindow().removeToolBar(self._toolbar)
            self._toolbar.deleteLater()
            self._toolbar = None

        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None
