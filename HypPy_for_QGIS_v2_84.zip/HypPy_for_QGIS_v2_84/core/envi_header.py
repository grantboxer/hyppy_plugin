"""
ENVI Header Sidecar Reader
===========================
Reads wavelength, BBL, FWHM and other fields directly from an ENVI .hdr
sidecar file.

This is necessary because gdal.Open('image.tif') opens the file as GeoTIFF
and never reads a companion .hdr — GDAL only parses the .hdr when it opens
the file as ENVI format.  All Hyppy algorithms that accept a GeoTIFF produced
by a previous step (e.g. the Log Residuals output) call these helpers so they
can find the wavelength list even when GDAL's metadata dictionaries are empty.

The lookup order used by get_wavelengths_from_dataset() is:
  1. GDAL 'ENVI' metadata domain  (works for files opened as ENVI format)
  2. GDAL default '' metadata domain
  3. Sidecar .hdr file next to the raster path
  4. Band descriptions (numeric wavelength values stored per-band)

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import os
import re
import numpy as np


# ── Sidecar .hdr path resolution ─────────────────────────────────────────────

def find_hdr(raster_path):
    """
    Return the path of the ENVI .hdr sidecar for *raster_path*, or None.

    Checks (in order):
      file.tif.hdr   — ENVI sidecar alongside a GeoTIFF
      file.hdr       — ENVI sidecar with the extension replaced
    """
    for candidate in (raster_path + '.hdr',
                      os.path.splitext(raster_path)[0] + '.hdr'):
        if os.path.isfile(candidate):
            return candidate
    return None


# ── Raw .hdr parser ───────────────────────────────────────────────────────────

def parse_hdr(hdr_path):
    """
    Parse an ENVI .hdr file and return a dict of all key→value pairs.

    Multi-line brace-delimited lists (wavelength, bbl, fwhm, band names …)
    are returned as raw strings including the braces so callers can strip
    and split them as needed.
    """
    with open(hdr_path, 'r', errors='replace') as f:
        content = f.read()

    result = {}

    # ── Multi-line brace-delimited fields ────────────────────────────────
    # Match:  key = { … }   (the value may span multiple lines)
    for m in re.finditer(r'(\w[\w ]*?)\s*=\s*(\{[^}]*\})', content, re.DOTALL):
        key = m.group(1).strip().lower()
        result[key] = m.group(2).strip()

    # ── Simple key = value pairs ─────────────────────────────────────────
    # Only add if not already captured by the brace pattern above
    for m in re.finditer(r'^([\w][\w ]*?)\s*=\s*(.+)$', content, re.MULTILINE):
        key = m.group(1).strip().lower()
        if key not in result:
            result[key] = m.group(2).strip()

    return result


# ── Field extractors ──────────────────────────────────────────────────────────

def _parse_numeric_list(raw, dtype=float):
    """Strip braces and split a comma-separated list to a numpy array."""
    cleaned = raw.strip('{}').strip()
    try:
        return np.array([dtype(v.strip()) for v in cleaned.split(',') if v.strip()])
    except ValueError:
        return None


def wavelengths_from_hdr(hdr_path):
    """
    Return a numpy float64 array of wavelengths from *hdr_path*, or None.
    """
    hdr = parse_hdr(hdr_path)
    for key in ('wavelength', 'wavelengths'):
        if key in hdr:
            arr = _parse_numeric_list(hdr[key], float)
            if arr is not None and len(arr) > 0:
                return arr.astype(np.float64)
    return None


def bbl_from_hdr(hdr_path, n_bands=None):
    """
    Return a boolean numpy array (True = good band) from *hdr_path*, or None.
    """
    hdr = parse_hdr(hdr_path)
    for key in ('bbl', 'bad band list', 'bad_band_multiplier'):
        if key in hdr:
            arr = _parse_numeric_list(hdr[key], float)
            if arr is not None and len(arr) > 0:
                if n_bands is None or len(arr) >= n_bands:
                    result = arr[:n_bands].astype(bool) if n_bands else arr.astype(bool)
                    return result
    return None


def fwhm_from_hdr(hdr_path):
    """Return fwhm array from *hdr_path*, or None."""
    hdr = parse_hdr(hdr_path)
    if 'fwhm' in hdr:
        arr = _parse_numeric_list(hdr['fwhm'], float)
        if arr is not None and len(arr) > 0:
            return arr.astype(np.float64)
    return None


def wavelength_units_from_hdr(hdr_path):
    """Return wavelength units string from *hdr_path*, or None."""
    hdr = parse_hdr(hdr_path)
    return hdr.get('wavelength units') or hdr.get('wavelength_units')


# ── Unit normalisation ────────────────────────────────────────────────────────

def _to_nm(arr, units_str):
    """
    Convert *arr* (numpy float64) to nanometres if necessary.

    Conversion rules (applied in order):
      1. Explicit units string — 'Micrometers' / 'Microns' / 'um'  → × 1000
                                 'Wavenumber'  / 'cm-1'            → 10 000 000 / arr
                                 'Nanometers'  / 'nm' / None       → no change
      2. Heuristic fallback when units_str is None or unrecognised:
           all values < 100  → assume µm → × 1000
           all values > 100  → assume nm → no change

    Returns a new numpy float64 array.
    """
    arr = np.array(arr, dtype=np.float64)
    if units_str is not None:
        u = units_str.strip().lower()
        if u in ('micrometers', 'microns', 'micrometres', 'um', 'μm'):
            return arr * 1000.0
        if u in ('wavenumber', 'wavenumbers', 'cm-1', 'cm^-1'):
            with np.errstate(divide='ignore', invalid='ignore'):
                return np.where(arr != 0, 1e7 / arr, np.nan)
        # 'nanometers', 'nm', or anything else — treat as nm
        return arr

    # Heuristic: if all finite values are below 100, assume µm
    finite = arr[np.isfinite(arr)]
    if len(finite) > 0 and np.all(finite < 100.0):
        return arr * 1000.0
    return arr


# ── Main convenience function used by all algorithms ─────────────────────────

def get_wavelengths_from_dataset(dataset, num_bands, raster_path=None, feedback=None):
    """
    Extract a wavelength array using a four-source lookup cascade.

    Parameters
    ----------
    dataset      : gdal.Dataset — already-opened raster
    num_bands    : int — expected number of bands
    raster_path  : str or None — filesystem path to the raster file;
                   required for sidecar .hdr lookup
    feedback     : QgsProcessingFeedback or None

    Returns
    -------
    numpy float64 array of length num_bands, or None if not found.
    """
    def log(msg):
        if feedback:
            feedback.pushInfo(msg)

    # 1. GDAL 'ENVI' metadata domain
    meta = dataset.GetMetadata('ENVI') or {}
    units = meta.get('wavelength units') or meta.get('wavelength_units')
    for key in ('wavelength', 'Wavelength', 'WAVELENGTH'):
        if key in meta:
            raw = meta[key].strip('{}').strip()
            try:
                arr = np.array([float(v.strip()) for v in raw.split(',') if v.strip()])
                if len(arr) == num_bands:
                    log(f'Wavelengths found in GDAL ENVI metadata domain ({num_bands} bands)')
                    return _to_nm(arr, units)
            except ValueError:
                pass

    # 2. GDAL default '' metadata domain
    meta = dataset.GetMetadata('') or {}
    units = meta.get('wavelength units') or meta.get('wavelength_units')
    for key in ('wavelength', 'Wavelength', 'WAVELENGTH'):
        if key in meta:
            raw = meta[key].strip('{}').strip()
            try:
                arr = np.array([float(v.strip()) for v in raw.split(',') if v.strip()])
                if len(arr) == num_bands:
                    log(f'Wavelengths found in GDAL default metadata domain ({num_bands} bands)')
                    return _to_nm(arr, units)
            except ValueError:
                pass

    # 3. Sidecar .hdr file
    if raster_path:
        hdr_path = find_hdr(raster_path)
        if hdr_path:
            arr = wavelengths_from_hdr(hdr_path)
            if arr is not None:
                if len(arr) == num_bands:
                    units = wavelength_units_from_hdr(hdr_path)
                    log(f'Wavelengths read from sidecar .hdr: {hdr_path} ({num_bands} bands)')
                    return _to_nm(arr, units)
                else:
                    log(f'Sidecar .hdr found ({hdr_path}) but band count mismatch '
                        f'({len(arr)} in hdr vs {num_bands} in raster) — skipping')
        else:
            log(f'No sidecar .hdr found alongside: {raster_path}')

    # 4. Band descriptions (numeric wavelength values stored per-band)
    wavs = []
    for b in range(num_bands):
        desc = dataset.GetRasterBand(b + 1).GetDescription()
        try:
            wavs.append(float(desc))
        except (ValueError, TypeError):
            wavs.append(None)
    if None not in wavs:
        log(f'Wavelengths read from band descriptions ({num_bands} bands)')
        return _to_nm(np.array(wavs, dtype=np.float64), None)

    if feedback:
        feedback.reportError(
            'No wavelength information found. Checked: ENVI metadata, default metadata, '
            'sidecar .hdr, band descriptions.'
        )
    return None


def get_bbl_from_dataset(dataset, num_bands, raster_path=None, feedback=None):
    """
    Extract a Bad Band List using a two-source lookup cascade.

    Returns a boolean numpy array (True = good band) or None.
    """
    def log(msg):
        if feedback:
            feedback.pushInfo(msg)

    # 1. GDAL metadata domains
    for domain in ('ENVI', ''):
        meta = dataset.GetMetadata(domain) or {}
        for key in ('bbl', 'BBL', 'bad band list', 'bad_band_multiplier'):
            if key in meta:
                raw = meta[key].strip('{}').strip()
                try:
                    arr = np.array([int(float(v.strip())) for v in raw.split(',') if v.strip()])
                    if len(arr) >= num_bands:
                        log(f'BBL found in GDAL {domain or "default"} metadata domain')
                        return arr[:num_bands].astype(bool)
                except ValueError:
                    pass

    # 2. Sidecar .hdr
    if raster_path:
        hdr_path = find_hdr(raster_path)
        if hdr_path:
            arr = bbl_from_hdr(hdr_path, num_bands)
            if arr is not None:
                log(f'BBL read from sidecar .hdr: {hdr_path}')
                return arr

    # 3. Sensor-aware fallback — synthesise a BBL when none is present in metadata.
    #
    # If the wavelength array is available we can recognise known airborne sensors
    # by their spectral range and band count, and apply the standard bad-band
    # regions for that sensor.  This protects downstream algorithms when a user
    # loads an AVIRIS-NG GeoTIFF that has been stripped of its .hdr sidecar.
    #
    # Sensors currently handled:
    #   AVIRIS-NG  (~365–2510 nm, ~432 bands)
    #     bad bands: 1340–1445 nm (atmospheric H₂O), 1790–1960 nm (atmospheric H₂O)
    #
    # The function re-uses the wavelengths already found by get_wavelengths_from_dataset
    # via a lightweight call to the GDAL/hdr lookup (no I/O beyond what was already done).
    wavelengths = get_wavelengths_from_dataset(dataset, num_bands, raster_path, feedback=None)
    if wavelengths is not None:
        bbl_synth = _synthesise_bbl(wavelengths, num_bands, feedback)
        if bbl_synth is not None:
            return bbl_synth

    return None


# ── Sensor-aware BBL synthesis and SNR classification ─────────────────────────
#
# Sensors are identified by a fingerprint of (wav_min, wav_max, band_count).
# Each entry carries:
#   name       — display name
#   wav_min/max — expected wavelength range bounds (±80 nm tolerance)
#   bands_min/max — expected band count range
#   bad_zones  — list of (start_nm, end_nm) atmospheric bad-band regions
#   snr_poor   — list of (start_nm, end_nm) ranges with insufficient SNR
#                for reliable polynomial depth extraction (not full bad bands,
#                but noisy enough to cause artefacts in mineral maps)
#   snr_note   — one-line description of the SNR limitation for user messages
#
# Reference for PRISMA SNR limits: GSWA Report 261, §3.2 and §3.4.1.
#   "The cross-track correction was not sufficient to remove instrument noise
#    that prevented the generation of useful hyperspectral products from the
#    2300 to 2400 nm wavelength range."
#   "The PRISMA hyperspectral VNIR reflectance spectra — especially in the
#    800 to 1000 nm region — are strongly impacted by atmospheric effects
#    and a very low SNR."
#
_SENSOR_PROFILES = [
    # ── AVIRIS-NG: 365–2510 nm, ~432 bands ───────────────────────────────
    {
        'name':      'AVIRIS-NG',
        'wav_min':   340.0,
        'wav_max':   2530.0,
        'bands_min': 400,
        'bands_max': 480,
        'bad_zones': [(1340.0, 1445.0), (1790.0, 1960.0)],
        'snr_poor':  [],   # AVIRIS-NG has good SNR across the SWIR
        'snr_note':  '',
    },
    # ── AVIRIS Classic: 400–2500 nm, 224 bands ───────────────────────────
    {
        'name':      'AVIRIS Classic',
        'wav_min':   380.0,
        'wav_max':   2520.0,
        'bands_min': 210,
        'bands_max': 240,
        'bad_zones': [(1340.0, 1445.0), (1790.0, 1960.0)],
        'snr_poor':  [],
        'snr_note':  '',
    },
    # ── PRISMA: 400–2500 nm, ~239 bands (VNIR 66 + SWIR 173) ────────────
    # SNR poor: 700–1000 nm (VNIR iron oxide region) and 2300–2450 nm (long SWIR)
    # Bad zones: standard atmospheric water vapour bands
    {
        'name':      'PRISMA',
        'wav_min':   380.0,
        'wav_max':   2520.0,
        'bands_min': 225,
        'bands_max': 255,
        'bad_zones': [(1340.0, 1445.0), (1790.0, 1960.0)],
        'snr_poor':  [(700.0, 1000.0), (2300.0, 2500.0)],
        'snr_note':  (
            'PRISMA has low SNR in 700–1000 nm (VNIR iron oxide) and '
            '2300–2450 nm (long SWIR amphibole/talc/carbonate). '
            'Polynomial depth products in these ranges may show strong noise artefacts. '
            'EnMAP or EMIT are recommended for the 2300–2450 nm range. '
            '(GSWA Report 261, §3.2 and §3.4.1)'
        ),
    },
    # ── PRISMA SWIR-only cube: 920–2500 nm, ~173 bands ───────────────────
    # Some workflows split the VNIR and SWIR cubes
    {
        'name':      'PRISMA (SWIR cube)',
        'wav_min':   880.0,
        'wav_max':   2520.0,
        'bands_min': 160,
        'bands_max': 190,
        'bad_zones': [(1340.0, 1445.0), (1790.0, 1960.0)],
        'snr_poor':  [(2300.0, 2500.0)],
        'snr_note':  (
            'PRISMA SWIR cube has low SNR in 2300–2450 nm. '
            'EnMAP or EMIT are recommended for amphibole/talc/carbonate mapping. '
            '(GSWA Report 261, §3.2)'
        ),
    },
    # ── EnMAP: 420–2450 nm, ~244 bands (VNIR 89 + SWIR 155) ─────────────
    # High SNR across full VNIR-SWIR — no poor-SNR zones for mineral mapping
    {
        'name':      'EnMAP',
        'wav_min':   400.0,
        'wav_max':   2470.0,
        'bands_min': 230,
        'bands_max': 260,
        'bad_zones': [(1340.0, 1445.0), (1790.0, 1960.0)],
        'snr_poor':  [],
        'snr_note':  '',
    },
    # ── EMIT: 381–2493 nm, ~285 bands ────────────────────────────────────
    # Good SNR; 60 m pixel size is coarser than PRISMA/EnMAP
    {
        'name':      'EMIT',
        'wav_min':   360.0,
        'wav_max':   2510.0,
        'bands_min': 270,
        'bands_max': 300,
        'bad_zones': [(1340.0, 1445.0), (1790.0, 1960.0)],
        'snr_poor':  [],
        'snr_note':  '',
    },
]

# Keep the old name for backward compatibility with existing code
_SENSOR_BAD_BANDS = _SENSOR_PROFILES


def get_sensor_info(wavelengths, num_bands):
    """
    Identify the sensor from a wavelength fingerprint.

    Returns a dict with keys:
        'name'      — sensor display name, or 'Unknown'
        'matched'   — True if a known sensor was matched
        'bad_zones' — list of (start_nm, end_nm) atmospheric bad-band zones
        'snr_poor'  — list of (start_nm, end_nm) low-SNR regions
        'snr_note'  — human-readable SNR limitation string (empty if none)

    Also checks the ENVI header 'sensor type' field if available — but
    wavelength fingerprinting is the primary mechanism since many workflows
    strip ENVI headers.
    """
    if wavelengths is None or len(wavelengths) != num_bands:
        return {'name': 'Unknown', 'matched': False,
                'bad_zones': [], 'snr_poor': [], 'snr_note': ''}

    wav_min = float(np.nanmin(wavelengths))
    wav_max = float(np.nanmax(wavelengths))

    for sensor in _SENSOR_PROFILES:
        if (sensor['wav_min'] <= wav_min <= sensor['wav_min'] + 80 and
                sensor['wav_max'] - 80 <= wav_max <= sensor['wav_max'] and
                sensor['bands_min'] <= num_bands <= sensor['bands_max']):
            return {
                'name':      sensor['name'],
                'matched':   True,
                'bad_zones': sensor['bad_zones'],
                'snr_poor':  sensor['snr_poor'],
                'snr_note':  sensor['snr_note'],
            }

    return {'name': 'Unknown', 'matched': False,
            'bad_zones': [], 'snr_poor': [], 'snr_note': ''}


def has_poor_snr_in_range(sensor_info, range_start_nm, range_end_nm):
    """
    Return True if any part of range_start_nm–range_end_nm overlaps a
    poor-SNR zone for the identified sensor.
    """
    for snr_start, snr_end in sensor_info.get('snr_poor', []):
        if range_start_nm < snr_end and range_end_nm > snr_start:
            return True
    return False


def _synthesise_bbl(wavelengths, num_bands, feedback=None):
    """
    Attempt to synthesise a BBL for a known sensor fingerprint.

    Returns a boolean numpy array (True = good band) if the sensor is
    recognised, or None if it cannot be identified.
    """
    def log(msg):
        if feedback:
            feedback.pushInfo(msg)

    if wavelengths is None or len(wavelengths) != num_bands:
        return None

    info = get_sensor_info(wavelengths, num_bands)
    if not info['matched'] or not info['bad_zones']:
        return None

    bbl = np.ones(num_bands, dtype=bool)
    for bad_start, bad_end in info['bad_zones']:
        mask = (wavelengths >= bad_start) & (wavelengths <= bad_end)
        bbl[mask] = False

    good = int(np.sum(bbl))
    bad  = num_bands - good
    log(
        f"BBL synthesised for {info['name']} "
        f"(no BBL in metadata): {good} good, {bad} bad bands masked "
        f"({', '.join(f'{s:.0f}–{e:.0f} nm' for s, e in info['bad_zones'])})"
    )
    return bbl
