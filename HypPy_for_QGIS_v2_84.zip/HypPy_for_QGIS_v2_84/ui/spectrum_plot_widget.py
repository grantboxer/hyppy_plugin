"""
Spectral Plot Widget  —  HypPy matplotlib-style renderer
=========================================================
A lightweight spectral chart widget built on pure QPainter.

Styling matches the HypPy 3.0.1 matplotlib plot window (tkSpecLib.py):
  - White background, light grey grid (matplotlib defaults)
  - matplotlib C0–C9 colour cycle
  - Black axis spines, inward ticks
  - Legend with line-handle swatches, 8pt font (legend.fontsize=8)
  - X label driven by ENVI 'wavelength units' header field
    ("wavelength (Micrometers)" etc.) — exactly replicating
    xlabel('wavelength (%s)' % units) in tkSpecLib.py
  - Library spectra on true Y scale, right axis
  - Overrideable x/y labels, title, and axis ranges
    (Set xlabel / Set ylabel / Set title / Set axes / Reset axes
     matching the HypPy SpecLib Viewer  View menu)
  - Vertical marker lines for special wavelengths (REE bands etc.)
  - Mouse crosshair + tooltip; right-click context menu

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
Original HypPy tkSpecLib concept: Copyright (C) Wim Bakker, Univ. of Twente.
"""

import numpy as np

from qgis.PyQt.QtWidgets import QWidget, QToolTip, QMenu, QAction, QApplication
from qgis.PyQt.QtCore    import Qt, QRect, QPoint, QPointF, QSize
from qgis.PyQt.QtGui     import (QPainter, QPen, QBrush, QColor, QFont,
                                  QFontMetrics, QPolygonF, QCursor)

from ..core.qt_compat import Enums as E, exec_menu, get_event_pos


# ── Matplotlib tab10 colour cycle ─────────────────────────────────────────────
_LIB_COLORS = [
    QColor('#1f77b4'),  # C0 mpl blue
    QColor('#ff7f0e'),  # C1 mpl orange
    QColor('#2ca02c'),  # C2 mpl green
    QColor('#9467bd'),  # C4 mpl purple
    QColor('#8c564b'),  # C5 mpl brown
    QColor('#e377c2'),  # C6 mpl pink
    QColor('#7f7f7f'),  # C7 mpl grey
    QColor('#bcbd22'),  # C8 mpl yellow-green
    QColor('#17becf'),  # C9 mpl teal
    QColor('#d62728'),  # C3 mpl red
]

# Pixel spectrum uses a bold crimson so it is immediately distinct from
# the blue/orange/green library palette above.
_PIXEL_COLOR = QColor('#C62828')    # deep red
_BACKGROUND  = QColor('#FFFFFF')
_GRID_COLOR  = QColor('#B0B0B0')    # matplotlib default grid
_SPINE_COLOR = QColor('#000000')
_LABEL_COLOR = QColor('#000000')
_LEGEND_EDGE = QColor('#CCCCCC')

_MARGIN = {'l': 72, 'r': 24, 't': 28, 'b': 56}


class SpectrumPlotWidget(QWidget):
    """
    Spectral plot styled to match the HypPy 3.0.1 matplotlib figure window.

    Left  Y  — all spectra normalised 0–1 per-series (shared axis)
    X        — wavelength in display units (µm or nm from ENVI header)
    Markers  — optional vertical lines at specified wavelengths (nm)

    Normalisation: each series (pixel + each library spectrum) is independently
    scaled to [0, 1] using its own finite min/max so that spectral shapes can
    be compared directly regardless of units or absolute reflectance level.
    The Y axis always shows 0–1.  Raw values appear in the mouse tooltip.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(QSize(320, 200))
        self.setMouseTracking(True)
        self.setContextMenuPolicy(E.CustomContextMenu)
        self.customContextMenuRequested.connect(self._context_menu)

        self._pixel_wav   = None
        self._pixel_val   = None
        self._pixel_label = ''

        # list of (wav_nm, val, name, QColor)
        self._lib_spectra = []

        # Wavelength units
        self._wav_units     = None
        self._display_in_um = False

        # Axis limits (auto-computed); Y is always normalised 0–1
        self._x_min = self._x_max = None
        self._y_min = self._y_max = None

        # Manual overrides — set via Set axes / Reset axes
        self._x_min_ovr = self._x_max_ovr = None
        self._y_min_ovr = self._y_max_ovr = None

        # Label / title overrides — set via Set xlabel / Set ylabel / Set title
        self._xlabel_ovr = None
        self._ylabel_ovr = None
        self._title_ovr  = None

        # Vertical marker lines: list of (wav_nm, QColor, label_str)
        self._markers = []

        self._legend_visible = True
        self._mouse_x = self._mouse_y = None

        # Legend drag state
        self._legend_pos         = None   # (bx, by) override; None = auto top-right
        self._legend_rect        = None   # QRect of last-drawn legend box (hit-test)
        self._legend_drag        = False  # currently dragging?
        self._legend_drag_offset = None   # (dx, dy) from box origin at press

        # Band point markers
        self._show_points = False   # draw a dot at each band position

    # ── Public API ─────────────────────────────────────────────────────────────

    def set_wav_units(self, units_str):
        self._wav_units = units_str
        u = (units_str or '').strip().lower()
        self._display_in_um = u in ('micrometers', 'microns', 'um', 'µm')
        self._recompute_limits()
        self.update()

    def set_pixel_spectrum(self, wavelengths, values, label='', legend_visible=True):
        self._pixel_wav   = np.asarray(wavelengths, dtype=float)
        self._pixel_val   = np.asarray(values,      dtype=float)
        # Mask negative reflectance values (noisy detector bands) as NaN
        # so they appear as gaps in the plot rather than pulling the axis down
        self._pixel_val[self._pixel_val < 0] = np.nan
        self._pixel_label = label
        self._legend_visible = legend_visible
        self._recompute_limits()
        self.update()

    def add_library_spectrum(self, wavelengths, values, name='',
                             legend_visible=True, wav_units=None):
        if len(self._lib_spectra) >= len(_LIB_COLORS):
            return
        if wav_units is not None and self._wav_units is None:
            self.set_wav_units(wav_units)
        color = _LIB_COLORS[len(self._lib_spectra)]
        self._lib_spectra.append((
            np.asarray(wavelengths, dtype=float),
            np.asarray(values,      dtype=float),
            name, color
        ))
        self._legend_visible = legend_visible
        self._recompute_limits()
        self.update()

    def set_legend_visible(self, visible):
        self._legend_visible = visible
        self.update()

    def reset_legend_position(self):
        """Reset legend to default top-right position."""
        self._legend_pos = None
        self.update()

    def clear_library_spectra(self):
        self._lib_spectra.clear()
        self._wav_units = None
        self._display_in_um = False
        self._recompute_limits()
        self.update()

    def clear_all(self):
        self._pixel_wav = self._pixel_val = None
        self._pixel_label = ''
        self._lib_spectra.clear()
        self._wav_units = None
        self._display_in_um = False
        self._x_min = self._x_max = None
        self._y_min = self._y_max = None
        self.update()

    def has_pixel_spectrum(self):
        return self._pixel_wav is not None and len(self._pixel_wav) > 0

    # ── View-menu overrides (Set xlabel / Set ylabel / Set title / Set axes) ──

    def set_xlabel_override(self, label):
        """Set xlabel — mirrors HypPy View > Set xlabel."""
        self._xlabel_ovr = label or None
        self.update()

    def set_ylabel_override(self, label):
        """Set ylabel — mirrors HypPy View > Set ylabel."""
        self._ylabel_ovr = label or None
        self.update()

    def set_title_override(self, title):
        """Set title — mirrors HypPy View > Set title."""
        self._title_ovr = title or None
        self.update()

    def set_axes_override(self, x_min, x_max, y_min, y_max):
        """Set axes — mirrors HypPy View > Set axes."""
        self._x_min_ovr = float(x_min) if x_min is not None else None
        self._x_max_ovr = float(x_max) if x_max is not None else None
        self._y_min_ovr = float(y_min) if y_min is not None else None
        self._y_max_ovr = float(y_max) if y_max is not None else None
        self._recompute_limits()
        self.update()

    def reset_axes(self):
        """Reset axes — mirrors HypPy View > Reset axes."""
        self._x_min_ovr = self._x_max_ovr = None
        self._y_min_ovr = self._y_max_ovr = None
        self._recompute_limits()
        self.update()

    # ── Marker lines ───────────────────────────────────────────────────────────

    def set_markers(self, markers):
        """
        Set vertical marker lines.
        markers: list of (wav_nm, color_str_or_QColor, label_str)
        e.g. [(580, '#e74c3c', '580'), (740, '#e74c3c', '740'), ...]
        Pass [] to clear.
        """
        self._markers = []
        for item in markers:
            wav, col, lbl = item
            c = QColor(col) if isinstance(col, str) else col
            self._markers.append((float(wav), c, str(lbl)))
        self.update()

    def clear_markers(self):
        self._markers.clear()
        self.update()

    # ── Unit helpers ───────────────────────────────────────────────────────────

    def _to_display(self, wav_nm):
        a = np.asarray(wav_nm, float)
        return a / 1000.0 if self._display_in_um else a

    def _x_label_str(self):
        if self._xlabel_ovr:
            return self._xlabel_ovr
        if self._wav_units:
            return f'wavelength ({self._wav_units})'
        return 'wavelength (Micrometers)' if self._display_in_um else 'wavelength (nm)'

    def _y_label_str(self):
        return self._ylabel_ovr if self._ylabel_ovr else 'reflectance (normalised)'

    def _title_str(self):
        return self._title_ovr or ''

    # ── Axis limits ────────────────────────────────────────────────────────────

    def _norm01(self, vals):
        """
        Normalise a 1-D array to [0, 1] using its own finite min/max.
        Returns (normalised_array, raw_min, raw_max).
        If the series is flat (min==max) returns all-0.5.
        """
        v = np.asarray(vals, dtype=float)
        m = np.isfinite(v)
        if not m.any():
            return np.full_like(v, np.nan), np.nan, np.nan
        lo, hi = v[m].min(), v[m].max()
        if hi == lo:
            out = np.where(m, 0.5, np.nan)
            return out, lo, hi
        out = np.where(m, (v - lo) / (hi - lo), np.nan)
        return out, lo, hi

    def _safe_range(self, vals):
        m = np.isfinite(vals)
        if not m.any():
            return 0.0, 1.0
        lo, hi = vals[m].min(), vals[m].max()
        span = hi - lo if hi > lo else max(abs(hi) * 0.1, 0.01)
        return lo - span * 0.05, hi + span * 0.05

    def _recompute_limits(self):
        all_x = []
        if self._pixel_wav is not None and len(self._pixel_wav):
            m = np.isfinite(self._pixel_wav)
            if m.any():
                all_x.append(self._to_display(self._pixel_wav[m]))
        for wav, *_ in self._lib_spectra:
            m = np.isfinite(wav)
            if m.any():
                all_x.append(self._to_display(wav[m]))

        if not all_x:
            self._x_min = self._x_max = self._y_min = self._y_max = None
            return

        xs  = np.concatenate(all_x)
        xr  = xs.max() - xs.min()
        pad = xr * 0.02 if xr > 0 else 0.01
        self._x_min = float(xs.min() - pad)
        self._x_max = float(xs.max() + pad)

        # Y axis: auto-stretch to fit the data values visible in the current
        # X window.  Each series is normalised 0–1 independently; we collect
        # those normalised values that fall within the X range and compute a
        # tight Y range with a small padding so the profile fills the plot.
        # Use the effective X limits (respects any X override) so that setting
        # an X range also auto-scales the Y to the visible data.
        x0_disp = self._x_min_ovr if self._x_min_ovr is not None else self._x_min
        x1_disp = self._x_max_ovr if self._x_max_ovr is not None else self._x_max
        all_y = []

        if self._pixel_wav is not None and len(self._pixel_wav):
            norm_val, _, _ = self._norm01(self._pixel_val)
            wav_disp = self._to_display(self._pixel_wav)
            mask = (np.isfinite(wav_disp) & np.isfinite(norm_val) &
                    (wav_disp >= x0_disp) & (wav_disp <= x1_disp))
            if mask.any():
                all_y.append(norm_val[mask])

        for wav, val, *_ in self._lib_spectra:
            norm_val, _, _ = self._norm01(val)
            wav_disp = self._to_display(wav)
            mask = (np.isfinite(wav_disp) & np.isfinite(norm_val) &
                    (wav_disp >= x0_disp) & (wav_disp <= x1_disp))
            if mask.any():
                all_y.append(norm_val[mask])

        if all_y:
            combined = np.concatenate(all_y)
            ylo, yhi = combined.min(), combined.max()
            pad = (yhi - ylo) * 0.05 if yhi > ylo else 0.05
            self._y_min = float(ylo - pad)
            self._y_max = float(yhi + pad)
        else:
            self._y_min = -0.02
            self._y_max =  1.05

    def _effective_xlim(self):
        x0 = self._x_min_ovr if self._x_min_ovr is not None else self._x_min
        x1 = self._x_max_ovr if self._x_max_ovr is not None else self._x_max
        return x0, x1

    def _effective_ylim(self):
        y0 = self._y_min_ovr if self._y_min_ovr is not None else self._y_min
        y1 = self._y_max_ovr if self._y_max_ovr is not None else self._y_max
        return y0, y1

    # ── Coordinate helpers ─────────────────────────────────────────────────────

    def _plot_rect(self):
        m = _MARGIN
        return QRect(m['l'], m['t'],
                     self.width()  - m['l'] - m['r'],
                     self.height() - m['t'] - m['b'])

    def _cx(self, wav_disp):
        r = self._plot_rect()
        x0, x1 = self._effective_xlim()
        rng = (x1 - x0) if x1 != x0 else 1.0
        return r.x() + (np.asarray(wav_disp, float) - x0) / rng * r.width()

    def _cy_left(self, val):
        r = self._plot_rect()
        y0, y1 = self._effective_ylim()
        rng = (y1 - y0) if y1 != y0 else 1.0
        return r.bottom() - (np.asarray(val, float) - y0) / rng * r.height()

    def _canvas_to_data(self, cx, cy):
        r = self._plot_rect()
        if r.width() <= 0 or r.height() <= 0:
            return None, None
        x0, x1 = self._effective_xlim()
        y0, y1 = self._effective_ylim()
        if x0 is None or y0 is None:
            return None, None
        wav = x0 + (cx - r.x()) / r.width()  * (x1 - x0)
        val = y0 + (r.bottom() - cy) / r.height() * (y1 - y0)
        return wav, val

    # ── Paint ──────────────────────────────────────────────────────────────────

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), _BACKGROUND)

        x0, x1 = self._effective_xlim()
        if x0 is None:
            # Nothing loaded at all — show placeholder
            if not self._lib_spectra:
                p.setPen(QPen(QColor('#AAAAAA')))
                p.setFont(QFont('Arial', 10))
                p.drawText(self.rect(), E.AlignCenter,
                           'Click a pixel on the map to display its spectrum')
            return

        r = self._plot_rect()
        p.fillRect(r, _BACKGROUND)
        self._draw_grid(p)

        # Marker lines behind spectra
        self._draw_markers(p)

        # Library spectra — normalised 0–1, shared left Y axis
        for wav, val, name, color in self._lib_spectra:
            norm_val, _, _ = self._norm01(val)
            self._polyline(p,
                self._cx(self._to_display(wav)),
                self._cy_left(norm_val), color, lw=1.5)

        # Pixel spectrum — normalised 0–1, shared left Y axis
        if self._pixel_wav is not None and len(self._pixel_wav) >= 1:
            norm_val, _, _ = self._norm01(self._pixel_val)
            self._polyline(p,
                self._cx(self._to_display(self._pixel_wav)),
                self._cy_left(norm_val), _PIXEL_COLOR, lw=1.5)

        # Band point markers (drawn on top of all lines)
        if self._show_points:
            self._draw_points(p)

        self._draw_axes(p)

        if self._legend_visible:
            self._draw_legend(p)

        if (self._mouse_x is not None and
                r.contains(QPoint(self._mouse_x, self._mouse_y))):
            self._draw_crosshair(p)

    def _draw_grid(self, p):
        r = self._plot_rect()
        p.setPen(QPen(_GRID_COLOR, 0.8, E.SolidLine))
        for i in range(1, 6):
            x = r.x() + int(i * r.width() / 6)
            p.drawLine(x, r.top(), x, r.bottom())
        for i in range(1, 5):
            y = r.top() + int(i * r.height() / 5)
            p.drawLine(r.left(), y, r.right(), y)

    def _draw_markers(self, p):
        """Draw vertical lines at specified wavelengths (e.g. REE Nd bands)."""
        if not self._markers:
            return
        r    = self._plot_rect()
        font = QFont('Arial', 7)
        p.setFont(font)
        fm   = QFontMetrics(font)
        p.save()
        p.setClipRect(r)
        for wav_nm, color, lbl in self._markers:
            wav_disp = wav_nm / 1000.0 if self._display_in_um else wav_nm
            xs = self._cx(np.array([wav_disp]))
            x  = int(xs[0])
            pen = QPen(color, 1.2, E.SolidLine)
            p.setPen(pen)
            p.drawLine(x, r.top(), x, r.bottom())
            # Label above the line
            if lbl:
                p.save()
                p.translate(x + 2, r.top() + fm.height())
                p.rotate(-90)
                p.setPen(QPen(color))
                p.drawText(0, 0, lbl)
                p.restore()
        p.restore()

    def _draw_axes(self, p):
        r    = self._plot_rect()
        font = QFont('Arial', 8)
        p.setFont(font)
        fm   = QFontMetrics(font)
        x0, x1 = self._effective_xlim()
        y0, y1 = self._effective_ylim()

        # Don't draw axes if limits aren't available yet
        if x0 is None or y0 is None:
            return

        # Title
        t = self._title_str()
        if t:
            p.setPen(QPen(_LABEL_COLOR))
            p.setFont(QFont('Arial', 9, E.FontBold))
            p.drawText(r.x() + (r.width() - QFontMetrics(QFont('Arial', 9, E.FontBold)).horizontalAdvance(t)) // 2,
                       _MARGIN['t'] - 4, t)
            p.setFont(font)

        # Spines
        p.setPen(QPen(_SPINE_COLOR, 1.0))
        p.drawRect(r)

        # X ticks + labels
        n_x = 6
        for i in range(n_x + 1):
            wav = x0 + (x1 - x0) * i / n_x
            x   = r.x() + int(i * r.width() / n_x)
            p.setPen(QPen(_SPINE_COLOR, 1.0))
            p.drawLine(x, r.bottom(), x, r.bottom() - 4)
            p.drawLine(x, r.top(),    x, r.top()    + 2)
            lbl = f'{wav:.2f}' if self._display_in_um else f'{wav:.0f}'
            tw  = fm.horizontalAdvance(lbl)
            p.setPen(QPen(_LABEL_COLOR))
            p.drawText(x - tw // 2, r.bottom() + fm.height() + 2, lbl)

        # X label
        x_lbl = self._x_label_str()
        p.setPen(QPen(_LABEL_COLOR))
        p.drawText(r.x() + (r.width() - fm.horizontalAdvance(x_lbl)) // 2,
                   self.height() - 4, x_lbl)

        # Left Y ticks + labels
        n_y = 5
        for i in range(n_y + 1):
            val = y0 + (y1 - y0) * i / n_y
            y   = r.bottom() - int(i * r.height() / n_y)
            p.setPen(QPen(_SPINE_COLOR, 1.0))
            p.drawLine(r.left(), y, r.left() + 4, y)
            p.drawLine(r.right(), y, r.right() - 2, y)
            lbl = f'{val:.4g}'
            p.setPen(QPen(_LABEL_COLOR))
            p.drawText(r.left() - fm.horizontalAdvance(lbl) - 6,
                       y + fm.ascent() // 2, lbl)

        p.save()
        p.setPen(QPen(_LABEL_COLOR))
        p.translate(10, r.y() + r.height() // 2)
        p.rotate(-90)
        yl = self._y_label_str()
        p.drawText(-fm.horizontalAdvance(yl) // 2, 0, yl)
        p.restore()

    def _polyline(self, p, cx, cy, color, lw=1.5):
        """Draw a polyline, breaking at NaN gaps into separate segments.

        Uses QPolygonF list-constructor (Qt5 and Qt6 compatible) instead of
        the Qt5-only QPolygonF.append() method.  Segments separated by NaN
        values (e.g. water-vapour atmospheric bands) are drawn as independent
        polylines so no connecting line spans the gap.
        """
        r  = self._plot_rect()
        cx = np.asarray(cx, float)
        cy = np.asarray(cy, float)
        valid = np.isfinite(cx) & np.isfinite(cy)
        if valid.sum() < 2:
            return
        p.save()
        p.setClipRect(r)
        pen = QPen(color, lw)
        pen.setCapStyle(E.RoundCap)
        pen.setJoinStyle(E.RoundJoin)
        p.setPen(pen)

        # Split into contiguous valid segments and draw each separately.
        # This prevents straight lines being drawn across NaN gaps (e.g.
        # atmospheric water-vapour bands stored as nodata).
        seg = []
        for i in range(len(cx)):
            if valid[i]:
                seg.append(QPointF(float(cx[i]), float(cy[i])))
            else:
                if len(seg) >= 2:
                    p.drawPolyline(QPolygonF(seg))
                seg = []
        if len(seg) >= 2:
            p.drawPolyline(QPolygonF(seg))

        p.restore()

    def _draw_points(self, p):
        """Draw a small filled circle at each band position for all spectra.

        The dot colour matches the spectrum line.  A white halo is drawn first
        so points are visible against both the plot background and the line.
        Points outside the current X/Y clip region are suppressed.
        """
        r  = self._plot_rect()
        RADIUS  = 3        # filled dot radius (px)
        HALO    = RADIUS + 1   # white halo radius (px)

        p.save()
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setClipRect(r)

        def _plot_dots(cx_arr, cy_arr, color):
            halo_brush = QBrush(QColor(255, 255, 255, 200))
            fill_brush = QBrush(color)
            no_pen     = QPen(Qt.NoPen if hasattr(Qt, 'NoPen')
                              else Qt.PenStyle.NoPen)
            for cx_f, cy_f in zip(cx_arr, cy_arr):
                if not (np.isfinite(cx_f) and np.isfinite(cy_f)):
                    continue
                cx_i, cy_i = int(round(cx_f)), int(round(cy_f))
                # White halo
                p.setPen(no_pen)
                p.setBrush(halo_brush)
                p.drawEllipse(QPoint(cx_i, cy_i), HALO, HALO)
                # Filled dot
                p.setBrush(fill_brush)
                p.drawEllipse(QPoint(cx_i, cy_i), RADIUS, RADIUS)

        # Pixel spectrum
        if self._pixel_wav is not None and len(self._pixel_wav) >= 1:
            norm_val, _, _ = self._norm01(self._pixel_val)
            cx = self._cx(self._to_display(self._pixel_wav))
            cy = self._cy_left(norm_val)
            _plot_dots(cx, cy, _PIXEL_COLOR)

        # Library spectra
        for wav, val, _name, color in self._lib_spectra:
            norm_val, _, _ = self._norm01(val)
            cx = self._cx(self._to_display(wav))
            cy = self._cy_left(norm_val)
            _plot_dots(cx, cy, color)

        p.restore()

    def _draw_legend(self, p):
        r = self._plot_rect()
        entries = []
        if self._pixel_wav is not None and len(self._pixel_wav) > 0:
            entries.append((_PIXEL_COLOR, self._pixel_label or 'Pixel spectrum'))
        for _, _, name, color in self._lib_spectra:
            entries.append((color, name))
        if not entries:
            self._legend_rect = None
            return

        font = QFont('Arial', 8)
        p.setFont(font)
        fm   = QFontMetrics(font)
        lh   = fm.height() + 3
        sw   = 22
        gap  = 6
        max_tw = max(fm.horizontalAdvance(lbl) for _, lbl in entries)
        box_w  = 6 + sw + gap + max_tw + 6
        box_h  = len(entries) * lh + 6

        # Position: use dragged position if set, otherwise default top-right
        if self._legend_pos is not None:
            bx, by = self._legend_pos
            # Clamp so legend stays inside the widget
            bx = max(0, min(bx, self.width()  - box_w))
            by = max(0, min(by, self.height() - box_h))
        else:
            bx = r.right() - box_w - 6
            by = r.top() + 6

        # Store for hit-testing in mouse events
        from qgis.PyQt.QtCore import QRect as _QRect
        self._legend_rect = _QRect(bx, by, box_w, box_h)

        # Draw box — slightly darker border when hovered to indicate draggability
        hovered = (self._legend_rect.contains(QPoint(self._mouse_x or -1,
                                                      self._mouse_y or -1)))
        p.fillRect(bx, by, box_w, box_h, QColor(255, 255, 255, 230))
        border_color = QColor('#888888') if hovered else _LEGEND_EDGE
        p.setPen(QPen(border_color, 1.5 if hovered else 1.0))
        p.drawRect(bx, by, box_w, box_h)

        for i, (color, lbl) in enumerate(entries):
            y   = by + 4 + i * lh
            mid = y + lh // 2
            p.setPen(QPen(color, 2.0))
            p.drawLine(bx + 5, mid, bx + 5 + sw, mid)
            p.setPen(QPen(_LABEL_COLOR))
            disp = lbl
            while fm.horizontalAdvance(disp) > max_tw + 4 and len(disp) > 6:
                disp = disp[:-4] + '…'
            p.drawText(bx + 5 + sw + gap, y + fm.ascent(), disp)

    def _draw_crosshair(self, p):
        r = self._plot_rect()
        p.setPen(QPen(QColor(100, 100, 100, 160), 1, E.SolidLine))
        p.drawLine(self._mouse_x, r.top(),  self._mouse_x, r.bottom())
        p.drawLine(r.left(), self._mouse_y, r.right(),     self._mouse_y)

    # ── Mouse ──────────────────────────────────────────────────────────────────

    def _in_legend(self, x, y):
        """Return True if (x,y) is inside the current legend box."""
        return (self._legend_rect is not None and
                self._legend_visible and
                self._legend_rect.contains(QPoint(int(x), int(y))))

    def mousePressEvent(self, event):
        _pos = get_event_pos(event)
        if event.button() == E.LeftButton and self._in_legend(
                int(_pos.x()), int(_pos.y())):
            self._legend_drag = True
            bx = self._legend_rect.x()
            by = self._legend_rect.y()
            self._legend_drag_offset = (int(_pos.x()) - bx,
                                        int(_pos.y()) - by)
            self.setCursor(QCursor(E.ClosedHandCursor))
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == E.LeftButton and self._legend_drag:
            self._legend_drag = False
            self._legend_drag_offset = None
            _pos = get_event_pos(event)
            # Restore cursor based on current hover state
            if self._in_legend(int(_pos.x()), int(_pos.y())):
                self.setCursor(QCursor(E.OpenHandCursor))
            else:
                self.setCursor(QCursor(E.ArrowCursor))
            event.accept()
        else:
            super().mouseReleaseEvent(event)

    def mouseMoveEvent(self, event):
        _pos = get_event_pos(event)
        x, y = int(_pos.x()), int(_pos.y())
        self._mouse_x = x
        self._mouse_y = y

        if self._legend_drag and self._legend_drag_offset is not None:
            # Move the legend
            dx, dy = self._legend_drag_offset
            self._legend_pos = (x - dx, y - dy)
            self.setCursor(QCursor(E.ClosedHandCursor))
            self.update()
            return

        # Cursor: open hand over legend, crosshair in plot area, arrow elsewhere
        if self._in_legend(x, y):
            self.setCursor(QCursor(E.OpenHandCursor))
            QToolTip.hideText()
            self.update()
            return

        self.setCursor(QCursor(E.ArrowCursor))

        if self._effective_xlim()[0] is not None and \
                self._plot_rect().contains(QPoint(x, y)):
            wav, val = self._canvas_to_data(x, y)
            if wav is not None:
                wav_str = (f'{wav:.4f} µm' if self._display_in_um
                           else f'{wav:.1f} nm')
                fmt = f'{wav_str}  /  {val:.3f} (normalised)'
                # globalPosition() returns QPointF (Qt6); pos()/globalPos() in Qt5
                gpos = (event.globalPosition().toPoint()
                        if hasattr(event, 'globalPosition')
                        else event.globalPos())
                QToolTip.showText(gpos, fmt, self)
        else:
            QToolTip.hideText()
        self.update()

    def leaveEvent(self, event):
        self._mouse_x = self._mouse_y = None
        if not self._legend_drag:
            self.setCursor(QCursor(E.ArrowCursor))
        self.update()

    # ── Context menu ───────────────────────────────────────────────────────────

    def _context_menu(self, pos):
        menu = QMenu(self)
        a_csv   = QAction('Copy pixel spectrum as CSV', self)
        a_clear = QAction('Clear library spectra', self)
        a_all   = QAction('Clear all', self)
        a_reset_leg = QAction('Reset legend position', self)
        a_points = QAction('Show band points', self)
        a_points.setCheckable(True)
        a_points.setChecked(self._show_points)
        a_csv.setEnabled(self._pixel_wav is not None)
        a_clear.setEnabled(bool(self._lib_spectra))
        a_reset_leg.setEnabled(self._legend_pos is not None)
        menu.addAction(a_csv)
        menu.addSeparator()
        menu.addAction(a_points)
        menu.addSeparator()
        menu.addAction(a_clear)
        menu.addAction(a_all)
        menu.addSeparator()
        menu.addAction(a_reset_leg)
        a_csv.triggered.connect(self._copy_csv)
        a_points.triggered.connect(self._toggle_points)
        a_clear.triggered.connect(self.clear_library_spectra)
        a_all.triggered.connect(self.clear_all)
        a_reset_leg.triggered.connect(self.reset_legend_position)
        exec_menu(menu, self.mapToGlobal(pos))

    def _toggle_points(self, checked):
        self._show_points = checked
        self.update()

    def _copy_csv(self):
        if self._pixel_wav is None:
            return
        lines = ['wavelength_nm,value']
        for w, v in zip(self._pixel_wav, self._pixel_val):
            lines.append(f'{w:.4f},{v:.6g}')
        QApplication.clipboard().setText('\n'.join(lines))
