"""
PCA (Principal Components Analysis) Algorithm for QGIS Processing

Performs forward PCA on an ENVI hyperspectral image using SVD decomposition.
Outputs a multi-band raster of PC score images plus a text statistics file
containing the mean vector, singular values (sqrt of eigenvalues), and
eigenvector matrix needed to reconstruct the original data.

Ported from HyPy pca.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original HyPy Copyright (C) 2010-2022 Wim Bakker, University of Twente

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import os
import pickle
import tempfile

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterEnum,
    QgsProcessingParameterExtent,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis,
)

from ..core.envi_header import (
    get_wavelengths_from_dataset,
    get_bbl_from_dataset,
    find_hdr,
    parse_hdr,
)

gdal.UseExceptions()


# ── Helpers ──────────────────────────────────────────────────────────────────

def _log(msg, feedback=None):
    if feedback:
        feedback.pushInfo(msg)
    QgsMessageLog.logMessage(msg, 'HypPy PCA', Qgis.Info)


def _write_envi_hdr(path, lines, samples, bands, dtype_str,
                    band_names=None, wavelengths=None,
                    map_info=None, coord_sys=None, description=''):
    """Write a minimal ENVI .hdr sidecar for the PC output raster."""
    gdal_to_envi = {
        'uint8': 1, 'int16': 2, 'int32': 3, 'float32': 4,
        'float64': 5, 'uint16': 12, 'uint32': 13,
    }
    envi_dt = gdal_to_envi.get(dtype_str, 4)   # default float32
    lines_out = ['ENVI']
    if description:
        lines_out.append(f'description = {{{description}}}')
    lines_out += [
        f'samples = {samples}',
        f'lines   = {lines}',
        f'bands   = {bands}',
        f'header offset = 0',
        f'file type = ENVI Standard',
        f'data type = {envi_dt}',
        f'interleave = bsq',
        f'byte order = 0',
    ]
    if band_names:
        lines_out.append('band names = {' + ', '.join(band_names) + '}')
    if wavelengths:
        lines_out.append('wavelength = {' +
                         ', '.join(f'{w:.4f}' for w in wavelengths) + '}')
        lines_out.append('wavelength units = Nanometers')
    if map_info:
        lines_out.append(f'map info = {map_info}')
    if coord_sys:
        lines_out.append(f'coordinate system string = {coord_sys}')

    hdr_path = path + '.hdr'
    with open(hdr_path, 'w') as f:
        f.write('\n'.join(lines_out) + '\n')
    return hdr_path


def _write_stats(stats_path, Xm, s, V, wavelengths):
    """Pickle PCA statistics (mean, singular values, eigenvectors, wavelengths)."""
    with open(stats_path, 'wb') as f:
        pickle.dump(np.array(Xm), f)
        pickle.dump(s, f)
        pickle.dump(V, f)
        pickle.dump(wavelengths, f)


def _fast_svd(X, n_components):
    """
    Thin SVD via numpy, returning U (scores), s (singular values), Vt.
    Uses full SVD then truncates to n_components for memory efficiency.
    """
    U, s, Vt = np.linalg.svd(X, full_matrices=False)
    return U[:, :n_components], s[:n_components], Vt[:n_components, :]


class PcaAlgorithm(QgsProcessingAlgorithm):
    """
    Forward PCA on a hyperspectral image.

    Computes principal components using SVD.  Optionally restricts statistics
    to a spatial bounding box (useful for large scenes where you want PC axes
    determined from a representative sub-region).

    Output:
        • Multi-band PC score image (float32, BSQ)
        • Binary statistics file (.pca_stats) for use by Inverse PCA
    """

    INPUT           = 'INPUT'
    N_COMPONENTS    = 'N_COMPONENTS'
    SORT_WAV        = 'SORT_WAV'
    USE_BBL         = 'USE_BBL'
    USE_BBOX        = 'USE_BBOX'
    BBOX            = 'BBOX'
    NAN_SAFE        = 'NAN_SAFE'
    OUTPUT          = 'OUTPUT'
    OUTPUT_STATS    = 'OUTPUT_STATS'

    def initAlgorithm(self, config=None):

        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT,
                'Input Hyperspectral Image (ENVI)',
                optional=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.N_COMPONENTS,
                'Number of PC components to output (0 = all bands)',
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=0,
                minValue=0,
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.SORT_WAV,
                'Sort bands by ascending wavelength before PCA',
                defaultValue=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.USE_BBL,
                'Exclude bad bands (use Bad Band List from header)',
                defaultValue=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.USE_BBOX,
                'Restrict statistics to a spatial bounding box\n'
                '(tick = use extent below for covariance stats only;\n'
                ' the full image is still projected into PC space)',
                defaultValue=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterExtent(
                self.BBOX,
                'Bounding box for statistics (used when "Restrict to bounding box" is ticked)',
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.NAN_SAFE,
                'NaN-safe mode (ignore pixels with any NaN band; '
                'slower but required for masked data)',
                defaultValue=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                'Output PC Score Image',
            )
        )
        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.OUTPUT_STATS,
                'Output PCA Statistics File (.pca_stats)',
                fileFilter='PCA Stats (*.pca_stats)',
                optional=True,
                defaultValue='',
            )
        )

    # ── processAlgorithm ────────────────────────────────────────────────────

    def processAlgorithm(self, parameters, context, feedback):

        # ── Resolve all parameters BEFORE opening GDAL ──────────────────
        bbox_rect = None
        if self.parameterAsBoolean(parameters, self.USE_BBOX, context):
            bbox_rect = self.parameterAsExtent(parameters, self.BBOX, context)
            if bbox_rect is None or bbox_rect.isEmpty():
                raise QgsProcessingException(
                    "Bounding box mode is ticked but no extent was supplied."
                )

        input_layer  = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        raster_path  = input_layer.source()
        n_components = self.parameterAsInt(parameters, self.N_COMPONENTS, context)
        sort_wav     = self.parameterAsBoolean(parameters, self.SORT_WAV, context)
        use_bbl      = self.parameterAsBoolean(parameters, self.USE_BBL, context)
        nan_safe     = self.parameterAsBoolean(parameters, self.NAN_SAFE, context)
        fout         = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        stats_path   = self.parameterAsFileOutput(parameters, self.OUTPUT_STATS, context)
        if not stats_path:
            stats_path = fout + '.pca_stats'

        _log("=== HypPy PCA (Forward) ===", feedback)
        _log(f"Input: {raster_path}", feedback)

        # ── Open dataset ────────────────────────────────────────────────
        ds = gdal.Open(raster_path, gdal.GA_ReadOnly)
        if ds is None:
            raise QgsProcessingException(f"Cannot open raster: {raster_path}")

        n_bands_raw = ds.RasterCount
        n_lines     = ds.RasterYSize
        n_samps     = ds.RasterXSize
        gt          = ds.GetGeoTransform()
        proj        = ds.GetProjection()

        _log(f"Image: {n_bands_raw} bands × {n_lines} lines × {n_samps} samples",
             feedback)

        # ── Wavelengths and BBL ─────────────────────────────────────────
        wavelengths = get_wavelengths_from_dataset(ds, n_bands_raw, raster_path, feedback)
        bbl_raw     = get_bbl_from_dataset(ds, n_bands_raw, raster_path, feedback)

        # ── Build band order (sort + BBL filter) ─────────────────────────
        order = list(range(n_bands_raw))
        if sort_wav and wavelengths is not None:
            order = sorted(order, key=lambda i: wavelengths[i])
        if use_bbl and bbl_raw is not None:
            order = [i for i in order if bbl_raw[i]]
            _log(f"After BBL filter: {len(order)} good bands", feedback)

        n_bands = len(order)
        if n_components <= 0 or n_components > n_bands:
            n_components = n_bands
        _log(f"Using {n_bands} bands, outputting {n_components} PCs", feedback)

        wav_ord = ([wavelengths[i] for i in order]
                   if wavelengths is not None else None)

        gdal_band_list = [b + 1 for b in order]   # GDAL 1-based

        # ── Map info from .hdr ──────────────────────────────────────────
        map_info_str  = None
        coord_sys_str = None
        hdr_path = find_hdr(raster_path)
        if hdr_path:
            hdr = parse_hdr(hdr_path)
            map_info_str  = hdr.get('map info', None)
            coord_sys_str = hdr.get('coordinate system string', None)

        # ── Read data into memmap ────────────────────────────────────────
        # Determine bounding box pixels for stats region
        if bbox_rect is not None:
            xmin_c = bbox_rect.xMinimum()
            xmax_c = bbox_rect.xMaximum()
            ymin_c = bbox_rect.yMinimum()
            ymax_c = bbox_rect.yMaximum()
            if gt and gt[1] != 0:
                x0 = max(0, int((xmin_c - gt[0]) / gt[1]))
                x1 = min(n_samps, int((xmax_c - gt[0]) / gt[1]) + 1)
            else:
                x0, x1 = 0, n_samps
            if gt and gt[5] != 0:
                y0 = max(0, int((ymax_c - gt[3]) / gt[5]))
                y1 = min(n_lines, int((ymin_c - gt[3]) / gt[5]) + 1)
            else:
                y0, y1 = 0, n_lines
            _log(f"Stats bounding box: x {x0}–{x1}, y {y0}–{y1}", feedback)
        else:
            x0, x1 = 0, n_samps
            y0, y1 = 0, n_lines

        stats_pixels = (y1 - y0) * (x1 - x0)
        total_pixels = n_lines * n_samps

        feedback.setProgress(5)

        # ── Read stats region ────────────────────────────────────────────
        _log("Reading statistics region...", feedback)
        stats_chunk = ds.ReadAsArray(
            xoff=x0, yoff=y0,
            xsize=(x1 - x0), ysize=(y1 - y0),
            band_list=gdal_band_list,
        ).astype(np.float32)   # shape: (n_bands, y1-y0, x1-x0)

        X = stats_chunk.reshape(n_bands, -1).T   # shape: (pixels, bands)
        del stats_chunk

        # NaN-safe: remove rows with any NaN
        if nan_safe:
            valid = np.isfinite(X).all(axis=1)
            n_valid = valid.sum()
            _log(f"NaN-safe: {n_valid} / {X.shape[0]} pixels used for stats", feedback)
            X = X[valid, :]

        feedback.setProgress(20)

        # ── Compute PCA via SVD ──────────────────────────────────────────
        _log("Computing mean and centring...", feedback)
        Xm = X.mean(axis=0)
        X -= Xm

        _log("Running SVD (this may take a while for large images)...", feedback)
        U_sub, s, Vt = _fast_svd(X, n_components)
        del X, U_sub

        _log(f"Top singular values: {s[:min(5, len(s))]}", feedback)
        feedback.setProgress(50)

        # ── Save statistics ──────────────────────────────────────────────
        _log(f"Writing PCA stats to: {stats_path}", feedback)
        _write_stats(stats_path, Xm, s, Vt, wav_ord)

        # ── Project full image into PC space (chunked) ───────────────────
        _log("Projecting full image into PC space...", feedback)

        drv = gdal.GetDriverByName('GTiff')
        ds_out = drv.Create(fout, n_samps, n_lines, n_components, gdal.GDT_Float32)
        if ds_out is None:
            raise QgsProcessingException(f"Cannot create output: {fout}")
        if gt:
            ds_out.SetGeoTransform(gt)
        if proj:
            ds_out.SetProjection(proj)

        # Set band descriptions
        for pc_idx in range(n_components):
            b = ds_out.GetRasterBand(pc_idx + 1)
            b.SetDescription(f'PC{pc_idx + 1}')

        # Chunk rows to keep memory bounded (~256 MB)
        bytes_per_line = n_samps * n_bands * 4
        chunk_lines = max(1, (256 * 1024 * 1024) // bytes_per_line)
        chunk_lines = min(chunk_lines, n_lines)

        lines_done = 0
        while lines_done < n_lines:
            if feedback.isCanceled():
                del ds_out
                raise QgsProcessingException("Cancelled by user.")

            n_this = min(chunk_lines, n_lines - lines_done)
            chunk = ds.ReadAsArray(
                xoff=0, yoff=lines_done,
                xsize=n_samps, ysize=n_this,
                band_list=gdal_band_list,
            ).astype(np.float32)   # (n_bands, n_this, n_samps)

            # Reshape to (pixels, bands), centre, project
            chunk_2d = chunk.reshape(n_bands, -1).T   # (pixels, bands)
            chunk_2d -= Xm
            scores = chunk_2d @ Vt.T   # (pixels, n_components)
            del chunk_2d

            scores_3d = scores.T.reshape(n_components, n_this, n_samps)
            del scores

            for pc_idx in range(n_components):
                ds_out.GetRasterBand(pc_idx + 1).WriteArray(
                    scores_3d[pc_idx], xoff=0, yoff=lines_done
                )

            lines_done += n_this
            feedback.setProgress(50 + int(50 * lines_done / n_lines))

        ds_out.FlushCache()
        del ds_out, ds

        # ── Write ENVI .hdr sidecar ──────────────────────────────────────
        band_names = [f'PC{i+1}' for i in range(n_components)]
        _write_envi_hdr(
            fout,
            lines=n_lines, samples=n_samps, bands=n_components,
            dtype_str='float32',
            band_names=band_names,
            wavelengths=None,   # PCs don't have wavelengths
            map_info=map_info_str,
            coord_sys=coord_sys_str,
            description=f'PCA of {os.path.basename(raster_path)} ({n_components} components)',
        )

        feedback.setProgress(100)
        _log(f"Output PC image: {fout}", feedback)
        _log(f"Output stats:    {stats_path}", feedback)
        _log("PCA completed.", feedback)

        return {self.OUTPUT: fout, self.OUTPUT_STATS: stats_path}

    # ── Metadata ────────────────────────────────────────────────────────────

    def name(self):
        return 'pca_forward'

    def displayName(self):
        return 'PCA - Forward'

    def group(self):
        return '6 - Spectral Processing Tools'

    def groupId(self):
        return '6_spectral_processing'

    def shortHelpString(self):
        return (
            'Forward Principal Components Analysis (PCA) on a hyperspectral image.\n\n'
            'Computes PC score images via SVD decomposition and saves a statistics '
            'file for use by the Inverse PCA tool.\n\n'
            'PARAMETERS\n'
            '  Number of PC components — how many PCs to output (0 = all bands).\n'
            '    For most mineralogical applications, 10–20 components capture\n'
            '    virtually all spectral variance.\n\n'
            '  Sort bands by wavelength — reorders bands before analysis.\n\n'
            '  Exclude bad bands — uses the Bad Band List from the ENVI header.\n\n'
            '  Restrict to bounding box — if ticked, the covariance matrix and\n'
            '    eigenvectors are computed from the specified sub-region only.\n'
            '    The full image is still projected into the derived PC space.\n'
            '    Useful when a representative sub-scene is geologically cleaner\n'
            '    or when memory is a constraint.\n\n'
            '  NaN-safe mode — removes pixels with any NaN band before computing\n'
            '    statistics. Required for masked or partially-nodata images.\n\n'
            'OUTPUT\n'
            '  PC Score Image — float32 GeoTIFF, one band per PC, band\n'
            '    descriptions labelled PC1, PC2, …\n'
            '  PCA Statistics File (.pca_stats) — binary pickle file containing\n'
            '    the mean vector, singular values, and eigenvector matrix.\n'
            '    Keep this file — it is required by the Inverse PCA tool.\n\n'
            'Ported from HyPy pca.py (Wim Bakker, University of Twente).'
        )

    def createInstance(self):
        return PcaAlgorithm()
