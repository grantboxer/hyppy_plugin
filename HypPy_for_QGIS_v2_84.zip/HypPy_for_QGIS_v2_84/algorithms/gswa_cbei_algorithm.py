"""
GSWA Table 5 — Chlorite-biotite-epidote indices (CBEai and CBEci)

CBEai (abundance):
  Algorithm: Intensity of the wavelength minimum between 2230 and 2280 nm
             using 4th order polynomial fit (2250D).
  Masks:     Gascoyne: MertonNDVI > 0.15  AND  2250D < 0.01
             Pilbara:  MertonNDVI > 0.2   AND  2250D < 0.01
  Stretch:   Gascoyne linear: Blue=0.01, Red=0.04
             Pilbara  linear: Blue=0.02, Red=0.065
  Targeted:  Chlorite, dark mica, epidote  (challenge: jarosite, tourmaline)

CBEci (composition):
  Algorithm: Wavelength position of the wavelength minimum between 2230 and 2280 nm
             using 4th order polynomial fit (2250D).
  Masks:     Pilbara: MertonNDVI > 0.2  AND  2250D < 0.02
  Stretch:   Pilbara linear:
             Blue = Mg-rich chlorite and/or biotite AND/OR Al-rich epidote (2248 nm)
             Red  = Fe-rich chlorite and/or biotite AND/OR Fe-rich epidote (2263 nm)
  Targeted:  Chlorite, dark mica, epidote

Reference:
    Laukamp et al. (2025) GSWA Report 261, Table 5.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterBoolean,
    QgsProcessingException,
)

from ..core.envi_header import get_wavelengths_from_dataset
from .gswa_index_utils import (
    compute_ndvi, read_wom_band, write_index,
    apply_ndvi_mask, log_gswa_stretch,
)

WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Cube (NDVI) + FE14-2250W WoM raster.<br/>
        Both CBEai (abundance) and CBEci (composition) are produced in one pass.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""

CBAI_STRETCH = {
    'gascoyne': 'linear: Blue=0.01 (low), Red=0.04 (high)',
    'pilbara':  'linear: Blue=0.02 (low), Red=0.065 (high)',
}

CBCI_STRETCH = {
    'pilbara':  'linear: Blue=2248 nm (Mg-rich chlorite/Al-rich epidote), '
                'Red=2263 nm (Fe-rich chlorite/Fe-rich epidote)',
}

REFERENCE = 'Laukamp et al. (2025) GSWA Report 261, Table 5 (CBEai/CBEci)'


class GswaCbeiAlgorithm(QgsProcessingAlgorithm):
    """GSWA Table 5 — CBEai + CBEci (Chlorite-biotite-epidote indices)."""

    CUBE             = 'CUBE'
    WOM_2250         = 'WOM_2250'
    NDVI_THRESH      = 'NDVI_THRESH'
    DEPTH_THRESH_AI  = 'DEPTH_THRESH_AI'
    DEPTH_THRESH_CI  = 'DEPTH_THRESH_CI'
    OUTPUT_CBAI      = 'OUTPUT_CBAI'
    OUTPUT_CBCI      = 'OUTPUT_CBCI'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.CUBE,    'Hyperspectral cube  (for MertonNDVI)'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2250,
            'FE14-2250W WoM raster  '
            '(Band 1 = wavelength position, Band 2 = 2250D depth)'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NDVI_THRESH,
            'MertonNDVI threshold (mask above)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.15, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.DEPTH_THRESH_AI,
            'CBEai — 2250D depth upper threshold (mask above)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.01, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.DEPTH_THRESH_CI,
            'CBEci — 2250D depth upper threshold for composition mask (mask above)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.02, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_CBAI,
            'Output CBEai raster  (chlorite-biotite-epidote abundance)'))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_CBCI,
            'Output CBEci raster  (chlorite-biotite-epidote composition, nm)'))

    def processAlgorithm(self, parameters, context, feedback):
        cube_layer    = self.parameterAsRasterLayer(parameters, self.CUBE, context)
        wom_2250      = self.parameterAsRasterLayer(parameters, self.WOM_2250, context)
        ndvi_thresh   = self.parameterAsDouble(parameters, self.NDVI_THRESH, context)
        d_thresh_ai   = self.parameterAsDouble(parameters, self.DEPTH_THRESH_AI, context)
        d_thresh_ci   = self.parameterAsDouble(parameters, self.DEPTH_THRESH_CI, context)
        out_cbai      = self.parameterAsOutputLayer(parameters, self.OUTPUT_CBAI, context)
        out_cbci      = self.parameterAsOutputLayer(parameters, self.OUTPUT_CBCI, context)

        # 1. Read 2250D depth (Band 2) and wavelength (Band 1)
        feedback.setProgress(5)
        feedback.pushInfo('Reading 2250D wavelength position (Band 1) …')
        wav2250, gt, proj, rows, cols = read_wom_band(wom_2250, 1, '2250W-wvl', feedback)
        feedback.pushInfo('Reading 2250D depth (Band 2) …')
        d2250, *_ = read_wom_band(wom_2250, 2, '2250D', feedback)

        # 2. MertonNDVI
        feedback.setProgress(20)
        feedback.pushInfo('Computing MertonNDVI …')
        cube_ds     = gdal.Open(cube_layer.source())
        wavelengths = get_wavelengths_from_dataset(
            cube_ds, cube_ds.RasterCount, cube_layer.source(), feedback)
        if wavelengths is None:
            raise QgsProcessingException('No wavelength metadata found in cube.')
        nodata = cube_ds.GetRasterBand(1).GetNoDataValue()
        ndvi   = compute_ndvi(cube_ds, wavelengths, nodata, feedback)
        del cube_ds

        # 3. CBEai — masked depth
        feedback.setProgress(55)
        feedback.pushInfo('Computing CBEai (masked 2250D depth) …')
        cbai = d2250.copy()
        cbai = apply_ndvi_mask(cbai, ndvi, ndvi_thresh, 'CBEai', feedback)
        deep_ai = ~np.isnan(d2250) & (d2250 >= d_thresh_ai)
        cbai[deep_ai] = np.nan
        feedback.pushInfo(
            f'  CBEai: 2250D≥{d_thresh_ai} mask: {int(np.sum(deep_ai))} px masked')

        # 4. CBEci — masked wavelength position
        feedback.setProgress(70)
        feedback.pushInfo('Computing CBEci (masked 2250D wavelength position) …')
        cbci = wav2250.copy()
        cbci = apply_ndvi_mask(cbci, ndvi, ndvi_thresh, 'CBEci', feedback)
        deep_ci = ~np.isnan(d2250) & (d2250 >= d_thresh_ci)
        cbci[deep_ci] = np.nan
        feedback.pushInfo(
            f'  CBEci: 2250D≥{d_thresh_ci} mask: {int(np.sum(deep_ci))} px masked')

        # 5. Write outputs
        feedback.setProgress(82)
        feedback.pushInfo('Writing CBEai …')
        write_index(
            out_cbai, cbai, gt, proj,
            product_name='CBEai',
            description='Chlorite-biotite-epidote abundance index (2250D, poly4)',
            gswa_stretch=CBAI_STRETCH,
            reference=REFERENCE,
        )

        feedback.setProgress(92)
        feedback.pushInfo('Writing CBEci …')
        write_index(
            out_cbci, cbci, gt, proj,
            product_name='CBEci',
            description='Chlorite-biotite-epidote composition index (2250D wavelength position, nm)',
            gswa_stretch=CBCI_STRETCH,
            reference=REFERENCE,
            extra_meta={
                'GSWA_blue_end_nm': '2248',
                'GSWA_red_end_nm':  '2263',
                'GSWA_blue_mineral': 'Mg-rich chlorite / biotite AND/OR Al-rich epidote',
                'GSWA_red_mineral':  'Fe-rich chlorite / biotite AND/OR Fe-rich epidote (2263 nm)',
            }
        )

        log_gswa_stretch(feedback, 'CBEai (Chlorite-biotite-epidote abundance)', CBAI_STRETCH)
        log_gswa_stretch(feedback, 'CBEci (Chlorite-biotite-epidote composition)', CBCI_STRETCH)
        feedback.pushInfo('Targeted minerals: chlorite, dark mica, epidote')
        feedback.pushInfo('CBEci colour: Blue=Mg-rich (2248 nm) → Red=Fe-rich (2263 nm)')
        feedback.setProgress(100)
        return {
            self.OUTPUT_CBAI: out_cbai,
            self.OUTPUT_CBCI: out_cbci,
        }

    def name(self):        return 'gswa_cbei'
    def displayName(self): return 'GSWA-CBEai+CBEci  (Chlorite-Biotite-Epidote Indices)'
    def group(self):       return '9 - GSWA Mineral Map Indices'
    def groupId(self):     return 'nine_gswa_indices'

    def shortHelpString(self):
        return WORKFLOW_NOTE + f"""
        <b>Chlorite-Biotite-Epidote Indices (CBEai + CBEci)</b>
        <p>GSWA Report 261, Table 5. Produces both the abundance index (CBEai,
        2250D depth) and composition index (CBEci, 2250D wavelength position)
        from a single FE14-2250W WoM raster in one pass.</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Index</th><th>Algorithm</th><th>Stretch</th></tr>
          <tr>
            <td><b>CBEai</b></td>
            <td>2250D depth (Band 2), masked by NDVI + 2250D threshold</td>
            <td>Gascoyne: Blue=0.01, Red=0.04<br/>
                Pilbara: Blue=0.02, Red=0.065</td></tr>
          <tr>
            <td><b>CBEci</b></td>
            <td>2250D wavelength position (Band 1), masked</td>
            <td>Pilbara: Blue=2248 nm, Red=2263 nm</td></tr>
        </table>

        <p><b>CBEci colour interpretation:</b></p>
        <ul>
          <li><b>Blue (~2248 nm)</b> — Mg-rich chlorite / biotite; Al-rich epidote</li>
          <li><b>Red (~2263 nm)</b> — Fe-rich chlorite / biotite; Fe-rich epidote</li>
        </ul>

        <p><i>Reference: Laukamp et al. (2025) GSWA Report 261, Table 5.</i></p>
        """

    def createInstance(self): return GswaCbeiAlgorithm()
