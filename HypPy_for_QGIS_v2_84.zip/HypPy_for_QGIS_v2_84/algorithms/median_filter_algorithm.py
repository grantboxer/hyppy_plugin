"""
3D Median / Mean Filter Algorithm for QGIS Processing

Applies a 3D spatial-spectral median or mean filter to an ENVI
hyperspectral image.  Filtering operates simultaneously in the spatial
(x, y) and spectral (band) dimensions, making it well-suited for
removing random 3D noise (e.g. detector cosmetic defects) while
preserving spectral shape.

Filter modes (neighbourhood size):
    fmed7  / mean7  — 7-point cross (6 face-neighbours + centre)
    fmed19 / mean19 — 19-point cross (face + edge neighbours)
    fmed27 / mean27 — 27-point full 3×3×3 cube

NaN values are ignored (nanmedian / nanmean).
The 1-pixel spatial border and 1-band spectral border are copied
unchanged from the input.

Ported from HyPy median.py / tkMedian.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original HyPy Copyright (C) 2010-2022 Wim Bakker, University of Twente

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import os
import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterEnum,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis,
)

from ..core.envi_header import (
    get_wavelengths_from_dataset,
    get_bbl_from_dataset,
    find_hdr,
    parse_hdr,
)

gdal.UseExceptions()


# ── Neighbourhood kernels (j, i, band_shift) ─────────────────────────────────
# j = line offset,  i = sample offset,  band_shift = band offset
# All offsets are ∈ {0, 1, 2}; the centre pixel is (1, 1, 1) in 0-based terms.

_KERNEL7 = (
    (1, 1, 0),
    (0, 1, 1), (1, 0, 1), (1, 1, 1), (1, 2, 1), (2, 1, 1),
    (1, 1, 2),
)

_KERNEL19 = (
    (0, 1, 0), (1, 0, 0), (1, 1, 0), (1, 2, 0), (2, 1, 0),
    (0, 0, 1), (0, 1, 1), (0, 2, 1),
    (1, 0, 1), (1, 1, 1), (1, 2, 1),
    (2, 0, 1), (2, 1, 1), (2, 2, 1),
    (0, 1, 2), (1, 0, 2), (1, 1, 2), (1, 2, 2), (2, 1, 2),
)

_KERNEL27 = tuple(
    (j, i, b)
    for b in range(3)
    for j in range(3)
    for i in range(3)
)

KERNEL_MAP = {
    'fmed7':  _KERNEL7,
    'fmed19': _KERNEL19,
    'fmed27': _KERNEL27,
    'mean7':  _KERNEL7,
    'mean19': _KERNEL19,
    'mean27': _KERNEL27,
}

MODE_LABELS = [
    'Fast Median 7  (7-point cross, fast)',
    'Fast Median 19 (19-point cross)',
    'Fast Median 27 (3×3×3 cube, thorough)',
    'Mean 7         (7-point mean)',
    'Mean 19        (19-point mean)',
    'Mean 27        (3×3×3 mean)',
]

MODE_KEYS = ['fmed7', 'fmed19', 'fmed27', 'mean7', 'mean19', 'mean27']


def _fast_filter(data, kernel, use_median):
    """
    Apply a 3D filter to a (bands, lines, samples) float64 array.

    Returns an output array of the same shape.  The 1-band spectral border
    and 1-pixel spatial border are copied from the input unchanged.
    """
    bands, lines, samples = data.shape
    n_k = len(kernel)
    result = data.copy()

    # Pre-allocate accumulator: (lines, samples, neighbourhood_size)
    acc = np.zeros((lines, samples, n_k), dtype=np.float64)

    for b in range(1, bands - 1):
        acc[:] = 0.0
        for idx, (dj, di, db) in enumerate(kernel):
            acc[1:-1, 1:-1, idx] = data[
                b + db - 1,
                dj: lines - 2 + dj,
                di: samples - 2 + di,
            ]

        if use_median:
            out = np.nanmedian(acc, axis=2)
        else:
            out = np.nanmean(acc, axis=2)

        result[b, 1:-1, 1:-1] = out[1:-1, 1:-1]

    return result


def _write_envi_sidecar(path, lines, samples, bands, dtype_str,
                        wavelengths=None, band_names=None,
                        map_info=None, coord_sys=None, description=''):
    gdal_to_envi = {
        'float64': 5, 'float32': 4, 'int16': 2, 'uint16': 12,
        'int32': 3, 'uint32': 13, 'uint8': 1,
    }
    envi_dt = gdal_to_envi.get(dtype_str, 5)
    hdr_lines = ['ENVI']
    if description:
        hdr_lines.append(f'description = {{{description}}}')
    hdr_lines += [
        f'samples = {samples}',
        f'lines   = {lines}',
        f'bands   = {bands}',
        f'header offset = 0',
        f'file type = ENVI Standard',
        f'data type = {envi_dt}',
        f'interleave = bsq',
        f'byte order = 0',
    ]
    if band_names:
        hdr_lines.append('band names = {' + ', '.join(band_names) + '}')
    if wavelengths:
        hdr_lines.append('wavelength = {' +
                         ', '.join(f'{w:.4f}' for w in wavelengths) + '}')
        hdr_lines.append('wavelength units = Nanometers')
    if map_info:
        hdr_lines.append(f'map info = {map_info}')
    if coord_sys:
        hdr_lines.append(f'coordinate system string = {coord_sys}')
    hdr_path = path + '.hdr'
    with open(hdr_path, 'w') as f:
        f.write('\n'.join(hdr_lines) + '\n')


class MedianFilterAlgorithm(QgsProcessingAlgorithm):
    """
    3D spatial-spectral median or mean filter for hyperspectral imagery.

    Removes random 3D noise while respecting neighbourhood structure
    in both spatial and spectral dimensions.
    """

    INPUT    = 'INPUT'
    MODE     = 'MODE'
    SORT_WAV = 'SORT_WAV'
    USE_BBL  = 'USE_BBL'
    OUTPUT   = 'OUTPUT'

    def initAlgorithm(self, config=None):

        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT,
                'Input Hyperspectral Image (ENVI)',
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.MODE,
                'Filter Mode',
                options=MODE_LABELS,
                defaultValue=0,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.SORT_WAV,
                'Sort bands by ascending wavelength before filtering',
                defaultValue=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.USE_BBL,
                'Exclude bad bands (use Bad Band List from header)',
                defaultValue=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                'Output Filtered Image',
            )
        )

    # ── processAlgorithm ────────────────────────────────────────────────────

    def processAlgorithm(self, parameters, context, feedback):

        input_layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        raster_path = input_layer.source()
        mode_idx    = self.parameterAsEnum(parameters, self.MODE, context)
        sort_wav    = self.parameterAsBoolean(parameters, self.SORT_WAV, context)
        use_bbl     = self.parameterAsBoolean(parameters, self.USE_BBL, context)
        fout        = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        mode_key   = MODE_KEYS[mode_idx]
        use_median = mode_key.startswith('fmed')
        kernel     = KERNEL_MAP[mode_key]

        feedback.pushInfo("=== HypPy 3D Median/Mean Filter ===")
        feedback.pushInfo(f"Input: {raster_path}")
        feedback.pushInfo(f"Mode: {MODE_LABELS[mode_idx]} "
                          f"({'median' if use_median else 'mean'}, "
                          f"{len(kernel)}-point neighbourhood)")

        # ── Open dataset ─────────────────────────────────────────────────
        ds = gdal.Open(raster_path, gdal.GA_ReadOnly)
        if ds is None:
            raise QgsProcessingException(f"Cannot open raster: {raster_path}")

        n_bands_raw = ds.RasterCount
        n_lines     = ds.RasterYSize
        n_samps     = ds.RasterXSize
        gt          = ds.GetGeoTransform()
        proj        = ds.GetProjection()

        if n_bands_raw < 3:
            raise QgsProcessingException(
                "3D filter requires at least 3 bands (spectral neighbourhood of 1)."
            )

        # ── Wavelengths and BBL ─────────────────────────────────────────
        wavelengths = get_wavelengths_from_dataset(ds, n_bands_raw, raster_path, feedback)
        bbl_raw     = get_bbl_from_dataset(ds, n_bands_raw, raster_path, feedback)

        order = list(range(n_bands_raw))
        if sort_wav and wavelengths is not None:
            order = sorted(order, key=lambda i: wavelengths[i])
        if use_bbl and bbl_raw is not None:
            order = [i for i in order if bbl_raw[i]]
            feedback.pushInfo(f"After BBL filter: {len(order)} good bands")

        n_bands = len(order)
        if n_bands < 3:
            raise QgsProcessingException(
                "Fewer than 3 bands remain after BBL filter. "
                "3D filter requires at least 3 bands."
            )

        wav_out = ([wavelengths[i] for i in order]
                   if wavelengths is not None else None)
        band_names_out = [f'{wav_out[b]:.4f}' for b in range(n_bands)] \
            if wav_out else [f'Band {b+1}' for b in range(n_bands)]

        # Map info
        map_info_str  = None
        coord_sys_str = None
        hdr_path = find_hdr(raster_path)
        if hdr_path:
            hdr = parse_hdr(hdr_path)
            map_info_str  = hdr.get('map info', None)
            coord_sys_str = hdr.get('coordinate system string', None)

        # ── Read entire image ────────────────────────────────────────────
        # 3D filter requires the full cube to be in memory.
        # Warn for large images.
        gdal_band_list = [b + 1 for b in order]
        est_mb = n_bands * n_lines * n_samps * 8 / (1024**2)
        feedback.pushInfo(
            f"Image: {n_bands} bands × {n_lines} lines × {n_samps} samples "
            f"(~{est_mb:.0f} MB in memory)"
        )
        if est_mb > 4096:
            feedback.pushWarning(
                f"Image requires ~{est_mb:.0f} MB — consider subsetting first."
            )

        feedback.pushInfo("Reading image into memory...")
        feedback.setProgress(10)

        data = ds.ReadAsArray(
            xoff=0, yoff=0, xsize=n_samps, ysize=n_lines,
            band_list=gdal_band_list,
        ).astype(np.float64)   # shape: (n_bands, n_lines, n_samps)

        feedback.setProgress(30)
        if feedback.isCanceled():
            raise QgsProcessingException("Cancelled by user.")

        # ── Apply filter ─────────────────────────────────────────────────
        feedback.pushInfo("Applying 3D filter...")
        filtered = _fast_filter(data, kernel, use_median)
        del data
        feedback.setProgress(80)

        # ── Write output ─────────────────────────────────────────────────
        drv    = gdal.GetDriverByName('GTiff')
        ds_out = drv.Create(fout, n_samps, n_lines, n_bands, gdal.GDT_Float64)
        if ds_out is None:
            raise QgsProcessingException(f"Cannot create output: {fout}")
        if gt:
            ds_out.SetGeoTransform(gt)
        if proj:
            ds_out.SetProjection(proj)

        for b_idx in range(n_bands):
            out_band = ds_out.GetRasterBand(b_idx + 1)
            out_band.WriteArray(filtered[b_idx])
            out_band.SetDescription(band_names_out[b_idx])
            src_band = ds.GetRasterBand(order[b_idx] + 1)
            nd = src_band.GetNoDataValue()
            if nd is not None:
                out_band.SetNoDataValue(nd)
            feedback.setProgress(80 + int(20 * (b_idx + 1) / n_bands))

        ds_out.FlushCache()
        del ds_out, filtered, ds

        # ── ENVI sidecar ─────────────────────────────────────────────────
        _write_envi_sidecar(
            fout,
            lines=n_lines, samples=n_samps, bands=n_bands,
            dtype_str='float64',
            wavelengths=wav_out,
            band_names=band_names_out,
            map_info=map_info_str,
            coord_sys=coord_sys_str,
            description=f'3D {MODE_LABELS[mode_idx]} of '
                        f'{os.path.basename(raster_path)}',
        )

        feedback.setProgress(100)
        feedback.pushInfo(f"Output: {fout}")
        feedback.pushInfo("3D Filter completed.")
        return {self.OUTPUT: fout}

    # ── Metadata ────────────────────────────────────────────────────────────

    def name(self):
        return 'median_filter'

    def displayName(self):
        return '3D Median / Mean Filter'

    def group(self):
        return '6 - Spectral Processing Tools'

    def groupId(self):
        return '6_spectral_processing'

    def shortHelpString(self):
        return (
            'Applies a 3D spatial-spectral median or mean filter to a hyperspectral '
            'image.\n\n'
            'The filter operates simultaneously across spatial (x, y) and spectral '
            '(band) dimensions, effectively removing random 3D noise such as detector '
            'cosmetic blemishes or isolated bad pixels, while preserving spectral shape '
            'better than a purely spatial filter.\n\n'
            'NaN values are ignored in all filter modes (nanmedian / nanmean).\n'
            'The 1-pixel spatial border and 1-band spectral border are copied '
            'unchanged from the input.\n\n'
            'FILTER MODES\n'
            '  fmed7  / mean7  — 7-point cross neighbourhood\n'
            '                    (centre + 6 face-adjacent pixels/bands)\n'
            '                    Fastest; minimal spatial-spectral mixing.\n\n'
            '  fmed19 / mean19 — 19-point cross neighbourhood\n'
            '                    (face + edge-adjacent pixels/bands)\n'
            '                    Balanced noise removal.\n\n'
            '  fmed27 / mean27 — full 3×3×3 cube neighbourhood (27 points)\n'
            '                    Most thorough denoising; also most mixing.\n\n'
            'MEMORY NOTE\n'
            'The entire image cube must be held in memory during filtering.\n'
            'For very large images, run a Subset first to reduce scene size.\n\n'
            'Ported from HyPy median.py (Wim Bakker, University of Twente).'
        )

    def createInstance(self):
        return MedianFilterAlgorithm()
