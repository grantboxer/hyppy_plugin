"""
DT Fedrop Decision Tree Classification Algorithm for QGIS Processing

Classifies pixels into iron drop (fedrop) intensity classes.

b1 is computed internally as the band ratio: R(1600nm) / R(1310nm),
using the two closest bands to those wavelengths in the hyperspectral cube.
Wavelength metadata is read from the cube's ENVI header or GDAL metadata.

Input bands:
  b1 - Band ratio R(1600nm)/R(1310nm), computed from the hyperspectral cube
  b2 - Primary absorption wavelength in nm   (WoM Band 1)
  b3 - Depth of deepest absorption feature   (WoM Band 2, threshold gate)

Decision tree (dt_fedrop.jpg):
  b3 <= 0.05                          -> aspectral
  NOT (2100 < b2 <= 2400)             -> no2100-2400
  b1 <= 1.1                           -> low
  b1 <= 1.2                           -> med-low
  b1 <= 1.3                           -> medium
  b1 <= 1.4                           -> med-high
  b1 <= 1.5                           -> high
  b1 >  1.5                           -> very-high

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

import numpy as np
from osgeo import gdal
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

FEDROP_CLASSES = [
    (0, 'unclassified', 0,   0,   0  ),
    (1, 'aspectral',    0,   0,   0  ),
    (2, 'no2100-2400',  128, 128, 128),  # grey
    (3, 'low',          255, 255, 180),  # pale yellow
    (4, 'med-low',      255, 220, 100),  # yellow
    (5, 'medium',       255, 180, 0  ),  # orange-yellow
    (6, 'med-high',     255, 120, 0  ),  # orange
    (7, 'high',         220, 50,  0  ),  # orange-red
    (8, 'very-high',    160, 0,   0  ),  # dark red
]
NAME_TO_ID = {m[1]: m[0] for m in FEDROP_CLASSES}
ID_TO_NAME = {m[0]: m[1] for m in FEDROP_CLASSES}


def get_band_wavelengths(ds):
    """
    Extract per-band centre wavelengths (nm) from GDAL dataset metadata.
    Tries ENVI-style metadata first, then band descriptions.
    Returns a list of floats (nm), or None if not found.
    """
    n = ds.RasterCount
    wavelengths = []

    # Try ENVI domain metadata (most common for hyperspectral)
    meta = ds.GetMetadata('ENVI')
    if 'wavelength' in meta:
        raw = meta['wavelength'].strip('{}').split(',')
        try:
            wl = [float(w.strip()) for w in raw if w.strip()]
            if len(wl) == n:
                # Convert micrometres to nm if needed
                if max(wl) < 10:
                    wl = [w * 1000 for w in wl]
                return wl
        except ValueError:
            pass

    # Try default domain
    meta = ds.GetMetadata()
    for key in ('wavelength', 'WAVELENGTH', 'Wavelength'):
        if key in meta:
            raw = meta[key].strip('{}').split(',')
            try:
                wl = [float(w.strip()) for w in raw if w.strip()]
                if len(wl) == n:
                    if max(wl) < 10:
                        wl = [w * 1000 for w in wl]
                    return wl
            except ValueError:
                pass

    # Try band-level metadata
    for i in range(1, n + 1):
        b = ds.GetRasterBand(i)
        desc = b.GetDescription()
        meta_b = b.GetMetadata()
        wl_val = meta_b.get('wavelength') or meta_b.get('WAVELENGTH') or desc
        try:
            val = float(wl_val)
            if val < 10:
                val *= 1000
            wavelengths.append(val)
        except (ValueError, TypeError):
            return None

    return wavelengths if len(wavelengths) == n else None


def closest_band(wavelengths, target_nm):
    """Return 1-based band index and actual wavelength closest to target_nm."""
    diffs = [abs(w - target_nm) for w in wavelengths]
    idx = int(np.argmin(diffs))
    return idx + 1, wavelengths[idx]


class DtFedropAlgorithm(QgsProcessingAlgorithm):

    CUBE_INPUT   = 'CUBE_INPUT'
    WOM_INPUT    = 'WOM_INPUT'
    B3_THRESHOLD = 'B3_THRESHOLD'
    OUTPUT_RGB   = 'OUTPUT_RGB'
    OUTPUT_CLASS = 'OUTPUT_CLASS'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.CUBE_INPUT,
            'Hyperspectral cube (original data — used to compute b1 = R(1600nm)/R(1310nm))'))

        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_INPUT,
            'Wavelength of Minimum raster (Step 1 output — Band 1=wavelength b2, Band 2=depth b3)'))

        self.addParameter(QgsProcessingParameterNumber(
            self.B3_THRESHOLD,
            'Depth threshold — pixels with b3 <= this value are classed as aspectral',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.05, minValue=0.0, maxValue=1.0))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_RGB, 'Output: Fedrop RGB raster', optional=True))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_CLASS, 'Output: Fedrop integer class raster'))

    def processAlgorithm(self, parameters, context, feedback):
        cube_layer = self.parameterAsRasterLayer(parameters, self.CUBE_INPUT,   context)
        wom_layer  = self.parameterAsRasterLayer(parameters, self.WOM_INPUT,    context)
        b3_thresh  = self.parameterAsDouble     (parameters, self.B3_THRESHOLD, context)
        out_class = self.parameterAsOutputLayer(parameters, self.OUTPUT_CLASS, context)
        out_rgb   = self.parameterAsOutputLayer(parameters, self.OUTPUT_RGB,   context) \
                    if self.OUTPUT_RGB in parameters else None

        # ── Open hyperspectral cube ───────────────────────────────────────────
        cube_path = cube_layer.dataProvider().dataSourceUri().split('|')[0].strip()
        feedback.pushInfo(f'Opening hyperspectral cube: {cube_path}')
        cube_ds = gdal.Open(cube_path, gdal.GA_ReadOnly)
        if cube_ds is None:
            raise QgsProcessingException(f'Cannot open hyperspectral cube: {cube_path}')

        cols      = cube_ds.RasterXSize
        rows      = cube_ds.RasterYSize
        n_bands   = cube_ds.RasterCount
        feedback.pushInfo(f'Cube: {cols} x {rows}, {n_bands} bands')

        # ── Get wavelength list ───────────────────────────────────────────────
        wavelengths = get_band_wavelengths(cube_ds)
        if wavelengths is None:
            raise QgsProcessingException(
                'Cannot read wavelength metadata from hyperspectral cube. '
                'Ensure the file has ENVI-style wavelength metadata.')

        feedback.pushInfo(f'Wavelength range: {wavelengths[0]:.1f} – {wavelengths[-1]:.1f} nm')

        # ── Find closest bands to 1600 nm and 1310 nm ────────────────────────
        band_1600, wl_1600 = closest_band(wavelengths, 1600.0)
        band_1310, wl_1310 = closest_band(wavelengths, 1310.0)
        feedback.pushInfo(f'Band for 1600 nm: band {band_1600} ({wl_1600:.1f} nm)')
        feedback.pushInfo(f'Band for 1310 nm: band {band_1310} ({wl_1310:.1f} nm)')

        # ── Read bands and compute ratio b1 = R(1600) / R(1310) ──────────────
        feedback.pushInfo('Reading R(1600nm)...')
        r1600 = cube_ds.GetRasterBand(band_1600).ReadAsArray().astype(np.float32)
        feedback.pushInfo('Reading R(1310nm)...')
        r1310 = cube_ds.GetRasterBand(band_1310).ReadAsArray().astype(np.float32)
        cube_ds = None
        feedback.setProgress(20)

        # Safe division — zero denominator -> NaN
        with np.errstate(invalid='ignore', divide='ignore'):
            b1 = np.where(r1310 > 0, r1600 / r1310, np.nan).astype(np.float32)

        valid_b1 = b1[np.isfinite(b1)]
        if valid_b1.size > 0:
            feedback.pushInfo(
                f'b1 (R1600/R1310): min={float(np.min(valid_b1)):.4f}  '
                f'max={float(np.max(valid_b1)):.4f}  '
                f'mean={float(np.mean(valid_b1)):.4f}')

        # ── Open WoM raster ───────────────────────────────────────────────────
        wom_ds = gdal.Open(wom_layer.source(), gdal.GA_ReadOnly)
        if wom_ds is None:
            raise QgsProcessingException('Cannot open WoM raster')
        if wom_ds.RasterCount < 2:
            raise QgsProcessingException('WoM raster needs >= 2 bands (Band1=wavelength, Band2=depth)')
        if wom_ds.RasterXSize != cols or wom_ds.RasterYSize != rows:
            raise QgsProcessingException(
                f'WoM raster size ({wom_ds.RasterXSize}x{wom_ds.RasterYSize}) '
                f'does not match cube size ({cols}x{rows})')

        feedback.pushInfo(f'WoM raster: {wom_ds.RasterXSize} x {wom_ds.RasterYSize}, {wom_ds.RasterCount} bands')
        feedback.pushInfo('Reading WoM Band 1 — primary wavelength (b2)...')
        b2 = wom_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        feedback.pushInfo('Reading WoM Band 2 — deepest feature depth (b3)...')
        b3 = wom_ds.GetRasterBand(2).ReadAsArray().astype(np.float32)

        # ── Apply decision tree ───────────────────────────────────────────────
        feedback.pushInfo(f'Depth threshold: b3 > {b3_thresh} = spectral pixel')
        feedback.pushInfo('Applying dt_fedrop decision tree...')
        feedback.setProgress(50)

        nodata = ~np.isfinite(b1) | ~np.isfinite(b2) | ~np.isfinite(b3)
        b1s = np.nan_to_num(b1, nan=0.0)
        b2s = np.nan_to_num(b2, nan=0.0)
        b3s = np.nan_to_num(b3, nan=0.0)

        class_data = np.zeros((rows, cols), dtype=np.uint8)
        spectral   = b3s > b3_thresh
        in_range   = spectral & (b2s > 2100) & (b2s <= 2400)

        class_data[~spectral]              = NAME_TO_ID['aspectral']
        class_data[spectral & ~in_range]   = NAME_TO_ID['no2100-2400']
        class_data[in_range & (b1s <= 1.1)] = NAME_TO_ID['low']
        class_data[in_range & (b1s >  1.1) & (b1s <= 1.2)] = NAME_TO_ID['med-low']
        class_data[in_range & (b1s >  1.2) & (b1s <= 1.3)] = NAME_TO_ID['medium']
        class_data[in_range & (b1s >  1.3) & (b1s <= 1.4)] = NAME_TO_ID['med-high']
        class_data[in_range & (b1s >  1.4) & (b1s <= 1.5)] = NAME_TO_ID['high']
        class_data[in_range & (b1s >  1.5)]                 = NAME_TO_ID['very-high']
        class_data[nodata | (b2s == 0)]    = 0

        feedback.setProgress(70)

        # ── Classification summary ────────────────────────────────────────────
        feedback.pushInfo('')
        feedback.pushInfo('Classification summary:')
        unique, counts = np.unique(class_data, return_counts=True)
        total = class_data.size
        for uid, cnt in zip(unique, counts):
            pct = 100.0 * cnt / total
            feedback.pushInfo(
                f'  {ID_TO_NAME.get(int(uid),"?"):15s}  (id={uid:2d})  {cnt:8d} px  {pct:5.1f}%')

        driver = gdal.GetDriverByName('GTiff')

        # ── Class raster (primary — always written) ──────────────────────
        feedback.pushInfo('Writing integer class raster...')
        ct = gdal.ColorTable()
        for mid, name, r, g, bv in FEDROP_CLASSES:
            ct.SetColorEntry(mid, (r, g, bv, 255))
        class_ds = driver.Create(out_class, cols, rows, 1, gdal.GDT_Byte,
                                 options=['COMPRESS=LZW', 'TILED=YES'])
        class_ds.SetGeoTransform(wom_ds.GetGeoTransform())
        class_ds.SetProjection(wom_ds.GetProjection())
        b = class_ds.GetRasterBand(1)
        b.SetNoDataValue(0)
        b.SetDescription('Fedrop Class')
        b.SetRasterColorTable(ct)
        b.SetRasterColorInterpretation(gdal.GCI_PaletteIndex)
        b.WriteArray(class_data)
        b.FlushCache()
        # Raster Attribute Table — class names visible in QGIS legend
        rat = gdal.RasterAttributeTable()
        rat.CreateColumn('Value', gdal.GFT_Integer,  gdal.GFU_MinMax)
        rat.CreateColumn('Class', gdal.GFT_String,   gdal.GFU_Name)
        rat.CreateColumn('R',     gdal.GFT_Integer,  gdal.GFU_Red)
        rat.CreateColumn('G',     gdal.GFT_Integer,  gdal.GFU_Green)
        rat.CreateColumn('B',     gdal.GFT_Integer,  gdal.GFU_Blue)
        for row_idx, (mid, name, r, g, bv) in enumerate(FEDROP_CLASSES):
            rat.SetValueAsInt   (row_idx, 0, mid)
            rat.SetValueAsString(row_idx, 1, name)
            rat.SetValueAsInt   (row_idx, 2, r)
            rat.SetValueAsInt   (row_idx, 3, g)
            rat.SetValueAsInt   (row_idx, 4, bv)
        b.SetDefaultRAT(rat)
        class_ds = None
        result = {self.OUTPUT_CLASS: out_class}
        # ── RGB raster (optional) ────────────────────────────────────────
        if out_rgb:
            feedback.pushInfo('Writing RGB colour raster...')
            rgb_r = np.zeros((rows, cols), dtype=np.uint8)
            rgb_g = np.zeros((rows, cols), dtype=np.uint8)
            rgb_b = np.zeros((rows, cols), dtype=np.uint8)
            for mid, name, r, g, bv in FEDROP_CLASSES:
                mask = class_data == mid
                rgb_r[mask], rgb_g[mask], rgb_b[mask] = r, g, bv
            rgb_ds = driver.Create(out_rgb, cols, rows, 3, gdal.GDT_Byte,
                                   options=['COMPRESS=LZW', 'TILED=YES'])
            rgb_ds.SetGeoTransform(wom_ds.GetGeoTransform())
            rgb_ds.SetProjection(wom_ds.GetProjection())
            for idx, (arr, lbl) in enumerate(
                    [(rgb_r, 'Red'), (rgb_g, 'Green'), (rgb_b, 'Blue')], 1):
                band = rgb_ds.GetRasterBand(idx)
                band.WriteArray(arr)
                band.SetDescription(lbl)
                band.FlushCache()
            rgb_ds = None
            feedback.setProgress(85)

            result[self.OUTPUT_RGB] = out_rgb

        wom_ds = None
        feedback.setProgress(100)
        feedback.pushInfo('dt_fedrop classification complete.')
        return result

    def name(self):        return 'dt_fedrop'
    def displayName(self): return 'DT Fedrop Classification'
    def group(self):       return '4 - Decision Tree Classification'
    def groupId(self):     return '4_decision_tree'

    def shortHelpString(self):
        return """
        <b>DT Fedrop Classification</b>

        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube + WoM-C (2100–2400 nm).<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.<br/>Run <i>Workflow A</i> to generate required WoM rasters.
        </p>


        <p>Classifies pixels into iron drop (fedrop) intensity classes using a
        spectral decision tree. The fedrop value (b1) is computed internally
        as the band ratio <b>R(1600nm) / R(1310nm)</b> from the hyperspectral
        cube. The two bands closest to 1600 nm and 1310 nm are found
        automatically from the cube's wavelength metadata.</p>

        <p><b>Inputs:</b></p>
        <ul>
          <li><b>Hyperspectral cube</b> — original spectral data with wavelength
              metadata (ENVI format or equivalent). Used to compute b1.</li>
          <li><b>WoM raster</b> — Wavelength of Minimum output (Step 1).
              Band 1 = primary absorption wavelength (b2, nm).
              Band 2 = feature depth (b3, threshold gate).</li>
          <li><b>Depth threshold</b> — pixels with b3 &le; this value are
              labelled aspectral (default 0.05).</li>
        </ul>

        <p><b>Decision tree:</b></p>
        <ul>
          <li>b3 &le; threshold &rarr; <b>aspectral</b></li>
          <li>b2 not in (2100, 2400] nm &rarr; <b>no2100-2400</b></li>
          <li>b1 &le; 1.1 &rarr; <b>low</b></li>
          <li>b1 &le; 1.2 &rarr; <b>med-low</b></li>
          <li>b1 &le; 1.3 &rarr; <b>medium</b></li>
          <li>b1 &le; 1.4 &rarr; <b>med-high</b></li>
          <li>b1 &le; 1.5 &rarr; <b>high</b></li>
          <li>b1 &gt; 1.5 &rarr; <b>very-high</b></li>
        </ul>

        <p>The log reports which bands were selected for 1600 nm and 1310 nm,
        and the b1 ratio min/max/mean, so you can verify the computation.</p>

        <p><i>Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return DtFedropAlgorithm()
