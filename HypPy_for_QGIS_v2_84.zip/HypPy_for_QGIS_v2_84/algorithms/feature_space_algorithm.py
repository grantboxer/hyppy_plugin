"""
2D Feature Space — scatter plot of two mineral index rasters

Plots the pixel values of two single-band rasters (X-axis and Y-axis) as a
2D scatter diagram, coloured by pixel density.  An optional ratio-threshold
line can be overlaid to distinguish mineral clusters (e.g. 2160D/2200D = 3.0
separating kaolinite from white mica, as derived in GSWA Report 261 Fig. 24).

Background (GSWA Report 261, §3.5.2, Figures 24 & 25):
    Plotting the relative intensities of the 2160 nm and 2200 nm absorption
    features against each other reveals distinct pixel clusters corresponding
    to different Al-sheetsilicate species (white mica, kaolinite, pyrophyllite).
    The ratio threshold separating these clusters is used to define the masking
    conditions in GSWA Table 5 mineral map products.  This tool makes that
    scatter-diagram workflow available directly within QGIS, allowing users to
    derive scene-specific thresholds rather than relying on generic GSWA values.

    "Plotting the relative intensities against each other shows a significant
     correlation … a large cluster of pixels with high 2200D values at low/absent
     2160D values can be discerned, which represents pixels dominated by white mica."
    — Laukamp et al. (2025) GSWA Report 261, §3.5.2

Output: an HTML file containing an interactive scatter plot (rendered via the
QGIS browser or any web browser).  The HTML is self-contained — no internet
connection required.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import os
import json
import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterString,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterFileDestination,
    QgsProcessingException,
)


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Inputs:</b> Two single-band rasters (e.g. FE depth outputs or GSWA index rasters).<br/>
        <b>Output:</b> Interactive HTML scatter plot — open in QGIS browser or any web browser.
        </p>
"""

# Maximum pixels to plot (downsampled randomly if scene is larger)
_MAX_PLOT_PX = 200_000


def _html_scatter(x_vals, y_vals, density, x_label, y_label, title,
                  ratio_threshold, ratio_label):
    """Return a self-contained HTML page with an SVG-based scatter plot."""

    # Bin into a 2D density grid for efficient rendering
    N_GRID = 300
    x_min, x_max = float(np.nanpercentile(x_vals, 0.5)), float(np.nanpercentile(x_vals, 99.5))
    y_min, y_max = float(np.nanpercentile(y_vals, 0.5)), float(np.nanpercentile(y_vals, 99.5))

    if x_min == x_max:
        x_max = x_min + 1e-6
    if y_min == y_max:
        y_max = y_min + 1e-6

    # 2D histogram for density-colour rendering
    hist2d, xedges, yedges = np.histogram2d(
        x_vals, y_vals, bins=N_GRID,
        range=[[x_min, x_max], [y_min, y_max]])

    # Convert to JSON-serialisable list for inline JS
    hist_data = hist2d.T.tolist()   # shape (N_GRID, N_GRID), rows=y, cols=x

    ratio_js = 'null'
    ratio_label_js = '""'
    if ratio_threshold is not None and ratio_threshold > 0:
        ratio_js = str(float(ratio_threshold))
        ratio_label_js = json.dumps(ratio_label or f'ratio = {ratio_threshold:.2f}')

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{title}</title>
<style>
  body {{ margin:0; background:#1a1a2e; color:#e0e0e0;
          font-family: 'Segoe UI', Arial, sans-serif; }}
  h2   {{ text-align:center; padding:10px 0 0 0; margin:0;
          font-size:15px; color:#90caf9; }}
  #wrap {{ display:flex; flex-direction:column; align-items:center; }}
  canvas {{ cursor:crosshair; display:block; margin:8px auto; }}
  #info {{ font-size:12px; color:#b0bec5; padding:2px 0 4px 0; min-height:18px; }}
  #legend {{ display:flex; align-items:center; gap:6px; margin:4px 0; font-size:11px; }}
  #legend canvas {{ margin:0; width:180px; height:14px; }}
</style>
</head>
<body>
<div id="wrap">
  <h2>{title}</h2>
  <div id="info">Hover over the plot …</div>
  <canvas id="sc" width="600" height="500"></canvas>
  <div id="legend">
    <span>Low density</span>
    <canvas id="lgd" width="180" height="14"></canvas>
    <span>High density</span>
  </div>
</div>
<script>
(function(){{
const hist = {json.dumps(hist_data)};
const N = hist.length;          // N_GRID rows (y)
const M = hist[0].length;       // N_GRID cols (x)
const xMin={x_min:.6f}, xMax={x_max:.6f};
const yMin={y_min:.6f}, yMax={y_max:.6f};
const xLabel={json.dumps(x_label)};
const yLabel={json.dumps(y_label)};
const ratioThresh={ratio_js};
const ratioLabel={ratio_label_js};

// ── colour scale: black → purple → blue → cyan → green → yellow → red ──
function densityColour(t) {{
  // t in [0,1]
  const stops = [
    [0,   [10,10,30]],
    [0.15,[60,0,120]],
    [0.35,[0,50,180]],
    [0.55,[0,180,180]],
    [0.70,[0,200,60]],
    [0.85,[220,200,0]],
    [1.0, [255,60,0]],
  ];
  for(let i=1;i<stops.length;i++){{
    const [t0,c0]=stops[i-1], [t1,c1]=stops[i];
    if(t<=t1){{
      const f=(t-t0)/(t1-t0);
      return stops[i-1][1].map((v,j)=>Math.round(v+(c1[j]-v)*f));
    }}
  }}
  return [255,60,0];
}}

// ── canvas setup ──────────────────────────────────────────────────────────
const cv  = document.getElementById('sc');
const ctx = cv.getContext('2d');
const W=cv.width, H=cv.height;
const PAD={{l:60,r:20,t:20,b:50}};
const pw=W-PAD.l-PAD.r, ph=H-PAD.t-PAD.b;

function toCanvasX(v){{ return PAD.l + (v-xMin)/(xMax-xMin)*pw; }}
function toCanvasY(v){{ return PAD.t + (1-(v-yMin)/(yMax-yMin))*ph; }}
function toDataX(cx){{ return xMin+(cx-PAD.l)/pw*(xMax-xMin); }}
function toDataY(cy){{ return yMin+(1-(cy-PAD.t)/ph)*(yMax-yMin); }}

// ── find max density for normalisation ───────────────────────────────────
let maxD=0;
for(let r=0;r<N;r++) for(let c=0;c<M;c++) if(hist[r][c]>maxD) maxD=hist[r][c];

function draw(){{
  ctx.clearRect(0,0,W,H);
  // Background
  ctx.fillStyle='#1a1a2e'; ctx.fillRect(0,0,W,H);

  // Plot area clip
  ctx.save();
  ctx.beginPath();
  ctx.rect(PAD.l, PAD.t, pw, ph);
  ctx.clip();

  // Density cells
  const cellW = pw/M, cellH = ph/N;
  for(let r=0;r<N;r++){{
    for(let c=0;c<M;c++){{
      const d = hist[r][c];
      if(d===0) continue;
      // log scale for density colour
      const t = Math.log1p(d)/Math.log1p(maxD);
      const [R,G,B]=densityColour(t);
      ctx.fillStyle=`rgb(${{R}},${{G}},${{B}})`;
      const cx=PAD.l+c*cellW, cy=PAD.t+(N-1-r)*cellH;
      ctx.fillRect(cx, cy, cellW+1, cellH+1);
    }}
  }}

  // Ratio threshold line: y = ratio * x  →  y/x = ratio
  if(ratioThresh!==null){{
    ctx.save();
    ctx.strokeStyle='#ffeb3b'; ctx.lineWidth=1.5;
    ctx.setLineDash([6,3]);
    const x1=xMin, y1=ratioThresh*xMin;
    const x2=xMax, y2=ratioThresh*xMax;
    ctx.beginPath();
    ctx.moveTo(toCanvasX(x1), toCanvasY(y1));
    ctx.lineTo(toCanvasX(x2), toCanvasY(y2));
    ctx.stroke();
    // Label
    ctx.setLineDash([]);
    ctx.fillStyle='#ffeb3b'; ctx.font='11px Arial'; ctx.textAlign='left';
    const lx=toCanvasX(xMin+(xMax-xMin)*0.55);
    const ly=toCanvasY(ratioThresh*(xMin+(xMax-xMin)*0.55))-6;
    ctx.fillText(ratioLabel, lx, ly);
    ctx.restore();
  }}

  ctx.restore();  // end clip

  // ── Axes ──────────────────────────────────────────────────────────────
  ctx.strokeStyle='#90caf9'; ctx.lineWidth=1;
  ctx.beginPath();
  ctx.moveTo(PAD.l, PAD.t); ctx.lineTo(PAD.l, PAD.t+ph);
  ctx.lineTo(PAD.l+pw, PAD.t+ph);
  ctx.stroke();

  // Tick marks & labels
  ctx.fillStyle='#b0bec5'; ctx.font='10px Arial'; ctx.textAlign='center';
  const nTicks=5;
  for(let i=0;i<=nTicks;i++){{
    const v=xMin+i*(xMax-xMin)/nTicks;
    const cx=toCanvasX(v);
    ctx.beginPath(); ctx.moveTo(cx,PAD.t+ph); ctx.lineTo(cx,PAD.t+ph+4); ctx.stroke();
    ctx.fillText(v.toFixed(3), cx, PAD.t+ph+15);
  }}
  ctx.textAlign='right';
  for(let i=0;i<=nTicks;i++){{
    const v=yMin+i*(yMax-yMin)/nTicks;
    const cy=toCanvasY(v);
    ctx.beginPath(); ctx.moveTo(PAD.l,cy); ctx.lineTo(PAD.l-4,cy); ctx.stroke();
    ctx.fillText(v.toFixed(3), PAD.l-6, cy+4);
  }}

  // Axis labels
  ctx.save();
  ctx.fillStyle='#90caf9'; ctx.font='bold 12px Arial'; ctx.textAlign='center';
  ctx.fillText(xLabel, PAD.l+pw/2, H-6);
  ctx.translate(14, PAD.t+ph/2);
  ctx.rotate(-Math.PI/2);
  ctx.fillText(yLabel, 0, 0);
  ctx.restore();
}}

draw();

// ── Legend ────────────────────────────────────────────────────────────────
const lgd=document.getElementById('lgd');
const lctx=lgd.getContext('2d');
const lw=lgd.width, lh=lgd.height;
for(let i=0;i<lw;i++){{
  const [R,G,B]=densityColour(i/lw);
  lctx.fillStyle=`rgb(${{R}},${{G}},${{B}})`;
  lctx.fillRect(i,0,1,lh);
}}

// ── Hover crosshair ───────────────────────────────────────────────────────
cv.addEventListener('mousemove', function(e){{
  const rect=cv.getBoundingClientRect();
  const mx=e.clientX-rect.left, my=e.clientY-rect.top;
  if(mx<PAD.l||mx>PAD.l+pw||my<PAD.t||my>PAD.t+ph){{
    document.getElementById('info').textContent='Hover over the plot …';
    draw(); return;
  }}
  const dx=toDataX(mx), dy=toDataY(my);
  let info=`X (${xLabel}): ${{dx.toFixed(5)}}   Y (${yLabel}): ${{dy.toFixed(5)}}`;
  if(ratioThresh!==null){{
    const r=(dx>0)?dy/dx:Infinity;
    info+=`   Y/X ratio: ${{r.toFixed(3)}}`;
  }}
  document.getElementById('info').textContent=info;
  draw();
  // crosshair
  ctx.save();
  ctx.strokeStyle='rgba(255,255,255,0.4)'; ctx.lineWidth=1; ctx.setLineDash([3,3]);
  ctx.beginPath(); ctx.moveTo(mx,PAD.t); ctx.lineTo(mx,PAD.t+ph); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(PAD.l,my); ctx.lineTo(PAD.l+pw,my); ctx.stroke();
  ctx.restore();
}});
cv.addEventListener('mouseleave',()=>{{ draw(); document.getElementById('info').textContent='Hover over the plot …'; }});
}})();
</script>
</body>
</html>
"""
    return html


class FeatureSpaceAlgorithm(QgsProcessingAlgorithm):
    """2D Feature Space scatter plot of two single-band rasters."""

    RASTER_X        = 'RASTER_X'
    RASTER_Y        = 'RASTER_Y'
    LABEL_X         = 'LABEL_X'
    LABEL_Y         = 'LABEL_Y'
    RATIO_THRESHOLD = 'RATIO_THRESHOLD'
    RATIO_LABEL     = 'RATIO_LABEL'
    TITLE           = 'TITLE'
    OUTPUT_HTML     = 'OUTPUT_HTML'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.RASTER_X,
            'X-axis raster  (e.g. 2160D depth from FE10)'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.RASTER_Y,
            'Y-axis raster  (e.g. 2200D depth from FE12)'))
        self.addParameter(QgsProcessingParameterString(
            self.LABEL_X, 'X-axis label', defaultValue='2160D depth'))
        self.addParameter(QgsProcessingParameterString(
            self.LABEL_Y, 'Y-axis label', defaultValue='2200D depth'))
        self.addParameter(QgsProcessingParameterNumber(
            self.RATIO_THRESHOLD,
            'Y/X ratio threshold line  (0 = none, e.g. 3.0 for 2160D/2200D kaolinite cut)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.0, minValue=0.0, maxValue=1000.0))
        self.addParameter(QgsProcessingParameterString(
            self.RATIO_LABEL,
            'Ratio line label  (shown on plot)',
            defaultValue='Y/X = 3.0  (kaolinite threshold)',
            optional=True))
        self.addParameter(QgsProcessingParameterString(
            self.TITLE,
            'Plot title',
            defaultValue='2D Feature Space'))
        self.addParameter(QgsProcessingParameterFileDestination(
            self.OUTPUT_HTML,
            'Output HTML scatter plot',
            fileFilter='HTML files (*.html)'))

    def processAlgorithm(self, parameters, context, feedback):
        rx       = self.parameterAsRasterLayer(parameters, self.RASTER_X, context)
        ry       = self.parameterAsRasterLayer(parameters, self.RASTER_Y, context)
        label_x  = self.parameterAsString(parameters, self.LABEL_X, context)
        label_y  = self.parameterAsString(parameters, self.LABEL_Y, context)
        ratio_t  = self.parameterAsDouble(parameters, self.RATIO_THRESHOLD, context)
        ratio_lbl= self.parameterAsString(parameters, self.RATIO_LABEL, context)
        title    = self.parameterAsString(parameters, self.TITLE, context)
        out_html = self.parameterAsFileOutput(parameters, self.OUTPUT_HTML, context)

        if rx is None or ry is None:
            raise QgsProcessingException('Invalid input raster(s)')

        # ── Read X raster ─────────────────────────────────────────────────
        feedback.pushInfo(f'Reading X raster: {rx.source()}')
        ds_x = gdal.Open(rx.source())
        if ds_x is None:
            raise QgsProcessingException(f'Cannot open X raster: {rx.source()}')
        if ds_x.RasterCount != 1:
            raise QgsProcessingException('X raster must be single-band.')
        bx   = ds_x.GetRasterBand(1)
        nd_x = bx.GetNoDataValue()
        x_arr = bx.ReadAsArray().astype(np.float32)
        if nd_x is not None:
            x_arr[x_arr == nd_x] = np.nan
        rows_x, cols_x = ds_x.RasterYSize, ds_x.RasterXSize
        del ds_x

        # ── Read Y raster ─────────────────────────────────────────────────
        feedback.pushInfo(f'Reading Y raster: {ry.source()}')
        ds_y = gdal.Open(ry.source())
        if ds_y is None:
            raise QgsProcessingException(f'Cannot open Y raster: {ry.source()}')
        if ds_y.RasterCount != 1:
            raise QgsProcessingException('Y raster must be single-band.')
        by   = ds_y.GetRasterBand(1)
        nd_y = by.GetNoDataValue()
        y_arr = by.ReadAsArray().astype(np.float32)
        if nd_y is not None:
            y_arr[y_arr == nd_y] = np.nan
        rows_y, cols_y = ds_y.RasterYSize, ds_y.RasterXSize
        del ds_y

        # ── Dimension check ───────────────────────────────────────────────
        if (rows_x, cols_x) != (rows_y, cols_y):
            raise QgsProcessingException(
                f'Raster dimensions do not match: '
                f'X={cols_x}×{rows_x}, Y={cols_y}×{rows_y}. '
                'Both rasters must cover the same area at the same resolution.')

        feedback.pushInfo(f'Scene: {rows_x}×{cols_x} = {rows_x*cols_x:,} pixels')

        # ── Build valid pixel mask ────────────────────────────────────────
        feedback.setProgress(20)
        valid = ~np.isnan(x_arr) & ~np.isnan(y_arr)
        x_vals = x_arr[valid]
        y_vals = y_arr[valid]
        n_valid = int(x_vals.size)
        feedback.pushInfo(f'Valid paired pixels: {n_valid:,}')

        if n_valid < 10:
            raise QgsProcessingException(
                'Fewer than 10 valid paired pixels — cannot produce a meaningful plot.')

        # ── Downsample if needed ──────────────────────────────────────────
        if n_valid > _MAX_PLOT_PX:
            rng = np.random.default_rng(42)
            idx = rng.choice(n_valid, size=_MAX_PLOT_PX, replace=False)
            x_vals = x_vals[idx]
            y_vals = y_vals[idx]
            feedback.pushInfo(
                f'Downsampled to {_MAX_PLOT_PX:,} pixels for plot performance.')

        # ── Compute density (for colour) ──────────────────────────────────
        feedback.setProgress(50)
        feedback.pushInfo('Building density estimate …')
        density = np.ones(len(x_vals), dtype=np.float32)  # placeholder; coloured by 2D hist

        # ── Generate HTML ─────────────────────────────────────────────────
        feedback.setProgress(70)
        feedback.pushInfo('Rendering scatter plot …')

        ratio_arg   = ratio_t if ratio_t > 0 else None
        ratio_label = ratio_lbl if (ratio_t > 0 and ratio_lbl) else None

        html = _html_scatter(
            x_vals, y_vals, density,
            label_x, label_y, title,
            ratio_arg, ratio_label)

        with open(out_html, 'w', encoding='utf-8') as f:
            f.write(html)

        feedback.pushInfo('')
        feedback.pushInfo('─' * 60)
        feedback.pushInfo(f'Scatter plot written to: {out_html}')
        feedback.pushInfo('Open the HTML file in any web browser or QGIS browser.')
        feedback.pushInfo('')
        feedback.pushInfo('Tip: To derive a scene-specific mineral threshold:')
        feedback.pushInfo('  1. Look for distinct clusters in the scatter plot')
        feedback.pushInfo('  2. Hover over the boundary between clusters to read')
        feedback.pushInfo('     the Y/X ratio value in the info bar')
        feedback.pushInfo('  3. Use that ratio as the threshold in GSWA index')
        feedback.pushInfo('     algorithms (e.g. NDVI mask, depth thresholds)')
        feedback.pushInfo('─' * 60)
        feedback.setProgress(100)

        return {self.OUTPUT_HTML: out_html}

    def name(self):        return 'feature_space_2d'
    def displayName(self): return '2D Feature Space  (scatter plot)'
    def group(self):       return '6 - Spectral Processing Tools'
    def groupId(self):     return 'five_spectral_processing'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>2D Feature Space — mineral cluster scatter plot</b>

        <p>Plots pixel values from two single-band rasters as a 2D scatter
        diagram, coloured by pixel density (blue=sparse → red=dense).
        An optional Y/X ratio line can be overlaid to mark the boundary
        between mineral clusters.</p>

        <p><b>Primary use case — deriving scene-specific mineral thresholds:</b></p>
        <ol>
          <li>Run <b>FE10-2160D</b> on your cube → save the WoM raster
              (Band 2 = 2160D depth)</li>
          <li>Run <b>FE12-2200W</b> on your cube → save the WoM raster
              (Band 2 = 2200D depth)</li>
          <li>Run this tool with X = 2160D depth, Y = 2200D depth</li>
          <li>Set ratio threshold = 3.0 (GSWA generic kaolinite/white-mica cut)</li>
          <li>Open the output HTML in a browser and hover over cluster boundaries
              to read the Y/X ratio — adjust threshold to match your scene</li>
          <li>Use your scene-specific threshold as the depth mask in
              GSWA-ASai, GSWA-WMai, GSWA-KLNai algorithms</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Cluster</th><th>2160D (X)</th><th>2200D (Y)</th><th>Y/X ratio</th>
          </tr>
          <tr><td>White mica</td>
              <td>Low/absent</td><td>High</td><td>&gt; 3.0</td></tr>
          <tr><td>Kaolinite</td>
              <td>Moderate</td><td>Moderate</td><td>1.0 – 3.0</td></tr>
          <tr><td>Pyrophyllite</td>
              <td>Very high</td><td>Moderate</td><td>&lt; 1.0</td></tr>
        </table>

        <p><b>Other useful combinations:</b></p>
        <ul>
          <li>X = 2250D, Y = 2200D → chlorite-biotite vs Al-sheetsilicate contrast</li>
          <li>X = KLNai, Y = ASai → kaolin vs total Al-sheetsilicate</li>
          <li>X = FOai, Y = MertonNDVI → iron oxide vs vegetation (cf. Fig. 11)</li>
        </ul>

        <p><b>Performance note:</b> The plot is downsampled to
        200,000 pixels if the scene is larger — statistics remain representative.</p>

        <p><i>Background: Laukamp, C., Miles, A.J. et al. (2025) GSWA Report 261,
        §3.5.2, Figures 24 and 25 (2160D vs 2200D scatter diagrams for Gascoyne
        and Pilbara ROIs).</i></p>
        """

    def createInstance(self): return FeatureSpaceAlgorithm()
