"""
Zonal Statistics Algorithm for QGIS Processing

For each zone in a single-band zones raster, computes a per-band statistic
across all pixels of a hyperspectral image that fall within that zone, and
writes one tab-separated text file per zone.

Output columns: wavelength (nm) or band index  |  statistic value

Supported statistics (after Bakker, HyPy 3.0.1  zonalstatistics.py):
  max, mean, median, min, std, sum, m-2s (mean − 2·std), m+2s (mean + 2·std)

The zones image must be a single-band raster. If its ENVI header carries a
class_names list (ENVI Classification type) the zone names are used in the
output filenames; otherwise the pixel value is used.

Ported from HyPy zonalstatistics.py
Original Author: Wim Bakker, University of Twente  (created 20200925)

Copyright (C) 2025 Grant Boxer
Original HyPy Copyright (C) 2020 Wim Bakker, University of Twente

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import os
import re

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterEnum,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterFolderDestination,
    QgsProcessingException,
)

from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset

# ── statistical methods (mirrors HyPy zonalstatistics.py) ─────────────────────

def _m_min_2s(a, axis=0):
    return np.mean(a, axis=axis) - 2.0 * np.std(a, axis=axis)

def _m_plus_2s(a, axis=0):
    return np.mean(a, axis=axis) + 2.0 * np.std(a, axis=axis)

_METHODS = {
    'mean':   lambda a: np.mean(a, axis=0),
    'median': lambda a: np.median(a, axis=0),
    'max':    lambda a: np.max(a, axis=0),
    'min':    lambda a: np.min(a, axis=0),
    'std':    lambda a: np.std(a, axis=0),
    'sum':    lambda a: np.sum(a, axis=0),
    'm-2s':   lambda a: _m_min_2s(a, axis=0),
    'm+2s':   lambda a: _m_plus_2s(a, axis=0),
}
_METHOD_LABELS = ['mean', 'median', 'max', 'min', 'std', 'sum', 'm-2s', 'm+2s']

SEP = '_'
EXTENSION = '.txt'


# ── helper: resolve .hdr → binary (same pattern as build_overviews) ───────────

def _resolve_binary(path):
    """If path ends in .hdr, find the matching binary data file."""
    if not path.lower().endswith('.hdr'):
        return path
    base = path[:-4]
    for ext in ('', '.img', '.dat', '.bil', '.bip', '.bsq'):
        candidate = base + ext
        if os.path.isfile(candidate):
            return candidate
    return path   # fall back; GDAL will report a useful error


# ── helper: read class names from ENVI header ─────────────────────────────────

def _read_class_names(hdr_path):
    """Return a list of class name strings from an ENVI header, or None."""
    if not os.path.isfile(hdr_path):
        return None
    try:
        with open(hdr_path, 'r', errors='replace') as f:
            text = f.read()
        m = re.search(r'class names\s*=\s*\{([^}]*)\}', text, re.IGNORECASE | re.DOTALL)
        if not m:
            return None
        raw = m.group(1)
        names = [n.strip() for n in raw.split(',')]
        return names
    except Exception:
        return None


# ── helper: safe filename component ──────────────────────────────────────────

def _safe(name):
    """Replace characters that are unsafe in filenames."""
    return re.sub(r'[\\/:*?"<>|]', '_', str(name))


# ── core computation ──────────────────────────────────────────────────────────

def _zonal_statistics(zones_path, image_path,
                      method='mean',
                      use_bbl=False,
                      sort_wavelengths=False,
                      output_dir=None,
                      feedback=None):
    """
    Compute per-zone per-band statistics for a hyperspectral image.

    Returns a list of output file paths created.
    """

    def msg(s):
        if feedback:
            feedback.pushInfo(s)

    # ── open zones raster ─────────────────────────────────────────────────────
    zones_binary = _resolve_binary(zones_path)
    ds_zones = gdal.Open(zones_binary)
    if ds_zones is None:
        raise QgsProcessingException(
            'Cannot open zones raster: %s' % zones_path)
    if ds_zones.RasterCount != 1:
        raise QgsProcessingException(
            'Zones raster must have exactly one band (found %d).'
            % ds_zones.RasterCount)

    zones_band = ds_zones.GetRasterBand(1)
    zones_arr  = zones_band.ReadAsArray()          # shape: (lines, samples)
    zones_flat = zones_arr.flatten()
    n_lines_z  = ds_zones.RasterYSize
    n_samps_z  = ds_zones.RasterXSize

    # ── try to get class names from ENVI header ───────────────────────────────
    zones_hdr = zones_binary
    for ext in ('.hdr', ):
        candidate = zones_binary + ext
        if os.path.isfile(candidate):
            zones_hdr = candidate
            break
    if not zones_hdr.lower().endswith('.hdr'):
        # also check base+'.hdr' (e.g. file.bil → file.hdr)
        candidate = os.path.splitext(zones_binary)[0] + '.hdr'
        if os.path.isfile(candidate):
            zones_hdr = candidate

    class_names = _read_class_names(zones_hdr)
    msg('Zones: %s' % zones_path)
    if class_names:
        msg('Class names found: %d names' % len(class_names))

    # ── open hyperspectral image ──────────────────────────────────────────────
    image_binary = _resolve_binary(image_path)
    ds_image = gdal.Open(image_binary)
    if ds_image is None:
        raise QgsProcessingException(
            'Cannot open hyperspectral image: %s' % image_path)

    n_bands   = ds_image.RasterCount
    n_lines_i = ds_image.RasterYSize
    n_samps_i = ds_image.RasterXSize

    if n_lines_z != n_lines_i or n_samps_z != n_samps_i:
        raise QgsProcessingException(
            'Zones image (%d×%d) and hyperspectral image (%d×%d) '
            'must have the same spatial dimensions.'
            % (n_samps_z, n_lines_z, n_samps_i, n_lines_i))

    # ── wavelengths ───────────────────────────────────────────────────────────
    wavelengths = get_wavelengths_from_dataset(ds_image, n_bands,
                                               raster_path=image_binary,
                                               feedback=feedback)

    # ── bad band list ─────────────────────────────────────────────────────────
    bbl = None
    if use_bbl:
        bbl = get_bbl_from_dataset(ds_image, n_bands,
                                   raster_path=image_binary,
                                   feedback=feedback)
        if bbl is not None:
            n_good = int(np.sum(bbl))
            msg('BBL loaded: %d/%d bands active' % (n_good, n_bands))

    # ── sort wavelengths ──────────────────────────────────────────────────────
    band_order = list(range(n_bands))
    if sort_wavelengths and wavelengths is not None:
        band_order = sorted(band_order, key=lambda b: wavelengths[b])
        msg('Bands sorted by wavelength.')

    # ── determine output directory ────────────────────────────────────────────
    if not output_dir:
        output_dir = os.path.dirname(image_binary)
    os.makedirs(output_dir, exist_ok=True)

    # ── determine base name for output files ──────────────────────────────────
    image_base = os.path.splitext(os.path.basename(image_binary))[0]

    # ── statistical function ──────────────────────────────────────────────────
    stat_fn = _METHODS[method]

    # ── iterate over unique zone values ──────────────────────────────────────
    unique_zones = sorted(set(zones_flat.tolist()))
    msg('Found %d unique zone values.' % len(unique_zones))
    msg('')

    output_files = []

    for z_idx, classvalue in enumerate(unique_zones):
        if feedback and feedback.isCanceled():
            break

        # pixel mask for this zone
        pixel_indices = np.where(zones_flat == classvalue)[0]
        n_pixels = len(pixel_indices)

        # zone name for filename
        cv_int = int(classvalue)
        if class_names and 0 <= cv_int < len(class_names):
            classname = class_names[cv_int]
        else:
            classname = '%g' % classvalue

        # build output path
        safe_name = _safe(classname)
        out_name = '%s%s%s%s%s%s' % (
            image_base, SEP, safe_name, SEP, method, EXTENSION)
        out_path = os.path.join(output_dir, out_name)

        msg('Zone %s  (%d pixels) → %s' % (classname, n_pixels, out_name))

        if n_pixels == 0:
            msg('  (skipped — no pixels)')
            continue

        # open file
        f = open(out_path, 'w')
        print('# Zonal Statistics', file=f)
        print('# Zones:      %s' % zones_path, file=f)
        print('# Image:      %s' % image_path, file=f)
        print('# Method:     %s' % method, file=f)
        print('# Sort wav:   %s' % sort_wavelengths, file=f)
        print('# Use BBL:    %s' % use_bbl, file=f)
        print('# Zone name:  %s' % classname, file=f)
        print('# Zone value: %g' % classvalue, file=f)
        print('# Pixels:     %d' % n_pixels, file=f)
        if wavelengths is not None:
            print('# wavelength(nm)\t%s' % method, file=f)
        else:
            print('# band_index\t%s' % method, file=f)

        # process band by band (memory-efficient — one GDAL read per band)
        for b_seq, b in enumerate(band_order):
            if feedback and feedback.isCanceled():
                break

            # BBL check
            if bbl is not None and not bbl[b]:
                continue

            band_data = ds_image.GetRasterBand(b + 1).ReadAsArray()
            band_flat = band_data.flatten().astype(np.float64)

            # extract pixels for this zone and apply stat
            zone_vals = band_flat[pixel_indices]
            result = float(stat_fn(zone_vals[np.newaxis, :]))

            if wavelengths is not None:
                print('%f\t%f' % (wavelengths[b], result), file=f)
            else:
                print('%d\t%f' % (b, result), file=f)

            if feedback:
                feedback.setProgress(
                    int(100 * (z_idx * n_bands + b_seq) /
                        (len(unique_zones) * n_bands)))

        f.close()
        output_files.append(out_path)

    del ds_zones, ds_image
    msg('')
    msg('Zonal statistics complete. %d file(s) written to: %s'
        % (len(output_files), output_dir))
    return output_files


# ── QGIS algorithm wrapper ────────────────────────────────────────────────────

class ZonalStatisticsAlgorithm(QgsProcessingAlgorithm):
    """
    Compute per-zone per-band statistics for a hyperspectral image.

    For each unique zone class a tab-separated text file is written containing
    wavelength (nm) or band index paired with the chosen statistic value.
    """

    ZONES   = 'ZONES'
    INPUT   = 'INPUT'
    METHOD  = 'METHOD'
    USE_BBL = 'USE_BBL'
    SORT_WAV = 'SORT_WAV'
    OUTPUT_DIR = 'OUTPUT_DIR'

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFile(
                self.ZONES,
                'Zones raster (single-band — ENVI Classification or integer raster)',
                behavior=QgsProcessingParameterFile.File,
                fileFilter='Raster Files (*.hdr *.img *.dat *.bil *.bip *.bsq *.tif *.tiff);;All Files (*)',
                optional=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT,
                'Input hyperspectral image',
                behavior=QgsProcessingParameterFile.File,
                fileFilter='ENVI / Raster Files (*.hdr *.img *.dat *.bil *.bip *.bsq *.tif *.tiff);;All Files (*)',
                optional=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.METHOD,
                'Statistical method',
                options=_METHOD_LABELS,
                defaultValue=0,   # mean
                optional=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.USE_BBL,
                'Use Bad Band List (BBL)',
                defaultValue=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.SORT_WAV,
                'Sort bands by wavelength',
                defaultValue=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.OUTPUT_DIR,
                'Output folder (one .txt file per zone)',
                optional=True,
                defaultValue=None,
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        zones_path  = self.parameterAsFile(parameters, self.ZONES,   context)
        image_path  = self.parameterAsFile(parameters, self.INPUT,   context)
        method_idx  = self.parameterAsEnum(parameters, self.METHOD,  context)
        use_bbl     = self.parameterAsBool(parameters, self.USE_BBL, context)
        sort_wav    = self.parameterAsBool(parameters, self.SORT_WAV, context)

        # output dir — None means "beside the image"
        output_dir = None
        if self.OUTPUT_DIR in parameters and parameters[self.OUTPUT_DIR]:
            output_dir = self.parameterAsString(parameters, self.OUTPUT_DIR, context)
            if not output_dir:
                output_dir = None

        method = _METHOD_LABELS[method_idx]

        feedback.pushInfo('=== Zonal Statistics ===')
        feedback.pushInfo('Method:    %s' % method)
        feedback.pushInfo('Use BBL:   %s' % use_bbl)
        feedback.pushInfo('Sort wav:  %s' % sort_wav)

        _zonal_statistics(
            zones_path, image_path,
            method=method,
            use_bbl=use_bbl,
            sort_wavelengths=sort_wav,
            output_dir=output_dir,
            feedback=feedback,
        )

        return {}

    # ── metadata ──────────────────────────────────────────────────────────────

    def name(self):
        return 'zonal_statistics'

    def displayName(self):
        return 'E09 - Zonal Statistics'

    def group(self):
        return '6 - Spectral Processing Tools'

    def groupId(self):
        return '6_spectral_processing'

    def shortHelpString(self):
        return (
            '<h3>E09 — Zonal Statistics</h3>'
            '<p>For each zone in a single-band zones raster, computes a per-band '
            'spectral statistic across all pixels of a hyperspectral image that '
            'fall within that zone. One tab-separated text file is written per zone, '
            'containing wavelength (nm) vs statistic value — ready for plotting as '
            'a mean or percentile spectrum.</p>'
            '<p><b>Typical use:</b> classify a scene (e.g. with Decision Tree or SAM), '
            'then use the classification output as the zones raster to extract a '
            'representative mean spectrum per mineral class.</p>'
            '<p><b>Parameters:</b></p>'
            '<ul>'
            '<li><b>Zones raster</b> — single-band integer raster. ENVI Classification '
            'files carry class names which are used in output filenames; otherwise '
            'the pixel value is used.</li>'
            '<li><b>Input image</b> — hyperspectral raster (.hdr or binary). '
            'Both rasters must have the same number of rows and columns.</li>'
            '<li><b>Method</b> — '
            '<i>mean</i> (default), <i>median</i>, <i>max</i>, <i>min</i>, '
            '<i>std</i>, <i>sum</i>, <i>m-2s</i> (mean − 2·std), '
            '<i>m+2s</i> (mean + 2·std).</li>'
            '<li><b>Use Bad Band List</b> — skip bands flagged in the ENVI BBL.</li>'
            '<li><b>Sort bands by wavelength</b> — reorder output rows by '
            'ascending wavelength.</li>'
            '<li><b>Output folder</b> — where to write the .txt files. '
            'Leave blank to write beside the input image.</li>'
            '</ul>'
            '<p><b>Output format</b> (tab-separated):</p>'
            '<pre>wavelength(nm)    mean\n'
            '400.000000        0.043210\n'
            '410.000000        0.044870\n'
            '...</pre>'
            '<p>Files are named <tt>&lt;image&gt;_&lt;zone&gt;_&lt;method&gt;.txt</tt>, '
            'e.g. <tt>f250610_Kaolinite_mean.txt</tt>.</p>'
            '<p><i>Ported from HyPy 3.0.1 zonalstatistics.py '
            '(Wim Bakker, University of Twente, 2020).</i></p>'
        )

    def createInstance(self):
        return ZonalStatisticsAlgorithm()
