"""
GSWA Table 5 — Al-sheetsilicate composition index (ASci)

Algorithm: Wavelength position of the wavelength minimum between 2140 and 2240 nm
           using 4th order polynomial fit (2200W).
Masks:     MertonNDVI > 0.15 / > 0.2  AND  2200D < 0.04
Stretch:   linear: Blue = short wvl (2190 nm); red = long wvl (2215 nm)
Targeted:  Kaolinite and/or Al-poor white mica and Al-smectite in blue;
           Al-rich white mica and Al-smectite in red  (challenge: tourmaline)

Reference:
    Laukamp et al. (2025) GSWA Report 261, Table 5.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

from ..core.envi_header import get_wavelengths_from_dataset
from .gswa_index_utils import (
    compute_ndvi, read_wom_band, write_index,
    apply_ndvi_mask, log_gswa_stretch,
)

WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube (for NDVI) + FE12-2200W WoM raster.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""

GSWA_STRETCH = {
    'gascoyne': 'linear: Blue=2190 nm (short wvl), Red=2215 nm (long wvl)',
    'pilbara':  'linear: Blue=2185 nm (short wvl), Red=2215 nm (long wvl)',
}

REFERENCE = 'Laukamp et al. (2025) GSWA Report 261, Table 5 (ASci)'


class GswaAsciAlgorithm(QgsProcessingAlgorithm):
    """GSWA Table 5 — Al-sheetsilicate composition index (ASci)."""

    CUBE         = 'CUBE'
    WOM_2200     = 'WOM_2200'
    NDVI_THRESH  = 'NDVI_THRESH'
    DEPTH_THRESH = 'DEPTH_THRESH'
    OUTPUT       = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.CUBE,
            'Hyperspectral cube  (for MertonNDVI computation)'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2200,
            'FE12-2200W WoM raster  (Band 1 = wavelength position, Band 2 = depth)'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NDVI_THRESH,
            'MertonNDVI threshold (mask pixels above this value)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.15, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.DEPTH_THRESH,
            '2200D depth lower threshold (mask pixels below this — too shallow)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.04, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT, 'Output ASci raster  (wavelength position, nm)'))

    def processAlgorithm(self, parameters, context, feedback):
        cube_layer   = self.parameterAsRasterLayer(parameters, self.CUBE, context)
        wom_2200     = self.parameterAsRasterLayer(parameters, self.WOM_2200, context)
        ndvi_thresh  = self.parameterAsDouble(parameters, self.NDVI_THRESH, context)
        depth_thresh = self.parameterAsDouble(parameters, self.DEPTH_THRESH, context)
        out_path     = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        # 1. Read wavelength position (Band 1) and depth (Band 2)
        feedback.setProgress(5)
        feedback.pushInfo('Reading 2200W wavelength position (Band 1) …')
        wav2200, gt, proj, rows, cols = read_wom_band(wom_2200, 1, '2200W-wvl', feedback)
        feedback.pushInfo('Reading 2200D depth (Band 2) …')
        d2200, *_ = read_wom_band(wom_2200, 2, '2200D', feedback)

        # 2. Compute MertonNDVI
        feedback.setProgress(20)
        feedback.pushInfo('Computing MertonNDVI …')
        cube_ds     = gdal.Open(cube_layer.source())
        wavelengths = get_wavelengths_from_dataset(
            cube_ds, cube_ds.RasterCount, cube_layer.source(), feedback)
        if wavelengths is None:
            raise QgsProcessingException('No wavelength metadata found in cube.')
        nodata = cube_ds.GetRasterBand(1).GetNoDataValue()
        ndvi   = compute_ndvi(cube_ds, wavelengths, nodata, feedback)
        del cube_ds

        # 3. Apply masks
        feedback.setProgress(60)
        feedback.pushInfo('Applying GSWA Table 5 masks …')
        asci = wav2200.copy()
        asci = apply_ndvi_mask(asci, ndvi, ndvi_thresh, 'ASci', feedback)

        shallow = ~np.isnan(d2200) & (d2200 < depth_thresh)
        feedback.pushInfo(
            f'  ASci: 2200D<{depth_thresh} mask: {int(np.sum(shallow))} px masked')
        asci[shallow] = np.nan

        # 4. Write
        feedback.setProgress(85)
        feedback.pushInfo('Writing ASci …')
        write_index(
            out_path, asci, gt, proj,
            product_name='ASci',
            description='Al-sheetsilicate composition index (2200W wavelength position, nm)',
            gswa_stretch=GSWA_STRETCH,
            reference=REFERENCE,
            extra_meta={
                'GSWA_units':          'nm (wavelength of minimum)',
                'GSWA_blue_end_nm':    '2185-2190',
                'GSWA_red_end_nm':     '2215',
                'GSWA_interpretation': 'blue=kaolinite/Al-poor WM; red=Al-rich WM',
            }
        )

        log_gswa_stretch(feedback, 'ASci (Al-sheetsilicate composition)', GSWA_STRETCH)
        feedback.pushInfo(
            'Interpretation: Blue (~2185-2190 nm) = kaolinite / Al-poor white mica / '
            'Al-smectite; Red (~2215 nm) = Al-rich white mica / Al-smectite')
        feedback.setProgress(100)
        return {self.OUTPUT: out_path}

    def name(self):        return 'gswa_asci'
    def displayName(self): return 'GSWA-ASci  (Al-sheetsilicate Composition)'
    def group(self):       return '9 - GSWA Mineral Map Indices'
    def groupId(self):     return 'nine_gswa_indices'

    def shortHelpString(self):
        return WORKFLOW_NOTE + f"""
        <b>Al-sheetsilicate Composition Index (ASci)</b>
        <p>GSWA Report 261, Table 5. Wavelength position of the ~2200 nm Al-OH
        absorption — separates kaolinite/Al-poor white mica (short-wave) from
        Al-rich white mica and Al-smectite (long-wave).</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>GSWA Table 5 value</th>
          </tr>
          <tr><td>Base algorithm</td>
              <td>Wavelength position of WoM minimum, 2140–2240 nm (2200W)</td></tr>
          <tr><td>Vegetation mask</td>
              <td>MertonNDVI &gt; 0.15 (Gascoyne) / &gt; 0.2 (Pilbara)</td></tr>
          <tr><td>Depth gate</td><td>2200D &lt; 0.04 masked (too shallow)</td></tr>
          <tr style="background:#fff3e0">
            <td><b>Gascoyne stretch</b></td>
            <td>linear: Blue=2190 nm, Red=2215 nm</td></tr>
          <tr style="background:#fff3e0">
            <td><b>Pilbara stretch</b></td>
            <td>linear: Blue=2185 nm, Red=2215 nm</td></tr>
        </table>

        <p><b>Colour interpretation:</b></p>
        <ul>
          <li><b>Blue (2185–2190 nm)</b> — kaolinite, Al-poor white mica, Al-smectite</li>
          <li><b>Red (~2215 nm)</b> — Al-rich white mica, Al-smectite</li>
        </ul>

        <p><i>Reference: Laukamp et al. (2025) GSWA Report 261, Table 5.</i></p>
        """

    def createInstance(self): return GswaAsciAlgorithm()
