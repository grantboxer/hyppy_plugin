"""
Savitzky-Golay Spectral Smoothing Filter

Applies a Savitzky-Golay filter along the spectral dimension of a
hyperspectral cube — i.e. smooths each pixel's spectrum independently.
This is a per-pixel spectral operation, not a spatial filter.

The Savitzky-Golay filter fits a polynomial of a specified order to a
sliding window of adjacent bands and replaces each band value with the
polynomial's value at that point.  It preserves the spectral shape of
absorption features better than a simple moving-average filter while
reducing high-frequency noise.

Background (GSWA Report 261, §9.1):
    "Additional pre-processing to obtain smoother data
    (e.g. Savitzky-Golay filtering)."
    — Laukamp et al. (2025) GSWA Report 261, Recommendations

    Savitzky-Golay filtering is recommended before feature extraction
    from spaceborne hyperspectral imagery (PRISMA, EnMAP, EMIT) because:
    - Low SNR in parts of the VNIR (700-1000 nm) and SWIR (2300-2450 nm)
      introduces spurious band-to-band oscillations that can bias
      polynomial depth estimates.
    - The filter removes high-frequency noise while preserving the
      broad absorption features used by FE and GSWA index tools.
    - It does not require a BBL — it smooths across all bands uniformly,
      allowing the polynomial fit to bridge noisy single bands.

Requires: scipy (bundled with most QGIS installations)

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with wavelength metadata.<br/>
        <b>Run before:</b> Feature Extraction, GSWA Mineral Map Index, or Band Math tools
        when working with noisy spaceborne imagery (PRISMA, EnMAP, EMIT).
        </p>
"""


class SavgolFilterAlgorithm(QgsProcessingAlgorithm):
    """Savitzky-Golay spectral smoothing filter for hyperspectral cubes."""

    INPUT       = 'INPUT'
    WINDOW_LEN  = 'WINDOW_LEN'
    POLY_ORDER  = 'POLY_ORDER'
    OUTPUT      = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT,
            'Hyperspectral cube'))
        self.addParameter(QgsProcessingParameterNumber(
            self.WINDOW_LEN,
            'Window length  (number of bands, must be odd)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=7, minValue=3, maxValue=51))
        self.addParameter(QgsProcessingParameterNumber(
            self.POLY_ORDER,
            'Polynomial order  (must be < window length)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=2, minValue=1, maxValue=10))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT,
            'Savitzky-Golay smoothed output cube'))

    def processAlgorithm(self, parameters, context, feedback):
        try:
            from scipy.signal import savgol_filter
        except ImportError:
            raise QgsProcessingException(
                'scipy is required for Savitzky-Golay filtering but is not installed. '
                'Install it via: OSGeo4W Shell → pip install scipy  '
                '(or pip3 install scipy on Linux/macOS)')

        cube      = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        win_len   = self.parameterAsInt(parameters, self.WINDOW_LEN, context)
        poly_ord  = self.parameterAsInt(parameters, self.POLY_ORDER, context)
        out_path  = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if cube is None:
            raise QgsProcessingException('Invalid input layer')

        # Validate parameters
        if win_len % 2 == 0:
            win_len += 1
            feedback.pushWarning(
                f'Window length must be odd — adjusted to {win_len}.')
        if poly_ord >= win_len:
            raise QgsProcessingException(
                f'Polynomial order ({poly_ord}) must be less than window length ({win_len}).')

        ds = gdal.Open(cube.source())
        if ds is None:
            raise QgsProcessingException(f'Cannot open raster: {cube.source()}')

        n_bands = ds.RasterCount
        n_rows  = ds.RasterYSize
        n_cols  = ds.RasterXSize
        nodata  = ds.GetRasterBand(1).GetNoDataValue()
        gt      = ds.GetGeoTransform()
        proj    = ds.GetProjection()

        raster_path = cube.source()
        wavelengths = get_wavelengths_from_dataset(ds, n_bands, raster_path, feedback)
        if wavelengths is None:
            raise QgsProcessingException(
                'No wavelength metadata found. Input must have wavelength information.')

        if n_bands < win_len:
            raise QgsProcessingException(
                f'Cube has only {n_bands} bands but window length is {win_len}. '
                f'Reduce window length to at most {n_bands} (odd).')

        feedback.pushInfo(f'Cube: {n_bands} bands, {n_rows}×{n_cols} pixels')
        feedback.pushInfo(f'Savitzky-Golay: window={win_len} bands, poly order={poly_ord}')
        feedback.pushInfo(
            f'Wavelength range: {wavelengths[0]:.1f}–{wavelengths[-1]:.1f} nm')
        feedback.pushInfo('')
        feedback.pushInfo('Loading cube into memory …')
        feedback.setProgress(5)

        # Load full cube: (n_bands, n_rows, n_cols)
        cube_data = np.full((n_bands, n_rows, n_cols), np.nan, dtype=np.float32)
        for b in range(n_bands):
            if feedback.isCanceled():
                return {}
            arr = ds.GetRasterBand(b + 1).ReadAsArray().astype(np.float32)
            if nodata is not None:
                arr[arr == nodata] = np.nan
            cube_data[b] = arr
            if b % max(1, n_bands // 10) == 0:
                feedback.setProgress(5 + int(b * 30 / n_bands))

        # Reshape to (n_pix, n_bands) for spectral processing
        feedback.setProgress(35)
        feedback.pushInfo('Applying Savitzky-Golay filter along spectral axis …')

        n_pix   = n_rows * n_cols
        spectra = cube_data.reshape(n_bands, n_pix).T   # (n_pix, n_bands)

        # Build NaN mask: pixels that have any valid band
        has_valid = ~np.all(np.isnan(spectra), axis=1)   # (n_pix,)

        # For NaN handling: interpolate NaN values within each spectrum before
        # filtering, then restore NaN mask afterwards.
        # This prevents the filter from smearing NaNs into adjacent bands.
        smoothed = spectra.copy()

        chunk = 20000
        for start in range(0, n_pix, chunk):
            if feedback.isCanceled():
                return {}
            end   = min(start + chunk, n_pix)
            block = spectra[start:end]   # (chunk, n_bands)
            valid = has_valid[start:end]

            if not np.any(valid):
                continue

            block_v = block[valid].copy()   # (n_valid, n_bands)

            # Interpolate per-pixel NaNs so savgol_filter doesn't propagate them
            x = np.arange(n_bands)
            for j in range(block_v.shape[0]):
                row  = block_v[j]
                nans = np.isnan(row)
                if nans.any():
                    good = ~nans
                    if good.sum() < poly_ord + 1:
                        block_v[j, :] = np.nan
                        continue
                    block_v[j] = np.interp(x, x[good], row[good])

            # Apply SG filter along axis=1 (spectral dimension)
            sg = savgol_filter(block_v, window_length=win_len,
                               polyorder=poly_ord, axis=1)

            # Restore original NaN positions
            nan_mask_v = np.isnan(spectra[start:end][valid])
            sg[nan_mask_v] = np.nan

            smoothed[start:end][valid] = sg.astype(np.float32)

            pct = 35 + int((end / n_pix) * 55)
            feedback.setProgress(pct)

        # ── Write output ──────────────────────────────────────────────────────
        feedback.setProgress(90)
        feedback.pushInfo('Writing smoothed cube …')

        smoothed_cube = smoothed.T.reshape(n_bands, n_rows, n_cols)

        driver = gdal.GetDriverByName('GTiff')
        out_ds = driver.Create(
            out_path, n_cols, n_rows, n_bands, gdal.GDT_Float32,
            options=['COMPRESS=LZW', 'TILED=YES', 'BIGTIFF=IF_SAFER'])
        out_ds.SetGeoTransform(gt)
        out_ds.SetProjection(proj)

        # Copy all source metadata (including wavelength info)
        out_ds.SetMetadata(ds.GetMetadata())
        for domain in ds.GetMetadataDomainList() or []:
            if domain:
                out_ds.SetMetadata(ds.GetMetadata(domain), domain)

        for b in range(n_bands):
            if feedback.isCanceled():
                break
            src_band = ds.GetRasterBand(b + 1)
            out_band = out_ds.GetRasterBand(b + 1)
            out_band.WriteArray(smoothed_cube[b])
            out_band.SetNoDataValue(float('nan'))
            out_band.SetDescription(src_band.GetDescription())

        out_ds.SetMetadataItem('savgol_window_len',  str(win_len))
        out_ds.SetMetadataItem('savgol_poly_order',  str(poly_ord))
        out_ds.SetMetadataItem('savgol_reference',
            'GSWA Report 261 §9.1 recommendation (Laukamp et al. 2025)')

        out_ds.FlushCache()
        del ds, out_ds

        feedback.pushInfo('')
        feedback.pushInfo('─' * 60)
        feedback.pushInfo('Savitzky-Golay spectral smoothing complete.')
        feedback.pushInfo(f'  Window length:    {win_len} bands')
        feedback.pushInfo(f'  Polynomial order: {poly_ord}')
        feedback.pushInfo(f'  Bands processed:  {n_bands}')
        feedback.pushInfo('')
        feedback.pushInfo('Next steps:')
        feedback.pushInfo('  • Run CTIC (if not already done) on this smoothed cube')
        feedback.pushInfo('  • Run Feature Extraction or GSWA Mineral Map Index tools')
        feedback.pushInfo('─' * 60)
        feedback.setProgress(100)

        return {self.OUTPUT: out_path}

    def name(self):        return 'savgol_filter'
    def displayName(self): return 'Savitzky-Golay Spectral Filter'
    def group(self):       return '6 - Spectral Processing Tools'
    def groupId(self):     return 'five_spectral_processing'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Savitzky-Golay Spectral Smoothing Filter</b>

        <p>Smooths each pixel's spectrum using a Savitzky-Golay filter applied
        along the spectral (band) axis.  This reduces high-frequency
        band-to-band noise while preserving the shape of broad mineral
        absorption features.</p>

        <p><b>When to use:</b> Before Feature Extraction or GSWA Mineral Map
        Index tools on spaceborne imagery with significant spectral noise,
        particularly PRISMA in the 700–1000 nm VNIR and 2300–2450 nm SWIR
        ranges.  Also useful for EnMAP and EMIT when processing noisy
        wavelength regions.</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Effect</th>
          </tr>
          <tr><td>Window length 5–7</td>
              <td>Light smoothing — preserves narrow features</td></tr>
          <tr><td>Window length 9–15</td>
              <td>Moderate smoothing — good for SWIR noise</td></tr>
          <tr><td>Window length 17–25</td>
              <td>Strong smoothing — use only for very noisy VNIR</td></tr>
          <tr><td>Poly order 2 (default)</td>
              <td>Quadratic — suitable for most mineral absorption shapes</td></tr>
          <tr><td>Poly order 3–4</td>
              <td>Preserves asymmetric features (e.g. carbonate doublets)</td></tr>
        </table>

        <p><b>Recommended settings for common sensors:</b></p>
        <ul>
          <li><b>PRISMA VNIR (700–1000 nm):</b> window=11, poly=2</li>
          <li><b>PRISMA SWIR (2300–2450 nm):</b> window=9, poly=2</li>
          <li><b>PRISMA general (full cube):</b> window=7, poly=2</li>
          <li><b>EnMAP / EMIT:</b> window=5, poly=2 (already higher SNR)</li>
        </ul>

        <p><b>Note on NaN handling:</b> Within each pixel spectrum, NaN values
        (nodata or bad bands) are temporarily interpolated before filtering,
        then restored afterwards.  The filter therefore does not smear NaN
        values into adjacent bands.</p>

        <p><b>Note on BBL:</b> The Savitzky-Golay filter is applied across all
        bands regardless of the Bad Band List — this is intentional, as the
        polynomial fitting naturally bridges noisy single bands.  Bad bands
        will be smoothed towards their neighbours rather than excluded.
        If you want to exclude bad bands from the output entirely, apply
        a spectral subset afterwards.</p>

        <p><i>Background: Laukamp, C., Miles, A.J. et al. (2025) GSWA Report 261,
        §9.1 (Recommendations).  Savitzky, A. and Golay, M.J.E. (1964).
        Smoothing and Differentiation of Data by Simplified Least Squares
        Procedures.  Analytical Chemistry, 36(8), 1627–1639.</i></p>
        """

    def createInstance(self): return SavgolFilterAlgorithm()
