"""
GSWA Table 3 — Band Ratio Basic Hyperspectral Products

Implements the band ratio-based basic hyperspectral products from
Laukamp et al. (2025) GSWA Report 261, Table 3.

Products computed (all using 3-band ratios with nearest-wavelength band selection):
  2160D  — (R2143 + R2206) / R2167   relative intensity of 2160 nm feature
            Target: kaolinite, pyrophyllite, alunite
  2200D  — (R2143 + R2229) / R2206   relative intensity of 2200 nm feature
            Target: white mica, kaolinite, Al-smectite, tourmaline
  2250D  — (R2229 + R2268) / R2252   relative intensity of 2250 nm feature
            Target: chlorite, dark mica, epidote, jarosite, tourmaline
  2250D_2200D — 2250D / 2200D        relative abundance of Fe/Mg-OH vs Al-OH
  MineralGroupsRGB — R=2200D, G=2250D, B=2160D  (false-colour composite)

Band ratio methods are simpler and faster than polynomial fitting, and can
be reproduced in any GIS package with basic raster algebra.  They are
recommended for:
  - Quick reconnaissance on new datasets
  - Training and education
  - Situations where scipy/polynomial fitting is unavailable
  - Cross-validation of polynomial fit results

The polynomial fit method (FE tools, GSWA index tools) is preferred for
quantitative work, particularly in noisy wavelength regions.

Reference:
    Laukamp, C., Miles, A.J., Lampinen, H.M. et al. (2025).
    Spaceborne Mineral Maps for Critical Metals Exploration in the
    Gascoyne and Pilbara.  Geological Survey of Western Australia,
    Report 261.  Table 3.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with wavelength metadata (SWIR 2100–2300 nm).<br/>
        <b>Tip:</b> Run CTIC correction before this tool for spaceborne imagery (PRISMA, EnMAP, EMIT).
        </p>
"""

# Table 3 wavelength targets (nm) for the 3-band ratios
# Format: (shoulder1_nm, feature_nm, shoulder2_nm)
_BAND_TARGETS = {
    '2160D': (2143.0, 2167.0, 2206.0),
    '2200D': (2143.0, 2206.0, 2229.0),
    '2250D': (2229.0, 2252.0, 2268.0),
}

# GSWA Table 3 recommended stretch values
_STRETCHES = {
    '2160D':        ('2.0',  '2.15'),
    '2200D':        ('2.05', '2.35'),
    '2250D':        ('2.05', '2.15'),
    '2250D_2200D':  ('0.86', '1.05'),
}

_MINERAL_TARGETS = {
    '2160D':       'Kaolinite, pyrophyllite, alunite',
    '2200D':       'White mica, kaolinite, Al-smectite, tourmaline',
    '2250D':       'Chlorite, dark mica, epidote, jarosite, tourmaline',
    '2250D_2200D': 'Relative Fe/Mg-OH vs Al-OH abundance',
    'RGB':         'All Al-OH and Fe/Mg-OH minerals (R=2200D, G=2250D, B=2160D)',
}


def _nearest_band(wavelengths, target_nm):
    """Return the index of the band nearest to target_nm."""
    return int(np.argmin(np.abs(wavelengths - target_nm)))


def _read_band_as_float(ds, band_idx, nodata):
    """Read one band (0-based index) as float32, replacing nodata with NaN."""
    arr = ds.GetRasterBand(band_idx + 1).ReadAsArray().astype(np.float32)
    if nodata is not None:
        arr[arr == nodata] = np.nan
    return arr


def _band_ratio_3(r_s1, r_feat, r_s2):
    """Compute (r_s1 + r_s2) / (2 * r_feat) safely."""
    with np.errstate(invalid='ignore', divide='ignore'):
        denom = 2.0 * r_feat
        return np.where(denom > 0, (r_s1 + r_s2) / denom, np.nan)


def _write_band(ds, arr, band_num, description, nodata=float('nan')):
    b = ds.GetRasterBand(band_num)
    b.WriteArray(arr)
    b.SetNoDataValue(nodata)
    b.SetDescription(description)


class GswaBandRatioAlgorithm(QgsProcessingAlgorithm):
    """GSWA Table 3 — Band Ratio Basic Hyperspectral Products."""

    INPUT        = 'INPUT'
    COMPUTE_2160 = 'COMPUTE_2160'
    COMPUTE_2200 = 'COMPUTE_2200'
    COMPUTE_2250 = 'COMPUTE_2250'
    COMPUTE_RATIO= 'COMPUTE_RATIO'
    COMPUTE_RGB  = 'COMPUTE_RGB'
    OUT_2160     = 'OUT_2160'
    OUT_2200     = 'OUT_2200'
    OUT_2250     = 'OUT_2250'
    OUT_RATIO    = 'OUT_RATIO'
    OUT_RGB      = 'OUT_RGB'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))

        self.addParameter(QgsProcessingParameterBoolean(
            self.COMPUTE_2160, 'Compute 2160D  (kaolinite/pyrophyllite)',
            defaultValue=True))
        self.addParameter(QgsProcessingParameterBoolean(
            self.COMPUTE_2200, 'Compute 2200D  (white mica/kaolinite/Al-smectite)',
            defaultValue=True))
        self.addParameter(QgsProcessingParameterBoolean(
            self.COMPUTE_2250, 'Compute 2250D  (chlorite/dark mica/epidote)',
            defaultValue=True))
        self.addParameter(QgsProcessingParameterBoolean(
            self.COMPUTE_RATIO, 'Compute 2250D/2200D ratio  (Fe/Mg-OH vs Al-OH)',
            defaultValue=True))
        self.addParameter(QgsProcessingParameterBoolean(
            self.COMPUTE_RGB, 'Compute Mineral Groups False Colour RGB  (R=2200D G=2250D B=2160D)',
            defaultValue=True))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUT_2160, '2160D output', optional=True))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUT_2200, '2200D output', optional=True))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUT_2250, '2250D output', optional=True))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUT_RATIO, '2250D/2200D ratio output', optional=True))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUT_RGB, 'Mineral Groups RGB output  (3-band)', optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        cube       = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        do_2160    = self.parameterAsBool(parameters, self.COMPUTE_2160, context)
        do_2200    = self.parameterAsBool(parameters, self.COMPUTE_2200, context)
        do_2250    = self.parameterAsBool(parameters, self.COMPUTE_2250, context)
        do_ratio   = self.parameterAsBool(parameters, self.COMPUTE_RATIO, context)
        do_rgb     = self.parameterAsBool(parameters, self.COMPUTE_RGB, context)

        if cube is None:
            raise QgsProcessingException('Invalid input layer')

        ds = gdal.Open(cube.source())
        if ds is None:
            raise QgsProcessingException(f'Cannot open raster: {cube.source()}')

        n_bands = ds.RasterCount
        n_rows  = ds.RasterYSize
        n_cols  = ds.RasterXSize
        nodata  = ds.GetRasterBand(1).GetNoDataValue()
        gt      = ds.GetGeoTransform()
        proj    = ds.GetProjection()

        raster_path = cube.source()
        wavelengths = get_wavelengths_from_dataset(ds, n_bands, raster_path, feedback)
        if wavelengths is None:
            raise QgsProcessingException(
                'No wavelength metadata found. Input must have wavelength information.')

        # Check SWIR coverage
        if wavelengths[-1] < 2200:
            raise QgsProcessingException(
                f'Cube only extends to {wavelengths[-1]:.0f} nm — '
                'SWIR coverage to at least 2270 nm is required for Table 3 products.')

        feedback.pushInfo(f'Cube: {n_bands} bands, {n_rows}×{n_cols}, '
                          f'{wavelengths[0]:.0f}–{wavelengths[-1]:.0f} nm')

        # ── Resolve nearest bands for all wavelength targets ──────────────
        targets_needed = set()
        for product, (s1, feat, s2) in _BAND_TARGETS.items():
            targets_needed.update([s1, feat, s2])
        targets_needed.add(2229.0)   # shared between 2200D and 2250D

        band_map = {}   # target_nm → (band_idx, actual_nm)
        for t in sorted(targets_needed):
            idx = _nearest_band(wavelengths, t)
            band_map[t] = (idx, float(wavelengths[idx]))
            feedback.pushInfo(
                f'  Target {t:.0f} nm → band {idx+1} at {wavelengths[idx]:.1f} nm')

        # ── Load only the required bands ──────────────────────────────────
        feedback.setProgress(10)
        feedback.pushInfo('Loading required bands …')
        loaded = {}
        unique_bands = sorted(set(idx for idx, _ in band_map.values()))
        for b_idx in unique_bands:
            loaded[b_idx] = _read_band_as_float(ds, b_idx, nodata)

        def get_arr(target_nm):
            idx, _ = band_map[target_nm]
            return loaded[idx]

        results = {}

        # ── 2160D ─────────────────────────────────────────────────────────
        feedback.setProgress(20)
        if do_2160 or do_rgb:
            feedback.pushInfo('Computing 2160D …')
            s1, feat, s2 = _BAND_TARGETS['2160D']
            results['2160D'] = _band_ratio_3(get_arr(s1), get_arr(feat), get_arr(s2))

        # ── 2200D ─────────────────────────────────────────────────────────
        feedback.setProgress(35)
        if do_2200 or do_ratio or do_rgb:
            feedback.pushInfo('Computing 2200D …')
            s1, feat, s2 = _BAND_TARGETS['2200D']
            results['2200D'] = _band_ratio_3(get_arr(s1), get_arr(feat), get_arr(s2))

        # ── 2250D ─────────────────────────────────────────────────────────
        feedback.setProgress(50)
        if do_2250 or do_ratio or do_rgb:
            feedback.pushInfo('Computing 2250D …')
            s1, feat, s2 = _BAND_TARGETS['2250D']
            results['2250D'] = _band_ratio_3(get_arr(s1), get_arr(feat), get_arr(s2))

        # ── 2250D/2200D ratio ─────────────────────────────────────────────
        feedback.setProgress(65)
        if do_ratio:
            feedback.pushInfo('Computing 2250D/2200D ratio …')
            with np.errstate(invalid='ignore', divide='ignore'):
                results['2250D_2200D'] = np.where(
                    results['2200D'] > 0,
                    results['2250D'] / results['2200D'],
                    np.nan).astype(np.float32)

        # ── Write outputs ─────────────────────────────────────────────────
        feedback.setProgress(75)
        driver = gdal.GetDriverByName('GTiff')

        def write_single(param_key, product_key):
            out_path = self.parameterAsOutputLayer(parameters, param_key, context)
            if not out_path:
                return
            arr = results.get(product_key)
            if arr is None:
                return
            out_ds = driver.Create(out_path, n_cols, n_rows, 1, gdal.GDT_Float32,
                                   options=['COMPRESS=LZW', 'TILED=YES'])
            out_ds.SetGeoTransform(gt)
            out_ds.SetProjection(proj)
            lo, hi = _stretches.get(product_key, ('?', '?'))
            _write_band(out_ds, arr, 1,
                        f'GSWA Table 3 {product_key} band ratio '
                        f'(stretch {lo}–{hi})')
            out_ds.SetMetadataItem('GSWA_product',   product_key)
            out_ds.SetMetadataItem('GSWA_method',    'band ratio (Table 3)')
            out_ds.SetMetadataItem('GSWA_stretch',   f'{lo} – {hi}')
            out_ds.SetMetadataItem('GSWA_minerals',  _MINERAL_TARGETS.get(product_key, ''))
            out_ds.SetMetadataItem('GSWA_reference', 'GSWA Report 261 Table 3 (Laukamp et al. 2025)')
            out_ds.FlushCache()
            del out_ds
            feedback.pushInfo(
                f'  {product_key}: written  (GSWA stretch {lo}–{hi})')

        _stretches = _STRETCHES  # local alias

        write_single(self.OUT_2160,  '2160D')
        write_single(self.OUT_2200,  '2200D')
        write_single(self.OUT_2250,  '2250D')
        write_single(self.OUT_RATIO, '2250D_2200D')

        # ── Mineral Groups False Colour RGB ───────────────────────────────
        feedback.setProgress(85)
        if do_rgb:
            feedback.pushInfo('Writing Mineral Groups False Colour RGB …')
            out_rgb = self.parameterAsOutputLayer(parameters, self.OUT_RGB, context)
            if out_rgb:
                r = results['2200D']
                g = results['2250D']
                b = results['2160D']

                out_ds = driver.Create(out_rgb, n_cols, n_rows, 3, gdal.GDT_Float32,
                                       options=['COMPRESS=LZW', 'TILED=YES'])
                out_ds.SetGeoTransform(gt)
                out_ds.SetProjection(proj)
                _write_band(out_ds, r, 1, '2200D (R) — white mica/kaolinite/Al-smectite')
                _write_band(out_ds, g, 2, '2250D (G) — chlorite/dark mica/epidote')
                _write_band(out_ds, b, 3, '2160D (B) — kaolinite/pyrophyllite/alunite')
                out_ds.SetMetadataItem('GSWA_product',   'MineralGroupsRGB')
                out_ds.SetMetadataItem('GSWA_channels',  'R=2200D G=2250D B=2160D')
                out_ds.SetMetadataItem('GSWA_method',    'band ratio (Table 3)')
                out_ds.SetMetadataItem('GSWA_reference', 'GSWA Report 261 Table 3 (Laukamp et al. 2025)')
                out_ds.FlushCache()
                del out_ds
                feedback.pushInfo(
                    '  MineralGroupsRGB: written  '
                    '(stretch each channel 2.05–2.35 for 2200D/2250D, 2.0–2.15 for 2160D)')

        del ds

        # ── GSWA Table 3 stretch summary ──────────────────────────────────
        feedback.pushInfo('')
        feedback.pushInfo('─' * 60)
        feedback.pushInfo('GSWA Report 261 Table 3 — recommended stretch (rainbow):')
        feedback.pushInfo('  2160D       min=2.0,  max=2.15   kaolinite/pyrophyllite/alunite')
        feedback.pushInfo('  2200D       min=2.05, max=2.35   white mica/kaolinite/Al-smectite')
        feedback.pushInfo('  2250D       min=2.05, max=2.15   chlorite/dark mica/epidote')
        feedback.pushInfo('  2250D/2200D min=0.86, max=1.05   Fe/Mg-OH vs Al-OH ratio')
        feedback.pushInfo('  RGB         stretch each channel independently (see above)')
        feedback.pushInfo('')
        feedback.pushInfo('Note: band ratio values > 2.0 indicate absorption (1.0 = no feature).')
        feedback.pushInfo('For quantitative work, use polynomial-fit FE tools instead.')
        feedback.pushInfo('─' * 60)
        feedback.setProgress(100)

        return {
            self.OUT_2160:  self.parameterAsOutputLayer(parameters, self.OUT_2160, context) or '',
            self.OUT_2200:  self.parameterAsOutputLayer(parameters, self.OUT_2200, context) or '',
            self.OUT_2250:  self.parameterAsOutputLayer(parameters, self.OUT_2250, context) or '',
            self.OUT_RATIO: self.parameterAsOutputLayer(parameters, self.OUT_RATIO, context) or '',
            self.OUT_RGB:   self.parameterAsOutputLayer(parameters, self.OUT_RGB, context) or '',
        }

    def name(self):        return 'gswa_band_ratio'
    def displayName(self): return 'GSWA Table 3  (Band Ratio Basic Products)'
    def group(self):       return '6 - Spectral Processing Tools'
    def groupId(self):     return 'five_spectral_processing'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>GSWA Table 3 — Band Ratio Basic Hyperspectral Products</b>

        <p>Computes the five band ratio products from GSWA Report 261, Table 3,
        using nearest-wavelength band selection.  All products can be computed
        in a single pass from the same cube.</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Product</th><th>Algorithm</th>
            <th>GSWA stretch</th><th>Target minerals</th>
          </tr>
          <tr><td><b>2160D</b></td>
              <td>(R2143+R2206)/R2167</td>
              <td>2.0 – 2.15</td>
              <td>Kaolinite, pyrophyllite, alunite</td></tr>
          <tr><td><b>2200D</b></td>
              <td>(R2143+R2229)/R2206</td>
              <td>2.05 – 2.35</td>
              <td>White mica, kaolinite, Al-smectite, tourmaline</td></tr>
          <tr><td><b>2250D</b></td>
              <td>(R2229+R2268)/R2252</td>
              <td>2.05 – 2.15</td>
              <td>Chlorite, dark mica, epidote, jarosite</td></tr>
          <tr><td><b>2250D/2200D</b></td>
              <td>2250D ÷ 2200D</td>
              <td>0.86 – 1.05</td>
              <td>Fe/Mg-OH relative to Al-OH abundance</td></tr>
          <tr><td><b>Mineral Groups RGB</b></td>
              <td>R=2200D G=2250D B=2160D</td>
              <td>Per channel</td>
              <td>All SWIR-active sheetsilicates combined</td></tr>
        </table>

        <p><b>Band ratio values:</b> values &gt; 1.0 indicate absorption
        relative to the shoulders (1.0 = flat spectrum, no feature;
        2.0 = strong feature).  The GSWA stretch minima of ~2.0 reflect this —
        the stretch window is centred on the feature intensity range.</p>

        <p><b>When to use over FE polynomial tools:</b></p>
        <ul>
          <li>Quick reconnaissance — faster computation, no polynomial fitting</li>
          <li>Cross-validation of polynomial fit FE results</li>
          <li>Training and education (can be reproduced in any GIS)</li>
          <li>When the full SWIR range has adequate SNR (e.g. EnMAP, EMIT)</li>
        </ul>

        <p><b>Limitation vs polynomial fit (GSWA Table 4/5 FE tools):</b>
        Band ratios are sensitive to noisy individual bands — a single noisy
        band at a shoulder or feature wavelength will bias all pixels equally.
        The polynomial fit method bridges noisy bands by fitting across a
        wider window.</p>

        <p><i>Reference: Laukamp, C., Miles, A.J. et al. (2025) GSWA Report 261,
        Table 3 (§3.4.2, Figure 9).</i></p>
        """

    def createInstance(self): return GswaBandRatioAlgorithm()
