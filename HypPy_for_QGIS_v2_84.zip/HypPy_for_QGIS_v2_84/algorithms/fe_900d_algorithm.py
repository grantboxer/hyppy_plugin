"""
Feature Extraction — 900D  (Iron Oxide Depth, Polynomial Fit)

GSWA Report 261 Table 4: 2nd order polynomial fit of the reflectance
minimum between 776 and 1050 nm.  Targets the iron charge-transfer
absorption (CFA) centred at ~890 nm in hematite and ~940 nm in goethite.

Reference:
    Laukamp, C., Miles, A.J., Lampinen, H.M. et al. (2025).
    Spaceborne Mineral Maps for Critical Metals Exploration in the
    Gascoyne and Pilbara.  Geological Survey of Western Australia,
    Report 261.  Table 4.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterNumber,
    QgsProcessingException,
)

from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with wavelength metadata.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""


class Fe900DAlgorithm(QgsProcessingAlgorithm):
    """Feature Extraction — 900D (Iron Oxide Depth, GSWA Table 4)."""

    INPUT      = 'INPUT'
    OUTPUT     = 'OUTPUT'

    # GSWA Report 261 Table 4 parameters
    POLY_ORDER  = 2
    RANGE_START = 776.0
    RANGE_END   = 1050.0

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT,
            'Output 900D depth raster  (776–1050 nm)'))

    def processAlgorithm(self, parameters, context, feedback):
        cube     = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        out_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if cube is None:
            raise QgsProcessingException('Invalid input layer')

        ds = gdal.Open(cube.source())
        if ds is None:
            raise QgsProcessingException(f'Cannot open raster: {cube.source()}')

        n_bands = ds.RasterCount
        n_rows  = ds.RasterYSize
        n_cols  = ds.RasterXSize
        nodata  = ds.GetRasterBand(1).GetNoDataValue()

        raster_path = cube.source()
        wavelengths = get_wavelengths_from_dataset(ds, n_bands, raster_path, feedback)
        if wavelengths is None:
            raise QgsProcessingException(
                'No wavelength metadata found.  The input cube must have '
                'wavelength information in its ENVI header or GDAL metadata.')

        bbl = get_bbl_from_dataset(ds, n_bands, raster_path, feedback)

        # Select bands within the 776–1050 nm window
        sel_idx = []
        for i, wl in enumerate(wavelengths):
            if self.RANGE_START <= wl <= self.RANGE_END:
                if bbl is None or bbl[i] == 1:
                    sel_idx.append(i)

        if len(sel_idx) < (self.POLY_ORDER + 1):
            raise QgsProcessingException(
                f'Too few valid bands in {self.RANGE_START}–{self.RANGE_END} nm '
                f'(need at least {self.POLY_ORDER + 1}, found {len(sel_idx)}).  '
                'Check wavelength metadata and BBL.')

        feedback.pushInfo(
            f'900D: {len(sel_idx)} bands selected in '
            f'{self.RANGE_START}–{self.RANGE_END} nm '
            f'({wavelengths[sel_idx[0]]:.1f}–{wavelengths[sel_idx[-1]]:.1f} nm)')
        feedback.pushInfo(f'Polynomial order: {self.POLY_ORDER}')

        sel_wav = wavelengths[sel_idx]

        # Load selected bands
        feedback.setProgress(5)
        feedback.pushInfo('Loading VNIR bands …')
        cube_data = np.full((len(sel_idx), n_rows, n_cols), np.nan, dtype=np.float32)
        for k, band_idx in enumerate(sel_idx):
            if feedback.isCanceled():
                return {}
            arr = ds.GetRasterBand(band_idx + 1).ReadAsArray().astype(np.float32)
            if nodata is not None:
                arr[arr == nodata] = np.nan
            cube_data[k] = arr
            if k % max(1, len(sel_idx) // 20) == 0:
                feedback.setProgress(5 + int(k * 35 / len(sel_idx)))

        # Continuum removal: fit polynomial to each pixel's spectral segment,
        # then compute depth = (fitted_continuum - reflectance) / fitted_continuum
        # at the wavelength of minimum of the fitted curve.
        feedback.setProgress(40)
        feedback.pushInfo('Computing polynomial fit depth …')

        depth_out = np.full((n_rows, n_cols), np.nan, dtype=np.float32)

        # Normalise wavelengths to [0,1] for numerical stability
        wav_norm = (sel_wav - sel_wav[0]) / (sel_wav[-1] - sel_wav[0])

        # Reshape to (pixels, bands)
        n_pix = n_rows * n_cols
        spectra = cube_data.reshape(len(sel_idx), n_pix).T   # (n_pix, n_bands)

        # Build Vandermonde matrix once
        V = np.vander(wav_norm, self.POLY_ORDER + 1, increasing=True)  # (n_bands, order+1)

        # Chunk processing for memory efficiency
        chunk = 50000
        for start in range(0, n_pix, chunk):
            if feedback.isCanceled():
                return {}
            end  = min(start + chunk, n_pix)
            spec = spectra[start:end]                          # (chunk, n_bands)

            # Mask pixels that are all-NaN
            valid = ~np.all(np.isnan(spec), axis=1)
            if not np.any(valid):
                continue

            spec_v = spec[valid]                               # (n_valid, n_bands)
            n_b    = len(sel_idx)

            # Replace per-pixel NaNs with linear interpolation so lstsq works
            for j in range(spec_v.shape[0]):
                row = spec_v[j]
                nans = np.isnan(row)
                if nans.any():
                    x     = np.arange(n_b)
                    good  = ~nans
                    if good.sum() < self.POLY_ORDER + 1:
                        spec_v[j] = np.nan
                        continue
                    spec_v[j] = np.interp(x, x[good], row[good])

            # Least-squares polynomial fit: V @ coeffs ≈ spec  (per pixel)
            # coeffs shape: (n_valid, order+1)
            coeffs, _, _, _ = np.linalg.lstsq(V, spec_v.T, rcond=None)  # (order+1, n_valid)
            coeffs = coeffs.T                                              # (n_valid, order+1)

            # Evaluate fitted continuum (endpoints used for linear continuum)
            # Following Laukamp et al. approach: continuum = line between endpoints of fitted curve
            fit_vals = (V @ coeffs.T).T                        # (n_valid, n_bands)

            # Continuum = straight line from fit[0] to fit[-1]
            continuum = (
                fit_vals[:, 0:1]
                + (fit_vals[:, -1:] - fit_vals[:, 0:1])
                * wav_norm[np.newaxis, :]
            )                                                   # (n_valid, n_bands)

            with np.errstate(invalid='ignore', divide='ignore'):
                removed = np.where(continuum > 0,
                                   (continuum - fit_vals) / continuum,
                                   np.nan)                      # (n_valid, n_bands)

            # Depth = maximum of continuum-removed spectrum in the window
            max_depth = np.nanmax(removed, axis=1)              # (n_valid,)

            result_pix = np.full(end - start, np.nan, dtype=np.float32)
            result_pix[valid] = max_depth.astype(np.float32)

            flat_idx = np.arange(start, end)
            rows_i   = flat_idx // n_cols
            cols_i   = flat_idx % n_cols
            depth_out[rows_i, cols_i] = result_pix

            pct = 40 + int((end / n_pix) * 55)
            feedback.setProgress(pct)

        # Write output — single band depth raster
        feedback.setProgress(95)
        feedback.pushInfo('Writing 900D depth raster …')

        driver = gdal.GetDriverByName('GTiff')
        out_ds = driver.Create(out_path, n_cols, n_rows, 1, gdal.GDT_Float32,
                               options=['COMPRESS=LZW', 'TILED=YES'])
        out_ds.SetGeoTransform(ds.GetGeoTransform())
        out_ds.SetProjection(ds.GetProjection())

        band = out_ds.GetRasterBand(1)
        band.WriteArray(depth_out)
        band.SetNoDataValue(float('nan'))
        band.SetDescription('900D iron oxide depth (776-1050 nm poly2)')

        wav_start = wavelengths[sel_idx[0]]
        wav_end   = wavelengths[sel_idx[-1]]
        out_ds.SetMetadataItem('900D_poly_order',  str(self.POLY_ORDER))
        out_ds.SetMetadataItem('900D_range_nm',    f'{wav_start:.1f}-{wav_end:.1f}')
        out_ds.SetMetadataItem('900D_reference',
                               'GSWA Report 261, Table 4 (Laukamp et al. 2025)')

        out_ds.FlushCache()
        del ds, out_ds

        # GSWA recommended stretch values for display guidance
        feedback.pushInfo('')
        feedback.pushInfo('─' * 60)
        feedback.pushInfo('GSWA Report 261 Table 4 — Recommended display stretch:')
        feedback.pushInfo('  Gascoyne / Pilbara:  min = 0.16,  max = 0.29')
        feedback.pushInfo('  Colour scheme: Rainbow (blue = low, red = high abundance)')
        feedback.pushInfo('  Targeted minerals: Iron oxides (hematite ~890 nm, goethite ~940 nm)')
        feedback.pushInfo('─' * 60)
        feedback.pushInfo('Feature Extraction 900D complete.')
        feedback.setProgress(100)

        return {self.OUTPUT: out_path}

    def name(self):        return 'fe_900d'
    def displayName(self): return 'FE-900D  (Iron Oxide Depth, GSWA Rpt261 Table 4)'
    def group(self):       return '7 - Feature Extraction'
    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 900D  (Iron Oxide Depth, Polynomial Fit)</b>

        <p>Computes the iron oxide charge-transfer absorption (CFA) depth
        centred at <b>~890–940 nm</b> using a <b>2nd order polynomial fit</b>
        of the reflectance minimum between <b>776 and 1050 nm</b>.</p>

        <p>The polynomial fit method is preferred over a simple band ratio in
        this wavelength range because PRISMA VNIR reflectance is strongly
        impacted by atmospheric effects and low SNR in the 800–1000 nm region.
        Fitting a polynomial across the full window allows the algorithm to
        model the broad CFA feature robustly despite noisy individual bands
        (as described in GSWA Report 261, section 3.4.1).</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>Polynomial order</td><td>2nd order</td></tr>
          <tr><td>Spectral range</td><td>776–1050 nm</td></tr>
          <tr><td>Feature name</td><td>900D (iron CFA depth)</td></tr>
          <tr style="background:#fff3e0">
            <td><b>GSWA recommended stretch (Gascoyne/Pilbara)</b></td>
            <td>min = 0.16, max = 0.29</td>
          </tr>
          <tr><td>Colour scheme</td><td>Rainbow (blue = low, red = high)</td></tr>
          <tr><td>Targeted minerals</td><td>Iron oxides (hematite, goethite)</td></tr>
        </table>

        <p><b>Iron oxide mineral associations:</b></p>
        <ul>
          <li><b>Hematite</b> — CFA centred at ~890 nm; strong, well-defined feature</li>
          <li><b>Goethite</b> — CFA centred at ~940 nm; broader, shifted to longer wavelengths</li>
          <li><b>Ferrihydrite</b> — broad CFA ~900–950 nm; indicates poorly crystalline iron oxides</li>
        </ul>

        <p><b>Output:</b> Single-band GeoTIFF with pixel values = 900D depth
        (0 = no feature, higher = stronger iron oxide absorption).
        Apply the GSWA recommended stretch in QGIS layer properties
        (min=0.16, max=0.29, rainbow colour ramp) for optimal display.</p>

        <p><b>Note:</b> The GSWA Table 4 polynomial fit depth (900D) successfully
        maps relative iron oxide abundance at regional scale.  However, the
        wavelength position (900W) cannot be reliably extracted from PRISMA imagery
        due to atmospheric effects, and the hematite/goethite ratio product is
        not available with this approach.  For scenes with higher VNIR SNR
        (e.g. EnMAP, EMIT), wavelength-position mapping may be feasible.</p>

        <p><i>Algorithm: GSWA Report 261, Table 4 (Laukamp, C., Miles, A.J.,
        Lampinen, H.M. et al., 2025, Geological Survey of Western Australia).
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe900DAlgorithm()
