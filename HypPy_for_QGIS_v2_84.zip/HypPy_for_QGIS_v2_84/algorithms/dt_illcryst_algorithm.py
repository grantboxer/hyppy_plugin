"""
DT Illcryst Decision Tree Classification Algorithm for QGIS Processing

Classifies pixels into illite crystallinity / smectite classes.

b1 (illite crystallinity = illx) is computed internally as the ratio:
  b1 = depth of deepest feature in 2100-2400 nm
     / depth of deepest feature in 1850-2100 nm

This requires two Wavelength of Minimum rasters as inputs:
  WoM 2100-2400: Band 1 = primary wavelength (b2), Band 2 = depth (b3, threshold)
  WoM 1850-2100: Band 2 = depth of deepest feature in that range

Decision tree (dt_illcryst.jpg):
  b3 <= 0.05                          -> aspectral
  NOT (2185 < b2 <= 2225)             -> NO-ALOH
  b1 <= 0.25                          -> smect3
  b1 <= 0.33                          -> smect2
  b1 <= 0.50                          -> smect1
  b1 <= 1.0                           -> smect-ill
  b1 <= 2.0                           -> ill-smect
  b1 <= 3.0                           -> hx-ill
  b1 <= 4.0                           -> musc1
  b1 >  4.0                           -> musc2

smect = smectite, ill = illite, hx = high crystallinity, musc = muscovite.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

import numpy as np
from osgeo import gdal
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

ILLCRYST_CLASSES = [
    (0,  'unclassified', 0,   0,   0  ),
    (1,  'aspectral',    0,   0,   0  ),
    (2,  'NO-ALOH',      128, 128, 128),  # grey
    (3,  'smect3',       200, 0,   0  ),  # dark red
    (4,  'smect2',       255, 80,  80 ),  # mid red
    (5,  'smect1',       255, 180, 180),  # pale red/pink
    (6,  'smect-ill',    200, 200, 255),  # pale blue-purple
    (7,  'ill-smect',    100, 100, 220),  # medium blue
    (8,  'hx-ill',       0,   0,   200),  # dark blue
    (9,  'musc1',        0,   220, 220),  # cyan
    (10, 'musc2',        0,   160, 160),  # dark cyan
]
NAME_TO_ID = {m[1]: m[0] for m in ILLCRYST_CLASSES}
ID_TO_NAME = {m[0]: m[1] for m in ILLCRYST_CLASSES}


class DtIllcrystAlgorithm(QgsProcessingAlgorithm):

    WOM_2100_2400 = 'WOM_2100_2400'
    WOM_1850_2100 = 'WOM_1850_2100'
    B3_THRESHOLD  = 'B3_THRESHOLD'
    OUTPUT_CLASS  = 'OUTPUT_CLASS'
    OUTPUT_RGB    = 'OUTPUT_RGB'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2100_2400,
            'WoM raster 2100-2400 nm (Band 1=wavelength b2, Band 2=depth b3)'))

        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_1850_2100,
            'WoM raster 1850-2100 nm (Band 2=depth used for illx ratio denominator)'))

        self.addParameter(QgsProcessingParameterNumber(
            self.B3_THRESHOLD,
            'Depth threshold — pixels with b3 (2100-2400 depth) <= this are aspectral',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.05, minValue=0.0, maxValue=1.0))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_CLASS, 'Output: Illcryst integer class raster'))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_RGB, 'Output: Illcryst RGB raster', optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        wom_a_layer = self.parameterAsRasterLayer(parameters, self.WOM_2100_2400, context)
        wom_b_layer = self.parameterAsRasterLayer(parameters, self.WOM_1850_2100, context)
        b3_thresh   = self.parameterAsDouble     (parameters, self.B3_THRESHOLD,  context)
        out_class   = self.parameterAsOutputLayer(parameters, self.OUTPUT_CLASS,   context)
        out_rgb     = self.parameterAsOutputLayer(parameters, self.OUTPUT_RGB,     context) \
                      if self.OUTPUT_RGB in parameters else None

        # ── Open WoM 2100-2400 ───────────────────────────────────────────────
        wom_a = gdal.Open(wom_a_layer.source(), gdal.GA_ReadOnly)
        if wom_a is None:
            raise QgsProcessingException('Cannot open WoM 2100-2400 raster')
        cols, rows = wom_a.RasterXSize, wom_a.RasterYSize
        if wom_a.RasterCount < 2:
            raise QgsProcessingException('WoM 2100-2400 raster needs >= 2 bands')

        feedback.pushInfo(f'WoM 2100-2400: {cols} x {rows}, {wom_a.RasterCount} bands')
        feedback.pushInfo('Reading WoM 2100-2400 Band 1 — primary wavelength (b2)...')
        b2 = wom_a.GetRasterBand(1).ReadAsArray().astype(np.float32)
        feedback.pushInfo('Reading WoM 2100-2400 Band 2 — depth (b3, threshold + numerator)...')
        depth_2100_2400 = wom_a.GetRasterBand(2).ReadAsArray().astype(np.float32)

        # ── Open WoM 1850-2100 ───────────────────────────────────────────────
        wom_b = gdal.Open(wom_b_layer.source(), gdal.GA_ReadOnly)
        if wom_b is None:
            raise QgsProcessingException('Cannot open WoM 1850-2100 raster')
        if wom_b.RasterXSize != cols or wom_b.RasterYSize != rows:
            raise QgsProcessingException(
                f'WoM 1850-2100 size ({wom_b.RasterXSize}x{wom_b.RasterYSize}) '
                f'does not match WoM 2100-2400 size ({cols}x{rows})')
        if wom_b.RasterCount < 2:
            raise QgsProcessingException('WoM 1850-2100 raster needs >= 2 bands')

        feedback.pushInfo(f'WoM 1850-2100: {wom_b.RasterXSize} x {wom_b.RasterYSize}, {wom_b.RasterCount} bands')
        feedback.pushInfo('Reading WoM 1850-2100 Band 2 — depth (denominator for illx)...')
        feedback.pushWarning(
            'AVIRIS-NG users: WoM-B (1850-2100 nm) is limited to ~1962-2101 nm after '
            'BBL masking of the atmospheric water zone. Band 2 depth reflects the '
            '2000 nm region, not the 1900 nm feature this ratio was calibrated for. '
            'The illx ratio (b1) will be inflated. DT class thresholds may need '
            'recalibration for AVIRIS-NG data — interpret results with caution.'
        )
        depth_1850_2100 = wom_b.GetRasterBand(2).ReadAsArray().astype(np.float32)
        wom_b = None
        feedback.setProgress(20)

        # ── Compute b1 = illx = depth(2100-2400) / depth(1850-2100) ─────────
        feedback.pushInfo('Computing illx ratio (b1 = depth_2100_2400 / depth_1850_2100)...')
        with np.errstate(invalid='ignore', divide='ignore'):
            b1 = np.where(depth_1850_2100 > 0,
                          depth_2100_2400 / depth_1850_2100,
                          np.nan).astype(np.float32)

        valid_b1 = b1[np.isfinite(b1)]
        if valid_b1.size > 0:
            feedback.pushInfo(
                f'b1 (illx ratio): min={float(np.min(valid_b1)):.4f}  '
                f'max={float(np.max(valid_b1)):.4f}  '
                f'mean={float(np.mean(valid_b1)):.4f}')

        # ── Apply decision tree ───────────────────────────────────────────────
        feedback.pushInfo(f'Depth threshold: b3 > {b3_thresh} = spectral pixel')
        feedback.pushInfo('Applying dt_illcryst decision tree...')
        feedback.setProgress(50)

        nodata   = ~np.isfinite(b1) | ~np.isfinite(b2) | ~np.isfinite(depth_2100_2400)
        b1s      = np.nan_to_num(b1,              nan=0.0)
        b2s      = np.nan_to_num(b2,              nan=0.0)
        b3s      = np.nan_to_num(depth_2100_2400, nan=0.0)

        class_data = np.zeros((rows, cols), dtype=np.uint8)
        spectral   = b3s > b3_thresh
        in_range   = spectral & (b2s > 2185) & (b2s <= 2225)

        class_data[~spectral]                                          = NAME_TO_ID['aspectral']
        class_data[spectral & ~in_range]                               = NAME_TO_ID['NO-ALOH']
        class_data[in_range & (b1s <= 0.25)]                          = NAME_TO_ID['smect3']
        class_data[in_range & (b1s > 0.25) & (b1s <= 0.33)]          = NAME_TO_ID['smect2']
        class_data[in_range & (b1s > 0.33) & (b1s <= 0.50)]          = NAME_TO_ID['smect1']
        class_data[in_range & (b1s > 0.50) & (b1s <= 1.0 )]          = NAME_TO_ID['smect-ill']
        class_data[in_range & (b1s > 1.0)  & (b1s <= 2.0 )]          = NAME_TO_ID['ill-smect']
        class_data[in_range & (b1s > 2.0)  & (b1s <= 3.0 )]          = NAME_TO_ID['hx-ill']
        class_data[in_range & (b1s > 3.0)  & (b1s <= 4.0 )]          = NAME_TO_ID['musc1']
        class_data[in_range & (b1s > 4.0)]                            = NAME_TO_ID['musc2']
        class_data[nodata | (b2s == 0)]                                = 0

        feedback.setProgress(70)

        # ── Classification summary ────────────────────────────────────────────
        feedback.pushInfo('')
        feedback.pushInfo('Classification summary:')
        unique, counts = np.unique(class_data, return_counts=True)
        total = class_data.size
        for uid, cnt in zip(unique, counts):
            pct = 100.0 * cnt / total
            feedback.pushInfo(
                f'  {ID_TO_NAME.get(int(uid),"?"):15s}  (id={uid:2d})  {cnt:8d} px  {pct:5.1f}%')

        driver = gdal.GetDriverByName('GTiff')

        # ── Class raster (primary — always written) ───────────────────────────
        feedback.pushInfo('Writing integer class raster...')
        ct = gdal.ColorTable()
        for mid, name, r, g, bv in ILLCRYST_CLASSES:
            ct.SetColorEntry(mid, (r, g, bv, 255))
        class_ds = driver.Create(out_class, cols, rows, 1, gdal.GDT_Byte,
                                 options=['COMPRESS=LZW', 'TILED=YES'])
        class_ds.SetGeoTransform(wom_a.GetGeoTransform())
        class_ds.SetProjection(wom_a.GetProjection())
        b = class_ds.GetRasterBand(1)
        b.SetNoDataValue(0)
        b.SetDescription('Illcryst Class')
        b.SetRasterColorTable(ct)
        b.SetRasterColorInterpretation(gdal.GCI_PaletteIndex)
        b.WriteArray(class_data)
        b.FlushCache()
        rat = gdal.RasterAttributeTable()
        rat.CreateColumn('Value', gdal.GFT_Integer, gdal.GFU_MinMax)
        rat.CreateColumn('Class', gdal.GFT_String,  gdal.GFU_Name)
        rat.CreateColumn('R',     gdal.GFT_Integer, gdal.GFU_Red)
        rat.CreateColumn('G',     gdal.GFT_Integer, gdal.GFU_Green)
        rat.CreateColumn('B',     gdal.GFT_Integer, gdal.GFU_Blue)
        for row_idx, (mid, name, r, g, bv) in enumerate(ILLCRYST_CLASSES):
            rat.SetValueAsInt   (row_idx, 0, mid)
            rat.SetValueAsString(row_idx, 1, name)
            rat.SetValueAsInt   (row_idx, 2, r)
            rat.SetValueAsInt   (row_idx, 3, g)
            rat.SetValueAsInt   (row_idx, 4, bv)
        b.SetDefaultRAT(rat)
        class_ds = None
        result = {self.OUTPUT_CLASS: out_class}
        feedback.setProgress(85)

        # ── RGB raster (optional) ─────────────────────────────────────────────
        if out_rgb:
            feedback.pushInfo('Writing RGB colour raster...')
            rgb_r = np.zeros((rows, cols), dtype=np.uint8)
            rgb_g = np.zeros((rows, cols), dtype=np.uint8)
            rgb_b = np.zeros((rows, cols), dtype=np.uint8)
            for mid, name, r, g, bv in ILLCRYST_CLASSES:
                mask = class_data == mid
                rgb_r[mask], rgb_g[mask], rgb_b[mask] = r, g, bv
            rgb_ds = driver.Create(out_rgb, cols, rows, 3, gdal.GDT_Byte,
                                   options=['COMPRESS=LZW', 'TILED=YES'])
            rgb_ds.SetGeoTransform(wom_a.GetGeoTransform())
            rgb_ds.SetProjection(wom_a.GetProjection())
            for idx, (arr, lbl) in enumerate(
                    [(rgb_r, 'Red'), (rgb_g, 'Green'), (rgb_b, 'Blue')], 1):
                band = rgb_ds.GetRasterBand(idx)
                band.WriteArray(arr)
                band.SetDescription(lbl)
                band.FlushCache()
            rgb_ds = None
            result[self.OUTPUT_RGB] = out_rgb

        wom_a = None
        feedback.setProgress(100)
        feedback.pushInfo('dt_illcryst classification complete.')
        return result

    def name(self):        return 'dt_illcryst'
    def displayName(self): return 'DT Illcryst Classification'
    def group(self):       return '4 - Decision Tree Classification'
    def groupId(self):     return '4_decision_tree'

    def shortHelpString(self):
        return """
        <b>DT Illcryst Classification</b>

        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube +
        WoM-B (1850–2100 nm) + WoM-C (2100–2400 nm).<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.<br/>Run <i>Workflow A</i> to generate required WoM rasters.
        </p>

        <p style="background-color:#fff3e0; padding:6px; border-left:4px solid #e65100;">
        <b>AVIRIS-NG note:</b> WoM-B for AVIRIS-NG data only covers
        <b>~1962–2101 nm</b> after BBL masking of the 1790–1960 nm atmospheric
        water zone. The Band 2 depth used as the <b>illx denominator</b> will
        reflect the shallower 2000 nm H₂O/carbonate feature rather than the 1900 nm
        feature these thresholds were calibrated for. The illx ratio will be
        <b>inflated</b> for AVIRIS-NG data — interpret mineral class boundaries
        with caution and consider recalibrating thresholds against known ground truth.
        </p>

        <p>Classifies pixels into illite crystallinity and smectite classes.
        The illite crystallinity value (illx, b1) is computed internally as
        the ratio of absorption feature depths:</p>

        <p style="margin-left:1em">
        <b>b1 = depth(2100-2400 nm) / depth(1850-2100 nm)</b>
        </p>

        <p>This requires two separate Wavelength of Minimum rasters, one run
        over each wavelength range.</p>

        <p><b>Inputs:</b></p>
        <ul>
          <li><b>WoM 2100-2400 nm</b> — Band 1 = primary wavelength (b2),
              Band 2 = feature depth (b3, used as threshold and numerator).</li>
          <li><b>WoM 1850-2100 nm</b> — Band 2 = feature depth
              (denominator for illx ratio).</li>
          <li><b>Depth threshold</b> — pixels with b3 &le; this value are
              labelled aspectral (default 0.05).</li>
        </ul>

        <p><b>Decision tree:</b></p>
        <ul>
          <li>b3 &le; threshold &rarr; <b>aspectral</b></li>
          <li>b2 not in (2185, 2225] nm &rarr; <b>NO-ALOH</b></li>
          <li>b1 &le; 0.25 &rarr; <b>smect3</b></li>
          <li>b1 &le; 0.33 &rarr; <b>smect2</b></li>
          <li>b1 &le; 0.50 &rarr; <b>smect1</b></li>
          <li>b1 &le; 1.0  &rarr; <b>smect-ill</b></li>
          <li>b1 &le; 2.0  &rarr; <b>ill-smect</b></li>
          <li>b1 &le; 3.0  &rarr; <b>hx-ill</b></li>
          <li>b1 &le; 4.0  &rarr; <b>musc1</b></li>
          <li>b1 &gt; 4.0  &rarr; <b>musc2</b></li>
        </ul>

        <p>smect = smectite, ill = illite, hx = high crystallinity,
        musc = muscovite.</p>

        <p>The log reports the computed b1 min/max/mean to help verify the
        ratio is in a sensible range.</p>

        <p><i>Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return DtIllcrystAlgorithm()
