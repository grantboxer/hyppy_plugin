"""
Feature Extraction — 1760W

WoM range 1730-1790 nm, wavelength map stretch 1751-1764 nm.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
)
import processing
import os


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with wavelength metadata.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""


class Fe1760WAlgorithm(QgsProcessingAlgorithm):
    """Feature Extraction — 1760W."""

    INPUT         = 'INPUT'
    NUM_FEATURES  = 'NUM_FEATURES'
    OUTPUT_WOM    = 'OUTPUT_WOM'
    OUTPUT_MAP    = 'OUTPUT_MAP'
    LEGEND_OUTPUT = 'LEGEND_OUTPUT'

    WOM_START = 1730.0
    WOM_END   = 1790.0
    MAP_MIN   = 1751.0
    MAP_MAX   = 1764.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract (1-9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=1, minValue=1, maxValue=9))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_WOM,
            'Output WoM raster (1730-1790 nm)'))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_MAP,
            'Output Wavelength Map RGB (1751-1764 nm stretch)'))
        self.addParameter(QgsProcessingParameterFileDestination(
            self.LEGEND_OUTPUT,
            'Output Colour Legend (PNG)',
            fileFilter='PNG Files (*.png)',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        cube        = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n           = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        out_wom     = self.parameterAsOutputLayer(parameters, self.OUTPUT_WOM, context)
        out_map     = self.parameterAsOutputLayer(parameters, self.OUTPUT_MAP, context)
        legend_path = self.parameterAsFileOutput(parameters, self.LEGEND_OUTPUT, context)

        self._legend_path = None

        # Step 1: Wavelength of Minimum 1730-1790 nm
        feedback.setProgress(5)
        feedback.pushInfo('Step 1/2  Wavelength of Minimum  1730-1790 nm ...')
        wom_result = processing.run(
            'hyppy:wavelength_of_minimum',
            {
                'INPUT':            cube,
                'START_WAVELENGTH': self.WOM_START,
                'END_WAVELENGTH':   self.WOM_END,
                'MODE':             0,
                'NUM_FEATURES':     n,
                'BROAD':            False,
                'USE_BBL':          True,
                'OUTPUT':           out_wom,
            },
            context=context,
            feedback=feedback,
            is_child_algorithm=True,
        )
        if feedback.isCanceled():
            return {}

        wom_path = wom_result['OUTPUT']
        feedback.pushInfo(f'  WoM raster saved: {wom_path}')

        # Step 2: Wavelength Mapping 1751-1764 nm
        feedback.setProgress(50)
        feedback.pushInfo('Step 2/2  Wavelength Mapping  1751-1764 nm stretch ...')

        from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
        wma     = WavelengthMappingAlgorithm()
        palette = wma.create_rainbow_palette()

        map_path = wma._run_colour_mapping(
            wom_path, palette,
            self.MAP_MIN, self.MAP_MAX,
            self.DEPTH_MIN, self.DEPTH_MAX,
            out_map, feedback,
        )

        feedback.setProgress(88)
        feedback.pushInfo(f'  Wavelength map saved: {map_path}')

        # Step 3: Legend — default filename is <tool_label>_legend.png
        # beside the WoM output so it is easy to find and clearly named.
        if not legend_path:
            wom_dir     = os.path.dirname(wom_path)
            legend_path = os.path.join(wom_dir, '1760W_legend.png')
        try:
            saved = wma.create_legend(
                legend_path, palette,
                self.MAP_MIN, self.MAP_MAX,
                self.DEPTH_MIN, self.DEPTH_MAX,
                feedback,
            )
            if saved:
                self._legend_path = saved
                feedback.pushInfo(f'  Colour legend saved: {saved}')
        except Exception as e:
            feedback.pushWarning(f'Legend generation failed: {e}')

        feedback.setProgress(100)
        feedback.pushInfo('Feature Extraction 1760W complete.')

        return {
            self.OUTPUT_WOM:    wom_path,
            self.OUTPUT_MAP:    map_path,
            self.LEGEND_OUTPUT: self._legend_path or '',
        }

    def postProcessAlgorithm(self, context, feedback):
        if getattr(self, '_legend_path', None):
            from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
            WavelengthMappingAlgorithm()._show_legend_dock(self._legend_path, feedback)
        return {}

    def name(self):        return 'fe_1760w'
    def displayName(self): return 'FE06 - 1760W'
    def group(self):       return '7 - Feature Extraction'
    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 1760W  (Carbonate CO₃ combination)</b>

        <p>Targets the carbonate CO₃ combination absorption near <b>~1760 nm</b>,
        present in calcite, dolomite, and magnesite. This is the last useful atmospheric
        window before the 1780–1960 nm water vapour zone.
        Derived from USGS GMEX reference spectra for calcite and dolomite.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>1730-1790 nm</b>.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>1751-1764 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>1730-1790 nm</td></tr>
          <tr><td>Colour stretch min</td><td>1751 nm</td></tr>
          <tr><td>Colour stretch max</td><td>1764 nm</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>~1760 nm feature — mineral associations (GMEX):</b></p>
        <ul>
          <li><b>Calcite</b> CaCO₃ — CO₃ combination at ~1750–1755 nm; weaker absorptions
              at 1880/1992 nm do NOT persist in mixtures; only ~2340–2345 nm persists (GMEX)</li>
          <li><b>Dolomite</b> CaMg(CO₃)₂ — CO₃ combination at ~1760–1765 nm; slightly
              longward of calcite; only ~2320–2328 nm persists in mixtures (GMEX)</li>
          <li><b>Magnesite</b> MgCO₃ — CO₃ combination near ~1760 nm; only ~2302 nm
              persists — shortest-wave diagnostic carbonate feature (GMEX)</li>
          <li><b>Siderite</b> FeCO₃ — CO₃ combination at ~1755 nm; confirm with 2320–2340 nm</li>
          <li><b>Alunite</b> (K,Na)Al₃(SO₄)₂(OH)₆ — strong SO₄/OH at <b>~1760 nm</b>
              very characteristic (GMEX); combine with 1436/1474–1480 nm OH doublet to
              confirm. Use this WoM as input to <b>DT Sulphate Group</b> classifier.</li>
          <li><b>Gypsum</b> CaSO₄·2H₂O — SO₄/OH feature at ~1750 nm alongside triple
              water absorptions at 1449/1490/1535 nm (GMEX)</li>
        </ul>

        <p>The small wavelength separation within the stretch range (~1751–1764 nm)
        can discriminate calcite from dolomite in high-SNR data. Use together with
        FE16-2320W and FE17-2350W for full carbonate suite characterisation.</p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, calcite and dolomite entries.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe1760WAlgorithm()
