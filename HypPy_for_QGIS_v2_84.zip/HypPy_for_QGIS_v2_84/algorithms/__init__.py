"""
Hyperspectral Processing Algorithms

This package contains QGIS Processing algorithms ported from HyPy.
"""

from .sam_algorithm import SpectralAngleMapperAlgorithm
from .wavelength_of_minimum_algorithm import WavelengthOfMinimumAlgorithm
from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
from .convex_hull_removal_algorithm import ConvexHullRemovalAlgorithm
from .band_ratio_algorithm import BandRatioAlgorithm
from .band_ratios_algorithm import BandRatiosAlgorithm
from .band_depths_algorithm import BandDepthsAlgorithm
from .band_math_algorithm import BandMathAlgorithm
from .spectra_math_algorithm import SpectraMathAlgorithm

__all__ = [
    'SpectralAngleMapperAlgorithm',
    'WavelengthOfMinimumAlgorithm',
    'WavelengthMappingAlgorithm',
    'ConvexHullRemovalAlgorithm',
    'BandRatioAlgorithm',
    'BandRatiosAlgorithm',
    'BandDepthsAlgorithm',
    'BandMathAlgorithm',
    'SpectraMathAlgorithm',
]
