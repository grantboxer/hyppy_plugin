"""
GSWA Table 5 — Kaolin abundance index (KLNai)

Algorithm: Intensity of the wavelength minimum between 2140 and 2200 nm
           using 4th order polynomial fit (2160D).
Masks:     MertonNDVI > threshold  AND  2200D < 0.04  AND  2200D/2160D < 3.0
Stretch:   Gascoyne/Pilbara linear: Blue=0.02, Red=0.15
           (high values also from pyrophyllite — see PPHai)
Targeted:  Kaolin group minerals

Reference:
    Laukamp et al. (2025) GSWA Report 261, Table 5.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

from ..core.envi_header import get_wavelengths_from_dataset
from .gswa_index_utils import (
    compute_ndvi, read_wom_band, write_index,
    apply_ndvi_mask, log_gswa_stretch,
)

WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Cube (NDVI) + FE10-2160D WoM + FE12-2200W WoM.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""

KLNAI_STRETCH = {
    'gascoyne': 'linear: Blue=0.02 (low), Red=0.15 (high)',
    'pilbara':  'linear: Blue=0.02 (low), Red=0.15 (high)',
}

KLNCI_STRETCH = {
    'gascoyne': 'linear: Blue=poorly crystalline (1.01), Red=well crystalline (1.09)',
    'pilbara':  'linear: Blue=poorly crystalline (1.01), Red=well crystalline (1.1)',
}

REFERENCE_AI = 'Laukamp et al. (2025) GSWA Report 261, Table 5 (KLNai)'
REFERENCE_CI = 'Laukamp et al. (2025) GSWA Report 261, Table 5 (KLNci)'


class GswaKlnaiAlgorithm(QgsProcessingAlgorithm):
    """GSWA Table 5 — Kaolin abundance index (KLNai)."""

    CUBE         = 'CUBE'
    WOM_2160     = 'WOM_2160'
    WOM_2200     = 'WOM_2200'
    NDVI_THRESH  = 'NDVI_THRESH'
    DEPTH_THRESH = 'DEPTH_THRESH'
    RATIO_THRESH = 'RATIO_THRESH'
    OUTPUT       = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.CUBE,    'Hyperspectral cube  (for MertonNDVI)'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2160, 'FE10-2160D WoM raster  (Band 2 = 2160D depth)'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2200, 'FE12-2200W WoM raster  (Band 2 = 2200D depth)'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NDVI_THRESH, 'MertonNDVI threshold (mask above)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.15, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.DEPTH_THRESH,
            '2200D depth upper threshold (mask above — too deep = WM dominated)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.04, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.RATIO_THRESH,
            '2200D/2160D ratio upper threshold — keep pixels BELOW this (kaolin dominance)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=3.0, minValue=0.1, maxValue=20.0))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT, 'Output KLNai raster'))

    def processAlgorithm(self, parameters, context, feedback):
        cube_layer   = self.parameterAsRasterLayer(parameters, self.CUBE, context)
        wom_2160     = self.parameterAsRasterLayer(parameters, self.WOM_2160, context)
        wom_2200     = self.parameterAsRasterLayer(parameters, self.WOM_2200, context)
        ndvi_thresh  = self.parameterAsDouble(parameters, self.NDVI_THRESH, context)
        depth_thresh = self.parameterAsDouble(parameters, self.DEPTH_THRESH, context)
        ratio_thresh = self.parameterAsDouble(parameters, self.RATIO_THRESH, context)
        out_path     = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        feedback.setProgress(5)
        feedback.pushInfo('Reading 2160D depth (Band 2 of FE10-2160D WoM) …')
        d2160, gt, proj, rows, cols = read_wom_band(wom_2160, 2, '2160D', feedback)
        feedback.pushInfo('Reading 2200D depth (Band 2 of FE12-2200W WoM) …')
        d2200, *_ = read_wom_band(wom_2200, 2, '2200D', feedback)

        feedback.setProgress(20)
        feedback.pushInfo('Computing MertonNDVI …')
        cube_ds     = gdal.Open(cube_layer.source())
        wavelengths = get_wavelengths_from_dataset(
            cube_ds, cube_ds.RasterCount, cube_layer.source(), feedback)
        if wavelengths is None:
            raise QgsProcessingException('No wavelength metadata found in cube.')
        nodata = cube_ds.GetRasterBand(1).GetNoDataValue()
        ndvi   = compute_ndvi(cube_ds, wavelengths, nodata, feedback)
        del cube_ds

        feedback.setProgress(60)
        feedback.pushInfo('Applying GSWA Table 5 masks …')
        klnai = d2160.copy()
        klnai = apply_ndvi_mask(klnai, ndvi, ndvi_thresh, 'KLNai', feedback)

        # 2200D < depth_thresh (mask deep Al-OH — WM dominated)
        deep = ~np.isnan(d2200) & (d2200 >= depth_thresh)
        klnai[deep] = np.nan
        feedback.pushInfo(
            f'  KLNai: 2200D≥{depth_thresh} mask: {int(np.sum(deep))} px masked')

        # 2200D/2160D < ratio_thresh (keep kaolin-dominant pixels)
        with np.errstate(invalid='ignore', divide='ignore'):
            ratio = np.where(d2160 > 0, d2200 / d2160, np.nan)
        high_ratio = ~np.isnan(ratio) & (ratio >= ratio_thresh)
        klnai[high_ratio] = np.nan
        feedback.pushInfo(
            f'  KLNai: ratio≥{ratio_thresh} mask: {int(np.sum(high_ratio))} px masked')

        feedback.setProgress(85)
        feedback.pushInfo('Writing KLNai …')
        write_index(
            out_path, klnai, gt, proj,
            product_name='KLNai',
            description='Kaolin abundance index (2160D, poly4, masked by ratio)',
            gswa_stretch=KLNAI_STRETCH,
            reference=REFERENCE_AI,
            extra_meta={
                'GSWA_note': 'High values also from pyrophyllite — see PPHai to discriminate',
            }
        )

        log_gswa_stretch(feedback, 'KLNai (Kaolin abundance)', KLNAI_STRETCH)
        feedback.pushInfo(
            'NOTE: High KLNai values can also indicate pyrophyllite. '
            'Run GSWA-PPHai to discriminate.')
        feedback.setProgress(100)
        return {self.OUTPUT: out_path}

    def name(self):        return 'gswa_klnai'
    def displayName(self): return 'GSWA-KLNai  (Kaolin Abundance)'
    def group(self):       return '9 - GSWA Mineral Map Indices'
    def groupId(self):     return 'nine_gswa_indices'

    def shortHelpString(self):
        return WORKFLOW_NOTE + f"""
        <b>Kaolin Abundance Index (KLNai)</b>
        <p>GSWA Report 261, Table 5. 2160D depth masked to retain kaolin-dominant
        pixels by excluding white-mica-dominant (high 2200D/2160D ratio) and
        over-saturated pixels.</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Mask condition</th><th>Rationale</th></tr>
          <tr><td>MertonNDVI &gt; threshold</td><td>Remove vegetation</td></tr>
          <tr><td>2200D &lt; 0.04</td>
              <td>Remove strong Al-OH signal at 2200 nm (white mica dominated)</td></tr>
          <tr><td>2200D / 2160D &lt; 3.0</td>
              <td>Kaolin: balanced 2200/2160 nm ratio</td></tr>
          <tr style="background:#fff3e0">
            <td><b>Stretch (both regions)</b></td>
            <td>linear: Blue=0.02, Red=0.15</td></tr>
          <tr><td>Challenge</td>
              <td>High values also from pyrophyllite — use GSWA-PPHai to discriminate</td></tr>
        </table>

        <p><i>Reference: Laukamp et al. (2025) GSWA Report 261, Table 5.</i></p>
        """

    def createInstance(self): return GswaKlnaiAlgorithm()


# ─────────────────────────────────────────────────────────────────────────────


class GswaKlnciAlgorithm(QgsProcessingAlgorithm):
    """GSWA Table 5 — Kaolin crystallinity index (KLNci = 2160D/2200D ratio)."""

    CUBE         = 'CUBE'
    WOM_2160     = 'WOM_2160'
    WOM_2200     = 'WOM_2200'
    NDVI_THRESH  = 'NDVI_THRESH'
    DEPTH_THRESH = 'DEPTH_THRESH'
    DEPTH_2160_THRESH = 'DEPTH_2160_THRESH'
    OUTPUT       = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.CUBE,    'Hyperspectral cube  (for MertonNDVI)'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2160, 'FE10-2160D WoM raster  (Band 2 = 2160D depth)'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2200, 'FE12-2200W WoM raster  (Band 2 = 2200D depth)'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NDVI_THRESH, 'MertonNDVI threshold (mask above)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.15, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.DEPTH_THRESH,
            '2200D depth upper threshold (mask above)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.04, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.DEPTH_2160_THRESH,
            '2160D minimum depth threshold (mask below — too shallow for reliable ratio)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.03, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT, 'Output KLNci raster  (2160D/2200D ratio)'))

    def processAlgorithm(self, parameters, context, feedback):
        cube_layer    = self.parameterAsRasterLayer(parameters, self.CUBE, context)
        wom_2160      = self.parameterAsRasterLayer(parameters, self.WOM_2160, context)
        wom_2200      = self.parameterAsRasterLayer(parameters, self.WOM_2200, context)
        ndvi_thresh   = self.parameterAsDouble(parameters, self.NDVI_THRESH, context)
        depth_thresh  = self.parameterAsDouble(parameters, self.DEPTH_THRESH, context)
        d2160_thresh  = self.parameterAsDouble(parameters, self.DEPTH_2160_THRESH, context)
        out_path      = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        feedback.setProgress(5)
        feedback.pushInfo('Reading 2160D and 2200D depths …')
        d2160, gt, proj, rows, cols = read_wom_band(wom_2160, 2, '2160D', feedback)
        d2200, *_ = read_wom_band(wom_2200, 2, '2200D', feedback)

        feedback.setProgress(20)
        feedback.pushInfo('Computing MertonNDVI …')
        cube_ds     = gdal.Open(cube_layer.source())
        wavelengths = get_wavelengths_from_dataset(
            cube_ds, cube_ds.RasterCount, cube_layer.source(), feedback)
        if wavelengths is None:
            raise QgsProcessingException('No wavelength metadata found in cube.')
        nodata = cube_ds.GetRasterBand(1).GetNoDataValue()
        ndvi   = compute_ndvi(cube_ds, wavelengths, nodata, feedback)
        del cube_ds

        feedback.setProgress(55)
        feedback.pushInfo('Computing KLNci = 2160D / 2200D …')
        with np.errstate(invalid='ignore', divide='ignore'):
            klnci = np.where(
                (d2200 > 0) & (~np.isnan(d2200)) & (~np.isnan(d2160)),
                d2160 / d2200,
                np.nan
            ).astype(np.float32)

        feedback.setProgress(65)
        feedback.pushInfo('Applying GSWA Table 5 masks …')
        klnci = apply_ndvi_mask(klnci, ndvi, ndvi_thresh, 'KLNci', feedback)

        deep = ~np.isnan(d2200) & (d2200 >= depth_thresh)
        klnci[deep] = np.nan
        feedback.pushInfo(
            f'  KLNci: 2200D≥{depth_thresh} mask: {int(np.sum(deep))} px masked')

        shallow = ~np.isnan(d2160) & (d2160 < d2160_thresh)
        klnci[shallow] = np.nan
        feedback.pushInfo(
            f'  KLNci: 2160D<{d2160_thresh} mask: {int(np.sum(shallow))} px masked')

        feedback.setProgress(85)
        feedback.pushInfo('Writing KLNci …')
        write_index(
            out_path, klnci, gt, proj,
            product_name='KLNci',
            description='Kaolin crystallinity index (2160D/2200D ratio)',
            gswa_stretch=KLNCI_STRETCH,
            reference=REFERENCE_CI,
            extra_meta={
                'GSWA_units':          '2160D/2200D ratio (dimensionless)',
                'GSWA_blue_end':       'poorly crystalline (ratio ~1.01)',
                'GSWA_red_end':        'well crystalline (ratio ~1.09-1.1)',
                'GSWA_interpretation': 'high ratio = well-crystallised kaolinite',
            }
        )

        log_gswa_stretch(feedback, 'KLNci (Kaolin crystallinity)', KLNCI_STRETCH)
        feedback.pushInfo(
            'Low ratio (~1.01) = poorly crystalline kaolinite / mixed-layer clays; '
            'High ratio (~1.09-1.1) = well-ordered kaolinite')
        feedback.setProgress(100)
        return {self.OUTPUT: out_path}

    def name(self):        return 'gswa_klnci'
    def displayName(self): return 'GSWA-KLNci  (Kaolin Crystallinity)'
    def group(self):       return '9 - GSWA Mineral Map Indices'
    def groupId(self):     return 'nine_gswa_indices'

    def shortHelpString(self):
        return WORKFLOW_NOTE + f"""
        <b>Kaolin Crystallinity Index (KLNci)</b>
        <p>GSWA Report 261, Table 5. Ratio of 2160D/2200D depths — proxy for
        kaolinite crystallinity order. Well-crystallised kaolinite has a strong
        2160 nm shoulder relative to the 2200 nm feature.</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th></tr>
          <tr><td>Algorithm</td><td>2160D / 2200D  (ratio of depths)</td></tr>
          <tr><td>Masks</td>
              <td>MertonNDVI &gt; threshold; 2200D &gt; 0.04; 2160D &lt; 0.03</td></tr>
          <tr style="background:#fff3e0">
            <td><b>Gascoyne stretch</b></td>
            <td>linear: Blue=1.01 (poorly crystalline), Red=1.09 (well crystalline)</td></tr>
          <tr style="background:#fff3e0">
            <td><b>Pilbara stretch</b></td>
            <td>linear: Blue=1.01 (poorly crystalline), Red=1.1 (well crystalline)</td></tr>
          <tr><td>Target</td>
              <td>Crystallinity of kaolin group minerals</td></tr>
          <tr><td>Challenge</td>
              <td>Pyrophyllite, white mica, Al-smectite</td></tr>
        </table>

        <p><i>Reference: Laukamp et al. (2025) GSWA Report 261, Table 5.</i></p>
        """

    def createInstance(self): return GswaKlnciAlgorithm()
