"""
Feature Extraction — Bastnäsite Indices (REE VNIR detection)
=============================================================
Implements the three Bastnäsite Indices (BI1, BI2, BI3) from:

    Gadea, O.C.A.; Khan, S.D. (2024). Identification of a Potential Rare Earth
    Element Deposit at Ivanpah Dry Lake, California Through the Bastnäsite
    Indices. Remote Sens. 16, 4540.
    https://doi.org/10.3390/rs16234540

    See also: Gadea, O.C.A.; Khan, S.D.; Sisson, V.B. (2024). Estimating rare
    earth elements at various scales with Bastnäsite Indices for Mountain Pass.
    Ore Geol. Rev. 173, 106254.

The indices detect four narrow Nd³⁺ absorption features in the VNIR:
    ~580 nm, ~740 nm, ~800 nm, ~870 nm
using five relative peak bands (P1–P5) and four trough bands (T1–T4)
whose wavelengths are sensor-dependent (see Table 1 of Gadea et al. 2024).

Default wavelengths (nm) are taken from the AVIRIS-NG column of Table 1,
which represents the highest-resolution airborne sensor in the study, and
are applicable to any sensor with similar spectral coverage and bandwidth.

BI equations (values normalised like NDVI, ranging –1 to +1 for BI1/BI2
and –4 to +4 for BI3):

    BI1 = [(P1+P2+P3+P4) – (T1+T2+T3+T4)]
          / [(P1+P2+P3+P4) + (T1+T2+T3+T4)]

    BI2 = [((P1+P5)/2 + P2+P3+P4) – (T1+T2+T3+T4)]
          / [((P1+P5)/2 + P2+P3+P4) + (T1+T2+T3+T4)]

    BI3 = Σ  [(Pi+Pi+1)/2 – Ti] / [(Pi+Pi+1)/2 + Ti]   for i = 1..4

Confirmation thresholds (Gadea et al. 2024):
    BI1 ≥ 0.040,  BI2 ≥ 0.055,  BI3 ≥ 0.221

Output: a 3-band float32 GeoTIFF (Band 1 = BI1, Band 2 = BI2, Band 3 = BI3)
        plus optional single-band threshold maps for each index.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset


# ── Default wavelengths from AVIRIS-NG column (Table 1, Gadea et al. 2024) ────
# All values in nm.  User may override each individually.
_DEF = {
    'P1': 567.0, 'T1': 577.1,
    'P2': 712.3, 'T2': 742.3,
    'P3': 772.4, 'T3': 797.4,
    'P4': 837.5, 'T4': 867.6,
    'P5': 922.7,
}

# Confirmation thresholds from Gadea et al. 2024
_THRESH = {'BI1': 0.040, 'BI2': 0.055, 'BI3': 0.221}

# Sensor presets from Table 1 (sensor name → dict of P/T wavelengths)
_PRESETS = {
    'AVIRIS-NG':      {'P1': 567.0, 'T1': 577.1, 'P2': 712.3, 'T2': 742.3,
                       'P3': 772.4, 'T3': 797.4, 'P4': 837.5, 'T4': 867.6, 'P5': 922.7},
    'AVIRIS-Classic': {'P1': 550.3, 'T1': 560.0, 'P2': 713.6, 'T2': 742.9,
                       'P3': 772.1, 'T3': 801.3, 'P4': 840.2, 'T4': 869.3, 'P5': 927.4},
    'HISUI':          {'P1': 565.0, 'T1': 575.0, 'P2': 715.0, 'T2': 735.0,
                       'P3': 775.0, 'T3': 795.0, 'P4': 835.0, 'T4': 865.0, 'P5': 915.0},
    'DESIS':          {'P1': 568.3, 'T1': 578.5, 'P2': 721.4, 'T2': 741.9,
                       'P3': 777.9, 'T3': 798.3, 'P4': 832.1, 'T4': 865.3, 'P5': 916.5},
    'EnMAP':          {'P1': 566.2, 'T1': 577.0, 'P2': 706.4, 'T2': 741.6,
                       'P3': 770.9, 'T3': 801.0, 'P4': 847.6, 'T4': 871.4, 'P5': 921.6},
    'EO-1 Hyperion':  {'P1': 559.1, 'T1': 579.5, 'P2': 711.7, 'T2': 742.3,
                       'P3': 772.8, 'T3': 803.3, 'P4': 844.0, 'T4': 864.4, 'P5': 932.6},
    'PRISMA':         {'P1': 567.2, 'T1': 583.8, 'P2': 713.7, 'T2': 744.1,
                       'P3': 775.3, 'T3': 796.1, 'P4': 849.2, 'T4': 870.7, 'P5': 924.0},
    'EMIT':           {'P1': 566.8, 'T1': 581.7, 'P2': 723.3, 'T2': 745.7,
                       'P3': 775.5, 'T3': 797.9, 'P4': 835.2, 'T4': 872.5, 'P5': 917.3},
}

WORKFLOW_NOTE = """\
        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with VNIR coverage (≥ 550–930 nm)
        and wavelength metadata (ENVI format).<br/>
        Sensors: AVIRIS-NG, AVIRIS-Classic, HISUI, DESIS, EnMAP, EO-1 Hyperion, PRISMA, EMIT.
        Sentinel-2 does not have sufficient spectral resolution for this analysis.
        </p>
"""

BI_NOTE = """\
        <p style="background-color:#e8f4fd; padding:6px; border-left:4px solid #1565c0;">
        <b>Bastnäsite Indices (Gadea &amp; Khan 2024):</b>
        Three spectral indices that detect neodymium (Nd³⁺) absorption features
        at ~580, ~740, ~800, and ~870 nm in REE-bearing minerals.
        All confirmed REE-rich pixels exceed <b>BI1 ≥ 0.040, BI2 ≥ 0.055, BI3 ≥ 0.221</b>.
        </p>
"""


def _nearest_band(wavelengths, target_nm):
    """Return 0-based index of band nearest to target_nm."""
    return int(np.argmin(np.abs(wavelengths - target_nm)))


def _read_band_float(ds, band_idx, nodata):
    """Read one band (0-based) as float32, replacing nodata with NaN."""
    arr = ds.GetRasterBand(band_idx + 1).ReadAsArray().astype(np.float32)
    if nodata is not None:
        arr[arr == nodata] = np.nan
    return arr


def _write_single_band_tif(path, arr, geo, proj, description='', nodata=np.nan):
    """Write a single-band float32 GeoTIFF."""
    driver = gdal.GetDriverByName('GTiff')
    n_rows, n_cols = arr.shape
    out_ds = driver.Create(path, n_cols, n_rows, 1, gdal.GDT_Float32,
                           ['COMPRESS=LZW', 'TILED=YES'])
    out_ds.SetGeoTransform(geo)
    out_ds.SetProjection(proj)
    b = out_ds.GetRasterBand(1)
    b.WriteArray(arr.astype(np.float32))
    b.SetNoDataValue(float(nodata))
    b.SetDescription(description)
    out_ds.FlushCache()
    out_ds = None


class FeReeBastanasiteAlgorithm(QgsProcessingAlgorithm):
    """Feature Extraction — Bastnäsite Indices BI1/BI2/BI3 for REE detection."""

    INPUT    = 'INPUT'
    USE_BBL  = 'USE_BBL'
    # Nine wavelength parameters
    P1 = 'P1'; T1 = 'T1'
    P2 = 'P2'; T2 = 'T2'
    P3 = 'P3'; T3 = 'T3'
    P4 = 'P4'; T4 = 'T4'
    P5 = 'P5'
    # Outputs
    OUTPUT_BI   = 'OUTPUT_BI'    # 3-band: BI1, BI2, BI3
    OUTPUT_MASK = 'OUTPUT_MASK'  # optional 3-band threshold mask

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube (VNIR, ≥550–930 nm)'))
        self.addParameter(QgsProcessingParameterBoolean(
            self.USE_BBL, 'Use Bad Band List (BBL) from metadata',
            defaultValue=True))

        # Wavelength positions — default to AVIRIS-NG values from Table 1
        wav_params = [
            (self.P1, 'P1 — first peak (shoulder before ~580 nm feature)',  _DEF['P1']),
            (self.T1, 'T1 — first trough (~580 nm Nd³⁺ feature)',            _DEF['T1']),
            (self.P2, 'P2 — second peak (shoulder before ~740 nm feature)',  _DEF['P2']),
            (self.T2, 'T2 — second trough (~740 nm Nd³⁺ feature)',           _DEF['T2']),
            (self.P3, 'P3 — third peak (shoulder before ~800 nm feature)',   _DEF['P3']),
            (self.T3, 'T3 — third trough (~800 nm Nd³⁺ feature)',            _DEF['T3']),
            (self.P4, 'P4 — fourth peak (shoulder before ~870 nm feature)',  _DEF['P4']),
            (self.T4, 'T4 — fourth trough (~870 nm Nd³⁺ feature)',           _DEF['T4']),
            (self.P5, 'P5 — fifth peak (shoulder after ~870 nm feature)',    _DEF['P5']),
        ]
        for name, label, default in wav_params:
            self.addParameter(QgsProcessingParameterNumber(
                name, f'{label}  [nm]',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=default, minValue=300.0, maxValue=1200.0))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_BI,
            'Output Bastnäsite Indices (3-band: BI1, BI2, BI3)'))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_MASK,
            'Output REE Confirmation Mask (3-band: BI1≥0.040, BI2≥0.055, BI3≥0.221)',
            optional=True))

    # ── Core computation (also callable as a standalone function) ─────────────

    @staticmethod
    def compute_indices(p1, t1, p2, t2, p3, t3, p4, t4, p5):
        """
        Compute BI1, BI2, BI3 from nine band arrays.
        All inputs are float32 numpy arrays of equal shape.
        Returns (bi1, bi2, bi3) as float32 arrays.
        """
        with np.errstate(invalid='ignore', divide='ignore'):
            # BI1
            peaks_1  = p1 + p2 + p3 + p4
            troughs  = t1 + t2 + t3 + t4
            bi1_num  = peaks_1  - troughs
            bi1_den  = peaks_1  + troughs
            bi1 = np.where(bi1_den != 0, bi1_num / bi1_den, np.nan).astype(np.float32)

            # BI2  — (P1+P5)/2 replaces P1 in the peak sum
            p1p5_half = (p1 + p5) * 0.5
            peaks_2   = p1p5_half + p2 + p3 + p4
            bi2_num   = peaks_2 - troughs
            bi2_den   = peaks_2 + troughs
            bi2 = np.where(bi2_den != 0, bi2_num / bi2_den, np.nan).astype(np.float32)

            # BI3  — sum of four individual NDVI-style depth terms
            def _ndvi_depth(lo_peak, hi_peak, trough):
                mid = (lo_peak + hi_peak) * 0.5
                den = mid + trough
                return np.where(den != 0, (mid - trough) / den, np.nan)

            bi3 = (
                _ndvi_depth(p1, p2, t1) +
                _ndvi_depth(p2, p3, t2) +
                _ndvi_depth(p3, p4, t3) +
                _ndvi_depth(p4, p5, t4)
            ).astype(np.float32)

        return bi1, bi2, bi3

    # ── QGIS processing ───────────────────────────────────────────────────────

    def processAlgorithm(self, parameters, context, feedback):
        cube      = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        use_bbl   = self.parameterAsBoolean(parameters, self.USE_BBL, context)
        out_bi    = self.parameterAsOutputLayer(parameters, self.OUTPUT_BI, context)
        out_mask  = self.parameterAsOutputLayer(parameters, self.OUTPUT_MASK, context)

        # Retrieve user wavelength values
        user_wav = {k: self.parameterAsDouble(parameters, k, context)
                    for k in (self.P1, self.T1, self.P2, self.T2,
                               self.P3, self.T3, self.P4, self.T4, self.P5)}

        if cube is None:
            raise QgsProcessingException('Invalid input layer')

        ds = gdal.Open(cube.source())
        if ds is None:
            raise QgsProcessingException(f'Cannot open raster: {cube.source()}')

        n_bands = ds.RasterCount
        n_rows  = ds.RasterYSize
        n_cols  = ds.RasterXSize
        nodata  = ds.GetRasterBand(1).GetNoDataValue()
        geo     = ds.GetGeoTransform()
        proj    = ds.GetProjection()

        raster_path = cube.source()
        wavelengths = get_wavelengths_from_dataset(ds, n_bands, raster_path, feedback)
        if wavelengths is None:
            raise QgsProcessingException(
                'No wavelength metadata found. Input must have ENVI wavelength information.')

        # Check VNIR coverage — need at least P1 to P5
        wmin, wmax = wavelengths[0], wavelengths[-1]
        needed_min = min(user_wav.values())
        needed_max = max(user_wav.values())
        if wmin > needed_min or wmax < needed_max:
            raise QgsProcessingException(
                f'Cube covers {wmin:.0f}–{wmax:.0f} nm but indices need '
                f'{needed_min:.0f}–{needed_max:.0f} nm.')

        # BBL
        bbl = None
        if use_bbl:
            bbl = get_bbl_from_dataset(ds, n_bands, raster_path)
            if bbl is not None:
                n_good = int(np.sum(bbl))
                feedback.pushInfo(f'BBL: {n_good}/{n_bands} good bands')

        feedback.pushInfo(f'Cube: {n_bands} bands, {n_rows}×{n_cols} px, '
                          f'{wmin:.0f}–{wmax:.0f} nm')

        # Resolve band indices and log them
        labels = [self.P1, self.T1, self.P2, self.T2,
                  self.P3, self.T3, self.P4, self.T4, self.P5]
        band_idx = {}
        feedback.pushInfo('')
        feedback.pushInfo('Band assignments (nearest available band):')
        for label in labels:
            target = user_wav[label]
            idx    = _nearest_band(wavelengths, target)
            actual = wavelengths[idx]
            # If BBL marks this band bad, warn but proceed (no safe alternative)
            bad_flag = ''
            if bbl is not None and not bbl[idx]:
                bad_flag = '  ⚠ flagged bad in BBL'
            feedback.pushInfo(f'  {label}: target {target:.1f} nm → '
                              f'band {idx+1} ({actual:.1f} nm){bad_flag}')
            band_idx[label] = idx

        feedback.pushInfo('')

        # Check that peaks and troughs don't collapse to the same band
        pairs = [('P1','T1'), ('P2','T2'), ('P3','T3'), ('P4','T4')]
        for pk, tr in pairs:
            if band_idx[pk] == band_idx[tr]:
                raise QgsProcessingException(
                    f'{pk} and {tr} resolve to the same band '
                    f'(band {band_idx[pk]+1}, {wavelengths[band_idx[pk]]:.1f} nm). '
                    f'Adjust wavelengths or choose a higher-resolution sensor.')

        # ── Read the nine required bands ──────────────────────────────────────
        feedback.setProgress(10)
        feedback.pushInfo('Reading 9 band arrays …')
        bands = {lbl: _read_band_float(ds, band_idx[lbl], nodata) for lbl in labels}
        ds = None   # close input
        feedback.setProgress(35)

        if feedback.isCanceled():
            return {}

        # ── Compute indices ───────────────────────────────────────────────────
        feedback.pushInfo('Computing BI1, BI2, BI3 …')
        bi1, bi2, bi3 = self.compute_indices(
            bands['P1'], bands['T1'],
            bands['P2'], bands['T2'],
            bands['P3'], bands['T3'],
            bands['P4'], bands['T4'],
            bands['P5'],
        )
        feedback.setProgress(65)

        if feedback.isCanceled():
            return {}

        # ── Statistics log ────────────────────────────────────────────────────
        for name, arr, thr in (('BI1', bi1, _THRESH['BI1']),
                                ('BI2', bi2, _THRESH['BI2']),
                                ('BI3', bi3, _THRESH['BI3'])):
            valid = arr[np.isfinite(arr)]
            if valid.size:
                above = int(np.sum(valid >= thr))
                pct   = 100.0 * above / valid.size
                feedback.pushInfo(
                    f'  {name}: min={float(valid.min()):.4f}  '
                    f'max={float(valid.max()):.4f}  '
                    f'mean={float(valid.mean()):.4f}  '
                    f'pixels≥{thr}={above} ({pct:.2f}%)')

        feedback.pushInfo('')
        feedback.pushInfo('Confirmation thresholds (Gadea et al. 2024):')
        feedback.pushInfo('  BI1 ≥ 0.040,  BI2 ≥ 0.055,  BI3 ≥ 0.221')

        # ── Write 3-band BI output ────────────────────────────────────────────
        feedback.setProgress(75)
        feedback.pushInfo(f'Writing 3-band Bastnäsite Index raster → {out_bi}')
        driver = gdal.GetDriverByName('GTiff')
        out_ds = driver.Create(out_bi, n_cols, n_rows, 3, gdal.GDT_Float32,
                               ['COMPRESS=LZW', 'TILED=YES'])
        out_ds.SetGeoTransform(geo)
        out_ds.SetProjection(proj)
        for band_num, (arr, desc) in enumerate([
                (bi1, 'BI1  (threshold ≥ 0.040)'),
                (bi2, 'BI2  (threshold ≥ 0.055)'),
                (bi3, 'BI3  (threshold ≥ 0.221)'),
        ], start=1):
            b = out_ds.GetRasterBand(band_num)
            b.WriteArray(arr)
            b.SetNoDataValue(float('nan'))
            b.SetDescription(desc)
        out_ds.FlushCache()
        out_ds = None
        feedback.setProgress(85)

        # ── Optional threshold mask ───────────────────────────────────────────
        if out_mask:
            feedback.pushInfo(f'Writing REE confirmation mask → {out_mask}')
            mask_ds = driver.Create(out_mask, n_cols, n_rows, 3, gdal.GDT_Float32,
                                    ['COMPRESS=LZW', 'TILED=YES'])
            mask_ds.SetGeoTransform(geo)
            mask_ds.SetProjection(proj)
            for band_num, (arr, thr, desc) in enumerate([
                    (bi1, _THRESH['BI1'], 'BI1 ≥ 0.040  (1=REE confirmed, NaN=below threshold)'),
                    (bi2, _THRESH['BI2'], 'BI2 ≥ 0.055  (1=REE confirmed, NaN=below threshold)'),
                    (bi3, _THRESH['BI3'], 'BI3 ≥ 0.221  (1=REE confirmed, NaN=below threshold)'),
            ], start=1):
                masked = np.where((np.isfinite(arr)) & (arr >= thr),
                                  arr, np.nan).astype(np.float32)
                b = mask_ds.GetRasterBand(band_num)
                b.WriteArray(masked)
                b.SetNoDataValue(float('nan'))
                b.SetDescription(desc)
            mask_ds.FlushCache()
            mask_ds = None

        feedback.setProgress(100)
        feedback.pushInfo('')
        feedback.pushInfo('Bastnäsite Indices complete.')
        feedback.pushInfo('Output bands:')
        feedback.pushInfo('  Band 1 — BI1  (range −1 to +1, threshold 0.040)')
        feedback.pushInfo('  Band 2 — BI2  (range −1 to +1, threshold 0.055)')
        feedback.pushInfo('  Band 3 — BI3  (range −4 to +4, threshold 0.221)')
        feedback.pushInfo('Stretch each band from its threshold to its maximum for display.')
        feedback.pushInfo('A pixel exceeding all three thresholds is a high-confidence REE detection.')

        result = {self.OUTPUT_BI: out_bi}
        if out_mask:
            result[self.OUTPUT_MASK] = out_mask
        return result

    # ── Algorithm metadata ────────────────────────────────────────────────────

    def name(self):        return 'fe_ree_bastnasite'
    def displayName(self): return 'FE-REE-BI  Bastnäsite Indices  (BI1/BI2/BI3)'
    def group(self):       return '7 - Feature Extraction'
    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        preset_rows = ''.join(
            f'<tr><td>{sensor}</td>'
            f'<td>{v["P1"]}</td><td>{v["T1"]}</td>'
            f'<td>{v["P2"]}</td><td>{v["T2"]}</td>'
            f'<td>{v["P3"]}</td><td>{v["T3"]}</td>'
            f'<td>{v["P4"]}</td><td>{v["T4"]}</td>'
            f'<td>{v["P5"]}</td></tr>'
            for sensor, v in _PRESETS.items()
        )
        return WORKFLOW_NOTE + BI_NOTE + f"""
        <b>Feature Extraction — Bastnäsite Indices (REE Detection)</b>

        <p>Implements the three Bastnäsite Indices of <b>Gadea &amp; Khan (2024)</b>
        for detecting rare earth elements (REEs) via four Nd³⁺ absorption features
        in the VNIR (550–930 nm). A pixel exceeding <b>all three thresholds</b>
        (BI1 ≥ 0.040, BI2 ≥ 0.055, BI3 ≥ 0.221) is a high-confidence REE detection.</p>

        <p><b>Absorption features targeted:</b></p>
        <table border="1" cellpadding="3" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Feature</th><th>Peak bands</th><th>Trough</th><th>Mineral target</th>
          </tr>
          <tr><td>~580 nm</td><td>P1, P2</td><td>T1</td>
              <td>Nd³⁺ ⁴G₅/₂ + ⁴G₇/₂  — bastnäsite, monazite</td></tr>
          <tr><td>~740 nm</td><td>P2, P3</td><td>T2</td>
              <td>Nd³⁺ ⁴F₇/₂ + ⁴S₃/₂  — bastnäsite, monazite</td></tr>
          <tr><td>~800 nm</td><td>P3, P4</td><td>T3</td>
              <td>Nd³⁺ ⁴F₅/₂ + ²H₉/₂  — bastnäsite, monazite, xenotime</td></tr>
          <tr><td>~870 nm</td><td>P4, P5</td><td>T4</td>
              <td>Nd³⁺ ⁴F₃/₂  — bastnäsite, monazite, carbonatite</td></tr>
        </table>

        <p><b>Index equations:</b></p>
        <ul>
          <li><b>BI1</b> = [(P1+P2+P3+P4)–(T1+T2+T3+T4)] / [(P1+P2+P3+P4)+(T1+T2+T3+T4)]</li>
          <li><b>BI2</b> = [((P1+P5)/2+P2+P3+P4)–(T1+T2+T3+T4)] / [((P1+P5)/2+P2+P3+P4)+(T1+T2+T3+T4)]</li>
          <li><b>BI3</b> = Σ[(Pi+Pi₊₁)/2–Ti] / [(Pi+Pi₊₁)/2+Ti]  for i=1..4</li>
        </ul>

        <p><b>Output:</b></p>
        <ul>
          <li><b>3-band BI raster</b> — Band 1=BI1, Band 2=BI2, Band 3=BI3.
              Stretch each band from its threshold value to its maximum for display.</li>
          <li><b>REE confirmation mask</b> (optional) — pixels above each threshold
              retain their BI value; sub-threshold pixels are set to NaN.</li>
        </ul>

        <p><b>Sensor wavelength presets (Table 1, Gadea et al. 2024) — nm:</b></p>
        <table border="1" cellpadding="3" cellspacing="0" width="100%" style="font-size:8pt;">
          <tr style="background:#1B3A5C; color:white">
            <th>Sensor</th>
            <th>P1</th><th>T1</th><th>P2</th><th>T2</th>
            <th>P3</th><th>T3</th><th>P4</th><th>T4</th><th>P5</th>
          </tr>
          {preset_rows}
        </table>

        <p><b>Usage notes:</b></p>
        <ul>
          <li>Set the nine wavelength parameters to match your sensor's Table 1 values.
              The defaults are AVIRIS-NG (4.1 m, the highest-resolution sensor in the study).</li>
          <li>All three indices must exceed their confirmation thresholds simultaneously
              for a high-confidence REE detection. BI2 is considered the most reliable
              (least susceptible to false positives from vegetation or dark pixels).</li>
          <li>Absorption features are shallow (&lt;5 % depth) — good atmospheric
              correction (e.g. QUAC or ATCOR) and noise reduction (MNF) are essential.</li>
          <li>The ~580 nm feature (T1) can be partially masked by ferric iron absorption.
              Check the 740 and 870 nm features as confirmatory evidence.</li>
          <li>Minimum detectable REE ore grade: ~3.25 wt% (Gadea et al. 2024).</li>
        </ul>

        <p><b>Reference:</b><br/>
        Gadea, O.C.A.; Khan, S.D. (2024). Identification of a Potential Rare Earth
        Element Deposit at Ivanpah Dry Lake, California Through the Bastnäsite Indices.
        <i>Remote Sens.</i>, 16, 4540.
        <a href="https://doi.org/10.3390/rs16234540">doi:10.3390/rs16234540</a><br/>
        Gadea, O.C.A.; Khan, S.D.; Sisson, V.B. (2024). Estimating rare earth elements
        at various scales with Bastnäsite Indices for Mountain Pass.
        <i>Ore Geol. Rev.</i>, 173, 106254.</p>
        """

    def createInstance(self):
        return FeReeBastanasiteAlgorithm()
