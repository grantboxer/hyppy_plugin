"""
DT Sulphate Group Classification Algorithm for QGIS Processing

Classifies pixels into the three SWIR-active sulphate minerals:
  Alunite   (K,Na)Al3(SO4)2(OH)6
  Jarosite  KFe3(SO4)2(OH)6
  Gypsum    CaSO4·2H2O

Based on USGS GMEX reference spectra (AusSpec International 2005).

============================  SPECTRAL LOGIC  ================================

ALUNITE
  Diagnostic:  ~1436–1440 nm (OH doublet short-wave component)
               ~1474–1480 nm (OH doublet long-wave component)
               ~1760 nm      (SO4 / OH combination)
               ~2160–2170 nm (Al-OH; broader than pyrophyllite)
               ~2324 nm      (persists in mixtures with pyrophyllite/kandite)
  Key test:    doublet at 1474–1480 distinguishes from kaolinite and pyrophyllite.
               The ~1760 nm feature is very characteristic. At ~2160–2170 nm alunite
               overlaps with pyrophyllite — use the 1474–1480 doublet to separate.

JAROSITE
  Diagnostic:  ~1468–1477 nm (FeOH doublet component 1 — shape & wavelength key)
               ~1512–1544 nm (FeOH doublet component 2)
               ~1844–1855 nm (FeOH combination)
               ~2206 nm      (diagnostic single absorption)
               ~2262–2277 nm (usually persists in mixtures)
  Key test:    The 1468+1512 FeOH doublet is unlike any clay — unique shape.
               The ~2262–2277 nm feature is the most reliable mixture indicator.
               No Al-OH feature in the 2160–2200 nm region (unlike alunite).

GYPSUM
  Diagnostic:  ~1449 nm  (H2O combination)
               ~1490 nm  (H2O combination)
               ~1535 nm  (H2O combination — three-band water signature)
               ~1750 nm  (OH feature)
               ~1948 nm  (H2O; wavelength position distinctive even in minor gypsum)
               ~2215 nm  (weak; may not persist in mixtures)
  Key test:    Triple water absorptions at 1449/1490/1535 nm are unique to gypsum.
               The 1948 nm water band wavelength position is diagnostic even when
               only minor gypsum is present. No strong 2200+ nm Al-OH feature.

============================  DECISION TREE  =================================

Step 1 — GATE: Does the pixel have any SWIR sulphate activity?
  Uses the 1440–1550 nm WoM (covers all three sulphate OH/water doublets).
  depth(1440–1550) <= gate_threshold  ->  aspectral

Step 2 — JAROSITE CHECK: Is there a FeOH doublet at ~1468–1544 nm?
  The jarosite FeOH doublet sits at 1468–1477 + 1512–1544 nm — longward of
  the alunite OH doublet (1436–1480 nm) and gypsum water (1449–1535 nm).
  wl_min(1440–1550) >= 1465:
    depth(2262–2277) > jarosite_2270_threshold  ->  jarosite
    else                                         ->  possible_jarosite

Step 3 — GYPSUM CHECK: Is there a diagnostic water feature at ~1948 nm?
  Gypsum has a unique 1948 nm water absorption not seen in sulphate clays.
  depth(1900–1970) > gypsum_water_threshold:
    wl_min(1900–1970) in [1930, 1965]            ->  gypsum
    else                                          ->  possible_gypsum

Step 4 — ALUNITE CHECK: Is there a 1474–1480 nm OH doublet + 1760 nm SO4?
  depth(1440–1550) > alunite_threshold
  AND wl_min(1440–1550) in [1462, 1488]:
    depth(1730–1790) > alunite_1760_threshold    ->  alunite
    else                                          ->  possible_alunite

Step 5 — Unclassified sulphate activity
  ->  other_sulphate

============================  INPUTS  ========================================
  WoM_1440_1550  — WoM over 1440–1550 nm  (Band 1=wavelength, Band 2=depth)
                   Covers the key OH/H2O doublet region for all three minerals.
  WoM_1730_1790  — WoM over 1730–1790 nm  (Band 2=depth of ~1760 nm SO4/OH)
                   Use the fe_1760w WoM output or a custom WoM in this range.
  WoM_1900_1970  — WoM over 1900–1970 nm  (Band 1=wavelength, Band 2=depth)
                   Targets the gypsum 1948 nm water feature.
  WoM_2262_2277  — WoM over 2240–2300 nm  (Band 2=depth of ~2262–2277 nm)
                   Use FE14-2250W or FE15-2290W output for the jarosite indicator.

============================  THRESHOLDS  ====================================
  gate_threshold         — min depth(1440–1550) to attempt classification (0.03)
  jarosite_2270_threshold — min depth(2262–2277) to confirm jarosite (0.03)
  gypsum_water_threshold  — min depth(1900–1970) to detect gypsum water (0.05)
  alunite_1760_threshold  — min depth(1730–1790) to confirm alunite (0.02)

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)


SULPHATE_CLASSES = [
    (0,  'unclassified',      0,   0,   0  ),
    (1,  'aspectral',         0,   0,   0  ),   # black
    (2,  'other_sulphate',    180, 180, 180),   # grey
    (3,  'possible_alunite',  255, 220, 120),   # pale yellow
    (4,  'alunite',           255, 180,   0),   # amber
    (5,  'possible_jarosite', 220, 120,  80),   # pale orange-brown
    (6,  'jarosite',          180,  60,   0),   # dark orange-brown
    (7,  'possible_gypsum',   180, 220, 255),   # pale blue
    (8,  'gypsum',              0, 160, 255),   # blue
]
NAME_TO_ID = {m[1]: m[0] for m in SULPHATE_CLASSES}
ID_TO_NAME = {m[0]: m[1] for m in SULPHATE_CLASSES}
ID_TO_RGB  = {m[0]: (m[2], m[3], m[4]) for m in SULPHATE_CLASSES}

# Wavelength windows (nm)
JAROSITE_WL_MIN   = 1465.0   # longward shift of FeOH doublet vs alunite OH doublet
JAROSITE_WL_MAX   = 1550.0
GYPSUM_WATER_MIN  = 1930.0   # 1948 nm water band window
GYPSUM_WATER_MAX  = 1965.0
ALUNITE_WL_MIN    = 1462.0   # alunite OH long-wave doublet component ~1474–1480
ALUNITE_WL_MAX    = 1488.0


def classify_pixel(wl_1550, d_1550, d_1760, wl_1950, d_1950, d_2270,
                   gate_thr, jaro_thr, gyp_thr, alun_thr):
    """
    Classify a single pixel into a sulphate mineral class.

    Parameters
    ----------
    wl_1550  : float  wavelength of minimum in 1440–1550 nm (WoM Band 1)
    d_1550   : float  depth of minimum in 1440–1550 nm     (WoM Band 2)
    d_1760   : float  depth of minimum in 1730–1790 nm     (WoM Band 2)
    wl_1950  : float  wavelength of minimum in 1900–1970 nm (WoM Band 1)
    d_1950   : float  depth of minimum in 1900–1970 nm     (WoM Band 2)
    d_2270   : float  depth of minimum in 2240–2300 nm     (WoM Band 2)
    gate_thr : float  gate depth threshold
    jaro_thr : float  jarosite 2270 nm depth threshold
    gyp_thr  : float  gypsum 1950 nm water depth threshold
    alun_thr : float  alunite 1760 nm depth threshold

    Returns
    -------
    int  class id
    """
    if d_1550 <= gate_thr:
        return NAME_TO_ID['aspectral']

    # --- Step 2: Jarosite — FeOH doublet longward of alunite/gypsum range
    if wl_1550 >= JAROSITE_WL_MIN:
        if d_2270 > jaro_thr:
            return NAME_TO_ID['jarosite']
        return NAME_TO_ID['possible_jarosite']

    # --- Step 3: Gypsum — unique 1948 nm water band
    if d_1950 > gyp_thr and GYPSUM_WATER_MIN <= wl_1950 <= GYPSUM_WATER_MAX:
        return NAME_TO_ID['gypsum']
    if d_1950 > gyp_thr:
        return NAME_TO_ID['possible_gypsum']

    # --- Step 4: Alunite — 1474–1480 nm OH doublet + 1760 nm SO4
    if ALUNITE_WL_MIN <= wl_1550 <= ALUNITE_WL_MAX:
        if d_1760 > alun_thr:
            return NAME_TO_ID['alunite']
        return NAME_TO_ID['possible_alunite']

    return NAME_TO_ID['other_sulphate']


class DtSulphateAlgorithm(QgsProcessingAlgorithm):

    WOM_1440_1550  = 'WOM_1440_1550'
    WOM_1730_1790  = 'WOM_1730_1790'
    WOM_1900_1970  = 'WOM_1900_1970'
    WOM_2240_2300  = 'WOM_2240_2300'
    GATE_THRESHOLD  = 'GATE_THRESHOLD'
    JARO_THRESHOLD  = 'JARO_THRESHOLD'
    GYPS_THRESHOLD  = 'GYPS_THRESHOLD'
    ALUN_THRESHOLD  = 'ALUN_THRESHOLD'
    OUTPUT_CLASS   = 'OUTPUT_CLASS'
    OUTPUT_RGB     = 'OUTPUT_RGB'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_1440_1550,
            'WoM 1440–1550 nm (Band 1=wavelength, Band 2=depth) — use FE-WOM-1440-1520 or custom'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_1730_1790,
            'WoM 1730–1790 nm (Band 2=depth of ~1760 nm SO4/OH) — use FE06-1760W WoM'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_1900_1970,
            'WoM 1900–1970 nm (Band 1=wavelength, Band 2=depth) — use FE07-1900W WoM'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2240_2300,
            'WoM 2240–2300 nm (Band 2=depth of ~2262–2277 nm) — use FE14-2250W or FE15-2290W'))
        self.addParameter(QgsProcessingParameterNumber(
            self.GATE_THRESHOLD,
            'Gate depth threshold — pixels with depth(1440–1550) <= this are aspectral',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.03, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.JARO_THRESHOLD,
            'Jarosite: min depth(2262–2277 nm) to confirm jarosite (vs possible_jarosite)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.03, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.GYPS_THRESHOLD,
            'Gypsum: min depth(1900–1970 nm) water band to detect gypsum',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.05, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.ALUN_THRESHOLD,
            'Alunite: min depth(1730–1790 nm) SO4/OH feature to confirm alunite',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.02, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_CLASS, 'Output class raster (integer class IDs)'))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_RGB,   'Output RGB colour raster'))

    def processAlgorithm(self, parameters, context, feedback):
        lyr_1550 = self.parameterAsRasterLayer(parameters, self.WOM_1440_1550, context)
        lyr_1760 = self.parameterAsRasterLayer(parameters, self.WOM_1730_1790, context)
        lyr_1950 = self.parameterAsRasterLayer(parameters, self.WOM_1900_1970, context)
        lyr_2270 = self.parameterAsRasterLayer(parameters, self.WOM_2240_2300, context)
        gate_thr = self.parameterAsDouble(parameters, self.GATE_THRESHOLD, context)
        jaro_thr = self.parameterAsDouble(parameters, self.JARO_THRESHOLD, context)
        gyp_thr  = self.parameterAsDouble(parameters, self.GYPS_THRESHOLD, context)
        alun_thr = self.parameterAsDouble(parameters, self.ALUN_THRESHOLD, context)
        out_cls  = self.parameterAsOutputLayer(parameters, self.OUTPUT_CLASS, context)
        out_rgb  = self.parameterAsOutputLayer(parameters, self.OUTPUT_RGB, context)

        # Open datasets
        ds1550 = gdal.Open(lyr_1550.source())
        ds1760 = gdal.Open(lyr_1760.source())
        ds1950 = gdal.Open(lyr_1950.source())
        ds2270 = gdal.Open(lyr_2270.source())

        if ds1550 is None:
            raise QgsProcessingException('Cannot open WoM 1440–1550 nm raster')

        cols = ds1550.RasterXSize
        rows = ds1550.RasterYSize
        gt   = ds1550.GetGeoTransform()
        prj  = ds1550.GetProjection()

        feedback.pushInfo(f'Grid: {cols} x {rows}')
        feedback.pushInfo(f'Thresholds — gate={gate_thr}, jarosite={jaro_thr}, '
                          f'gypsum={gyp_thr}, alunite={alun_thr}')

        # Read bands
        wl_1550_arr = ds1550.GetRasterBand(1).ReadAsArray().astype(np.float32)
        d_1550_arr  = ds1550.GetRasterBand(2).ReadAsArray().astype(np.float32)
        d_1760_arr  = ds1760.GetRasterBand(2).ReadAsArray().astype(np.float32) if ds1760 else np.zeros_like(d_1550_arr)
        wl_1950_arr = ds1950.GetRasterBand(1).ReadAsArray().astype(np.float32) if ds1950 else np.zeros_like(d_1550_arr)
        d_1950_arr  = ds1950.GetRasterBand(2).ReadAsArray().astype(np.float32) if ds1950 else np.zeros_like(d_1550_arr)
        d_2270_arr  = ds2270.GetRasterBand(2).ReadAsArray().astype(np.float32) if ds2270 else np.zeros_like(d_1550_arr)

        # Replace NaN
        for arr in [wl_1550_arr, d_1550_arr, d_1760_arr, wl_1950_arr, d_1950_arr, d_2270_arr]:
            np.nan_to_num(arr, copy=False, nan=0.0)

        feedback.pushInfo('Classifying pixels ...')

        # Vectorised classification
        cls = np.zeros((rows, cols), dtype=np.uint8)

        # Aspectral gate
        cls[:] = NAME_TO_ID['aspectral']
        active = d_1550_arr > gate_thr

        # Jarosite: wl >= JAROSITE_WL_MIN
        mask_jaro_wl = active & (wl_1550_arr >= JAROSITE_WL_MIN)
        cls[mask_jaro_wl & (d_2270_arr > jaro_thr)]  = NAME_TO_ID['jarosite']
        cls[mask_jaro_wl & (d_2270_arr <= jaro_thr)] = NAME_TO_ID['possible_jarosite']

        # Gypsum: wl < JAROSITE_WL_MIN, deep 1948 nm water band in window
        remain = active & (wl_1550_arr < JAROSITE_WL_MIN)
        gyp_water = (wl_1950_arr >= GYPSUM_WATER_MIN) & (wl_1950_arr <= GYPSUM_WATER_MAX)
        cls[remain & (d_1950_arr > gyp_thr) & gyp_water] = NAME_TO_ID['gypsum']
        cls[remain & (d_1950_arr > gyp_thr) & ~gyp_water] = NAME_TO_ID['possible_gypsum']

        # Alunite: not jarosite/gypsum, wl in alunite OH doublet window
        remain2 = remain & (cls == NAME_TO_ID['aspectral']) | (
            remain & ~(d_1950_arr > gyp_thr))
        alun_wl = (wl_1550_arr >= ALUNITE_WL_MIN) & (wl_1550_arr <= ALUNITE_WL_MAX)
        # Re-derive cleanly
        not_jarosite_gypsum = active & (cls == NAME_TO_ID['aspectral'])
        cls[not_jarosite_gypsum & alun_wl & (d_1760_arr > alun_thr)] = NAME_TO_ID['alunite']
        cls[not_jarosite_gypsum & alun_wl & (d_1760_arr <= alun_thr)] = NAME_TO_ID['possible_alunite']

        # Remaining active but unclassified
        still_unclassed = active & (cls == NAME_TO_ID['aspectral'])
        cls[still_unclassed] = NAME_TO_ID['other_sulphate']

        feedback.pushInfo('Writing class raster ...')
        drv = gdal.GetDriverByName('GTiff')
        ds_out = drv.Create(out_cls, cols, rows, 1, gdal.GDT_Byte,
                            options=['COMPRESS=LZW', 'TILED=YES'])
        ds_out.SetGeoTransform(gt)
        ds_out.SetProjection(prj)
        b = ds_out.GetRasterBand(1)
        b.WriteArray(cls)
        b.SetNoDataValue(0)
        # Colour table
        ct = gdal.ColorTable()
        for cid, name, r, g, bv in SULPHATE_CLASSES:
            ct.SetColorEntry(cid, (r, g, bv, 255))
        b.SetColorTable(ct)
        b.SetCategoryNames([m[1] for m in SULPHATE_CLASSES])
        ds_out.FlushCache()
        ds_out = None

        # Build RGB raster
        feedback.pushInfo('Writing RGB raster ...')
        r_arr = np.zeros((rows, cols), dtype=np.uint8)
        g_arr = np.zeros((rows, cols), dtype=np.uint8)
        bv_arr = np.zeros((rows, cols), dtype=np.uint8)
        for cid, _, r, g, bv in SULPHATE_CLASSES:
            mask = cls == cid
            r_arr[mask] = r
            g_arr[mask] = g
            bv_arr[mask] = bv

        ds_rgb = drv.Create(out_rgb, cols, rows, 3, gdal.GDT_Byte,
                            options=['COMPRESS=LZW', 'TILED=YES'])
        ds_rgb.SetGeoTransform(gt)
        ds_rgb.SetProjection(prj)
        ds_rgb.GetRasterBand(1).WriteArray(r_arr)
        ds_rgb.GetRasterBand(2).WriteArray(g_arr)
        ds_rgb.GetRasterBand(3).WriteArray(bv_arr)
        ds_rgb.FlushCache()
        ds_rgb = None

        # Stats
        total = rows * cols
        feedback.pushInfo('--- Classification summary ---')
        for cid, name, _, _, _ in SULPHATE_CLASSES:
            n = int(np.sum(cls == cid))
            if n > 0:
                feedback.pushInfo(f'  {name:<22s}: {n:>9,d}  ({100*n/total:.2f}%)')

        feedback.setProgress(100)
        return {self.OUTPUT_CLASS: out_cls, self.OUTPUT_RGB: out_rgb}

    def postProcessAlgorithm(self, context, feedback):
        return {}

    def name(self):        return 'dt_sulphate'
    def displayName(self): return 'DT Sulphate Group'
    def group(self):       return '4 - Decision Tree Classification'
    def groupId(self):     return '4_decision_tree'

    def shortHelpString(self):
        return """
        <b>DT Sulphate Group Classification</b>

        <p>Classifies pixels into the three SWIR-active sulphate minerals using
        USGS GMEX reference spectral features (AusSpec International 2005):</p>

        <ul>
          <li><b>Alunite</b> (K,Na)Al₃(SO₄)₂(OH)₆ — OH doublet ~1436/1474–1480 nm,
              SO₄ ~1760 nm, Al-OH ~2160–2170 nm, persists at ~2324 nm</li>
          <li><b>Jarosite</b> KFe₃(SO₄)₂(OH)₆ — unique FeOH doublet ~1468–1477 +
              1512–1544 nm, diagnostic ~2206 nm, persists at ~2262–2277 nm</li>
          <li><b>Gypsum</b> CaSO₄·2H₂O — triple water absorptions ~1449/1490/1535 nm,
              diagnostic ~1948 nm water band wavelength position, ~2215 nm</li>
        </ul>

        <p><b>Decision logic (GMEX-based):</b></p>
        <ol>
          <li><b>Gate:</b> depth(1440–1550 nm) ≤ threshold → aspectral</li>
          <li><b>Jarosite:</b> WoM minimum at ≥ 1465 nm (FeOH doublet longward of
              alunite/gypsum OH/water absorptions). Confirmed by ~2262–2277 nm depth.</li>
          <li><b>Gypsum:</b> Deep 1900–1970 nm water absorption with minimum at
              1930–1965 nm (the distinctive gypsum 1948 nm band).</li>
          <li><b>Alunite:</b> WoM minimum at 1462–1488 nm (long-wave OH doublet
              component) + 1730–1790 nm SO₄/OH feature confirmation.</li>
          <li><b>Other sulphate:</b> active but unclassified.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Class</th><th>ID</th><th>Colour</th>
          </tr>
          <tr><td>aspectral</td><td>1</td><td style="background:#000">black</td></tr>
          <tr><td>other_sulphate</td><td>2</td><td style="background:#b4b4b4">grey</td></tr>
          <tr><td>possible_alunite</td><td>3</td><td style="background:#ffdc78">pale yellow</td></tr>
          <tr><td>alunite</td><td>4</td><td style="background:#ffb400">amber</td></tr>
          <tr><td>possible_jarosite</td><td>5</td><td style="background:#dc7850">pale orange-brown</td></tr>
          <tr><td>jarosite</td><td>6</td><td style="background:#b43c00">dark orange-brown</td></tr>
          <tr><td>possible_gypsum</td><td>7</td><td style="background:#b4dcff">pale blue</td></tr>
          <tr><td>gypsum</td><td>8</td><td style="background:#00a0ff">blue</td></tr>
        </table>

        <p><b>Inputs required:</b></p>
        <ul>
          <li>WoM 1440–1550 nm — run <i>FE-WOM-1440-1520</i> or Wavelength of Minimum
              with range 1440–1550 nm</li>
          <li>WoM 1730–1790 nm — run <i>FE06-1760W</i> WoM output</li>
          <li>WoM 1900–1970 nm — run <i>FE07-1900W</i> WoM output</li>
          <li>WoM 2240–2300 nm — run <i>FE14-2250W</i> or <i>FE15-2290W</i> WoM output</li>
        </ul>

        <p><i>Spectral features from USGS GMEX Spectral Library (AusSpec International 2005),
        alunite, jarosite and gypsum entries. Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return DtSulphateAlgorithm()
