"""
DT Kaolinite Crystallinity Classification Algorithm for QGIS Processing

Classifies kaolinite pixels by crystallinity using the 2162/2206 nm
depth ratio derived from the USGS GMEX kaolinite2 reference spectrum.

From GMEX kaolinite2 (USGS Spectral Library):
  The 2162/2206 nm pair is described as the "Diagnostic double absorption.
  Note different wavelengths compared to Dickite. Variations in crystallinity
  affect this doublet."  The 2162 nm feature is "characteristic 3 absorptions
  of kaolinite spectra."

  Well-ordered (highly crystalline) kaolinite shows a deep, sharp 2162 nm
  shoulder relative to 2206 nm.  Disordered kaolinite (and halloysite)
  shows a shallow or absent 2162 nm feature — described in GMEX as "this
  absorption may be seen as an inflection or weak absorption in poorly
  crystalline kaolinite and in mixtures."

  Crystallinity Index (CI) = depth(2162) / depth(2206)
    CI > 0.6  -> well-ordered kaolinite (kaol_hi)
    CI > 0.4  -> moderately ordered kaolinite (kaol_med)
    CI > 0.2  -> poorly ordered kaolinite (kaol_lo)
    CI <= 0.2 -> disordered / halloysite / dickite-type (kaol_dis)

Inputs:
  WoM_2160  - WoM raster from FE5-2160D (2138-2179 nm)
               Band 1 = wavelength, Band 2 = depth of 2162 nm feature
  WoM_2206  - WoM raster from FE12-2206W (2162-2245 nm)
               Band 1 = wavelength, Band 2 = depth of 2206 nm feature
  depth_threshold - minimum depth(2206) to be classed as 'kaolinite present'

Decision tree:
  depth(2206) <= threshold        -> aspectral (no Al-OH)
  wavelength(2206) not in
    (2197, 2215]                  -> not_kaol  (illite / smectite / other)
  CI = depth(2162) / depth(2206):
    CI > 0.6  -> kaol_hi   (well-ordered)
    CI > 0.4  -> kaol_med  (moderately ordered)
    CI > 0.2  -> kaol_lo   (poorly ordered)
    CI <= 0.2 -> kaol_dis  (disordered / halloysite-like)

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

import numpy as np
from osgeo import gdal
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

KAOL_CRYST_CLASSES = [
    (0,  'unclassified', 0,   0,   0  ),
    (1,  'aspectral',    0,   0,   0  ),   # black
    (2,  'not_kaol',     128, 128, 128),   # grey
    (3,  'kaol_dis',     255, 230, 100),   # pale yellow — disordered
    (4,  'kaol_lo',      200, 255, 100),   # yellow-green — poorly ordered
    (5,  'kaol_med',     0,   200,  80),   # mid green — moderately ordered
    (6,  'kaol_hi',      0,   100,   0),   # dark green — well-ordered
]
NAME_TO_ID = {m[1]: m[0] for m in KAOL_CRYST_CLASSES}
ID_TO_NAME = {m[0]: m[1] for m in KAOL_CRYST_CLASSES}

# Kaolinite wavelength window for 2206 nm band (nm)
KAOL_WL_MIN = 2197.0
KAOL_WL_MAX = 2215.0

# Crystallinity index thresholds (depth_2162 / depth_2206)
CI_HI  = 0.6
CI_MED = 0.4
CI_LO  = 0.2


def classify_pixel(depth_2206, wl_2206, depth_2162, threshold):
    """Classify a single pixel by kaolinite crystallinity."""
    if depth_2206 <= threshold:
        return NAME_TO_ID['aspectral']
    if not (KAOL_WL_MIN < wl_2206 <= KAOL_WL_MAX):
        return NAME_TO_ID['not_kaol']
    # Compute crystallinity index — guard against division by zero
    if depth_2206 < 1e-6:
        return NAME_TO_ID['kaol_dis']
    ci = depth_2162 / depth_2206
    if ci > CI_HI:
        return NAME_TO_ID['kaol_hi']
    if ci > CI_MED:
        return NAME_TO_ID['kaol_med']
    if ci > CI_LO:
        return NAME_TO_ID['kaol_lo']
    return NAME_TO_ID['kaol_dis']


class DtKaolCrystAlgorithm(QgsProcessingAlgorithm):

    WOM_2160      = 'WOM_2160'
    WOM_2206      = 'WOM_2206'
    DEPTH_THRESH  = 'DEPTH_THRESH'
    OUTPUT_CLASS  = 'OUTPUT_CLASS'
    OUTPUT_RGB    = 'OUTPUT_RGB'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2206,
            'WoM 2206 raster — FE12-2206W output  (Band 1=wavelength, Band 2=depth)'))

        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2160,
            'WoM 2160 raster — FE5-2160D output  (Band 2=depth of 2162 nm feature)'))

        self.addParameter(QgsProcessingParameterNumber(
            self.DEPTH_THRESH,
            'Minimum depth(2206) to classify as kaolinite present',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.05, minValue=0.0, maxValue=1.0))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_CLASS, 'Output: Kaolinite Crystallinity class raster'))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_RGB, 'Output: Kaolinite Crystallinity RGB raster',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        wom_2206_layer = self.parameterAsRasterLayer(parameters, self.WOM_2206,     context)
        wom_2160_layer = self.parameterAsRasterLayer(parameters, self.WOM_2160,     context)
        depth_thresh   = self.parameterAsDouble     (parameters, self.DEPTH_THRESH, context)
        out_class      = self.parameterAsOutputLayer(parameters, self.OUTPUT_CLASS, context)
        out_rgb        = self.parameterAsOutputLayer(parameters, self.OUTPUT_RGB,   context) \
                         if self.OUTPUT_RGB in parameters else None

        # ── Open WoM 2206 raster ─────────────────────────────────────────
        ds_2206 = gdal.Open(wom_2206_layer.source(), gdal.GA_ReadOnly)
        if ds_2206 is None:
            raise QgsProcessingException('Cannot open WoM 2206 raster')
        cols, rows = ds_2206.RasterXSize, ds_2206.RasterYSize
        if ds_2206.RasterCount < 2:
            raise QgsProcessingException(
                'WoM 2206 raster needs >= 2 bands (Band1=wavelength, Band2=depth)')

        feedback.pushInfo(f'WoM 2206 raster: {cols} x {rows}, {ds_2206.RasterCount} bands')
        feedback.pushInfo('Reading WoM 2206 Band 1 — primary wavelength...')
        wl_2206    = ds_2206.GetRasterBand(1).ReadAsArray().astype(np.float32)
        feedback.pushInfo('Reading WoM 2206 Band 2 — feature depth...')
        depth_2206 = ds_2206.GetRasterBand(2).ReadAsArray().astype(np.float32)

        # ── Open WoM 2160 raster ─────────────────────────────────────────
        ds_2160 = gdal.Open(wom_2160_layer.source(), gdal.GA_ReadOnly)
        if ds_2160 is None:
            raise QgsProcessingException('Cannot open WoM 2160 raster')
        if ds_2160.RasterXSize != cols or ds_2160.RasterYSize != rows:
            raise QgsProcessingException(
                f'WoM 2160 raster size ({ds_2160.RasterXSize}x{ds_2160.RasterYSize}) '
                f'does not match WoM 2206 size ({cols}x{rows})')
        if ds_2160.RasterCount < 2:
            raise QgsProcessingException(
                'WoM 2160 raster needs >= 2 bands (Band1=wavelength, Band2=depth)')

        feedback.pushInfo('Reading WoM 2160 Band 2 — depth of 2162 nm feature...')
        depth_2162 = ds_2160.GetRasterBand(2).ReadAsArray().astype(np.float32)
        ds_2160 = None

        # ── Classify ─────────────────────────────────────────────────────
        feedback.pushInfo(f'Depth threshold: depth_2206 > {depth_thresh} = kaolinite present')
        feedback.pushInfo(f'Kaolinite wavelength window: {KAOL_WL_MIN}-{KAOL_WL_MAX} nm')
        feedback.pushInfo(f'Crystallinity index thresholds: CI_hi={CI_HI}, CI_med={CI_MED}, CI_lo={CI_LO}')
        feedback.pushInfo('Applying kaolinite crystallinity decision tree...')
        feedback.setProgress(20)

        nodata = np.isnan(wl_2206) | np.isnan(depth_2206) | np.isnan(depth_2162)

        wl_2206s    = np.nan_to_num(wl_2206,    nan=0.0)
        depth_2206s = np.nan_to_num(depth_2206, nan=0.0)
        depth_2162s = np.nan_to_num(depth_2162, nan=0.0)

        # Vectorised classification
        class_data = np.zeros((rows, cols), dtype=np.uint8)

        # aspectral
        mask_asp = depth_2206s <= depth_thresh
        class_data[mask_asp] = NAME_TO_ID['aspectral']

        # not kaolinite (wrong wavelength)
        mask_kaol_range = (~mask_asp) & (
            (wl_2206s <= KAOL_WL_MIN) | (wl_2206s > KAOL_WL_MAX))
        class_data[mask_kaol_range] = NAME_TO_ID['not_kaol']

        # kaolinite pixels — compute CI
        mask_kaol = (~mask_asp) & (~mask_kaol_range)
        ci = np.where(depth_2206s > 1e-6, depth_2162s / depth_2206s, 0.0)

        class_data[mask_kaol & (ci >  CI_HI )] = NAME_TO_ID['kaol_hi']
        class_data[mask_kaol & (ci <= CI_HI)
                              & (ci >  CI_MED)] = NAME_TO_ID['kaol_med']
        class_data[mask_kaol & (ci <= CI_MED)
                              & (ci >  CI_LO )] = NAME_TO_ID['kaol_lo']
        class_data[mask_kaol & (ci <= CI_LO )]  = NAME_TO_ID['kaol_dis']

        class_data[nodata]         = 0
        class_data[wl_2206s == 0]  = 0
        feedback.setProgress(70)

        # ── Summary ──────────────────────────────────────────────────────
        feedback.pushInfo('')
        feedback.pushInfo('Classification summary:')
        unique, counts = np.unique(class_data, return_counts=True)
        total = class_data.size
        for uid, cnt in zip(unique, counts):
            pct = 100.0 * cnt / total
            feedback.pushInfo(
                f'  {ID_TO_NAME.get(int(uid), "?"):15s}  (id={uid:2d})  {cnt:8d} px  {pct:5.1f}%')

        # ── Crystallinity index statistics for kaolinite pixels ───────────
        if mask_kaol.any():
            ci_kaol = ci[mask_kaol]
            feedback.pushInfo('')
            feedback.pushInfo(f'Crystallinity index (kaolinite pixels):')
            feedback.pushInfo(f'  min={ci_kaol.min():.3f}  max={ci_kaol.max():.3f}  '
                              f'mean={ci_kaol.mean():.3f}  median={np.median(ci_kaol):.3f}')

        driver = gdal.GetDriverByName('GTiff')

        # ── Class raster ─────────────────────────────────────────────────
        feedback.pushInfo('Writing integer class raster...')
        ct = gdal.ColorTable()
        for mid, name, r, g, bv in KAOL_CRYST_CLASSES:
            ct.SetColorEntry(mid, (r, g, bv, 255))

        class_ds = driver.Create(out_class, cols, rows, 1, gdal.GDT_Byte,
                                 options=['COMPRESS=LZW', 'TILED=YES'])
        class_ds.SetGeoTransform(ds_2206.GetGeoTransform())
        class_ds.SetProjection(ds_2206.GetProjection())
        b = class_ds.GetRasterBand(1)
        b.SetNoDataValue(0)
        b.SetDescription('Kaolinite Crystallinity Class')
        b.SetRasterColorTable(ct)
        b.SetRasterColorInterpretation(gdal.GCI_PaletteIndex)
        b.WriteArray(class_data)
        b.FlushCache()

        # Raster Attribute Table
        rat = gdal.RasterAttributeTable()
        rat.CreateColumn('Value', gdal.GFT_Integer, gdal.GFU_MinMax)
        rat.CreateColumn('Class', gdal.GFT_String,  gdal.GFU_Name)
        rat.CreateColumn('R',     gdal.GFT_Integer, gdal.GFU_Red)
        rat.CreateColumn('G',     gdal.GFT_Integer, gdal.GFU_Green)
        rat.CreateColumn('B',     gdal.GFT_Integer, gdal.GFU_Blue)
        for row_idx, (mid, name, r, g, bv) in enumerate(KAOL_CRYST_CLASSES):
            rat.SetValueAsInt   (row_idx, 0, mid)
            rat.SetValueAsString(row_idx, 1, name)
            rat.SetValueAsInt   (row_idx, 2, r)
            rat.SetValueAsInt   (row_idx, 3, g)
            rat.SetValueAsInt   (row_idx, 4, bv)
        b.SetDefaultRAT(rat)
        class_ds = None
        result = {self.OUTPUT_CLASS: out_class}

        # ── Optional RGB raster ───────────────────────────────────────────
        if out_rgb:
            feedback.pushInfo('Writing RGB colour raster...')
            rgb_r = np.zeros((rows, cols), dtype=np.uint8)
            rgb_g = np.zeros((rows, cols), dtype=np.uint8)
            rgb_b = np.zeros((rows, cols), dtype=np.uint8)
            for mid, name, r, g, bv in KAOL_CRYST_CLASSES:
                mask = class_data == mid
                rgb_r[mask], rgb_g[mask], rgb_b[mask] = r, g, bv
            rgb_ds = driver.Create(out_rgb, cols, rows, 3, gdal.GDT_Byte,
                                   options=['COMPRESS=LZW', 'TILED=YES'])
            rgb_ds.SetGeoTransform(ds_2206.GetGeoTransform())
            rgb_ds.SetProjection(ds_2206.GetProjection())
            for idx, (arr, lbl) in enumerate(
                    [(rgb_r, 'Red'), (rgb_g, 'Green'), (rgb_b, 'Blue')], 1):
                band = rgb_ds.GetRasterBand(idx)
                band.WriteArray(arr)
                band.SetDescription(lbl)
                band.FlushCache()
            rgb_ds = None
            feedback.setProgress(92)
            result[self.OUTPUT_RGB] = out_rgb

        ds_2206 = None
        feedback.setProgress(100)
        feedback.pushInfo('DT Kaolinite Crystallinity classification complete.')
        return result

    def name(self):        return 'dt_kaol_cryst'
    def displayName(self): return 'DT Kaol-Cryst Classification'
    def group(self):       return '4 - Decision Tree Classification'
    def groupId(self):     return '4_decision_tree'

    def shortHelpString(self):
        return """
        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Outputs from <b>FE5-2160D</b> and <b>FE12-2206W</b>.<br/>
        Run both Feature Extraction tools first, then use their WoM rasters as inputs here.
        </p>

        <b>DT Kaolinite Crystallinity Classification</b>

        <p>Classifies kaolinite pixels by crystallinity order using the
        <b>2162/2206 nm depth ratio</b> (Crystallinity Index, CI), derived from the
        USGS GMEX kaolinite2 reference spectrum.</p>

        <p><b>Scientific basis (GMEX kaolinite2):</b><br/>
        The 2162/2206 nm doublet is described as the
        "characteristic 3 absorptions of kaolinite spectra." The 2162 nm feature is
        "weak or absent in poorly crystalline kaolinite and in mixtures."
        Variations in crystallinity shift wavelength positions and affect doublet shape.</p>

        <p><b>Inputs:</b></p>
        <ul>
          <li><b>WoM 2206 raster</b> — from FE12-2206W.
              Provides 2206 nm wavelength (Band 1) and depth (Band 2).</li>
          <li><b>WoM 2160 raster</b> — from FE5-2160D.
              Provides 2162 nm feature depth (Band 2).</li>
        </ul>

        <p><b>Decision tree:</b></p>
        <ul>
          <li>depth(2206) &le; threshold &rarr; <b>aspectral</b></li>
          <li>wavelength(2206) &notin; (2197, 2215] nm &rarr; <b>not_kaol</b> (illite/smectite)</li>
          <li>CI = depth(2162) / depth(2206):</li>
          <ul>
            <li>CI &gt; 0.6 &rarr; <b>kaol_hi</b>  (dark green) — well-ordered kaolinite</li>
            <li>CI &gt; 0.4 &rarr; <b>kaol_med</b> (mid green) — moderately ordered</li>
            <li>CI &gt; 0.2 &rarr; <b>kaol_lo</b>  (yellow-green) — poorly ordered</li>
            <li>CI &le; 0.2 &rarr; <b>kaol_dis</b> (pale yellow) — disordered / halloysite-like</li>
          </ul>
        </ul>

        <p><b>Colour legend:</b></p>
        <ul>
          <li><span style="color:#006400">&#9632;</span> Dark green — kaol_hi (well-ordered)</li>
          <li><span style="color:#00C850">&#9632;</span> Mid green — kaol_med</li>
          <li><span style="color:#C8FF64">&#9632;</span> Yellow-green — kaol_lo</li>
          <li><span style="color:#FFE664">&#9632;</span> Pale yellow — kaol_dis (disordered)</li>
          <li><span style="color:#808080">&#9632;</span> Grey — not_kaol (illite/smectite/other)</li>
          <li><span style="color:#000000">&#9632;</span> Black — aspectral</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, kaolinite2 entry.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return DtKaolCrystAlgorithm()
