"""
Spectra Math Algorithm for QGIS Processing
==========================================

Applies a per-pixel spectral Python expression to one or more input images.
Each pixel spectrum is exposed as S1, S2, … using the full HyPy Spectrum class.

HyPy Spectrum capabilities available in expressions:
  • Float wavelength indexing:  S1[2200.0]  or  S1(2200.0)
  • Float wavelength slices:    S1[2000.0:2400.0]
  • Integer band indexing:      S1[5]
  • Arithmetic:  S1 + S2,  S1 / 2,  1 - S1.nohull(), …
  • Coercion:    S1 + S2 automatically resamples onto overlapping wavelengths
  • numpy ops:   S1.log(), S1.sqrt(), S1.mean(), S1.clip(0,1), …
  • Shape ops:   S1.hull(), S1.nohull(), S1.peaks()
  • Feature ops: S1.localmin(), S1.localmax(), S1.minwav()
  • Resampling:  S1.resample(S2.wavelength)

Ported from HyPy specmath.py (Wim Bakker, University of Twente)
Original Copyright (C) 2018 Wim Bakker (GPL v3)
QGIS adaptation Copyright (C) 2025 Grant Boxer (GPL v3)
"""

import collections
import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterString,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis,
)

from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset
from ..core.spectrum import Spectrum


class SpectraMathAlgorithm(QgsProcessingAlgorithm):

    INPUTS     = 'INPUTS'
    EXPRESSION = 'EXPRESSION'
    USE_BBL    = 'USE_BBL'
    OUTPUT     = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUTS,
                'Input Hyperspectral Image(s)  (S1, S2, … in expression)',
                layerType=QgsProcessing.TypeRaster,
                optional=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.EXPRESSION,
                'Spectral Math Expression',
                defaultValue='S1 / S2',
                multiLine=False,
                optional=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.USE_BBL,
                'Use Bad Band List (BBL) from metadata',
                defaultValue=True,
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                'Output Image',
            )
        )

    def processAlgorithm(self, parameters, context, feedback):

        layers      = self.parameterAsLayerList(parameters, self.INPUTS, context)
        expression  = self.parameterAsString(parameters, self.EXPRESSION, context).strip()
        use_bbl     = self.parameterAsBoolean(parameters, self.USE_BBL, context)
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if not layers:
            raise QgsProcessingException('No input layers supplied.')
        if not expression:
            raise QgsProcessingException('Expression is empty.')

        feedback.pushInfo(f'Expression: {expression}')
        feedback.pushInfo(f'Inputs: {len(layers)} image(s)')

        # Open all input datasets
        datasets    = []
        wavelengths = []
        bbls        = []
        for lyr in layers:
            ds = gdal.Open(lyr.source())
            if ds is None:
                raise QgsProcessingException(f'Cannot open: {lyr.source()}')
            nb  = ds.RasterCount
            wl  = get_wavelengths_from_dataset(ds, nb, lyr.source(), feedback)
            bl  = get_bbl_from_dataset(ds, nb, lyr.source(), feedback) if use_bbl else None
            datasets.append(ds)
            wavelengths.append(wl)
            bbls.append(bl)

        ds0    = datasets[0]
        n_rows = ds0.RasterYSize
        n_cols = ds0.RasterXSize
        geo    = ds0.GetGeoTransform()
        proj   = ds0.GetProjection()
        feedback.pushInfo(f'Image: {ds0.RasterCount} bands, {n_rows} rows, {n_cols} cols')

        # Build valid-band index lists
        valid = []
        for k, (ds, bl) in enumerate(zip(datasets, bbls)):
            nb = ds.RasterCount
            if bl is not None:
                vb = [i for i, good in enumerate(bl) if good]
                feedback.pushInfo(f'  S{k+1}: BBL → {len(vb)} of {nb} bands valid')
            else:
                vb = list(range(nb))
            valid.append(vb)

        # Dry-run on first pixel to determine output band count / wavelengths
        math_ns = self._math_namespace()
        eval_vars = {}
        for k, (ds, wl, vb) in enumerate(zip(datasets, wavelengths, valid)):
            pixel = np.array([float(ds.GetRasterBand(b+1).ReadAsArray()[0, 0])
                               for b in vb], dtype=np.float64)
            wl_vb = wl[vb] if wl is not None else np.arange(len(vb), dtype=np.float64)
            eval_vars[f'S{k+1}'] = Spectrum(wavelength=wl_vb, spectrum=pixel,
                                             name=f'S{k+1}',
                                             wavelength_units='Nanometers')
        try:
            result0 = eval(expression, {**math_ns, **eval_vars})
        except Exception as e:
            raise QgsProcessingException(f'Expression error on test pixel: {e}')

        out_wavelengths = None
        if isinstance(result0, Spectrum):
            out_bands       = len(result0)
            out_wavelengths = result0.wavelength
            feedback.pushInfo(f'Output: {out_bands} band(s) (Spectrum)')
        elif isinstance(result0, np.ndarray):
            out_bands = len(result0.flatten())
            feedback.pushInfo(f'Output: {out_bands} band(s) (ndarray)')
        elif isinstance(result0, collections.abc.Iterable):
            out_bands = len(list(result0))
            feedback.pushInfo(f'Output: {out_bands} band(s) (iterable)')
        else:
            out_bands = 1
            feedback.pushInfo('Output: 1 band (scalar)')

        # Create output GeoTIFF
        drv     = gdal.GetDriverByName('GTiff')
        out_ds  = drv.Create(output_path, n_cols, n_rows, out_bands,
                             gdal.GDT_Float64, options=['COMPRESS=LZW', 'BIGTIFF=IF_SAFER'])
        out_ds.SetGeoTransform(geo)
        out_ds.SetProjection(proj)
        for b in range(out_bands):
            out_ds.GetRasterBand(b + 1).SetNoDataValue(np.nan)

        # Pre-load all input data
        input_data = []
        for k, (ds, vb) in enumerate(zip(datasets, valid)):
            feedback.pushInfo(f'Reading S{k+1}...')
            nd  = ds.GetRasterBand(1).GetNoDataValue()
            arr = np.zeros((len(vb), n_rows, n_cols), dtype=np.float64)
            for bi, b in enumerate(vb):
                a = ds.GetRasterBand(b + 1).ReadAsArray().astype(np.float64)
                if nd is not None:
                    a[a == nd] = np.nan
                arr[bi] = a
            input_data.append(arr)

        # Build reusable Spectrum objects (spectrum array swapped per pixel)
        spec_objs = []
        for k, (wl, vb) in enumerate(zip(wavelengths, valid)):
            wl_vb = wl[vb] if wl is not None else np.arange(len(vb), dtype=np.float64)
            sp = Spectrum(wavelength=wl_vb,
                          spectrum=np.zeros(len(vb), dtype=np.float64),
                          name=f'S{k+1}', wavelength_units='Nanometers')
            spec_objs.append(sp)

        out_buf  = np.full((out_bands, n_rows, n_cols), np.nan, dtype=np.float64)
        step     = max(1, n_rows // 100)

        feedback.pushInfo('Processing pixels...')
        for j in range(n_rows):
            if feedback.isCanceled():
                break
            if j % step == 0:
                feedback.setProgress(int(j * 100 / n_rows))

            row_vars = {f'S{k+1}': sp for k, sp in enumerate(spec_objs)}

            for i in range(n_cols):
                skip = False
                for k, (arr, sp) in enumerate(zip(input_data, spec_objs)):
                    col = arr[:, j, i]
                    if np.all(np.isnan(col)):
                        skip = True
                        break
                    sp.spectrum = col
                    sp.s        = col
                if skip:
                    continue

                try:
                    result = eval(expression, {**math_ns, **row_vars})
                    if isinstance(result, Spectrum):
                        vals = result.spectrum
                    elif isinstance(result, np.ndarray):
                        vals = result.flatten()
                    elif isinstance(result, collections.abc.Iterable):
                        vals = np.array(list(result), dtype=np.float64).flatten()
                    else:
                        vals = np.array([result], dtype=np.float64)

                    n_write = min(len(vals), out_bands)
                    out_buf[:n_write, j, i] = vals[:n_write]

                except Exception as e:
                    feedback.reportError(f'Pixel ({j},{i}): {e}')

        # Write output
        feedback.pushInfo('Writing output...')
        for b in range(out_bands):
            out_ds.GetRasterBand(b + 1).WriteArray(out_buf[b])
            if out_wavelengths is not None and b < len(out_wavelengths):
                out_ds.GetRasterBand(b + 1).SetDescription(f'{out_wavelengths[b]:.4f}')

        out_ds.FlushCache()
        del out_ds

        # Sidecar .hdr
        if out_wavelengths is not None:
            hdr_lines = ['ENVI',
                         'wavelength = {' + ', '.join(f'{w:.4f}' for w in out_wavelengths) + '}',
                         'wavelength units = Nanometers',
                         f'spectra_math_expression = {expression}']
            with open(output_path + '.hdr', 'w') as hf:
                hf.write('\n'.join(hdr_lines) + '\n')
            feedback.pushInfo(f'Sidecar .hdr written.')

        for ds in datasets:
            del ds

        feedback.setProgress(100)
        feedback.pushInfo('Spectra Math completed successfully.')
        return {self.OUTPUT: output_path}

    def _math_namespace(self):
        """numpy + Spectrum available in expressions (mirrors HyPy 'from numpy import *')."""
        import numpy as np
        ns = {name: getattr(np, name)
              for name in dir(np) if not name.startswith('_')}
        ns['np']       = np
        ns['Spectrum'] = Spectrum
        return ns

    def name(self):        return 'spectramathfull'
    def displayName(self): return 'Spectra Math'
    def group(self):       return '6 - Spectral Processing Tools'
    def groupId(self):     return '6_spectral_processing'

    def shortHelpString(self):
        return (
            'Applies a per-pixel spectral Python expression to one or more\n'
            'hyperspectral images using the full HyPy Spectrum class.\n\n'
            'Input images are available as S1, S2, … in the expression.\n\n'
            'INDEXING (the key feature):\n'
            '  S1[2200.0]          → value at wavelength 2200 nm (float index)\n'
            '  S1(2200.0)          → same, callable syntax\n'
            '  S1[2000.0:2400.0]   → sub-spectrum 2000–2400 nm\n'
            '  S1[5]               → value at integer band index 5\n\n'
            'ARITHMETIC:\n'
            '  S1 / S2             → per-band ratio (auto-resamples if needed)\n'
            '  S1[2200.0] / S1[2100.0]  → two-wavelength ratio\n'
            '  (S1 - S2).absolute()     → absolute difference\n\n'
            'NUMPY METHODS:\n'
            '  S1.log(), S1.sqrt(), S1.mean(), S1.clip(0,1), S1.smooth()\n\n'
            'SPECTRAL SHAPE:\n'
            '  S1.hull()    → convex hull\n'
            '  S1.nohull()  → continuum-removed\n'
            '  S1.peaks()   → absorption peaks\n'
            '  S1.localmin(n)  → n deepest local minima\n\n'
            'COERCION:\n'
            '  S1 + S2 automatically resamples both onto overlapping wavelengths.\n\n'
            'Ported from HyPy specmath.py (Wim Bakker, University of Twente).'
        )

    def createInstance(self):
        return SpectraMathAlgorithm()
