"""
Cross-Track Illumination Correction (CTIC)

Removes cross-track (along-column) illumination gradients from a hyperspectral
cube.  These gradients cause a smooth brightness ramp across each scan line,
making pixels on one side of the swath appear systematically brighter or darker
than those on the other side — independent of surface mineralogy.

The correction is applied band-by-band using a per-column normalisation
approach:
  1. For each band, compute the column median across all rows (ignoring NaN/nodata).
  2. Fit a low-order polynomial to those medians vs column index to derive
     a smooth cross-track trend (the CTIC correction curve).
  3. Divide each pixel's reflectance by the normalised trend
     (trend / grand_median) so the mean level is preserved.

Background (GSWA Report 261, §3.2, Figure 50A):
    "A cross-track illumination correction (CTIC) was applied to each VNIR and
     SWIR scene to reduce the sometimes intense cross-track illumination trends."
    — Laukamp et al. (2025) GSWA Report 261, §3.2

    The CTIC is a mandatory pre-processing step before any absorption-feature
    extraction (band ratios, polynomial depth fitting) to avoid systematic
    banding artefacts propagating into mineral maps.  It does not correct for
    atmospheric effects or instrument noise — it specifically addresses the
    smooth, scan-line-parallel brightness variation due to vignetting or
    non-uniform detector response across the swath.

    ENVI includes a built-in CTIC module.  This tool provides equivalent
    functionality for users working in QGIS without ENVI.

Output: an ENVI flat-binary cube (same dimensions and wavelengths as input)
with cross-track illumination trends removed.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np
from osgeo import gdal
import os

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterEnum,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube (ENVI or GeoTIFF) with wavelength metadata.<br/>
        <b>Run this before:</b> any Feature Extraction, GSWA Index, or Band Math tool.
        </p>
"""


class CticAlgorithm(QgsProcessingAlgorithm):
    """Cross-Track Illumination Correction (CTIC) for hyperspectral cubes."""

    INPUT      = 'INPUT'
    POLY_ORDER = 'POLY_ORDER'
    METHOD     = 'METHOD'
    OUTPUT     = 'OUTPUT'

    _METHODS = ['Column median polynomial fit  (recommended)', 'Column mean polynomial fit']

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT,
            'Hyperspectral cube  (pre-processed reflectance)'))
        self.addParameter(QgsProcessingParameterEnum(
            self.METHOD,
            'Cross-track statistic',
            options=self._METHODS,
            defaultValue=0))
        self.addParameter(QgsProcessingParameterNumber(
            self.POLY_ORDER,
            'Polynomial order for trend fitting  (1=linear, 2=quadratic, 3=cubic)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=2, minValue=1, maxValue=6))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT,
            'CTIC-corrected output cube'))

    def processAlgorithm(self, parameters, context, feedback):
        cube     = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        method   = self.parameterAsEnum(parameters, self.METHOD, context)
        poly_ord = self.parameterAsInt(parameters, self.POLY_ORDER, context)
        out_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if cube is None:
            raise QgsProcessingException('Invalid input layer')

        ds = gdal.Open(cube.source())
        if ds is None:
            raise QgsProcessingException(f'Cannot open raster: {cube.source()}')

        n_bands = ds.RasterCount
        n_rows  = ds.RasterYSize
        n_cols  = ds.RasterXSize
        nodata  = ds.GetRasterBand(1).GetNoDataValue()
        gt      = ds.GetGeoTransform()
        proj    = ds.GetProjection()

        raster_path = cube.source()
        wavelengths = get_wavelengths_from_dataset(ds, n_bands, raster_path, feedback)
        if wavelengths is None:
            raise QgsProcessingException(
                'No wavelength metadata found.  The input cube must have '
                'wavelength information in its ENVI header or GDAL metadata.')

        bbl = get_bbl_from_dataset(ds, n_bands, raster_path, feedback)

        use_median = (method == 0)
        stat_name  = 'median' if use_median else 'mean'

        feedback.pushInfo(f'Input cube: {n_bands} bands, {n_rows}×{n_cols} pixels')
        feedback.pushInfo(f'CTIC method: column {stat_name}, poly order {poly_ord}')
        feedback.pushInfo('')

        # ── Prepare output dataset ────────────────────────────────────────
        driver = gdal.GetDriverByName('GTiff')
        out_ds = driver.Create(
            out_path, n_cols, n_rows, n_bands, gdal.GDT_Float32,
            options=['COMPRESS=LZW', 'TILED=YES', 'BIGTIFF=IF_SAFER'])
        out_ds.SetGeoTransform(gt)
        out_ds.SetProjection(proj)

        # Copy all metadata from source
        out_ds.SetMetadata(ds.GetMetadata())
        for domain in ds.GetMetadataDomainList() or []:
            if domain:
                out_ds.SetMetadata(ds.GetMetadata(domain), domain)

        # Column index array for polynomial fitting
        col_idx    = np.arange(n_cols, dtype=np.float64)
        col_norm   = col_idx / (n_cols - 1)   # normalise to [0,1] for stability

        correction_logged = False

        for b in range(n_bands):
            if feedback.isCanceled():
                break

            pct = int(b * 100 / n_bands)
            feedback.setProgress(pct)
            if b % max(1, n_bands // 20) == 0:
                wl_str = f'{wavelengths[b]:.1f} nm' if wavelengths is not None else f'band {b+1}'
                feedback.pushInfo(f'  Band {b+1}/{n_bands}  ({wl_str}) …')

            src_band = ds.GetRasterBand(b + 1)
            arr      = src_band.ReadAsArray().astype(np.float32)

            if nodata is not None:
                arr[arr == nodata] = np.nan

            # Skip bad bands — copy through unchanged
            if bbl is not None and bbl[b] == 0:
                out_band = out_ds.GetRasterBand(b + 1)
                out_band.WriteArray(arr)
                out_band.SetNoDataValue(float('nan'))
                continue

            # ── Compute cross-track statistic per column ──────────────────
            # col_stat shape: (n_cols,) — median or mean of each column
            with np.errstate(all='ignore'):
                if use_median:
                    col_stat = np.nanmedian(arr, axis=0)   # (n_cols,)
                else:
                    col_stat = np.nanmean(arr, axis=0)

            # ── Fit polynomial to cross-track trend ───────────────────────
            # Only use columns that have valid data
            valid_cols = ~np.isnan(col_stat)
            n_valid_cols = int(valid_cols.sum())

            if n_valid_cols < poly_ord + 1:
                # Not enough valid columns to fit — pass through unchanged
                out_band = out_ds.GetRasterBand(b + 1)
                out_band.WriteArray(arr)
                out_band.SetNoDataValue(float('nan'))
                continue

            # Fit polynomial: col_stat ≈ poly(col_norm)
            coeffs = np.polyfit(col_norm[valid_cols], col_stat[valid_cols], poly_ord)
            trend  = np.polyval(coeffs, col_norm)   # fitted trend, shape (n_cols,)

            # Grand mean of the fitted trend (used to preserve overall level)
            trend_mean = float(np.nanmean(trend))
            if trend_mean == 0 or np.isnan(trend_mean):
                out_band = out_ds.GetRasterBand(b + 1)
                out_band.WriteArray(arr)
                out_band.SetNoDataValue(float('nan'))
                continue

            # ── Apply correction: divide by normalised trend ──────────────
            # norm_trend shape (1, n_cols) for broadcasting
            norm_trend = (trend / trend_mean).reshape(1, n_cols)

            with np.errstate(invalid='ignore', divide='ignore'):
                corrected = np.where(norm_trend > 0, arr / norm_trend, np.nan)

            corrected = corrected.astype(np.float32)

            # Log correction statistics for first non-bad band
            if not correction_logged:
                trend_range = float(np.nanmax(trend) - np.nanmin(trend))
                trend_pct   = 100.0 * trend_range / trend_mean if trend_mean > 0 else 0.0
                feedback.pushInfo(
                    f'  Cross-track trend range (band {b+1}): '
                    f'{trend_range:.5f}  ({trend_pct:.1f}% of scene mean)')
                correction_logged = True

            out_band = out_ds.GetRasterBand(b + 1)
            out_band.WriteArray(corrected)
            out_band.SetNoDataValue(float('nan'))

            # Copy band-level metadata (description, wavelength)
            out_band.SetDescription(src_band.GetDescription())
            for domain in src_band.GetMetadataDomainList() or []:
                meta = src_band.GetMetadata(domain)
                if meta:
                    out_band.SetMetadata(meta, domain)

        # Mark output with CTIC metadata
        out_ds.SetMetadataItem('CTIC_applied',    'True')
        out_ds.SetMetadataItem('CTIC_method',     stat_name)
        out_ds.SetMetadataItem('CTIC_poly_order', str(poly_ord))
        out_ds.SetMetadataItem('CTIC_reference',
            'GSWA Report 261 §3.2 (Laukamp et al. 2025); ENVI CTIC equivalent')

        out_ds.FlushCache()
        del ds, out_ds

        feedback.pushInfo('')
        feedback.pushInfo('─' * 60)
        feedback.pushInfo('Cross-Track Illumination Correction complete.')
        feedback.pushInfo(f'  Method:        Column {stat_name} + poly{poly_ord} fit')
        feedback.pushInfo(f'  Bands processed: {n_bands}')
        feedback.pushInfo('')
        feedback.pushInfo('Next steps:')
        feedback.pushInfo('  • Run Feature Extraction tools on the CTIC-corrected cube')
        feedback.pushInfo('  • Run GSWA Mineral Map Index tools for quantitative maps')
        feedback.pushInfo('  • If residual banding remains, try a higher poly order (3–4)')
        feedback.pushInfo('─' * 60)
        feedback.setProgress(100)

        return {self.OUTPUT: out_path}

    def name(self):        return 'ctic'
    def displayName(self): return 'Cross-Track Illumination Correction  (CTIC)'
    def group(self):       return '2 - Data Import'
    def groupId(self):     return 'one_data_import'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Cross-Track Illumination Correction (CTIC)</b>

        <p>Removes smooth brightness gradients across the scan direction
        (cross-track / along-column) from a hyperspectral cube.  These gradients
        arise from vignetting, non-uniform detector response, or residual
        atmospheric effects, and cause systematic banding in mineral maps if
        left uncorrected.</p>

        <p><b>Algorithm:</b></p>
        <ol>
          <li>For each band, compute the column-wise median (or mean) across
              all rows — this gives a 1D cross-track profile</li>
          <li>Fit a low-order polynomial to that profile</li>
          <li>Divide every pixel in the band by the normalised trend
              <code>(trend / grand_mean)</code> so the overall brightness
              level is preserved</li>
        </ol>

        <p>The result is a cube where systematic scan-direction brightness
        variations are removed, leaving only surface-reflectance-related
        spectral information.</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Guidance</th>
          </tr>
          <tr><td>Method: Column median</td>
              <td>Recommended — robust against bright/dark outlier pixels
                  (e.g. water bodies, shadows)</td></tr>
          <tr><td>Method: Column mean</td>
              <td>Faster; use if scene has very few outliers</td></tr>
          <tr><td>Poly order 1 (linear)</td>
              <td>Simple left–right brightness ramp</td></tr>
          <tr><td>Poly order 2 (quadratic)</td>
              <td>Default — handles curved vignetting profiles</td></tr>
          <tr><td>Poly order 3–4</td>
              <td>For sensors with complex cross-track response
                  (e.g. PRISMA western tile edge artefacts)</td></tr>
        </table>

        <p><b>When to use:</b></p>
        <ul>
          <li>Before running any FE, GSWA, or Band Math tool on PRISMA,
              EnMAP, or EMIT imagery</li>
          <li>When you see smooth brightness bands parallel to the scan
              direction in mineral maps (not striping — that is a different
              artefact)</li>
          <li>After atmospheric correction but before feature extraction</li>
        </ul>

        <p><b>What it does NOT fix:</b></p>
        <ul>
          <li>Along-track striping (detector fixed-pattern noise) — use a
              destriping filter for that</li>
          <li>Atmospheric effects (water vapour, aerosols)</li>
          <li>Geometric misregistration between tiles</li>
        </ul>

        <p><i>Background: Laukamp, C., Miles, A.J. et al. (2025) GSWA Report 261,
        §3.2, Figure 50A.  ENVI® includes an equivalent built-in CTIC module —
        this tool provides the same correction within QGIS.</i></p>
        """

    def createInstance(self): return CticAlgorithm()
