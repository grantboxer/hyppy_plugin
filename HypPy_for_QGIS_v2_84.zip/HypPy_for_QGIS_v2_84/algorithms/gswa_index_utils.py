"""
Shared utilities for GSWA Report 261 Table 5 mineral index algorithms.

Provides:
  - compute_ndvi()     — MertonNDVI from hyperspectral cube (858/667 nm ratio)
  - read_wom_band()    — read depth (band 2) or wavelength (band 1) from WoM output
  - write_index()      — write a masked float32 GeoTIFF with GSWA metadata
  - poly_fit_depth()   — 2nd/4th order polynomial fit depth over a wavelength window

Reference:
    Laukamp, C., Miles, A.J., Lampinen, H.M. et al. (2025).
    Spaceborne Mineral Maps for Critical Metals Exploration in the
    Gascoyne and Pilbara.  Geological Survey of Western Australia, Report 261.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset


# ── NDVI ─────────────────────────────────────────────────────────────────────

def compute_ndvi(cube_ds, wavelengths, nodata, feedback,
                 nir_nm=858.0, red_nm=667.0):
    """
    Compute MertonNDVI = (NIR - Red) / (NIR + Red) from the cube.

    Uses bands nearest to nir_nm (~858 nm) and red_nm (~667 nm).
    Returns a float32 2-D array.  NaN where nodata or denominator is zero.
    """
    n_bands = cube_ds.RasterCount

    def nearest_band(target_nm):
        diffs = np.abs(wavelengths - target_nm)
        idx = int(np.argmin(diffs))
        actual = wavelengths[idx]
        feedback.pushInfo(
            f'  NDVI: target {target_nm:.0f} nm → band {idx+1} at {actual:.1f} nm')
        return idx

    i_nir = nearest_band(nir_nm)
    i_red = nearest_band(red_nm)

    nir = cube_ds.GetRasterBand(i_nir + 1).ReadAsArray().astype(np.float32)
    red = cube_ds.GetRasterBand(i_red + 1).ReadAsArray().astype(np.float32)

    if nodata is not None:
        nir[nir == nodata] = np.nan
        red[red == nodata] = np.nan

    with np.errstate(invalid='ignore', divide='ignore'):
        denom = nir + red
        ndvi = np.where(denom > 0, (nir - red) / denom, np.nan)

    return ndvi.astype(np.float32)


# ── WoM band reader ───────────────────────────────────────────────────────────

def read_wom_band(wom_layer, band_number, label, feedback):
    """
    Read one band from a WoM raster layer.

    band_number: 1 = wavelength of minimum, 2 = depth.
    Returns (array float32, geotransform, projection, nrows, ncols).
    """
    path = wom_layer.source()
    ds   = gdal.Open(path)
    if ds is None:
        raise RuntimeError(f'Cannot open WoM raster: {path} ({label})')

    n = ds.RasterCount
    if band_number > n:
        raise RuntimeError(
            f'{label}: requested band {band_number} but raster only has {n} bands.')

    arr  = ds.GetRasterBand(band_number).ReadAsArray().astype(np.float32)
    nd   = ds.GetRasterBand(band_number).GetNoDataValue()
    if nd is not None:
        arr[arr == nd] = np.nan

    gt   = ds.GetGeoTransform()
    proj = ds.GetProjection()
    rows = ds.RasterYSize
    cols = ds.RasterXSize
    del ds

    feedback.pushInfo(
        f'  {label}: read band {band_number} from {path}  '
        f'({rows}×{cols}, valid={int(np.sum(~np.isnan(arr)))})')
    return arr, gt, proj, rows, cols


# ── Output writer ─────────────────────────────────────────────────────────────

def write_index(out_path, data, gt, proj, product_name, description,
                gswa_stretch, reference, extra_meta=None):
    """
    Write a masked float32 single-band GeoTIFF with GSWA metadata.

    gswa_stretch: dict with keys 'gascoyne' and/or 'pilbara', each a
                  string like 'min=0.04, max=0.15'.
    """
    rows, cols = data.shape
    driver = gdal.GetDriverByName('GTiff')
    out_ds = driver.Create(out_path, cols, rows, 1, gdal.GDT_Float32,
                           options=['COMPRESS=LZW', 'TILED=YES'])
    out_ds.SetGeoTransform(gt)
    out_ds.SetProjection(proj)

    band = out_ds.GetRasterBand(1)
    band.WriteArray(data)
    band.SetNoDataValue(float('nan'))
    band.SetDescription(description)

    out_ds.SetMetadataItem('GSWA_product',   product_name)
    out_ds.SetMetadataItem('GSWA_reference', reference)
    for region, stretch in gswa_stretch.items():
        out_ds.SetMetadataItem(f'GSWA_stretch_{region}', stretch)
    if extra_meta:
        for k, v in extra_meta.items():
            out_ds.SetMetadataItem(k, str(v))

    out_ds.FlushCache()
    del out_ds


# ── Polynomial depth engine ───────────────────────────────────────────────────

def poly_fit_depth(cube_ds, wavelengths, bbl, nodata,
                   range_start, range_end, poly_order,
                   feedback, chunk=40000):
    """
    Compute absorption depth across range_start–range_end nm using a
    polynomial fit of the specified order, with linear continuum removal.

    Returns a float32 (nrows, ncols) depth array.
    Identical algorithm to fe_900d_algorithm.py — generalised for any range
    and polynomial order.
    """
    n_bands = cube_ds.RasterCount
    n_rows  = cube_ds.RasterYSize
    n_cols  = cube_ds.RasterXSize

    sel_idx = []
    for i, wl in enumerate(wavelengths):
        if range_start <= wl <= range_end:
            if bbl is None or bbl[i] == 1:
                sel_idx.append(i)

    if len(sel_idx) < poly_order + 1:
        raise RuntimeError(
            f'Too few valid bands in {range_start}–{range_end} nm '
            f'(need ≥{poly_order+1}, found {len(sel_idx)}). '
            'Check wavelength metadata and BBL.')

    sel_wav = wavelengths[sel_idx]
    feedback.pushInfo(
        f'  poly{poly_order} fit: {len(sel_idx)} bands '
        f'({sel_wav[0]:.1f}–{sel_wav[-1]:.1f} nm)')

    feedback.pushInfo('  Loading bands …')
    cube_data = np.full((len(sel_idx), n_rows, n_cols), np.nan, dtype=np.float32)
    for k, bi in enumerate(sel_idx):
        arr = cube_ds.GetRasterBand(bi + 1).ReadAsArray().astype(np.float32)
        if nodata is not None:
            arr[arr == nodata] = np.nan
        cube_data[k] = arr

    depth_out = np.full((n_rows, n_cols), np.nan, dtype=np.float32)
    wav_norm  = (sel_wav - sel_wav[0]) / (sel_wav[-1] - sel_wav[0])
    V         = np.vander(wav_norm, poly_order + 1, increasing=True)
    n_pix     = n_rows * n_cols
    spectra   = cube_data.reshape(len(sel_idx), n_pix).T

    feedback.pushInfo('  Computing polynomial fit depth …')
    for start in range(0, n_pix, chunk):
        if feedback.isCanceled():
            return depth_out
        end  = min(start + chunk, n_pix)
        spec = spectra[start:end]
        valid = ~np.all(np.isnan(spec), axis=1)
        if not np.any(valid):
            continue
        spec_v = spec[valid].copy()
        for j in range(spec_v.shape[0]):
            row  = spec_v[j]
            nans = np.isnan(row)
            if nans.any():
                x    = np.arange(len(sel_idx))
                good = ~nans
                if good.sum() < poly_order + 1:
                    spec_v[j] = np.nan
                    continue
                spec_v[j] = np.interp(x, x[good], row[good])
        coeffs, _, _, _ = np.linalg.lstsq(V, spec_v.T, rcond=None)
        fit_vals  = (V @ coeffs).T
        continuum = (fit_vals[:, 0:1]
                     + (fit_vals[:, -1:] - fit_vals[:, 0:1]) * wav_norm[np.newaxis, :])
        with np.errstate(invalid='ignore', divide='ignore'):
            removed = np.where(continuum > 0,
                               (continuum - fit_vals) / continuum, np.nan)
        max_depth = np.nanmax(removed, axis=1)
        result    = np.full(end - start, np.nan, dtype=np.float32)
        result[valid] = max_depth.astype(np.float32)
        flat_idx  = np.arange(start, end)
        depth_out[flat_idx // n_cols, flat_idx % n_cols] = result

    return depth_out


# ── GSWA Table 5 mask conditions ─────────────────────────────────────────────

def apply_ndvi_mask(arr, ndvi, ndvi_threshold, label, feedback):
    """Mask pixels where NDVI >= threshold (vegetated) to NaN."""
    veg_mask = ~np.isnan(ndvi) & (ndvi >= ndvi_threshold)
    n_masked = int(np.sum(veg_mask & ~np.isnan(arr)))
    arr = arr.copy()
    arr[veg_mask] = np.nan
    feedback.pushInfo(f'  {label}: vegetation mask (NDVI≥{ndvi_threshold}): {n_masked} px masked')
    return arr


def log_gswa_stretch(feedback, product, stretch_dict):
    """Print GSWA recommended stretch values to processing log."""
    feedback.pushInfo('')
    feedback.pushInfo('─' * 60)
    feedback.pushInfo(f'GSWA Report 261 Table 5 — {product} recommended stretch:')
    for region, s in stretch_dict.items():
        feedback.pushInfo(f'  {region.title()}: {s}')
    feedback.pushInfo('  Colour scheme: Rainbow (blue = low, red = high)')
    feedback.pushInfo('─' * 60)
