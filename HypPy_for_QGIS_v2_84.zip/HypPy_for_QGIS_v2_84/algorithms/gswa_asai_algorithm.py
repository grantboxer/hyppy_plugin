"""
GSWA Table 5 — Al-sheetsilicate abundance index (ASai)

Algorithm: Intensity of the wavelength minimum between 2140 and 2240 nm
           using 4th order polynomial fit (2200D).
Masks:     MertonNDVI > 0.15 (Gascoyne) / > 0.2 (Pilbara)  AND  2200D < 0.04
Stretch:   Gascoyne linear: Blue=0.04, Red=0.18
           Pilbara  linear: Blue=0.04, Red=0.16
Targeted:  White mica, kaolinite, Al-smectite  (challenge: tourmaline)

Reference:
    Laukamp et al. (2025) GSWA Report 261, Table 5.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset
from .gswa_index_utils import (
    compute_ndvi, read_wom_band, write_index,
    apply_ndvi_mask, log_gswa_stretch,
)

WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube (for NDVI) + FE12-2200W WoM raster.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""

GSWA_STRETCH = {
    'gascoyne': 'linear: Blue=0.04, Red=0.18',
    'pilbara':  'linear: Blue=0.04, Red=0.16',
}

REFERENCE = 'Laukamp et al. (2025) GSWA Report 261, Table 5 (ASai)'


class GswaAsaiAlgorithm(QgsProcessingAlgorithm):
    """GSWA Table 5 — Al-sheetsilicate abundance index (ASai)."""

    CUBE         = 'CUBE'
    WOM_2200     = 'WOM_2200'
    NDVI_THRESH  = 'NDVI_THRESH'
    DEPTH_THRESH = 'DEPTH_THRESH'
    OUTPUT       = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.CUBE,
            'Hyperspectral cube  (for MertonNDVI computation)'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2200,
            'FE12-2200W WoM raster  (Band 2 = 2200D depth)'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NDVI_THRESH,
            'MertonNDVI threshold (mask pixels above this value)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.15, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.DEPTH_THRESH,
            '2200D depth upper threshold (mask pixels above this value)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.04, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT, 'Output ASai raster'))

    def processAlgorithm(self, parameters, context, feedback):
        cube_layer   = self.parameterAsRasterLayer(parameters, self.CUBE, context)
        wom_2200     = self.parameterAsRasterLayer(parameters, self.WOM_2200, context)
        ndvi_thresh  = self.parameterAsDouble(parameters, self.NDVI_THRESH, context)
        depth_thresh = self.parameterAsDouble(parameters, self.DEPTH_THRESH, context)
        out_path     = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        # 1. Read 2200D depth (Band 2 of WoM)
        feedback.setProgress(5)
        feedback.pushInfo('Reading 2200D depth (Band 2 of FE12-2200W WoM) …')
        d2200, gt, proj, rows, cols = read_wom_band(wom_2200, 2, '2200D', feedback)

        # 2. Compute MertonNDVI from cube
        feedback.setProgress(20)
        feedback.pushInfo('Computing MertonNDVI from cube (858/667 nm) …')
        cube_ds    = gdal.Open(cube_layer.source())
        wavelengths = get_wavelengths_from_dataset(
            cube_ds, cube_ds.RasterCount, cube_layer.source(), feedback)
        if wavelengths is None:
            raise QgsProcessingException('No wavelength metadata found in cube.')
        nodata = cube_ds.GetRasterBand(1).GetNoDataValue()
        ndvi   = compute_ndvi(cube_ds, wavelengths, nodata, feedback)
        del cube_ds

        # 3. Apply masks: NDVI and 2200D depth threshold
        feedback.setProgress(60)
        feedback.pushInfo('Applying GSWA Table 5 masks …')
        asai = d2200.copy()
        asai = apply_ndvi_mask(asai, ndvi, ndvi_thresh, 'ASai', feedback)

        # 2200D < depth_thresh mask (mask spectral artefacts / bare rock with no Al-OH)
        below = ~np.isnan(asai) & (asai < depth_thresh)
        feedback.pushInfo(
            f'  ASai: 2200D<{depth_thresh} mask: {int(np.sum(below))} px masked')
        asai[below] = np.nan

        # 4. Write output
        feedback.setProgress(85)
        feedback.pushInfo('Writing ASai …')
        write_index(
            out_path, asai, gt, proj,
            product_name='ASai',
            description='Al-sheetsilicate abundance index (2200D, poly4, 2140-2240 nm)',
            gswa_stretch=GSWA_STRETCH,
            reference=REFERENCE,
            extra_meta={
                'GSWA_ndvi_threshold':  str(ndvi_thresh),
                'GSWA_depth_threshold': str(depth_thresh),
                'GSWA_base_algorithm':  '2200D poly4 2140-2240 nm',
            }
        )

        log_gswa_stretch(feedback, 'ASai (Al-sheetsilicate abundance)', GSWA_STRETCH)
        feedback.pushInfo('Targeted minerals: white mica, kaolinite, Al-smectite')
        feedback.setProgress(100)
        return {self.OUTPUT: out_path}

    def name(self):        return 'gswa_asai'
    def displayName(self): return 'GSWA-ASai  (Al-sheetsilicate Abundance)'
    def group(self):       return '9 - GSWA Mineral Map Indices'
    def groupId(self):     return 'nine_gswa_indices'

    def shortHelpString(self):
        return WORKFLOW_NOTE + f"""
        <b>Al-sheetsilicate Abundance Index (ASai)</b>
        <p>GSWA Report 261, Table 5. Relative intensity of the Al-OH absorption
        at ~2200 nm — diagnostic for white mica, Al-smectite, and kaolin group
        minerals.</p>

        <p><b>Algorithm:</b> Intensity of the wavelength minimum between
        <b>2140 and 2240 nm</b> using 4th order polynomial fit (2200D).
        This tool reads the depth (Band 2) from a pre-computed FE12-2200W WoM
        raster, then applies the GSWA masking conditions.</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>GSWA Table 5 value</th>
          </tr>
          <tr><td>Base algorithm</td><td>2200D poly₄, 2140–2240 nm</td></tr>
          <tr><td>Vegetation mask</td>
              <td>MertonNDVI &gt; 0.15 (Gascoyne) / &gt; 0.2 (Pilbara)</td></tr>
          <tr><td>Depth mask</td><td>2200D &lt; 0.04 masked out</td></tr>
          <tr style="background:#fff3e0">
            <td><b>Gascoyne stretch</b></td>
            <td>linear: Blue=0.04 (low), Red=0.18 (high)</td></tr>
          <tr style="background:#fff3e0">
            <td><b>Pilbara stretch</b></td>
            <td>linear: Blue=0.04 (low), Red=0.16 (high)</td></tr>
          <tr><td>Targeted minerals</td>
              <td>White mica, kaolinite, Al-smectite</td></tr>
          <tr><td>Challenge</td><td>High values also from tourmaline</td></tr>
        </table>

        <p><b>Workflow:</b></p>
        <ol>
          <li>Run <b>FE12-2200W</b> on the cube → save the WoM raster</li>
          <li>Run this tool, supplying the cube and the FE12-2200W WoM raster</li>
          <li>Apply rainbow stretch: Gascoyne min=0.04, max=0.18;
              Pilbara min=0.04, max=0.16</li>
        </ol>

        <p><i>Reference: Laukamp et al. (2025) GSWA Report 261, Table 5.</i></p>
        """

    def createInstance(self): return GswaAsaiAlgorithm()
