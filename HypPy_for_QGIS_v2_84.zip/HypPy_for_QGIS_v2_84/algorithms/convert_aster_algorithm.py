"""
Convert ASTER HDF to ENVI Algorithm for QGIS Processing

Extracts ImageData / Band / Temperature subdatasets from an ASTER HDF file
and writes each as a georectified ENVI file using GDAL's gdalwarp/gdal_translate.

Ported from HyPy convaster.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original HyPy Copyright (C) 2010-2022 Wim Bakker, University of Twente

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import json
import os
import subprocess
import sys

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterFileDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis,
)


def _find_gdal_tools():
    """Locate gdalinfo, gdalwarp, gdal_translate executables."""
    try:
        import osgeo
        osgeo_paths = list(osgeo.__path__)
    except ImportError:
        osgeo_paths = []

    win_paths = [
        r'C:\OSGeo4W64\bin',
        r'C:\Program Files\QGIS 3\bin',
        r'C:\Program Files\QGIS 3.28\bin',
        r'C:\Program Files\QGIS 3.34\bin',
    ]

    if sys.platform.startswith('win'):
        env_path = os.environ.get('PATH', '').split(';')
        search = osgeo_paths + env_path + win_paths
        for d in search:
            gi = os.path.join(d, 'gdalinfo.exe')
            if os.path.exists(gi):
                return (
                    gi,
                    os.path.join(d, 'gdalwarp.exe'),
                    os.path.join(d, 'gdal_translate.exe'),
                )
        raise EnvironmentError(
            "Could not find GDAL executables (gdalinfo.exe). "
            "Ensure QGIS / OSGeo4W is on the PATH."
        )
    else:
        # Unix: use names directly (assumed on PATH)
        return 'gdalinfo', 'gdalwarp', 'gdal_translate'


def _convert_aster(fin, feedback=None):
    """Extract ASTER subdatasets and write ENVI files."""

    def log(msg):
        if feedback:
            feedback.pushInfo(msg)
        else:
            print(msg)

    gdalinfo, gdalwarp, gdal_translate = _find_gdal_tools()

    base = os.path.splitext(fin)[0]
    log("Input:  %s" % fin)
    log("Output base: %s" % base)

    # ── Run gdalinfo -json ────────────────────────────────────────────
    try:
        result = subprocess.run(
            [gdalinfo, '-json', fin],
            capture_output=True, text=True, timeout=120
        )
    except FileNotFoundError:
        return False, "gdalinfo not found. Ensure GDAL is accessible."
    except subprocess.TimeoutExpired:
        return False, "gdalinfo timed out."

    if result.returncode != 0:
        return False, "gdalinfo failed: %s" % result.stderr

    try:
        meta = json.loads(result.stdout)
    except json.JSONDecodeError as e:
        return False, "Could not parse gdalinfo JSON output: %s" % str(e)

    subs = meta.get('metadata', {}).get('SUBDATASETS', {})
    n = len(subs) // 2
    if n == 0:
        return False, "No subdatasets found in the ASTER HDF file."

    log("Number of subdatasets: %d" % n)

    written = 0

    for i in range(1, n + 1):
        if feedback:
            feedback.setProgress(int((i / n) * 100))
        if feedback and feedback.isCanceled():
            return False, "Cancelled by user."

        key_desc = "SUBDATASET_%d_DESC" % i
        key_name = "SUBDATASET_%d_NAME" % i
        desc = subs.get(key_desc, '')
        name = subs.get(key_name, '')

        log(desc)

        if not any(kw in desc for kw in ('ImageData', 'Band', 'Temperature')):
            continue

        # Build a clean output filename from the description
        # e.g. "[1] ImageData1 (3000x3000) Byte" -> "ImageData1"
        try:
            desc2 = '_'.join(desc.split('] ')[1].split(' (')[0].split(' '))
        except IndexError:
            desc2 = 'sub%d' % i

        fout = base + '_' + desc2
        log("  -> %s" % fout)

        try:
            if 'Swath' in name:
                cmd = [gdalwarp, '-of', 'ENVI', '-overwrite', name, fout]
            else:
                cmd = [gdal_translate, '-of', 'ENVI', name, fout]

            result2 = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            if result2.stdout.strip():
                log("  " + result2.stdout.strip())
            if result2.returncode != 0:
                log("  Warning: command returned %d — %s" % (result2.returncode, result2.stderr.strip()))
            else:
                written += 1
        except subprocess.TimeoutExpired:
            log("  Warning: command timed out for subdataset %d" % i)

    log("")
    log("Written %d ENVI file(s)." % written)
    if written == 0:
        return False, "No ASTER ImageData/Band/Temperature subdatasets found — nothing written."

    return True, "Completed. %d ENVI file(s) written." % written


# ── QGIS Algorithm wrapper ─────────────────────────────────────────────────

class ConvertAsterAlgorithm(QgsProcessingAlgorithm):
    """Convert an ASTER HDF file to ENVI format using GDAL gdalwarp/gdal_translate."""

    INPUT = 'INPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT,
                'Input ASTER HDF File',
                behavior=QgsProcessingParameterFile.File,
                fileFilter='HDF Files (*.hdf *.h4 *.hdf4);;All Files (*)',
                optional=False,
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        fin = self.parameterAsFile(parameters, self.INPUT, context)

        feedback.pushInfo("=== Convert ASTER HDF to ENVI ===")
        feedback.pushInfo("This tool uses GDAL gdalwarp/gdal_translate.")

        try:
            _find_gdal_tools()
        except EnvironmentError as e:
            raise QgsProcessingException(str(e))

        ok, msg = _convert_aster(fin, feedback=feedback)
        if not ok:
            raise QgsProcessingException(msg)

        feedback.pushInfo(msg)
        return {}

    # ── Metadata ────────────────────────────────────────────────────────

    def name(self):
        return 'convert_aster_hdf'

    def displayName(self):
        return 'G03 - Convert ASTER HDF to ENVI'

    def group(self):
        return '8 - Convert Tools'

    def groupId(self):
        return 'convert_tools'

    def shortHelpString(self):
        return (
            "Extract ImageData, Band, and Temperature subdatasets from an ASTER "
            "HDF file and write each as a georectified ENVI file.\n\n"
            "Swath-geometry subdatasets are reprojected via gdalwarp; "
            "grid-geometry subdatasets are copied via gdal_translate.\n\n"
            "Output files are named  <input_basename>_<BandDescription>  "
            "in the same folder as the input.\n\n"
            "Requires GDAL executables (gdalinfo, gdalwarp, gdal_translate) "
            "to be on the system PATH (standard QGIS installation).\n\n"
            "Ported from HyPy convaster.py (Wim Bakker, University of Twente)."
        )

    def createInstance(self):
        return ConvertAsterAlgorithm()
