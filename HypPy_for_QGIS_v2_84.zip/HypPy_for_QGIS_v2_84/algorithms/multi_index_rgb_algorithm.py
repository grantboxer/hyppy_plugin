"""
Multi-Index RGB Composite

Combines three single-band rasters (any FE depth outputs, GSWA mineral
indices, or external layers such as radiometrics K-channel) into a
false-colour RGB GeoTIFF, with independent per-channel linear or
histogram-equalised stretch.

Background (GSWA Report 261, Figures 30b, 31b, 32b, 33b, 44f, 45b, f):
    GSWA Report 261 makes extensive use of three-band false-colour RGB
    composites as a primary geological interpretation product.  Common
    combinations include:
      • R=WMai, G=CBEai, B=KLNai  — white mica / chlorite-epidote / kaolinite
      • R=FOai, G=WMai,  B=KLNai  — iron oxide / white mica / kaolinite
      • R=K-radiometrics, G=WMai, B=KLNai  — geophysics + mineralogy

    These composites reveal geological domain boundaries and alteration
    patterns more effectively than any single index, because they display
    three complementary mineral systems simultaneously.

    This tool generalises the FE-GSWA-RGB tool (which uses a fixed
    combination of 2200D/2250D/2160D) to accept any three single-band
    rasters and any per-channel stretch.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterString,
    QgsProcessingParameterEnum,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Inputs:</b> Three single-band rasters (FE depth, GSWA index, or any float raster).<br/>
        <b>Output:</b> 3-band float32 RGB GeoTIFF ready for display in QGIS.
        </p>
"""

_STRETCH_MODES = ['Linear stretch  (preserves quantitative values)',
                  'Histogram equalisation  (maximum visual contrast)']

# Pre-defined channel combinations from GSWA Report 261
_PRESETS = {
    'WMai / CBEai / KLNai  (white mica / chlorite-epidote / kaolinite)':
        {'R': 'WMai', 'G': 'CBEai', 'B': 'KLNai'},
    'FOai / WMai / KLNai  (iron oxide / white mica / kaolinite)':
        {'R': 'FOai',  'G': 'WMai',  'B': 'KLNai'},
    'PPHai / WMai / KLNai  (pyrophyllite / white mica / kaolinite)':
        {'R': 'PPHai', 'G': 'WMai',  'B': 'KLNai'},
    'ASai / CBEai / KLNai  (Al-sheetsilicate / chlorite-epidote / kaolinite)':
        {'R': 'ASai',  'G': 'CBEai', 'B': 'KLNai'},
}


def _read_single_band(layer, label, feedback):
    """Read a single-band raster layer as float32, NaN for nodata."""
    ds = gdal.Open(layer.source())
    if ds is None:
        raise QgsProcessingException(f'Cannot open raster ({label}): {layer.source()}')
    if ds.RasterCount != 1:
        raise QgsProcessingException(
            f'{label} raster has {ds.RasterCount} bands — must be single-band.')
    band   = ds.GetRasterBand(1)
    nodata = band.GetNoDataValue()
    arr    = band.ReadAsArray().astype(np.float32)
    if nodata is not None:
        arr[arr == nodata] = np.nan
    rows, cols = ds.RasterYSize, ds.RasterXSize
    gt   = ds.GetGeoTransform()
    proj = ds.GetProjection()
    del ds
    feedback.pushInfo(
        f'  {label}: {cols}×{rows}, '
        f'range {float(np.nanmin(arr)):.4f}–{float(np.nanmax(arr)):.4f}')
    return arr, gt, proj, rows, cols


def _stretch_linear(arr, lo, hi):
    """Stretch arr to [0,1] using fixed lo/hi values."""
    if hi <= lo:
        raise QgsProcessingException(
            f'Stretch max ({hi}) must be greater than min ({lo}).')
    with np.errstate(invalid='ignore'):
        out = np.clip((arr - lo) / (hi - lo), 0.0, 1.0)
    out[np.isnan(arr)] = np.nan
    return out.astype(np.float32)


def _stretch_histeq(arr, n_bins=1024):
    """Stretch arr to [0,1] using histogram equalisation."""
    valid = arr[~np.isnan(arr)]
    if valid.size == 0:
        return arr.copy()
    v_min, v_max = float(valid.min()), float(valid.max())
    if v_min == v_max:
        out = np.where(np.isnan(arr), np.nan, 0.5)
        return out.astype(np.float32)
    hist, edges = np.histogram(valid, bins=n_bins, range=(v_min, v_max))
    cdf  = hist.cumsum().astype(np.float64)
    cdf  = (cdf - cdf.min()) / (cdf.max() - cdf.min())
    bidx = np.searchsorted(edges[:-1], arr.ravel(), side='right') - 1
    bidx = np.clip(bidx, 0, n_bins - 1)
    out  = cdf[bidx].reshape(arr.shape).astype(np.float32)
    out[np.isnan(arr)] = np.nan
    return out


class MultiIndexRGBAlgorithm(QgsProcessingAlgorithm):
    """Multi-Index False-Colour RGB Composite."""

    RASTER_R  = 'RASTER_R'
    RASTER_G  = 'RASTER_G'
    RASTER_B  = 'RASTER_B'
    LABEL_R   = 'LABEL_R'
    LABEL_G   = 'LABEL_G'
    LABEL_B   = 'LABEL_B'
    STRETCH   = 'STRETCH'
    R_MIN     = 'R_MIN'
    R_MAX     = 'R_MAX'
    G_MIN     = 'G_MIN'
    G_MAX     = 'G_MAX'
    B_MIN     = 'B_MIN'
    B_MAX     = 'B_MAX'
    OUTPUT    = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.RASTER_R, 'Red channel raster  (single-band)'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.RASTER_G, 'Green channel raster  (single-band)'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.RASTER_B, 'Blue channel raster  (single-band)'))

        self.addParameter(QgsProcessingParameterString(
            self.LABEL_R, 'Red channel label  (for metadata)', defaultValue='R'))
        self.addParameter(QgsProcessingParameterString(
            self.LABEL_G, 'Green channel label', defaultValue='G'))
        self.addParameter(QgsProcessingParameterString(
            self.LABEL_B, 'Blue channel label', defaultValue='B'))

        self.addParameter(QgsProcessingParameterEnum(
            self.STRETCH,
            'Stretch mode  (applied independently to each channel)',
            options=_STRETCH_MODES,
            defaultValue=0))

        # Per-channel stretch values (only used for linear mode)
        self.addParameter(QgsProcessingParameterNumber(
            self.R_MIN, 'Red channel stretch min  (linear mode)',
            type=QgsProcessingParameterNumber.Double, defaultValue=0.02))
        self.addParameter(QgsProcessingParameterNumber(
            self.R_MAX, 'Red channel stretch max  (linear mode)',
            type=QgsProcessingParameterNumber.Double, defaultValue=0.18))
        self.addParameter(QgsProcessingParameterNumber(
            self.G_MIN, 'Green channel stretch min  (linear mode)',
            type=QgsProcessingParameterNumber.Double, defaultValue=0.01))
        self.addParameter(QgsProcessingParameterNumber(
            self.G_MAX, 'Green channel stretch max  (linear mode)',
            type=QgsProcessingParameterNumber.Double, defaultValue=0.04))
        self.addParameter(QgsProcessingParameterNumber(
            self.B_MIN, 'Blue channel stretch min  (linear mode)',
            type=QgsProcessingParameterNumber.Double, defaultValue=0.02))
        self.addParameter(QgsProcessingParameterNumber(
            self.B_MAX, 'Blue channel stretch max  (linear mode)',
            type=QgsProcessingParameterNumber.Double, defaultValue=0.15))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT, 'Output RGB composite  (3-band float32)'))

    def processAlgorithm(self, parameters, context, feedback):
        lr      = self.parameterAsRasterLayer(parameters, self.RASTER_R, context)
        lg      = self.parameterAsRasterLayer(parameters, self.RASTER_G, context)
        lb      = self.parameterAsRasterLayer(parameters, self.RASTER_B, context)
        lbl_r   = self.parameterAsString(parameters, self.LABEL_R, context)
        lbl_g   = self.parameterAsString(parameters, self.LABEL_G, context)
        lbl_b   = self.parameterAsString(parameters, self.LABEL_B, context)
        stretch = self.parameterAsEnum(parameters, self.STRETCH, context)
        r_min   = self.parameterAsDouble(parameters, self.R_MIN, context)
        r_max   = self.parameterAsDouble(parameters, self.R_MAX, context)
        g_min   = self.parameterAsDouble(parameters, self.G_MIN, context)
        g_max   = self.parameterAsDouble(parameters, self.G_MAX, context)
        b_min   = self.parameterAsDouble(parameters, self.B_MIN, context)
        b_max   = self.parameterAsDouble(parameters, self.B_MAX, context)
        out_path= self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if any(x is None for x in [lr, lg, lb]):
            raise QgsProcessingException('One or more input rasters are invalid')

        # ── Read all three bands ──────────────────────────────────────────
        feedback.pushInfo('Reading input rasters …')
        feedback.setProgress(5)
        r_arr, gt, proj, rows, cols = _read_single_band(lr, f'R ({lbl_r})', feedback)
        feedback.setProgress(20)
        g_arr, gt_g, proj_g, rows_g, cols_g = _read_single_band(lg, f'G ({lbl_g})', feedback)
        feedback.setProgress(35)
        b_arr, gt_b, proj_b, rows_b, cols_b = _read_single_band(lb, f'B ({lbl_b})', feedback)
        feedback.setProgress(50)

        # Dimension check
        if (rows, cols) != (rows_g, cols_g) or (rows, cols) != (rows_b, cols_b):
            raise QgsProcessingException(
                f'Raster dimensions do not match: '
                f'R={cols}×{rows}, G={cols_g}×{rows_g}, B={cols_b}×{rows_b}. '
                'All three rasters must have the same pixel dimensions.')

        # ── Apply stretch ─────────────────────────────────────────────────
        feedback.pushInfo(f'Applying stretch: {_STRETCH_MODES[stretch]} …')
        feedback.setProgress(60)

        if stretch == 0:  # Linear
            r_out = _stretch_linear(r_arr, r_min, r_max)
            g_out = _stretch_linear(g_arr, g_min, g_max)
            b_out = _stretch_linear(b_arr, b_min, b_max)
            stretch_info = (f'R={r_min}–{r_max}, G={g_min}–{g_max}, B={b_min}–{b_max}')
        else:  # Histogram equalisation
            r_out = _stretch_histeq(r_arr)
            g_out = _stretch_histeq(g_arr)
            b_out = _stretch_histeq(b_arr)
            stretch_info = 'histogram equalised per channel'
            feedback.pushWarning(
                'Histogram-equalised RGB: pixel values are not proportional to '
                'absorption depth.  Use for visual display only.')

        # ── Write 3-band output ───────────────────────────────────────────
        feedback.setProgress(80)
        feedback.pushInfo('Writing RGB composite …')

        driver = gdal.GetDriverByName('GTiff')
        out_ds = driver.Create(out_path, cols, rows, 3, gdal.GDT_Float32,
                               options=['COMPRESS=LZW', 'TILED=YES'])
        out_ds.SetGeoTransform(gt)
        out_ds.SetProjection(proj)

        def write_ch(data, band_num, label):
            b = out_ds.GetRasterBand(band_num)
            b.WriteArray(data)
            b.SetNoDataValue(float('nan'))
            b.SetDescription(label)

        write_ch(r_out, 1, f'Red — {lbl_r}')
        write_ch(g_out, 2, f'Green — {lbl_g}')
        write_ch(b_out, 3, f'Blue — {lbl_b}')

        out_ds.SetMetadataItem('RGB_red',     lbl_r)
        out_ds.SetMetadataItem('RGB_green',   lbl_g)
        out_ds.SetMetadataItem('RGB_blue',    lbl_b)
        out_ds.SetMetadataItem('RGB_stretch', stretch_info)
        out_ds.SetMetadataItem('RGB_reference',
            'GSWA Report 261 (Laukamp et al. 2025) — Figures 30b, 32b, 44f etc.')

        out_ds.FlushCache()
        del out_ds

        feedback.pushInfo('')
        feedback.pushInfo('─' * 60)
        feedback.pushInfo('Multi-Index RGB Composite complete.')
        feedback.pushInfo(f'  R (red):   {lbl_r}')
        feedback.pushInfo(f'  G (green): {lbl_g}')
        feedback.pushInfo(f'  B (blue):  {lbl_b}')
        feedback.pushInfo(f'  Stretch:   {stretch_info}')
        feedback.pushInfo('')
        feedback.pushInfo('Display in QGIS: Layer Properties → Symbology → Multiband Color')
        feedback.pushInfo('  Red band=1, Green band=2, Blue band=3')
        feedback.pushInfo('  Set Min=0, Max=1 for all channels')
        feedback.pushInfo('─' * 60)
        feedback.setProgress(100)

        return {self.OUTPUT: out_path}

    def name(self):        return 'multi_index_rgb'
    def displayName(self): return 'Multi-Index RGB Composite'
    def group(self):       return '6 - Spectral Processing Tools'
    def groupId(self):     return 'five_spectral_processing'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Multi-Index False-Colour RGB Composite</b>

        <p>Combines any three single-band rasters into a false-colour RGB
        GeoTIFF for geological interpretation.  Each channel is stretched
        independently.  Output pixel values are in the range 0–1.</p>

        <p><b>GSWA Report 261 recommended channel combinations:</b></p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Red</th><th>Green</th><th>Blue</th><th>Application</th>
          </tr>
          <tr><td>WMai</td><td>CBEai</td><td>KLNai</td>
              <td>White mica / chlorite-epidote / kaolinite (Figs 30b, 45b)</td></tr>
          <tr><td>FOai</td><td>WMai</td><td>KLNai</td>
              <td>Iron oxide / white mica / kaolinite (Figs 32b, 33b)</td></tr>
          <tr><td>PPHai</td><td>WMai</td><td>KLNai</td>
              <td>Pyrophyllite / white mica / kaolinite (Fig 29b)</td></tr>
          <tr><td>K-radiometrics</td><td>WMai</td><td>KLNai</td>
              <td>Potassic alteration / white mica / kaolinite (Figs 44f, 45f)</td></tr>
        </table>

        <p><b>Stretch modes:</b></p>
        <ul>
          <li><b>Linear stretch</b> — pixel values proportional to absorption depth.
              Use when comparing maps quantitatively or feeding into ML workflows.
              Set per-channel min/max to the GSWA recommended values for your region.</li>
          <li><b>Histogram equalisation</b> — maximum visual contrast.
              Use for display and geological interpretation.
              Output values are NOT proportional to absorption depth.</li>
        </ul>

        <p><b>GSWA linear stretch guide (from Report 261 figures):</b></p>
        <ul>
          <li>WMai: Gascoyne min=0.02, max=0.18 | Pilbara min=0.02, max=0.30</li>
          <li>CBEai: Gascoyne min=0.01, max=0.04 | Pilbara min=0.02, max=0.065</li>
          <li>KLNai: Gascoyne min=0.04, max=0.15 | Pilbara min=0.02, max=0.15</li>
          <li>FOai: Gascoyne min=0.10, max=0.30 | Pilbara min=0.25, max=0.41</li>
          <li>PPHai: Pilbara min=0.15, max=0.25</li>
        </ul>

        <p><b>Display in QGIS:</b> After loading the output, open Layer Properties
        → Symbology → Multiband Color.  Set Red=Band 1, Green=Band 2, Blue=Band 3,
        Min=0, Max=1 for all channels.</p>

        <p><i>Background: Laukamp, C., Miles, A.J. et al. (2025) GSWA Report 261,
        Figures 29b, 30b, 31b, 32b, 33b, 44f, 45b, 45f.</i></p>
        """

    def createInstance(self): return MultiIndexRGBAlgorithm()
