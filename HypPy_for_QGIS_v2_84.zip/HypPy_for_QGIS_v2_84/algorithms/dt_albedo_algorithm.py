"""
DT Albedo Decision Tree Classification Algorithm for QGIS Processing

Classifies pixels into four brightness classes using the mean reflectance
(albedo) value of the pixel spectrum.

Albedo is defined as the mean reflectance across all spectral bands for
each pixel, computed from the original hyperspectral raster prior to the
Wavelength of Minimum step. This must be supplied as a pre-computed
single-band raster with values in the 0-1 reflectance range.

To compute the albedo raster from your hyperspectral data, use the
Band Math or Statistics tools to calculate the per-pixel band mean.

Input:
  b1 - Mean reflectance (albedo) raster (single-band, values 0-1)

Decision tree (dt_albedo.jpg):
  b1 <  0.25 -> dark
  b1 <  0.38 -> med-dark
  b1 <= 0.50 -> med-light
  b1 >  0.50 -> light

Thresholds based on experience with brightness levels of similar types
of rock in hyperspectral images. med = medium.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

import numpy as np
from osgeo import gdal
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

ALBEDO_CLASSES = [
    (0, 'unclassified', 0,   0,   0  ),
    (1, 'dark',         30,  30,  30 ),  # near black
    (2, 'med-dark',     110, 110, 110),  # dark grey
    (3, 'med-light',    180, 180, 180),  # light grey
    (4, 'light',        255, 255, 255),  # white
]
NAME_TO_ID = {m[1]: m[0] for m in ALBEDO_CLASSES}
ID_TO_NAME = {m[0]: m[1] for m in ALBEDO_CLASSES}



class DtAlbedoAlgorithm(QgsProcessingAlgorithm):

    ALBEDO_INPUT = 'ALBEDO_INPUT'
    OUTPUT_RGB   = 'OUTPUT_RGB'
    OUTPUT_CLASS = 'OUTPUT_CLASS'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.ALBEDO_INPUT,
            'Hyperspectral raster (original spectral cube — all bands used to compute mean reflectance)'))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_RGB, 'Output: Albedo RGB raster', optional=True))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_CLASS, 'Output: Albedo integer class raster'))

    def processAlgorithm(self, parameters, context, feedback):
        alb_layer = self.parameterAsRasterLayer(parameters, self.ALBEDO_INPUT, context)
        out_class = self.parameterAsOutputLayer(parameters, self.OUTPUT_CLASS, context)
        out_rgb   = self.parameterAsOutputLayer(parameters, self.OUTPUT_RGB,   context) \
                    if self.OUTPUT_RGB in parameters else None

        # Use the layer's dataProvider source path, stripping any QGIS
        # band/subdataset decorators so GDAL sees the full file with all bands
        raw_source = alb_layer.dataProvider().dataSourceUri()
        # Strip anything after | (QGIS appends |layerid=0 etc. for some formats)
        file_path = raw_source.split('|')[0].strip()
        feedback.pushInfo(f'Opening: {file_path}')

        alb_ds = gdal.Open(file_path, gdal.GA_ReadOnly)
        if alb_ds is None:
            raise QgsProcessingException(f'Cannot open hyperspectral raster: {file_path}')

        cols, rows  = alb_ds.RasterXSize, alb_ds.RasterYSize
        n_bands     = alb_ds.RasterCount
        feedback.pushInfo(f'Hyperspectral raster: {cols} x {rows}, {n_bands} bands')
        feedback.pushInfo('Computing per-pixel mean reflectance across all bands (albedo)...')

        # Accumulate band sum into float32 array, then divide
        band_sum = np.zeros((rows, cols), dtype=np.float64)
        valid_count = np.zeros((rows, cols), dtype=np.int32)

        for i in range(1, n_bands + 1):
            if feedback.isCanceled():
                return {}
            arr = alb_ds.GetRasterBand(i).ReadAsArray().astype(np.float32)
            nodata_val = alb_ds.GetRasterBand(i).GetNoDataValue()
            if nodata_val is not None:
                mask = arr != nodata_val
            else:
                mask = np.isfinite(arr)
            band_sum[mask] += arr[mask]
            valid_count[mask] += 1
            if i % 20 == 0 or i == n_bands:
                feedback.pushInfo(f'  Processed {i}/{n_bands} bands...')
                feedback.setProgress(int(20 * i / n_bands))

        # Compute mean; pixels with no valid bands -> NaN
        with np.errstate(invalid='ignore'):
            b1 = np.where(valid_count > 0,
                          band_sum / valid_count,
                          np.nan).astype(np.float32)

        # Report value range
        valid = b1[np.isfinite(b1)]
        if valid.size == 0:
            raise QgsProcessingException('No valid data found in raster.')
        b1_min  = float(np.min(valid))
        b1_max  = float(np.max(valid))
        b1_mean = float(np.mean(valid))
        feedback.pushInfo(f'Mean reflectance (b1): min={b1_min:.4f}  max={b1_max:.4f}  mean={b1_mean:.4f}')

        # Auto-scale if values are not in 0-1 range
        if b1_max > 2.0:
            scale = 10000.0 if b1_max > 100 else b1_max
            feedback.pushInfo(f'Values outside 0-1 range — dividing by {scale:.0f} to normalise.')
            b1 = b1 / scale
            feedback.pushInfo(f'After scaling: min={float(np.nanmin(b1)):.4f}  max={float(np.nanmax(b1)):.4f}')

        # Compute dynamic thresholds from quartiles of valid (non-zero) pixels
        valid_nonzero = b1[np.isfinite(b1) & (b1 > 0)]
        if valid_nonzero.size == 0:
            raise QgsProcessingException('No valid non-zero pixels found after scaling.')
        t25 = float(np.percentile(valid_nonzero, 25))
        t50 = float(np.percentile(valid_nonzero, 50))
        t75 = float(np.percentile(valid_nonzero, 75))
        feedback.pushInfo(f'Dynamic thresholds (quartiles of valid pixels):')
        feedback.pushInfo(f'  dark     : b1 <  {t25:.4f}  (25th percentile)')
        feedback.pushInfo(f'  med-dark : b1 <  {t50:.4f}  (50th percentile)')
        feedback.pushInfo(f'  med-light: b1 <= {t75:.4f}  (75th percentile)')
        feedback.pushInfo(f'  light    : b1 >  {t75:.4f}')
        feedback.pushInfo(f'Applying dt_albedo decision tree...')
        feedback.setProgress(20)

        nodata = ~np.isfinite(b1)
        b1s = np.nan_to_num(b1, nan=0.0)

        class_data = np.zeros((rows, cols), dtype=np.uint8)
        class_data[(b1s > 0) & (b1s <  t25)] = NAME_TO_ID['dark']
        class_data[(b1s > 0) & (b1s >= t25) & (b1s <  t50)] = NAME_TO_ID['med-dark']
        class_data[(b1s > 0) & (b1s >= t50) & (b1s <= t75)] = NAME_TO_ID['med-light']
        class_data[(b1s > 0) & (b1s >  t75)] = NAME_TO_ID['light']
        class_data[nodata] = 0
        feedback.setProgress(70)

        feedback.pushInfo('')
        feedback.pushInfo('Classification summary:')
        unique, counts = np.unique(class_data, return_counts=True)
        total = class_data.size
        for uid, cnt in zip(unique, counts):
            pct = 100.0 * cnt / total
            feedback.pushInfo(
                f'  {ID_TO_NAME.get(int(uid),"?"):15s}  (id={uid:2d})  {cnt:8d} px  {pct:5.1f}%')

        driver = gdal.GetDriverByName('GTiff')

        # ── Class raster (primary — always written) ──────────────────────
        feedback.pushInfo('Writing integer class raster...')
        ct = gdal.ColorTable()
        for mid, name, r, g, bv in ALBEDO_CLASSES:
            ct.SetColorEntry(mid, (r, g, bv, 255))
        class_ds = driver.Create(out_class, cols, rows, 1, gdal.GDT_Byte,
                                 options=['COMPRESS=LZW', 'TILED=YES'])
        class_ds.SetGeoTransform(alb_ds.GetGeoTransform())
        class_ds.SetProjection(alb_ds.GetProjection())
        b = class_ds.GetRasterBand(1)
        b.SetNoDataValue(0)
        b.SetDescription('Albedo Class')
        b.SetRasterColorTable(ct)
        b.SetRasterColorInterpretation(gdal.GCI_PaletteIndex)
        b.WriteArray(class_data)
        b.FlushCache()
        # Raster Attribute Table — class names visible in QGIS legend
        rat = gdal.RasterAttributeTable()
        rat.CreateColumn('Value', gdal.GFT_Integer,  gdal.GFU_MinMax)
        rat.CreateColumn('Class', gdal.GFT_String,   gdal.GFU_Name)
        rat.CreateColumn('R',     gdal.GFT_Integer,  gdal.GFU_Red)
        rat.CreateColumn('G',     gdal.GFT_Integer,  gdal.GFU_Green)
        rat.CreateColumn('B',     gdal.GFT_Integer,  gdal.GFU_Blue)
        for row_idx, (mid, name, r, g, bv) in enumerate(ALBEDO_CLASSES):
            rat.SetValueAsInt   (row_idx, 0, mid)
            rat.SetValueAsString(row_idx, 1, name)
            rat.SetValueAsInt   (row_idx, 2, r)
            rat.SetValueAsInt   (row_idx, 3, g)
            rat.SetValueAsInt   (row_idx, 4, bv)
        b.SetDefaultRAT(rat)
        class_ds = None
        result = {self.OUTPUT_CLASS: out_class}
        # ── RGB raster (optional) ────────────────────────────────────────
        if out_rgb:
            feedback.pushInfo('Writing RGB colour raster...')
            rgb_r = np.zeros((rows, cols), dtype=np.uint8)
            rgb_g = np.zeros((rows, cols), dtype=np.uint8)
            rgb_b = np.zeros((rows, cols), dtype=np.uint8)
            for mid, name, r, g, bv in ALBEDO_CLASSES:
                mask = class_data == mid
                rgb_r[mask], rgb_g[mask], rgb_b[mask] = r, g, bv
            rgb_ds = driver.Create(out_rgb, cols, rows, 3, gdal.GDT_Byte,
                                   options=['COMPRESS=LZW', 'TILED=YES'])
            rgb_ds.SetGeoTransform(alb_ds.GetGeoTransform())
            rgb_ds.SetProjection(alb_ds.GetProjection())
            for idx, (arr, lbl) in enumerate(
                    [(rgb_r, 'Red'), (rgb_g, 'Green'), (rgb_b, 'Blue')], 1):
                band = rgb_ds.GetRasterBand(idx)
                band.WriteArray(arr)
                band.SetDescription(lbl)
                band.FlushCache()
            rgb_ds = None
            feedback.setProgress(85)

            result[self.OUTPUT_RGB] = out_rgb

        alb_ds = None
        feedback.setProgress(100)
        feedback.pushInfo('dt_albedo classification complete.')
        return result

    def name(self):        return 'dt_albedo'
    def displayName(self): return 'DT Albedo Classification'
    def group(self):       return '4 - Decision Tree Classification'
    def groupId(self):     return '4_decision_tree'

    def shortHelpString(self):
        return """
        <b>DT Albedo Classification</b>

        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube only.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.<br/>Run <i>Workflow A</i> to generate required WoM rasters.
        </p>


        <p>Classifies pixels into four brightness classes based on mean
        reflectance (albedo). Albedo is the <b>mean reflectance across all
        spectral bands</b> for each pixel, computed internally from the
        input hyperspectral cube.</p>

        <p><b>Input:</b></p>
        <ul>
          <li><b>Hyperspectral raster</b> — the original spectral cube
              prior to the Wavelength of Minimum step. All bands are read
              and averaged per pixel to produce the albedo value. Values
              above 2.0 are automatically scaled to the 0-1 range.</li>
        </ul>

        <p><b>Decision tree thresholds (computed dynamically per image):</b></p>
        <ul>
          <li>b1 &lt; 25th percentile  &rarr; <b>dark</b></li>
          <li>b1 &lt; 50th percentile  &rarr; <b>med-dark</b></li>
          <li>b1 &le; 75th percentile  &rarr; <b>med-light</b></li>
          <li>b1 &gt; 75th percentile  &rarr; <b>light</b></li>
        </ul>
        <p>Thresholds are calculated from the quartiles of valid (non-zero)
        pixels, so each image is classified relative to its own brightness
        distribution. The actual threshold values are reported in the log.</p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>RGB raster</b> — greyscale brightness map:
              dark=near black, med-dark=dark grey,
              med-light=light grey, light=white.</li>
          <li><b>Integer class raster</b> — optional palette-indexed GeoTIFF.</li>
        </ul>

        <p>The log reports the computed mean reflectance min/max/mean to
        confirm the correct data range is being used.</p>

        <p><i>Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return DtAlbedoAlgorithm()
