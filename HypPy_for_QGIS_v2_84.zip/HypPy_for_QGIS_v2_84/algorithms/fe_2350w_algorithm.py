"""
Feature Extraction — 2350W

WoM range 2310-2370 nm, wavelength map stretch 2320-2366 nm.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
)
import processing
import os

from ..core.envi_header import (
    get_wavelengths_from_dataset,
    get_sensor_info,
    has_poor_snr_in_range,
)


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with wavelength metadata.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
        <p style="background-color:#fff3cd; padding:6px; border-left:4px solid #ffc107;">
        <b>⚠ Sensor note (2310–2370 nm):</b>
        PRISMA has insufficient SNR in the 2300–2450 nm range for reliable results.
        <b>EnMAP or EMIT are recommended</b> for this feature
        (GSWA Report 261 §3.2). A warning will appear in the Processing Log if
        PRISMA is detected.
        </p>
"""


class Fe2350WAlgorithm(QgsProcessingAlgorithm):
    """Feature Extraction — 2350W."""

    INPUT         = 'INPUT'
    NUM_FEATURES  = 'NUM_FEATURES'
    OUTPUT_WOM    = 'OUTPUT_WOM'
    OUTPUT_MAP    = 'OUTPUT_MAP'
    LEGEND_OUTPUT = 'LEGEND_OUTPUT'

    WOM_START = 2310.0
    WOM_END   = 2370.0
    MAP_MIN   = 2320.0
    MAP_MAX   = 2366.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract (1-9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=1, minValue=1, maxValue=9))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_WOM,
            'Output WoM raster (2310-2370 nm)'))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_MAP,
            'Output Wavelength Map RGB (2320-2366 nm stretch)'))
        self.addParameter(QgsProcessingParameterFileDestination(
            self.LEGEND_OUTPUT,
            'Output Colour Legend (PNG)',
            fileFilter='PNG Files (*.png)',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        cube        = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n           = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        out_wom     = self.parameterAsOutputLayer(parameters, self.OUTPUT_WOM, context)
        out_map     = self.parameterAsOutputLayer(parameters, self.OUTPUT_MAP, context)
        legend_path = self.parameterAsFileOutput(parameters, self.LEGEND_OUTPUT, context)

        self._legend_path = None


        # ── Sensor-aware SNR warning ──────────────────────────────────────
        # Identify sensor from wavelength fingerprint and warn if the WoM
        # range overlaps a known poor-SNR zone (e.g. PRISMA 2300-2450 nm).
        # GSWA Report 261, §3.2: "instrument noise prevented the generation
        # of useful hyperspectral products from the 2300–2400 nm range."
        try:
            from osgeo import gdal as _gdal
            _ds = _gdal.Open(cube.source())
            if _ds is not None:
                _wavs = get_wavelengths_from_dataset(
                    _ds, _ds.RasterCount, cube.source(), feedback=None)
                _sinfo = get_sensor_info(_wavs, _ds.RasterCount)
                if _sinfo['matched'] and has_poor_snr_in_range(
                        _sinfo, self.WOM_START, self.WOM_END):
                    msg = (
                        f"{_sinfo['name']} detected: the "
                        f"{self.WOM_START:.0f}–{self.WOM_END:.0f} nm WoM range "
                        f"overlaps a known low-SNR zone for this sensor. "
                        f"Results may show noise artefacts. {_sinfo['snr_note']}"
                    )
                    feedback.pushWarning(msg)
                del _ds
        except Exception:
            pass  # sensor detection is advisory only — never block processing
        # ─────────────────────────────────────────────────────────────────
        # Step 1: Wavelength of Minimum 2310-2370 nm
        feedback.setProgress(5)
        feedback.pushInfo('Step 1/2  Wavelength of Minimum  2310-2370 nm ...')
        wom_result = processing.run(
            'hyppy:wavelength_of_minimum',
            {
                'INPUT':            cube,
                'START_WAVELENGTH': self.WOM_START,
                'END_WAVELENGTH':   self.WOM_END,
                'MODE':             0,
                'NUM_FEATURES':     n,
                'BROAD':            False,
                'USE_BBL':          True,
                'OUTPUT':           out_wom,
            },
            context=context,
            feedback=feedback,
            is_child_algorithm=True,
        )
        if feedback.isCanceled():
            return {}

        wom_path = wom_result['OUTPUT']
        feedback.pushInfo(f'  WoM raster saved: {wom_path}')

        # Step 2: Wavelength Mapping 2320-2366 nm
        feedback.setProgress(50)
        feedback.pushInfo('Step 2/2  Wavelength Mapping  2320-2366 nm stretch ...')

        from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
        wma     = WavelengthMappingAlgorithm()
        palette = wma.create_rainbow_palette()

        map_path = wma._run_colour_mapping(
            wom_path, palette,
            self.MAP_MIN, self.MAP_MAX,
            self.DEPTH_MIN, self.DEPTH_MAX,
            out_map, feedback,
        )

        feedback.setProgress(88)
        feedback.pushInfo(f'  Wavelength map saved: {map_path}')

        # Step 3: Legend - default filename is <tool_label>_legend.png
        # beside the WoM output so it is easy to find and clearly named.
        if not legend_path:
            wom_dir     = os.path.dirname(wom_path)
            legend_path = os.path.join(wom_dir, '2350W_legend.png')
        try:
            saved = wma.create_legend(
                legend_path, palette,
                self.MAP_MIN, self.MAP_MAX,
                self.DEPTH_MIN, self.DEPTH_MAX,
                feedback,
            )
            if saved:
                self._legend_path = saved
                feedback.pushInfo(f'  Colour legend saved: {saved}')
        except Exception as e:
            feedback.pushWarning(f'Legend generation failed: {e}')

        feedback.setProgress(100)
        feedback.pushInfo('Feature Extraction 2350W complete.')

        return {
            self.OUTPUT_WOM:    wom_path,
            self.OUTPUT_MAP:    map_path,
            self.LEGEND_OUTPUT: self._legend_path or '',
        }

    def postProcessAlgorithm(self, context, feedback):
        if getattr(self, '_legend_path', None):
            from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
            WavelengthMappingAlgorithm()._show_legend_dock(self._legend_path, feedback)
        return {}

    def name(self):        return 'fe_2350w'
    def displayName(self): return 'FE17 - 2350W'
    def group(self):       return '7 - Feature Extraction'
    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2350W  (Pyrophyllite / Calcite / Phengite Al-OH &amp; CO₃)</b>

        <p>Targets the pyrophyllite Al-OH overtone at <b>~2319 nm</b> plus the calcite
        CO₃ absorption at <b>~2335 nm</b> and phengite / muscovite Al-OH features near
        <b>~2345–2365 nm</b>. The pyrophyllite feature at ~2319 nm is noted in GMEX as
        persisting in mixed spectra. Derived from USGS GMEX reference spectra for
        pyrophyllite (AusSpec International 2005), calcite, and muscovite.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>2310-2370 nm</b>.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>2320-2366 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>2310-2370 nm</td></tr>
          <tr><td>Colour stretch min</td><td>2320 nm</td></tr>
          <tr><td>Colour stretch max</td><td>2366 nm</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>2320–2366 nm colour stretch — mineral positions (GMEX):</b></p>
        <ul>
          <li><b>Blue (~2320–2328 nm)</b> — Pyrophyllite Al-OH overtone (~2319 nm;
              GMEX: "persists in mixtures"); <b>Dolomite</b> CaMg(CO₃)₂ (~2320–2328 nm;
              GMEX: "only one to persist in mixtures")</li>
          <li><b>Cyan (~2328–2338 nm)</b> — <b>Ankerite</b> Ca(Mg,Fe²⁺)(CO₃)₂
              (~2330–2340 nm; GMEX: between dolomite and calcite, "only absorption
              that persists in mixtures"); Epidote FeOH (~2335–2342 nm)</li>
          <li><b>Green (~2338–2345 nm)</b> — <b>Calcite</b> CaCO₃ (~2340–2345 nm;
              GMEX: "diagnostic carbonate absorption; this is the only absorption
              that persists in mixtures"); Illite/Muscovite Al-OH secondary (~2347 nm)</li>
          <li><b>Yellow (~2345–2352 nm)</b> — Phlogopite Mg-OH (~2345 nm);
              Muscovite Al-OH secondary (~2342 nm; "two diagnostics persist in
              mixed spectra" — GMEX)</li>
          <li><b>Red (~2352–2366 nm)</b> — Phengite / Muscovite Al-OH overtone
              (~2350–2360 nm); Illite secondary (~2440 nm range, partially captured)</li>
        </ul>

        <p><b>Carbonate discrimination summary (GMEX):</b> In this stretch,
        dolomite (2320–2328 nm, blue) and calcite (2340–2345 nm, green) are
        clearly separated. Ankerite fills the gap between them (cyan).
        Combine with FE16-2320W and FE06-1760W for robust identification.</p>

        <p>Use this tool together with FE02-1396W, FE08-2066D, and FE10-2160D for
        comprehensive pyrophyllite mapping, and with FE06-1760W and FE16-2320W for
        carbonate suite discrimination.</p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, pyrophyllite entry
        (AusSpec International 2005), calcite, and muscovite entries.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe2350WAlgorithm()
