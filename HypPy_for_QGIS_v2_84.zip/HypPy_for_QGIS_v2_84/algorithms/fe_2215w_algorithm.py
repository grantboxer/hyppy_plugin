"""
Feature Extraction — 2215W  (White Mica Al-OH)

Uses WoM-C (2100-2400 nm) as the wavelength source and applies a colour
stretch of 2195-2215 nm to resolve the white mica (muscovite–phengite)
Al-OH absorption series.

From GMEX / USGS Spectral Library (splib07a):
  Muscovite:  ~2200–2210 nm — Al-OH primary absorption
  Illite:     ~2200 nm       — Al-OH absorption; position shifts with
                               octahedral Al/Fe and interlayer composition
  Phengite:   ~2205–2215 nm — Al-OH shifts toward longer wavelengths
                               as Mg/Fe substitutes for Al (phengite series)
  The 2195–2215 nm stretch window captures this white mica diagnostic range:
  shorter positions = higher Al (muscovite), longer positions = Mg/Fe
  substitution (phengite trend) or increased disorder.

WoM source: WoM-C  (2100-2400 nm)  — pre-computed or auto-calculated
Stretch:    2195-2215 nm            — white mica Al-OH diagnostic window

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
)
import processing
import os


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with wavelength metadata.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""


class Fe2215WAlgorithm(QgsProcessingAlgorithm):
    """Feature Extraction — 2215W (White Mica Al-OH) using WoM-C."""

    INPUT         = 'INPUT'
    INPUT_WOM_C   = 'INPUT_WOM_C'
    NUM_FEATURES  = 'NUM_FEATURES'
    OUTPUT_WOM_C  = 'OUTPUT_WOM_C'
    OUTPUT_MAP    = 'OUTPUT_MAP'
    LEGEND_OUTPUT = 'LEGEND_OUTPUT'

    # WoM-C range (used when auto-calculating)
    WOM_C_START = 2100.0
    WOM_C_END   = 2400.0

    # Colour stretch
    MAP_MIN   = 2195.0
    MAP_MAX   = 2215.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT,
            'Hyperspectral cube  (required for auto-calculation of WoM-C)'))

        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT_WOM_C,
            'WoM-C raster (2100-2400 nm)  — leave blank to auto-calculate',
            optional=True))

        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features (used only when auto-calculating WoM-C)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=1, minValue=1, maxValue=9))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_WOM_C,
            'Output WoM-C raster (2100-2400 nm)  — written only when auto-calculated',
            optional=True))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_MAP,
            'Output Wavelength Map RGB (2195-2215 nm stretch)'))

        self.addParameter(QgsProcessingParameterFileDestination(
            self.LEGEND_OUTPUT,
            'Output Colour Legend (PNG)',
            fileFilter='PNG Files (*.png)',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        cube        = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        wom_c_layer = self.parameterAsRasterLayer(parameters, self.INPUT_WOM_C, context)
        n           = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        out_wom_c   = self.parameterAsOutputLayer(parameters, self.OUTPUT_WOM_C, context)
        out_map     = self.parameterAsOutputLayer(parameters, self.OUTPUT_MAP, context)
        legend_path = self.parameterAsFileOutput(parameters, self.LEGEND_OUTPUT, context)

        self._legend_path = None
        wom_c_was_calculated = False

        # ── Step 1: Obtain WoM-C ─────────────────────────────────────────────
        if wom_c_layer is not None:
            # Pre-computed WoM-C supplied — use it directly
            wom_c_path = wom_c_layer.source()
            feedback.pushInfo(f'Using supplied WoM-C: {wom_c_path}')
        else:
            # Auto-calculate WoM-C from the hyperspectral cube
            feedback.setProgress(5)
            feedback.pushInfo(
                'No WoM-C supplied — auto-calculating WoM-C (2100-2400 nm) ...')

            # Determine output path for WoM-C when none specified
            if not out_wom_c:
                map_dir   = os.path.dirname(out_map)
                out_wom_c = os.path.join(map_dir, 'WoM_C_2100_2400.tif')

            wom_c_result = processing.run(
                'hyppy:generate_wom_c',
                {
                    'INPUT':        cube,
                    'NUM_FEATURES': n,
                    'OUTPUT':       out_wom_c,
                },
                context=context,
                feedback=feedback,
                is_child_algorithm=True,
            )
            if feedback.isCanceled():
                return {}

            wom_c_path = wom_c_result['OUTPUT']
            wom_c_was_calculated = True
            feedback.pushInfo(f'  WoM-C saved: {wom_c_path}')

        if feedback.isCanceled():
            return {}

        # ── Step 2: Wavelength Map 2195-2215 nm using WoM-C Band 1 ──────────
        feedback.setProgress(55)
        feedback.pushInfo(
            'Step 2  Wavelength Mapping  2195-2215 nm stretch  (White Mica Al-OH) ...')
        feedback.pushInfo(
            '  Blue = muscovite/high-Al illite (~2195 nm)  '
            'Red = phengite trend (~2215 nm)')

        from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
        wma     = WavelengthMappingAlgorithm()
        palette = wma.create_rainbow_palette()

        map_path = wma._run_colour_mapping(
            wom_c_path, palette,
            self.MAP_MIN, self.MAP_MAX,
            self.DEPTH_MIN, self.DEPTH_MAX,
            out_map, feedback,
        )

        feedback.setProgress(88)
        feedback.pushInfo(f'  Wavelength map saved: {map_path}')

        # ── Step 3: Legend ───────────────────────────────────────────────────
        if not legend_path:
            map_dir_out = os.path.dirname(map_path)
            legend_path = os.path.join(map_dir_out, '2215W_legend.png')
        try:
            saved = wma.create_legend(
                legend_path, palette,
                self.MAP_MIN, self.MAP_MAX,
                self.DEPTH_MIN, self.DEPTH_MAX,
                feedback,
            )
            if saved:
                self._legend_path = saved
                feedback.pushInfo(f'  Colour legend saved: {saved}')
        except Exception as e:
            feedback.pushWarning(f'Legend generation failed: {e}')

        feedback.setProgress(100)
        feedback.pushInfo('Feature Extraction 2215W complete.')

        result = {
            self.OUTPUT_MAP:    map_path,
            self.LEGEND_OUTPUT: self._legend_path or '',
        }
        if wom_c_was_calculated:
            result[self.OUTPUT_WOM_C] = wom_c_path

        return result

    def postProcessAlgorithm(self, context, feedback):
        if getattr(self, '_legend_path', None):
            from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
            WavelengthMappingAlgorithm()._show_legend_dock(self._legend_path, feedback)
        return {}

    def name(self):        return 'fe_2215w'
    def displayName(self): return 'FE-2215W  (White Mica Al-OH)'
    def group(self):       return '7 - Feature Extraction'
    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2215W  (White Mica Al-OH)</b>

        <p>Maps the diagnostic Al-OH absorption of white mica minerals
        (muscovite, illite, phengite) using the <b>WoM-C (2100-2400 nm)</b>
        wavelength-of-minimum raster and a colour stretch of <b>2195-2215 nm</b>.
        If no WoM-C is supplied the tool calculates it automatically from the
        hyperspectral cube.
        Derived from USGS GMEX / splib07a reference spectra for the white mica group.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li><b>Checks</b> whether a WoM-C raster has been supplied.</li>
          <li>If not, <b>auto-calculates WoM-C</b> (2100-2400 nm) from the cube.</li>
          <li>Generates a <b>Wavelength Map</b> from WoM-C Band 1 with colour
              stretch <b>2195-2215 nm</b> (white mica Al-OH diagnostic window).</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM source</td><td>WoM-C (2100-2400 nm)</td></tr>
          <tr><td>Colour stretch min</td><td>2195 nm (muscovite / high-Al illite)</td></tr>
          <tr><td>Colour stretch max</td><td>2215 nm (phengite trend / Mg&#x2013;Fe substitution)</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue = high-Al, Red = Mg/Fe-substituted)</td></tr>
        </table>

        <p><b>White Mica Al-OH absorption positions (GMEX / splib07a):</b></p>
        <ul>
          <li><b>~2195&#x2013;2200 nm</b> &#x2014; Muscovite (high-Al end-member); also illite end-member</li>
          <li><b>~2200&#x2013;2207 nm</b> &#x2014; Illite (Al-OH; position varies with composition
              and interlayer charge)</li>
          <li><b>~2207&#x2013;2215 nm</b> &#x2014; Phengite series (Al-OH shifts to longer wavelengths
              as Mg or Fe substitutes for Al in octahedral sites)</li>
        </ul>

        <p><b>Mineral discrimination (colour stretch 2195-2215 nm):</b></p>
        <ul>
          <li><b>Blue (~2195-2200 nm)</b> &#x2014; Muscovite / high-Al illite</li>
          <li><b>Green (~2200-2207 nm)</b> &#x2014; Illite (intermediate composition)</li>
          <li><b>Yellow&#x2013;Red (~2207-2215 nm)</b> &#x2014; Phengite / Mg&#x2013;Fe-rich white mica</li>
        </ul>

        <p><i>Tip: if you have already run Step 2a (Generate WoM-C) earlier in your
        workflow, supply that raster in the optional <b>WoM-C raster</b> field to
        skip recalculation. Leave it blank to let the tool calculate WoM-C
        automatically.</i></p>

        <p><i>This tool complements FE12-2200W (broad Al-OH survey) and
        FE13-2206W (kaolinite discrimination). Use in combination with
        DT-IllCryst for illite crystallinity mapping, or with DT-Ill-Kaol
        to discriminate white mica from kaolinite.</i></p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM-C raster</b> &#x2014; only written when auto-calculated (Band 1: wavelength,
              Band 2: feature depth). Omitted if a pre-computed WoM-C was supplied.</li>
          <li><b>Wavelength Map RGB</b> &#x2014; colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> &#x2014; 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, white mica group
        (muscovite, illite, phengite). Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe2215WAlgorithm()
