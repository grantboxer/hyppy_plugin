"""
Workflow A — Generate WoM Rasters from a hyperspectral cube.

Four algorithms in this module:
  GenerateAllWomAlgorithm  — all three in one run
  GenerateWomAAlgorithm    — 750–1300 nm
  GenerateWomBAlgorithm    — 1850–2100 nm
  GenerateWomCAlgorithm    — 2100–2400 nm

Each wraps the existing WavelengthOfMinimumAlgorithm with preset
wavelength range parameters, so the user only needs to supply the
hyperspectral cube, number of features, and output path(s).

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterNumber,
    QgsProcessingParameterEnum,
    QgsProcessingException,
    QgsProcessingUtils,
)
import processing


# ── shared helpers ─────────────────────────────────────────────────────────────

POLY_ORDER_OPTIONS = [
    '2nd order (quadratic)  — default, fast, suited to narrow/symmetric features',
    '4th order (quartic)    — improved fit for asymmetric or broad features',
]

WORKFLOW_NOTE = """
        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral spectral cube with wavelength metadata.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""

WOM_B_AVIRIS_NOTE = """
        <p style="background-color:#fff3e0; padding:6px; border-left:4px solid #e65100;">
        <b>AVIRIS-NG note:</b> The 1850–1960 nm portion of this range falls within
        the AVIRIS-NG atmospheric water bad band zone (~1790–1960 nm). After BBL
        masking, WoM-B will effectively process <b>~1962–2101 nm</b> only (29 bands
        at ~5 nm spacing). The WoM algorithm will still run successfully and find
        real absorption features in this range (2000 nm H₂O/carbonate, 2100 nm AlOH
        shoulder). However, the feature depth output (Band 2) will reflect the
        2000 nm region, <b>not</b> the 1900 nm halloysite water band that the
        <b>dt_illcryst</b> and <b>dt_ill_kaol</b> classifiers were calibrated for.
        Decision tree thresholds using WoM-B Band 2 depth may need recalibration
        for AVIRIS-NG data.
        </p>
"""

NUM_FEATURES_HELP = """
        <p><b>Number of features (1–9):</b> How many absorption minima to
        extract per pixel within the wavelength range. Features are sorted
        by depth (deepest first), so Band 1 always holds the dominant
        feature. The output raster will have 2 x N bands
        (wavelength + depth for each feature).</p>

        <p>For decision tree classification, 1 feature is sufficient.
        Use more features when you want to capture secondary absorption
        positions for custom analysis.</p>
"""


def _run_wom(cube_layer, start_nm, end_nm, num_features, output_path, context, feedback, poly_order=0):
    """Call the Wavelength of Minimum algorithm with preset parameters."""
    params = {
        'INPUT':            cube_layer,
        'START_WAVELENGTH': float(start_nm),
        'END_WAVELENGTH':   float(end_nm),
        'MODE':             0,       # Division (recommended)
        'NUM_FEATURES':     int(num_features),
        'BROAD':            False,
        'POLY_ORDER':       int(poly_order),   # 0 = 2nd order, 1 = 4th order
        'USE_BBL':          True,
        'OUTPUT':           output_path,
    }
    result = processing.run(
        'hyppy:wavelength_of_minimum',
        params,
        context=context,
        feedback=feedback,
        is_child_algorithm=True,
    )
    return result['OUTPUT']


# ── WoM-A: 750-1300 nm ────────────────────────────────────────────────────────

class GenerateWomAAlgorithm(QgsProcessingAlgorithm):

    INPUT        = 'INPUT'
    NUM_FEATURES = 'NUM_FEATURES'
    OUTPUT       = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract (1-9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=3, minValue=1, maxValue=9))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT, 'WoM-A output (750-1300 nm)'))

    def processAlgorithm(self, parameters, context, feedback):
        cube = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n    = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        out  = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        feedback.pushInfo(f'Generating WoM-A: 750-1300 nm  (features: {n}) ...')
        result = _run_wom(cube, 750, 1300, n, out, context, feedback)
        return {self.OUTPUT: result}

    def name(self):        return 'generate_wom_a'
    def displayName(self): return 'Step 2a - Generate WoM-A (750-1300 nm)'
    def group(self):       return '3 - Generate WoM Rasters'
    def groupId(self):     return '3_generate_wom'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Generate WoM-A (750-1300 nm)</b>

        <p>Creates the Wavelength of Minimum raster for the 750-1300 nm
        range from the hyperspectral cube. This range captures iron oxide
        and hydroxyl features.</p>
        """ + NUM_FEATURES_HELP + """
        <p><b>Output:</b> Raster with 2 x N bands (Band 1 = wavelength of
        primary minimum, Band 2 = feature depth, and so on for each
        additional feature).</p>

        <p>WoM-A is reserved for future decision tree classifiers.</p>
        """

    def createInstance(self): return GenerateWomAAlgorithm()


# ── WoM-B: 1850-2100 nm ───────────────────────────────────────────────────────

class GenerateWomBAlgorithm(QgsProcessingAlgorithm):

    INPUT        = 'INPUT'
    NUM_FEATURES = 'NUM_FEATURES'
    POLY_ORDER   = 'POLY_ORDER'
    OUTPUT       = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract (1-9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=3, minValue=1, maxValue=9))
        self.addParameter(QgsProcessingParameterEnum(
            self.POLY_ORDER,
            'Polynomial fit order',
            options=POLY_ORDER_OPTIONS,
            defaultValue=0))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT, 'WoM-B output (1850-2100 nm)'))

    def processAlgorithm(self, parameters, context, feedback):
        cube       = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n          = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        poly_order = self.parameterAsEnum(parameters, self.POLY_ORDER, context)
        out        = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        poly_label = '2nd order' if poly_order == 0 else '4th order'
        feedback.pushInfo(f'Generating WoM-B: 1850-2100 nm  (features: {n}, poly: {poly_label}) ...')
        feedback.pushWarning(
            'AVIRIS-NG users: BBL masking will exclude 1852-1957 nm (the atmospheric water zone). '
            'WoM-B will effectively process ~1962-2101 nm. '
            'The output depth (Band 2) reflects the 2000 nm region, not the 1900 nm band. '
            'dt_illcryst / dt_ill_kaol thresholds using this depth may need recalibration.'
        )
        result = _run_wom(cube, 1850, 2100, n, out, context, feedback, poly_order)
        return {self.OUTPUT: result}

    def name(self):        return 'generate_wom_b'
    def displayName(self): return 'Step 2b - Generate WoM-B (1850-2100 nm)'
    def group(self):       return '3 - Generate WoM Rasters'
    def groupId(self):     return '3_generate_wom'

    def shortHelpString(self):
        return WORKFLOW_NOTE + WOM_B_AVIRIS_NOTE + """
        <b>Generate WoM-B (1850-2100 nm)</b>

        <p>Creates the Wavelength of Minimum raster for the 1850-2100 nm
        range from the hyperspectral cube. This range captures the
        1900 nm water/carbonate feature and the shoulder of the
        2100-2400 nm clay mineral region.</p>
        """ + NUM_FEATURES_HELP + """
        <p><b>Polynomial fit order:</b> Controls the curve used to locate
        the sub-pixel minimum position of each absorption feature.</p>
        <ul>
          <li><b>2nd order (quadratic, default):</b> Fits a parabola through
          3 adjacent points. Fast and reliable for narrow, symmetric features.</li>
          <li><b>4th order (quartic):</b> Fits a quartic through 5 adjacent
          points; better for asymmetric or broad features. The minimum is
          located via the derivative roots of the fitted curve.</li>
        </ul>

        <p><b>Output:</b> Raster with 2 x N bands (Band 1 = wavelength of
        primary minimum, Band 2 = feature depth, and so on for each
        additional feature).</p>

        <p>WoM-B is used by <b>dt_illcryst</b> and <b>dt_ill_kaol</b>
        as the depth denominator in the illite crystallinity ratio.</p>
        """

    def createInstance(self): return GenerateWomBAlgorithm()


# ── WoM-C: 2100-2400 nm ───────────────────────────────────────────────────────

class GenerateWomCAlgorithm(QgsProcessingAlgorithm):

    INPUT        = 'INPUT'
    NUM_FEATURES = 'NUM_FEATURES'
    OUTPUT       = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract (1-9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=3, minValue=1, maxValue=9))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT, 'WoM-C output (2100-2400 nm)'))

    def processAlgorithm(self, parameters, context, feedback):
        cube = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n    = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        out  = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        feedback.pushInfo(f'Generating WoM-C: 2100-2400 nm  (features: {n}) ...')
        result = _run_wom(cube, 2100, 2400, n, out, context, feedback)
        return {self.OUTPUT: result}

    def name(self):        return 'generate_wom_c'
    def displayName(self): return 'Step 2a - Generate WoM-C (2100-2400 nm)'
    def group(self):       return '3 - Generate WoM Rasters'
    def groupId(self):     return '3_generate_wom'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Generate WoM-C (2100-2400 nm)</b>

        <p>Creates the Wavelength of Minimum raster for the 2100-2400 nm
        range from the hyperspectral cube. This is the primary clay
        mineral absorption region.</p>
        """ + NUM_FEATURES_HELP + """
        <p><b>Output:</b> Raster with 2 x N bands (Band 1 = wavelength of
        primary minimum, Band 2 = feature depth, and so on for each
        additional feature).</p>

        <p>WoM-C is used by <b>dt_2100_2400</b>, <b>dt_fedrop</b>,
        <b>dt_illcryst</b>, and <b>dt_ill_kaol</b>.</p>
        """

    def createInstance(self): return GenerateWomCAlgorithm()


# ── Generate All Three ─────────────────────────────────────────────────────────

class GenerateAllWomAlgorithm(QgsProcessingAlgorithm):

    INPUT        = 'INPUT'
    NUM_FEATURES = 'NUM_FEATURES'
    OUTPUT_A     = 'OUTPUT_A'
    OUTPUT_B     = 'OUTPUT_B'
    OUTPUT_C     = 'OUTPUT_C'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract per WoM raster (1-9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=3, minValue=1, maxValue=9))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_A, 'WoM-A output (750-1300 nm)'))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_B, 'WoM-B output (1850-2100 nm)'))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_C, 'WoM-C output (2100-2400 nm)'))

    def processAlgorithm(self, parameters, context, feedback):
        cube  = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n     = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        out_a = self.parameterAsOutputLayer(parameters, self.OUTPUT_A, context)
        out_b = self.parameterAsOutputLayer(parameters, self.OUTPUT_B, context)
        out_c = self.parameterAsOutputLayer(parameters, self.OUTPUT_C, context)

        feedback.pushInfo(f'Features per WoM raster: {n}')
        steps = [
            (750,  1300, out_a, self.OUTPUT_A, 'WoM-A (750-1300 nm)'),
            (1850, 2100, out_b, self.OUTPUT_B, 'WoM-B (1850-2100 nm)'),
            (2100, 2400, out_c, self.OUTPUT_C, 'WoM-C (2100-2400 nm)'),
        ]
        results = {}
        for i, (start, end, out, key, label) in enumerate(steps):
            if feedback.isCanceled():
                break
            feedback.setProgress(int(i * 33))
            feedback.pushInfo(f'Step {i+1}/3: Generating {label} ...')
            results[key] = _run_wom(cube, start, end, n, out, context, feedback)
            feedback.pushInfo(f'  -> {label} complete.')

        feedback.setProgress(100)
        feedback.pushInfo('')
        feedback.pushInfo('All three WoM rasters generated successfully.')
        feedback.pushInfo('  WoM-A: ' + str(results.get(self.OUTPUT_A, '')))
        feedback.pushInfo('  WoM-B: ' + str(results.get(self.OUTPUT_B, '')))
        feedback.pushInfo('  WoM-C: ' + str(results.get(self.OUTPUT_C, '')))
        return results

    def name(self):        return 'generate_all_wom'
    def displayName(self): return 'Step 2a - Generate All Three WoM Rasters (750-1300, 1850-2100, 2100-2400 nm)'
    def group(self):       return '3 - Generate WoM Rasters'
    def groupId(self):     return '3_generate_wom'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Generate All Three WoM Rasters</b>

        <p>Runs the Wavelength of Minimum algorithm three times on the
        hyperspectral cube to generate all required WoM rasters in a
        single operation. The same number-of-features setting applies
        to all three ranges.</p>
        """ + NUM_FEATURES_HELP + """
        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Output</th><th>Range</th><th>Used by</th>
          </tr>
          <tr><td><b>WoM-A</b></td><td>750-1300 nm</td>
              <td>Future classifiers</td></tr>
          <tr><td><b>WoM-B</b></td><td>1850-2100 nm</td>
              <td>dt_illcryst, dt_ill_kaol</td></tr>
          <tr><td><b>WoM-C</b></td><td>2100-2400 nm</td>
              <td>dt_2100_2400, dt_fedrop, dt_illcryst, dt_ill_kaol</td></tr>
        </table>

        <p>Use the individual <i>Generate WoM-A/B/C</i> algorithms if you
        need different feature counts per range, or to regenerate just
        one raster.</p>
        """

    def createInstance(self): return GenerateAllWomAlgorithm()
