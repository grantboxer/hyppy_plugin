"""
GSWA Table 5 — White mica composition index (WMci)

Algorithm: Wavelength position of the WoM minimum between 2140 and 2240 nm (2200W),
           masked to white-mica-dominant pixels using the 2200D/2160D ratio.
Masks:     MertonNDVI > threshold  AND  2200D/2160D > 3.0  AND  2160D > 0.03
Stretch:   linear: Blue=2185 nm; Red=2190 nm (Gascoyne/Pilbara both 2185-2190)
Targeted:  White mica ± Al-smectite  (challenge: kaolinite)

Reference:
    Laukamp et al. (2025) GSWA Report 261, Table 5.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

from ..core.envi_header import get_wavelengths_from_dataset
from .gswa_index_utils import (
    compute_ndvi, read_wom_band, write_index,
    apply_ndvi_mask, log_gswa_stretch,
)

WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Cube (NDVI) + FE12-2200W WoM + FE10-2160D WoM.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""

GSWA_STRETCH = {
    'gascoyne': 'linear: Blue=2185 nm, Red=2190 nm',
    'pilbara':  'linear: Blue=2190 nm, Red=2215 nm',
}

REFERENCE = 'Laukamp et al. (2025) GSWA Report 261, Table 5 (WMci)'


class GswaWmciAlgorithm(QgsProcessingAlgorithm):
    """GSWA Table 5 — White mica composition index (WMci)."""

    CUBE         = 'CUBE'
    WOM_2200     = 'WOM_2200'
    WOM_2160     = 'WOM_2160'
    NDVI_THRESH  = 'NDVI_THRESH'
    RATIO_THRESH = 'RATIO_THRESH'
    DEPTH_2160_THRESH = 'DEPTH_2160_THRESH'
    OUTPUT       = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.CUBE,    'Hyperspectral cube  (for MertonNDVI)'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2200, 'FE12-2200W WoM raster  (Band 1 = wavelength, Band 2 = depth)'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2160, 'FE10-2160D WoM raster  (Band 2 = 2160D depth)'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NDVI_THRESH, 'MertonNDVI threshold (mask above)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.15, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.RATIO_THRESH,
            '2200D/2160D ratio threshold — keep pixels ABOVE this',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=3.0, minValue=0.1, maxValue=20.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.DEPTH_2160_THRESH,
            '2160D minimum depth threshold — keep pixels ABOVE this',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.03, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT, 'Output WMci raster  (wavelength position, nm)'))

    def processAlgorithm(self, parameters, context, feedback):
        cube_layer   = self.parameterAsRasterLayer(parameters, self.CUBE, context)
        wom_2200     = self.parameterAsRasterLayer(parameters, self.WOM_2200, context)
        wom_2160     = self.parameterAsRasterLayer(parameters, self.WOM_2160, context)
        ndvi_thresh  = self.parameterAsDouble(parameters, self.NDVI_THRESH, context)
        ratio_thresh = self.parameterAsDouble(parameters, self.RATIO_THRESH, context)
        d2160_thresh = self.parameterAsDouble(parameters, self.DEPTH_2160_THRESH, context)
        out_path     = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        feedback.setProgress(5)
        feedback.pushInfo('Reading 2200W wavelength position (Band 1) …')
        wav2200, gt, proj, rows, cols = read_wom_band(wom_2200, 1, '2200W-wvl', feedback)
        feedback.pushInfo('Reading 2200D depth (Band 2) …')
        d2200, *_ = read_wom_band(wom_2200, 2, '2200D', feedback)
        feedback.pushInfo('Reading 2160D depth …')
        d2160, *_ = read_wom_band(wom_2160, 2, '2160D', feedback)

        feedback.setProgress(20)
        feedback.pushInfo('Computing MertonNDVI …')
        cube_ds     = gdal.Open(cube_layer.source())
        wavelengths = get_wavelengths_from_dataset(
            cube_ds, cube_ds.RasterCount, cube_layer.source(), feedback)
        if wavelengths is None:
            raise QgsProcessingException('No wavelength metadata found in cube.')
        nodata = cube_ds.GetRasterBand(1).GetNoDataValue()
        ndvi   = compute_ndvi(cube_ds, wavelengths, nodata, feedback)
        del cube_ds

        feedback.setProgress(60)
        feedback.pushInfo('Applying GSWA Table 5 masks …')
        wmci = wav2200.copy()
        wmci = apply_ndvi_mask(wmci, ndvi, ndvi_thresh, 'WMci', feedback)

        with np.errstate(invalid='ignore', divide='ignore'):
            ratio = np.where(d2160 > 0, d2200 / d2160, np.nan)
        low_ratio = ~np.isnan(ratio) & (ratio <= ratio_thresh)
        wmci[low_ratio] = np.nan
        feedback.pushInfo(
            f'  WMci: ratio≤{ratio_thresh}: {int(np.sum(low_ratio))} px masked')

        shallow = ~np.isnan(d2160) & (d2160 <= d2160_thresh)
        wmci[shallow] = np.nan
        feedback.pushInfo(
            f'  WMci: 2160D≤{d2160_thresh}: {int(np.sum(shallow))} px masked')

        feedback.setProgress(85)
        feedback.pushInfo('Writing WMci …')
        write_index(
            out_path, wmci, gt, proj,
            product_name='WMci',
            description='White mica composition index (2200W wavelength position, nm)',
            gswa_stretch=GSWA_STRETCH,
            reference=REFERENCE,
            extra_meta={
                'GSWA_units':          'nm',
                'GSWA_blue_end_nm':    '2185-2190',
                'GSWA_red_end_nm':     '2215',
                'GSWA_interpretation': 'blue=muscovite/high-Al illite; red=phengite',
            }
        )
        log_gswa_stretch(feedback, 'WMci (White mica composition)', GSWA_STRETCH)
        feedback.pushInfo(
            'Blue (~2185-2190 nm) = muscovite / high-Al illite; '
            'Red (~2215 nm) = phengite / Mg-Fe-substituted white mica')
        feedback.pushInfo('')
        feedback.pushInfo('Composition map display (GSWA Report 261 §3.5.2, Figures 28, 36, 43):')
        feedback.pushInfo('  Apply a LINEAR colour stretch — do NOT histogram-equalise.')
        feedback.pushInfo('  Gascoyne: stretch 2185–2215 nm')
        feedback.pushInfo('  Pilbara:  stretch 2185–2215 nm')
        feedback.pushInfo('  In QGIS: Layer Properties → Symbology → Singleband pseudocolor')
        feedback.pushInfo('           Min = 2185, Max = 2215, Colour ramp = Rainbow')
        feedback.pushInfo('  Blue = Al-rich muscovite/illite (high-Al hydrothermal fluids)')
        feedback.pushInfo('  Red  = Al-poor phengite (Fe/Mg substitution, shear zones, distal alteration)')
        feedback.setProgress(100)
        return {self.OUTPUT: out_path}

    def name(self):        return 'gswa_wmci'
    def displayName(self): return 'GSWA-WMci  (White Mica Composition)'
    def group(self):       return '9 - GSWA Mineral Map Indices'
    def groupId(self):     return 'nine_gswa_indices'

    def shortHelpString(self):
        return WORKFLOW_NOTE + f"""
        <b>White Mica Composition Index (WMci)</b>
        <p>GSWA Report 261, Table 5. Wavelength position of the 2200 nm Al-OH
        absorption, masked to white-mica-dominant pixels. Separates
        muscovite/high-Al illite (short wavelength, blue) from phengite/Mg-Fe
        white mica (long wavelength, red).</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th></tr>
          <tr><td>Base algorithm</td>
              <td>2200W wavelength position (Band 1 of FE12-2200W WoM)</td></tr>
          <tr><td>Ratio mask</td><td>2200D/2160D &gt; 3.0</td></tr>
          <tr><td>Depth gate</td><td>2160D &gt; 0.03</td></tr>
          <tr style="background:#fff3e0">
            <td><b>Gascoyne stretch</b></td>
            <td>linear Blue=2185 nm, Red=2190 nm</td></tr>
          <tr style="background:#fff3e0">
            <td><b>Pilbara stretch</b></td>
            <td>linear Blue=2190 nm, Red=2215 nm</td></tr>
        </table>

        <p><b>⚠ Always use LINEAR stretch for composition maps.</b>
        Do NOT apply histogram equalisation to the WMci — the wavelength
        position values are quantitative (nm) and must preserve their linear
        relationship for geological interpretation.
        (GSWA Report 261, §3.5.1: "wavelength positions … require a linear stretch.")</p>

        <p><b>Display in QGIS (step by step):</b></p>
        <ol>
          <li>Load the WMci raster into QGIS</li>
          <li>Open Layer Properties → Symbology</li>
          <li>Set render type to <b>Singleband pseudocolor</b></li>
          <li>Set <b>Min = 2185</b>, <b>Max = 2215</b></li>
          <li>Choose colour ramp <b>Rainbow</b> (or Spectral reversed)</li>
          <li>Click Classify → Apply</li>
        </ol>

        <p><b>Geological interpretation of colours:</b></p>
        <ul>
          <li><b>Blue (~2185–2195 nm)</b> — Al-rich muscovite / high-Al illite;
              associated with proximal hydrothermal alteration, fluid recharge zones
              (Van Ruitenbeek et al. 2006, 2012)</li>
          <li><b>Green (~2200–2205 nm)</b> — intermediate illite composition;
              typical regional metamorphic assemblages</li>
          <li><b>Red (~2210–2215 nm)</b> — Al-poor phengite (Tschermaks exchange
              Al→Fe/Mg); shear zones, distal hydrothermal outflow, Ti Tree Shear Zone
              (GSWA Report 261, §6, Figure 36)</li>
        </ul>

        <p><i>Reference: Laukamp et al. (2025) GSWA Report 261, Table 5, §3.5.2,
        Figures 22, 28, 36, 43.</i></p>
        """

    def createInstance(self): return GswaWmciAlgorithm()
