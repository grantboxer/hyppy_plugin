"""
GSWA Table 5 — Pyrophyllite abundance index (PPHai)

Algorithm: Intensity of the wavelength minimum between 2140 and 2200 nm
           using 4th order polynomial fit.  NOTE: narrower window than
           ASai/WMai (2140-2200 nm vs 2140-2240 nm) — this emphasises the
           shorter-wave pyrophyllite feature at ~2160-2166 nm.
Masks:     Pilbara only: MertonNDVI > 0.2  AND  2200D < 2.05  AND  2160D < 0.1
Stretch:   Pilbara linear: Blue=0.15 (low), Red=0.25 (high)
Targeted:  Pyrophyllite  (challenge: pixels with a lot of kaolinite)

Note: PPHai only appears for the Pilbara dataset in GSWA Report 261 Table 5.
The narrow 2140–2200 nm polynomial window isolates the pyrophyllite primary
Al-OH feature from the kaolinite/white-mica features at 2200–2220 nm.

Reference:
    Laukamp et al. (2025) GSWA Report 261, Table 5.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset
from .gswa_index_utils import (
    compute_ndvi, write_index, apply_ndvi_mask,
    log_gswa_stretch, poly_fit_depth,
)

WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube + FE10-2160D WoM + FE12-2200W WoM.<br/>
        PPHai uses a <b>narrower 2140–2200 nm polynomial window</b> than standard
        FE10-2160D — this tool computes it fresh from the cube.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""

GSWA_STRETCH = {
    'pilbara': 'linear: Blue=0.15 (low abundance), Red=0.25 (high abundance)',
}

REFERENCE = 'Laukamp et al. (2025) GSWA Report 261, Table 5 (PPHai)'


class GswaPphaiAlgorithm(QgsProcessingAlgorithm):
    """GSWA Table 5 — Pyrophyllite abundance index (PPHai), own poly-fit window."""

    CUBE             = 'CUBE'
    WOM_2200         = 'WOM_2200'
    WOM_2160         = 'WOM_2160'
    NDVI_THRESH      = 'NDVI_THRESH'
    DEPTH_2200_THRESH = 'DEPTH_2200_THRESH'
    DEPTH_2160_THRESH = 'DEPTH_2160_THRESH'
    OUTPUT           = 'OUTPUT'

    # GSWA Table 5 PPHai polynomial window
    POLY_START = 2140.0
    POLY_END   = 2200.0
    POLY_ORDER = 4

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.CUBE,
            'Hyperspectral cube  '
            '(poly₄ fit computed fresh from cube over 2140–2200 nm; also for NDVI)'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2200,
            'FE12-2200W WoM raster  (Band 2 = 2200D depth, used for mask)'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2160,
            'FE10-2160D WoM raster  (Band 2 = 2160D depth, used for mask)'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NDVI_THRESH,
            'MertonNDVI threshold (mask above — GSWA Pilbara: 0.2)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.2, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.DEPTH_2200_THRESH,
            '2200D upper mask threshold — keep pixels BELOW this '
            '(GSWA Pilbara: 2.05 — retains almost all pixels except extreme WM)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=2.05, minValue=0.0, maxValue=10.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.DEPTH_2160_THRESH,
            '2160D upper mask threshold — keep pixels BELOW this '
            '(GSWA Pilbara: 0.1 — removes the deepest kaolinite pixels)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.1, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT, 'Output PPHai raster'))

    def processAlgorithm(self, parameters, context, feedback):
        cube_layer     = self.parameterAsRasterLayer(parameters, self.CUBE, context)
        wom_2200       = self.parameterAsRasterLayer(parameters, self.WOM_2200, context)
        wom_2160       = self.parameterAsRasterLayer(parameters, self.WOM_2160, context)
        ndvi_thresh    = self.parameterAsDouble(parameters, self.NDVI_THRESH, context)
        d2200_thresh   = self.parameterAsDouble(parameters, self.DEPTH_2200_THRESH, context)
        d2160_thresh   = self.parameterAsDouble(parameters, self.DEPTH_2160_THRESH, context)
        out_path       = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        # 1. Open cube and get metadata
        feedback.setProgress(3)
        feedback.pushInfo('Opening cube …')
        cube_ds     = gdal.Open(cube_layer.source())
        if cube_ds is None:
            raise QgsProcessingException(f'Cannot open cube: {cube_layer.source()}')
        n_bands     = cube_ds.RasterCount
        n_rows      = cube_ds.RasterYSize
        n_cols      = cube_ds.RasterXSize
        wavelengths = get_wavelengths_from_dataset(
            cube_ds, n_bands, cube_layer.source(), feedback)
        if wavelengths is None:
            raise QgsProcessingException('No wavelength metadata found in cube.')
        bbl    = get_bbl_from_dataset(cube_ds, n_bands, cube_layer.source(), feedback)
        nodata = cube_ds.GetRasterBand(1).GetNoDataValue()

        gt   = cube_ds.GetGeoTransform()
        proj = cube_ds.GetProjection()

        # 2. Compute poly4 depth over narrow 2140–2200 nm window (PPHai algorithm)
        feedback.setProgress(5)
        feedback.pushInfo(
            f'Computing poly₄ depth over {self.POLY_START}–{self.POLY_END} nm …')
        feedback.pushInfo(
            '  (PPHai uses a narrower window than FE10-2160D to isolate '
            'the pyrophyllite feature)')
        pphai = poly_fit_depth(
            cube_ds, wavelengths, bbl, nodata,
            self.POLY_START, self.POLY_END, self.POLY_ORDER,
            feedback,
        )
        if feedback.isCanceled():
            del cube_ds
            return {}

        # 3. Compute MertonNDVI from same cube
        feedback.setProgress(70)
        feedback.pushInfo('Computing MertonNDVI …')
        ndvi = compute_ndvi(cube_ds, wavelengths, nodata, feedback)
        del cube_ds

        # 4. Read mask rasters
        feedback.setProgress(75)
        feedback.pushInfo('Reading mask rasters …')

        def _read_depth(layer, label):
            from osgeo import gdal as _gdal
            ds  = _gdal.Open(layer.source())
            arr = ds.GetRasterBand(2).ReadAsArray().astype(np.float32)
            nd  = ds.GetRasterBand(2).GetNoDataValue()
            if nd is not None:
                arr[arr == nd] = np.nan
            del ds
            feedback.pushInfo(f'  {label}: read Band 2 from {layer.source()}')
            return arr

        d2200 = _read_depth(wom_2200, '2200D')
        d2160 = _read_depth(wom_2160, '2160D')

        # 5. Apply GSWA Table 5 masks
        feedback.setProgress(80)
        feedback.pushInfo('Applying GSWA Table 5 masks …')
        pphai = apply_ndvi_mask(pphai, ndvi, ndvi_thresh, 'PPHai', feedback)

        high_d2200 = ~np.isnan(d2200) & (d2200 >= d2200_thresh)
        pphai[high_d2200] = np.nan
        feedback.pushInfo(
            f'  PPHai: 2200D≥{d2200_thresh} mask: {int(np.sum(high_d2200))} px masked')

        high_d2160 = ~np.isnan(d2160) & (d2160 >= d2160_thresh)
        pphai[high_d2160] = np.nan
        feedback.pushInfo(
            f'  PPHai: 2160D≥{d2160_thresh} mask: {int(np.sum(high_d2160))} px masked')

        # 6. Write output
        feedback.setProgress(90)
        feedback.pushInfo('Writing PPHai …')
        write_index(
            out_path, pphai, gt, proj,
            product_name='PPHai',
            description=(
                f'Pyrophyllite abundance index '
                f'(poly{self.POLY_ORDER} fit, {self.POLY_START:.0f}-{self.POLY_END:.0f} nm)'),
            gswa_stretch=GSWA_STRETCH,
            reference=REFERENCE,
            extra_meta={
                'GSWA_poly_order':    str(self.POLY_ORDER),
                'GSWA_poly_range_nm': f'{self.POLY_START:.0f}-{self.POLY_END:.0f}',
                'GSWA_note':          (
                    'Narrow 2140-2200 nm window targets pyrophyllite primary '
                    'Al-OH at ~2160-2166 nm independently of 2200 nm feature'),
            }
        )

        log_gswa_stretch(feedback, 'PPHai (Pyrophyllite abundance)', GSWA_STRETCH)
        feedback.pushInfo(
            'Targeted mineral: pyrophyllite  '
            '(challenge: pixels dominated by kaolinite)')
        feedback.pushInfo(
            'Note: PPHai only appears in the Pilbara dataset in GSWA Report 261. '
            'The narrow 2140-2200 nm window can be applied to any hyperspectral scene '
            'with sufficient SWIR SNR.')
        feedback.setProgress(100)
        return {self.OUTPUT: out_path}

    def name(self):        return 'gswa_pphai'
    def displayName(self): return 'GSWA-PPHai  (Pyrophyllite Abundance)'
    def group(self):       return '9 - GSWA Mineral Map Indices'
    def groupId(self):     return 'nine_gswa_indices'

    def shortHelpString(self):
        return WORKFLOW_NOTE + f"""
        <b>Pyrophyllite Abundance Index (PPHai)</b>
        <p>GSWA Report 261, Table 5. Uses a <b>narrow 2140–2200 nm polynomial
        window</b> (poly₄) to isolate the pyrophyllite primary Al-OH feature
        at ~2160–2166 nm — shorter than the white-mica/kaolinite features at
        2200–2215 nm. This tool computes the polynomial fit fresh from the cube
        rather than reusing the FE10-2160D WoM, because the narrower window
        is critical for the PPHai algorithm.</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>GSWA Table 5 value</th></tr>
          <tr><td>Polynomial window</td>
              <td><b>2140–2200 nm</b> (narrower than FE10-2160D 2138–2179 nm)</td></tr>
          <tr><td>Polynomial order</td><td>4th order</td></tr>
          <tr><td>NDVI mask</td>
              <td>MertonNDVI &gt; 0.2 (Pilbara default)</td></tr>
          <tr><td>2200D mask</td>
              <td>&lt; 2.05 (retains most pixels, removes extreme WM)</td></tr>
          <tr><td>2160D mask</td>
              <td>&lt; 0.1 (removes deepest kaolinite-dominated pixels)</td></tr>
          <tr style="background:#fff3e0">
            <td><b>Stretch (Pilbara)</b></td>
            <td>linear: Blue=0.15 (low), Red=0.25 (high)</td></tr>
          <tr><td>Targeted mineral</td><td>Pyrophyllite</td></tr>
          <tr><td>Challenge</td>
              <td>Pixels with strong kaolinite (similar 2160 nm feature)</td></tr>
        </table>

        <p><b>Why a separate tool?</b> The 2200D mask threshold of 2.05 is
        very permissive (almost no pixels masked on depth alone), and the
        narrow 2140–2200 nm polynomial window is algorithmically distinct from
        FE10-2160D's WoM approach. Using the FE10-2160D output directly would
        produce different results.</p>

        <p><i>Reference: Laukamp et al. (2025) GSWA Report 261, Table 5.</i></p>
        """

    def createInstance(self): return GswaPphaiAlgorithm()
