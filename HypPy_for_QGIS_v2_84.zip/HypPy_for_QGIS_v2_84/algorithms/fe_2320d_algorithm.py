"""
Feature Extraction — 2320D  (Amphibole / Talc / Biotite)

WoM range 2295-2400 nm, wavelength map stretch 2305-2385 nm.

Targets the diagnostic Mg-OH combination absorption doublet at
~2320 nm and ~2380 nm characteristic of amphiboles (actinolite,
tremolite), talc, and tri-octahedral micas (biotite/phlogopite).

Background (GSWA Report 261, §8.1, Figure 46-47):
    "Due to the high quality of EnMAP's reflectance spectra in the
    2300 to 2400 nm wavelength region, it was possible to identify
    amphibole-related spectral signatures characterised by strong
    absorption features at 2320 nm and 2380 nm, which could be used
    to map mafic and ultramafic rocks."
    — Laukamp et al. (2025) GSWA Report 261, §8.1

    A separate 'amphibole-talc abundance index' (EnMAP-derived) was
    produced in this study to identify known pegmatites of the Sisters
    Supersuite and highlight new potential pegmatite targets in the
    Tambourah area.

    SENSOR NOTE: PRISMA hyperspectral imagery has insufficient SNR
    in the 2300–2450 nm region for reliable amphibole mapping.
    This tool is recommended for EnMAP and EMIT data only.
    Use with PRISMA data is experimental — results may show strong
    noise artefacts.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
)
import processing
import os

from ..core.envi_header import (
    get_wavelengths_from_dataset,
    get_sensor_info,
    has_poor_snr_in_range,
)


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with wavelength metadata.<br/>
        <b>Recommended sensor:</b> EnMAP or EMIT (high SNR in 2300–2400 nm).<br/>
        <b>PRISMA:</b> Experimental — insufficient SNR may produce noisy results.
        </p>
"""

class Fe2320DAlgorithm(QgsProcessingAlgorithm):
    """Feature Extraction — 2320D (Amphibole / Talc)."""

    INPUT         = 'INPUT'
    NUM_FEATURES  = 'NUM_FEATURES'
    OUTPUT_WOM    = 'OUTPUT_WOM'
    OUTPUT_MAP    = 'OUTPUT_MAP'
    LEGEND_OUTPUT = 'LEGEND_OUTPUT'

    WOM_START = 2295.0
    WOM_END   = 2400.0
    MAP_MIN   = 2305.0
    MAP_MAX   = 2385.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.15

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract (1-9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=1, minValue=1, maxValue=9))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_WOM,
            'Output WoM raster  (2295–2400 nm)'))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_MAP,
            'Output Wavelength Map RGB  (2305–2385 nm stretch)'))
        self.addParameter(QgsProcessingParameterFileDestination(
            self.LEGEND_OUTPUT,
            'Output Colour Legend (PNG)',
            fileFilter='PNG Files (*.png)',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        cube        = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n           = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        out_wom     = self.parameterAsOutputLayer(parameters, self.OUTPUT_WOM, context)
        out_map     = self.parameterAsOutputLayer(parameters, self.OUTPUT_MAP, context)
        legend_path = self.parameterAsFileOutput(parameters, self.LEGEND_OUTPUT, context)

        self._legend_path = None

        # ── Sensor-aware SNR warning ──────────────────────────────────────
        import numpy as np
        from osgeo import gdal
        try:
            _ds = gdal.Open(cube.source())
            if _ds is not None:
                _wavs = get_wavelengths_from_dataset(
                    _ds, _ds.RasterCount, cube.source(), feedback=None)
                _sinfo = get_sensor_info(_wavs, _ds.RasterCount)
                if _sinfo['matched'] and has_poor_snr_in_range(
                        _sinfo, self.WOM_START, self.WOM_END):
                    msg = (
                        f"{_sinfo['name']} detected: the "
                        f"{self.WOM_START:.0f}–{self.WOM_END:.0f} nm WoM range "
                        f"overlaps a known low-SNR zone for this sensor. "
                        f"Results may show noise artefacts. {_sinfo['snr_note']}"
                    )
                    feedback.pushWarning(msg)
                del _ds
        except Exception:
            pass  # sensor detection is advisory only
        # ─────────────────────────────────────────────────────────────────

        # Step 1: Wavelength of Minimum 2295-2400 nm
        feedback.setProgress(5)
        feedback.pushInfo('Step 1/2  Wavelength of Minimum  2295–2400 nm …')
        feedback.pushInfo(
            '  Targets: amphibole (~2320 nm + ~2380 nm doublet), talc (~2320 nm), '
            'biotite/phlogopite (~2345 nm + ~2380 nm)')
        wom_result = processing.run(
            'hyppy:wavelength_of_minimum',
            {
                'INPUT':            cube,
                'START_WAVELENGTH': self.WOM_START,
                'END_WAVELENGTH':   self.WOM_END,
                'MODE':             0,
                'NUM_FEATURES':     n,
                'BROAD':            False,
                'USE_BBL':          True,
                'OUTPUT':           out_wom,
            },
            context=context,
            feedback=feedback,
            is_child_algorithm=True,
        )
        if feedback.isCanceled():
            return {}

        wom_path = wom_result['OUTPUT']
        feedback.pushInfo(f'  WoM raster saved: {wom_path}')

        # Step 2: Wavelength Mapping 2305-2385 nm
        feedback.setProgress(55)
        feedback.pushInfo('Step 2/2  Wavelength Mapping  2305–2385 nm stretch …')

        from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
        wma     = WavelengthMappingAlgorithm()
        palette = wma.create_rainbow_palette()

        map_path = wma._run_colour_mapping(
            wom_path, palette,
            self.MAP_MIN, self.MAP_MAX,
            self.DEPTH_MIN, self.DEPTH_MAX,
            out_map, feedback,
        )
        feedback.setProgress(88)
        feedback.pushInfo(f'  Wavelength map saved: {map_path}')

        # Step 3: Legend
        if not legend_path:
            legend_path = os.path.join(os.path.dirname(wom_path), '2320D_legend.png')
        try:
            saved = wma.create_legend(
                legend_path, palette,
                self.MAP_MIN, self.MAP_MAX,
                self.DEPTH_MIN, self.DEPTH_MAX,
                feedback,
            )
            if saved:
                self._legend_path = saved
                feedback.pushInfo(f'  Colour legend saved: {saved}')
        except Exception as e:
            feedback.pushWarning(f'Legend generation failed: {e}')

        feedback.pushInfo('')
        feedback.pushInfo('─' * 60)
        feedback.pushInfo('GSWA Report 261 — recommended stretch:')
        feedback.pushInfo('  Map stretch: 2305–2385 nm (rainbow colour scheme)')
        feedback.pushInfo('  Blue = shorter wavelength (actinolite/tremolite ~2310 nm)')
        feedback.pushInfo('  Red  = longer wavelength  (biotite/phlogopite ~2380 nm)')
        feedback.pushInfo('─' * 60)
        feedback.setProgress(100)
        feedback.pushInfo('Feature Extraction 2320D complete.')

        return {
            self.OUTPUT_WOM:    wom_path,
            self.OUTPUT_MAP:    map_path,
            self.LEGEND_OUTPUT: self._legend_path or '',
        }

    def postProcessAlgorithm(self, context, feedback):
        if getattr(self, '_legend_path', None):
            from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
            WavelengthMappingAlgorithm()._show_legend_dock(self._legend_path, feedback)
        return {}

    def name(self):        return 'fe_2320d'
    def displayName(self): return 'FE-2320D  (Amphibole / Talc)  [EnMAP/EMIT recommended]'
    def group(self):       return '7 - Feature Extraction'
    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2320D  (Amphibole / Talc)</b>

        <p>Targets the Mg-OH combination absorption doublet at <b>~2320 nm</b>
        and <b>~2380 nm</b> characteristic of amphiboles, talc, and tri-octahedral
        micas.  This wavelength range is particularly diagnostic for mafic and
        ultramafic rocks — greenstone belts, ultramafic sills, and amphibolites.</p>

        <p style="background-color:#fff3cd; padding:6px; border-left:4px solid #ffc107;">
        <b>⚠ Sensor note:</b> PRISMA hyperspectral imagery has insufficient SNR
        in the 2300–2450 nm range for reliable amphibole/talc mapping.
        EnMAP and EMIT are recommended for this feature
        (GSWA Report 261, §3.2 and §8.1, Figure 46–47).
        </p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>2295–2400 nm</td></tr>
          <tr><td>Map stretch min</td><td>2305 nm  (cool blue)</td></tr>
          <tr><td>Map stretch max</td><td>2385 nm  (warm red)</td></tr>
          <tr><td>Recommended sensor</td><td>EnMAP, EMIT</td></tr>
        </table>

        <p><b>Mineral associations:</b></p>
        <ul>
          <li><b>Actinolite / Tremolite</b> — ~2310–2320 nm + ~2380 nm doublet;
              mafic/ultramafic country rocks to pegmatites</li>
          <li><b>Talc</b> — strong ~2320 nm primary feature; Mg-rich ultramafics</li>
          <li><b>Phlogopite / Biotite</b> — ~2345 nm + ~2380 nm; dark mica in granites
              and pegmatites</li>
          <li><b>Hornblende</b> — broad ~2320 nm absorption; amphibolites</li>
        </ul>

        <p><b>Geological applications (GSWA Report 261, §8.1):</b></p>
        <ul>
          <li>Mapping greenstone belt mafic/ultramafic sequences</li>
          <li>Identifying pegmatite-hosting ultramafic rocks (e.g. Sisters Supersuite,
              Tambourah area)</li>
          <li>Distinguishing prehnite from white mica in metamorphic terranes</li>
          <li>Mapping amphibolites and dolerites (complement to CBEai)</li>
        </ul>

        <p>Combine with FE14-2250W (chlorite/epidote) and FE15-2290W (chlorite
        long-wave) for a comprehensive Mg-OH mineral suite.</p>

        <p><i>Background: Laukamp, C., Miles, A.J. et al. (2025) GSWA Report 261,
        §8.1, Figure 46–47 (EnMAP amphibole-talc abundance index).</i></p>
        """

    def createInstance(self): return Fe2320DAlgorithm()
