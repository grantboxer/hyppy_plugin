"""
Histogram Equalisation — raster display normalisation

Applies histogram equalisation to a single-band raster (e.g. any FE depth
output or GSWA mineral index), producing a new float32 GeoTIFF whose pixel
values follow a uniform distribution.  Intended for improving visual contrast
of mineral index maps without altering the underlying linear stretch product.

Background (GSWA Report 261, §3.5.1):
    Histogram equalisation reassigns pixel intensity values so that the output
    histogram is flat (uniform).  This significantly improves visual contrast
    and discrimination of geological domains in mineral maps, but removes the
    linearity between absorption depth and pixel value — making the output
    unsuitable for quantitative chemometrics or ML input.  Always keep the
    original linear-stretch output for quantitative work; use the histogram-
    equalised version for visual/GIS comparison.

    "When compared to the linearly stretched Gascoyne ROI ASai, the increased
     contrast of the histogram equalised ASai mosaic significantly improves the
     visualisation of domains of different mineral assemblages."
    — Laukamp et al. (2025) GSWA Report 261, §3.5.1

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Input:</b> Any single-band raster — FE depth output, GSWA mineral index, etc.<br/>
        <b>Warning:</b> Histogram-equalised output is for <em>visual display only</em>.
        Pixel values are no longer proportional to absorption depth.
        Keep the original linear-stretch raster for quantitative analysis.
        </p>
"""


class HistEqualiseAlgorithm(QgsProcessingAlgorithm):
    """Histogram Equalisation of a single-band mineral index raster."""

    INPUT      = 'INPUT'
    N_BINS     = 'N_BINS'
    OUTPUT     = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT,
            'Input single-band raster  (FE depth, GSWA index, etc.)'))
        self.addParameter(QgsProcessingParameterNumber(
            self.N_BINS,
            'Number of histogram bins',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=1024, minValue=64, maxValue=65536))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT,
            'Output histogram-equalised raster'))

    def processAlgorithm(self, parameters, context, feedback):
        in_layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n_bins   = self.parameterAsInt(parameters, self.N_BINS, context)
        out_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if in_layer is None:
            raise QgsProcessingException('Invalid input layer')

        ds = gdal.Open(in_layer.source())
        if ds is None:
            raise QgsProcessingException(f'Cannot open raster: {in_layer.source()}')
        if ds.RasterCount != 1:
            raise QgsProcessingException(
                f'Input must be a single-band raster (got {ds.RasterCount} bands). '
                'Run on one band at a time.')

        n_rows = ds.RasterYSize
        n_cols = ds.RasterXSize
        gt     = ds.GetGeoTransform()
        proj   = ds.GetProjection()

        band   = ds.GetRasterBand(1)
        nodata = band.GetNoDataValue()
        desc   = band.GetDescription() or ''
        meta   = ds.GetMetadata()

        feedback.pushInfo(f'Reading {n_rows}×{n_cols} raster …')
        data = band.ReadAsArray().astype(np.float32)
        del ds

        # Build valid pixel mask
        valid_mask = ~np.isnan(data)
        if nodata is not None:
            valid_mask &= (data != nodata)
        valid_vals = data[valid_mask]

        n_valid = int(valid_vals.size)
        if n_valid == 0:
            raise QgsProcessingException('No valid (non-NaN/nodata) pixels found.')

        feedback.pushInfo(f'Valid pixels: {n_valid:,}')
        feedback.pushInfo(f'Value range:  {float(np.nanmin(valid_vals)):.6f} – '
                          f'{float(np.nanmax(valid_vals)):.6f}')
        feedback.pushInfo(f'Histogram bins: {n_bins}')

        # ── Histogram equalisation ────────────────────────────────────────────
        feedback.setProgress(20)
        feedback.pushInfo('Computing histogram …')

        v_min = float(valid_vals.min())
        v_max = float(valid_vals.max())

        if v_min == v_max:
            raise QgsProcessingException(
                'All valid pixels have the same value — histogram equalisation '
                'is not meaningful for a constant raster.')

        hist, bin_edges = np.histogram(valid_vals, bins=n_bins, range=(v_min, v_max))

        # Cumulative distribution function, normalised to [0, 1]
        cdf = hist.cumsum().astype(np.float64)
        cdf = (cdf - cdf.min()) / (cdf.max() - cdf.min())   # → [0, 1]

        # Map each valid pixel to its equalised value via bin lookup
        feedback.setProgress(50)
        feedback.pushInfo('Applying equalisation transform …')

        # Bin index for each valid pixel (clip to valid range)
        bin_idx = np.searchsorted(bin_edges[:-1], valid_vals, side='right') - 1
        bin_idx = np.clip(bin_idx, 0, n_bins - 1)

        out_data = np.full_like(data, np.nan)
        out_data[valid_mask] = cdf[bin_idx].astype(np.float32)

        # ── Write output ──────────────────────────────────────────────────────
        feedback.setProgress(80)
        feedback.pushInfo('Writing equalised raster …')

        driver = gdal.GetDriverByName('GTiff')
        out_ds = driver.Create(out_path, n_cols, n_rows, 1, gdal.GDT_Float32,
                               options=['COMPRESS=LZW', 'TILED=YES'])
        out_ds.SetGeoTransform(gt)
        out_ds.SetProjection(proj)

        out_band = out_ds.GetRasterBand(1)
        out_band.WriteArray(out_data)
        out_band.SetNoDataValue(float('nan'))
        out_band.SetDescription(f'{desc} [histeq]' if desc else 'histeq')

        # Propagate source metadata, mark as equalised
        for k, v in meta.items():
            out_ds.SetMetadataItem(k, v)
        out_ds.SetMetadataItem('histeq_n_bins',      str(n_bins))
        out_ds.SetMetadataItem('histeq_source_min',  f'{v_min:.6f}')
        out_ds.SetMetadataItem('histeq_source_max',  f'{v_max:.6f}')
        out_ds.SetMetadataItem('histeq_warning',
            'DISPLAY ONLY — pixel values no longer proportional to absorption depth')

        out_ds.FlushCache()
        del out_ds

        feedback.pushInfo('')
        feedback.pushInfo('─' * 60)
        feedback.pushInfo('Histogram Equalisation complete.')
        feedback.pushInfo('  Output pixel values: 0.0 (low) → 1.0 (high)')
        feedback.pushInfo('  Apply a rainbow colour ramp stretched 0–1 in QGIS.')
        feedback.pushInfo('')
        feedback.pushInfo('  ⚠  WARNING: Histogram-equalised output is for VISUAL')
        feedback.pushInfo('     DISPLAY ONLY.  Pixel values are not proportional')
        feedback.pushInfo('     to absorption depth.  Use the original linear-')
        feedback.pushInfo('     stretch raster for quantitative / ML workflows.')
        feedback.pushInfo('─' * 60)
        feedback.setProgress(100)

        return {self.OUTPUT: out_path}

    def name(self):        return 'hist_equalise'
    def displayName(self): return 'Histogram Equalisation  (display contrast)'
    def group(self):       return '6 - Spectral Processing Tools'
    def groupId(self):     return 'five_spectral_processing'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Histogram Equalisation — mineral index display contrast</b>

        <p>Applies histogram equalisation to any single-band raster, producing
        a new GeoTIFF whose pixel values follow a uniform (flat) distribution.
        Output values are rescaled to <b>0.0–1.0</b>.</p>

        <p><b>When to use:</b> After running any FE depth tool or GSWA mineral
        index algorithm, apply histogram equalisation to the output for improved
        visual contrast when displaying results in QGIS or ArcGIS alongside
        geological layers.  Histogram equalisation is the standard display mode
        used in GSWA Report 261 for all Mineral Map Products
        (Laukamp et al., 2025, §3.5.1 and Figures 19, 26–33).</p>

        <p><b>Display in QGIS after running:</b></p>
        <ol>
          <li>Load the equalised raster into QGIS</li>
          <li>Open Layer Properties → Symbology → Singleband pseudocolor</li>
          <li>Set Min = 0.0, Max = 1.0</li>
          <li>Choose a colour ramp (Rainbow recommended for mineral maps)</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Aspect</th><th>Linear stretch</th><th>Histogram equalised</th>
          </tr>
          <tr><td>Pixel values</td>
              <td>Proportional to absorption depth</td>
              <td>Uniformly distributed 0–1</td></tr>
          <tr><td>Visual contrast</td>
              <td>May be low if data is skewed</td>
              <td>Maximum contrast</td></tr>
          <tr><td>Quantitative use</td>
              <td>✓ Suitable for ML / chemometrics</td>
              <td>✗ NOT suitable — values non-linear</td></tr>
          <tr><td>Geological mapping</td>
              <td>Good</td>
              <td>Better — domain boundaries clearer</td></tr>
        </table>

        <p><b>Parameter:</b> <i>Number of histogram bins</i> — controls the
        precision of the equalisation.  Default 1024 is suitable for most
        mineral index rasters.  Increase to 4096 for very large scenes or
        when pixel value distribution is highly non-uniform.</p>

        <p><i>Background: Laukamp, C., Miles, A.J. et al. (2025) GSWA Report 261,
        §3.5.1; Figure 20 (concept of linear vs histogram equalisation).</i></p>
        """

    def createInstance(self): return HistEqualiseAlgorithm()
