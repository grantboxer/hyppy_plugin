"""
Convert EOS HDF to ENVI Algorithm for QGIS Processing

Extracts EOS_SWATH subdatasets from an HDF file and writes each one as a
separate ENVI flat-binary file with a matching .hdr header.

Ported from HyPy converthdf.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original HyPy Copyright (C) 2010-2022 Wim Bakker, University of Twente

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import os
import sys

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterFileDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis,
)


def _convert_hdf(fin, baseout, feedback=None):
    """Extract EOS_SWATH subdatasets from HDF and write ENVI files."""

    def log(msg):
        if feedback:
            feedback.pushInfo(msg)
        else:
            print(msg)

    try:
        from osgeo import gdal
        gdal.UseExceptions()
    except ImportError:
        return False, "GDAL is required but not available."

    try:
        import numpy as np
    except ImportError:
        return False, "NumPy is required but not available."

    # ── Minimal ENVI header writer (no envi2 dependency) ───────────────
    ENVI_BSQ = 'bsq'

    _DTYPE_MAP = {
        'uint8':   1,
        'int16':   2,
        'int32':   3,
        'float32': 4,
        'float64': 5,
        'uint16':  12,
        'uint32':  13,
        'int64':   14,
        'uint64':  15,
    }

    def write_envi_header(path, samples, lines, bands, band_name, dtype):
        envi_type = _DTYPE_MAP.get(str(dtype), 4)
        byte_order = 0 if sys.byteorder == 'little' else 1
        hdr = path + '.hdr'
        with open(hdr, 'w') as f:
            f.write("ENVI\n")
            f.write("description = { %s }\n" % os.path.basename(fin))
            f.write("samples = %d\n" % samples)
            f.write("lines = %d\n" % lines)
            f.write("bands = %d\n" % bands)
            f.write("header offset = 0\n")
            f.write("file type = ENVI Standard\n")
            f.write("data type = %d\n" % envi_type)
            f.write("interleave = bsq\n")
            f.write("byte order = %d\n" % byte_order)
            f.write("band names = { %s }\n" % band_name)
        return hdr

    # ── Open HDF ────────────────────────────────────────────────────────
    log("Input:  %s" % fin)
    log("Output base: %s" % baseout)

    try:
        ds = gdal.Open(fin)
    except Exception as e:
        return False, "Cannot open HDF file: %s" % str(e)

    if ds is None:
        return False, "GDAL could not open the HDF file (check GDAL HDF4 support)."

    subs = ds.GetSubDatasets()
    if not subs:
        return False, "No subdatasets found in HDF file."

    log("Found %d subdatasets." % len(subs))

    n = float(len(subs))
    written = 0

    for i, (fname, fmeta) in enumerate(subs):
        if feedback:
            feedback.setProgress(int((i / n) * 100))
        if feedback and feedback.isCanceled():
            return False, "Cancelled by user."

        if 'EOS_SWATH' not in fname:
            continue

        log(fname)
        log(fmeta)

        fmetasplit = fmeta.split()
        if len(fmetasplit) < 3:
            log("  Skipped (unexpected metadata format)")
            continue

        bandname = fmetasplit[1]
        setname  = fmetasplit[2]
        fout     = '_'.join([baseout, bandname, setname])

        log("  -> %s" % fout)

        try:
            sub_ds = gdal.Open(fname)
            a = sub_ds.ReadAsArray()
        except Exception as e:
            log("  Error reading subdataset: %s" % str(e))
            continue

        log("  Shape: %s  Dtype: %s" % (str(a.shape), str(a.dtype)))

        a.tofile(fout)
        write_envi_header(fout, a.shape[1], a.shape[0], 1, bandname, a.dtype)
        written += 1

    log("")
    log("Written %d ENVI file(s)." % written)
    if written == 0:
        return False, "No EOS_SWATH subdatasets found — no files written."

    return True, "Completed. %d ENVI file(s) written." % written


# ── QGIS Algorithm wrapper ─────────────────────────────────────────────────

class ConvertHdfAlgorithm(QgsProcessingAlgorithm):
    """Convert an EOS HDF file to ENVI format (one file per EOS_SWATH subdataset)."""

    INPUT   = 'INPUT'
    BASEOUT = 'BASEOUT'

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT,
                'Input EOS HDF File',
                behavior=QgsProcessingParameterFile.File,
                fileFilter='HDF Files (*.hdf *.h4 *.hdf4);;All Files (*)',
                optional=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.BASEOUT,
                'Output Basename (suffix will be added per band)',
                fileFilter='All Files (*)',
                optional=False,
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        fin     = self.parameterAsFile(parameters, self.INPUT, context)
        baseout = self.parameterAsFileOutput(parameters, self.BASEOUT, context)

        # Remove any extension QGIS may have appended
        baseout = os.path.splitext(baseout)[0]

        feedback.pushInfo("=== Convert EOS HDF to ENVI ===")
        ok, msg = _convert_hdf(fin, baseout, feedback=feedback)
        if not ok:
            raise QgsProcessingException(msg)

        feedback.pushInfo(msg)
        return {self.BASEOUT: baseout}

    # ── Metadata ────────────────────────────────────────────────────────

    def name(self):
        return 'convert_eos_hdf'

    def displayName(self):
        return 'G02 - Convert EOS HDF to ENVI'

    def group(self):
        return '8 - Convert Tools'

    def groupId(self):
        return 'convert_tools'

    def shortHelpString(self):
        return (
            "Extract EOS_SWATH subdatasets from an EOS HDF file and write each "
            "as a separate ENVI flat-binary file.\n\n"
            "Requires GDAL with HDF4 support (hdf.dll / libhdf.so must be present).\n\n"
            "One output file is created per EOS_SWATH subdataset, named:\n"
            "  <basename>_<BandName>_<SetName>\n\n"
            "Ported from HyPy converthdf.py (Wim Bakker, University of Twente)."
        )

    def createInstance(self):
        return ConvertHdfAlgorithm()
