"""
Feature Extraction — 2066D  (Pyrophyllite Al-OH Doublet)

Targets the diagnostic Al-OH combination doublet of pyrophyllite at
~2066 and ~2078 nm.

From GMEX pyrophyllite (AusSpec International 2005):
  ~2066, ~2078 nm — Al-OH combination doublet.
    GMEX annotation: "These absorptions may persist in mixtures."
    This doublet is a characteristic mid-SWIR feature of pyrophyllite
    (Al4[Si8O20](OH)4) not shared by kaolinite, dickite, or illite in
    this exact position, making it a useful discriminator in mixed
    Al-OH scenes.
  ~2166 nm — primary diagnostic Al-OH absorption.
  ~2319 nm — persists in mixtures.
  ~1396 nm — single sharp OH absorption (FE02).

WoM range:  2050-2100 nm  (captures both doublet peaks)
Stretch:    2060-2090 nm  (resolves the ~2066/2078 nm positions)

Note: FE09-2080D covers a similar range (2060-2100 nm) but with a
tighter stretch (2075-2085 nm).  This tool uses a wider stretch
(2060-2090 nm) to better resolve the doublet separation and is labelled
specifically for pyrophyllite identification.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
)
import processing
import os


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with wavelength metadata.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""


class Fe2066DAlgorithm(QgsProcessingAlgorithm):
    """Feature Extraction — 2066D (Pyrophyllite Al-OH Doublet)."""

    INPUT         = 'INPUT'
    NUM_FEATURES  = 'NUM_FEATURES'
    OUTPUT_WOM    = 'OUTPUT_WOM'
    OUTPUT_MAP    = 'OUTPUT_MAP'
    LEGEND_OUTPUT = 'LEGEND_OUTPUT'

    WOM_START = 2050.0
    WOM_END   = 2110.0
    MAP_MIN   = 2055.0
    MAP_MAX   = 2095.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract (1-9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=2, minValue=1, maxValue=9))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_WOM,
            'Output WoM raster (2050-2110 nm)'))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_MAP,
            'Output Wavelength Map RGB (2055-2095 nm stretch)'))
        self.addParameter(QgsProcessingParameterFileDestination(
            self.LEGEND_OUTPUT,
            'Output Colour Legend (PNG)',
            fileFilter='PNG Files (*.png)',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        cube        = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n           = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        out_wom     = self.parameterAsOutputLayer(parameters, self.OUTPUT_WOM, context)
        out_map     = self.parameterAsOutputLayer(parameters, self.OUTPUT_MAP, context)
        legend_path = self.parameterAsFileOutput(parameters, self.LEGEND_OUTPUT, context)

        self._legend_path = None

        feedback.setProgress(5)
        feedback.pushInfo('Step 1/2  Wavelength of Minimum  2050.0-2110.0 nm ...')
        feedback.pushInfo('  (Pyrophyllite Al-OH doublet ~2066/2078 nm)')
        feedback.pushInfo('  Default 2 features to resolve both doublet peaks')
        wom_result = processing.run(
            'hyppy:wavelength_of_minimum',
            {
                'INPUT':            cube,
                'START_WAVELENGTH': self.WOM_START,
                'END_WAVELENGTH':   self.WOM_END,
                'MODE':             0,
                'NUM_FEATURES':     n,
                'BROAD':            False,
                'USE_BBL':          True,
                'OUTPUT':           out_wom,
            },
            context=context,
            feedback=feedback,
            is_child_algorithm=True,
        )
        if feedback.isCanceled():
            return {}

        wom_path = wom_result['OUTPUT']
        feedback.pushInfo(f'  WoM raster saved: {wom_path}')

        feedback.setProgress(50)
        feedback.pushInfo('Step 2/2  Wavelength Mapping  2060-2090 nm stretch ...')

        from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
        wma     = WavelengthMappingAlgorithm()
        palette = wma.create_rainbow_palette()

        map_path = wma._run_colour_mapping(
            wom_path, palette,
            self.MAP_MIN, self.MAP_MAX,
            self.DEPTH_MIN, self.DEPTH_MAX,
            out_map, feedback,
        )

        feedback.setProgress(88)
        feedback.pushInfo(f'  Wavelength map saved: {map_path}')

        if not legend_path:
            wom_dir     = os.path.dirname(wom_path)
            legend_path = os.path.join(wom_dir, '2066D_legend.png')
        try:
            saved = wma.create_legend(
                legend_path, palette,
                self.MAP_MIN, self.MAP_MAX,
                self.DEPTH_MIN, self.DEPTH_MAX,
                feedback,
            )
            if saved:
                self._legend_path = saved
                feedback.pushInfo(f'  Colour legend saved: {saved}')
        except Exception as e:
            feedback.pushWarning(f'Legend generation failed: {e}')

        feedback.setProgress(100)
        feedback.pushInfo('Feature Extraction 2066D complete.')

        return {
            self.OUTPUT_WOM:    wom_path,
            self.OUTPUT_MAP:    map_path,
            self.LEGEND_OUTPUT: self._legend_path or '',
        }

    def postProcessAlgorithm(self, context, feedback):
        if getattr(self, '_legend_path', None):
            from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
            WavelengthMappingAlgorithm()._show_legend_dock(self._legend_path, feedback)
        return {}

    def name(self):        return 'fe_2066d'
    def displayName(self): return 'FE08 - 2066D  (Pyrophyllite Al-OH Doublet)'
    def group(self):       return '7 - Feature Extraction'
    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2066D  (Pyrophyllite Al-OH Doublet)</b>

        <p>Targets the diagnostic Al-OH combination doublet of pyrophyllite at
        <b>~2066 and ~2078 nm</b>, derived from the USGS GMEX pyrophyllite
        reference spectrum (AusSpec International 2005).</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>2050-2100 nm</b>
              with default <b>2 features</b> to resolve both doublet peaks.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>2060-2090 nm</b>
              (wider than FE09-2080D to resolve the doublet separation).</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>2050-2100 nm</td></tr>
          <tr><td>Colour stretch min</td><td>2060 nm</td></tr>
          <tr><td>Colour stretch max</td><td>2090 nm</td></tr>
          <tr><td>Default features</td><td>2 (resolves ~2066 and ~2078 nm peaks)</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>GMEX pyrophyllite — key diagnostic features:</b></p>
        <ul>
          <li><b>~2066, ~2078 nm</b> — Al-OH doublet; "may persist in mixtures"</li>
          <li><b>~2166 nm</b> — primary diagnostic Al-OH (see FE10-2160D)</li>
          <li><b>~2319 nm</b> — Al-OH overtone; "persists in mixtures"</li>
          <li><b>~1396 nm</b> — single sharp OH (see FE02-1396W)</li>
        </ul>

        <p>The ~2066/2078 nm doublet distinguishes pyrophyllite from kaolinite
        (which has no feature here) and from illite (broader ~2080 nm feature).
        Use together with <b>FE02-1396W</b> and <b>DT Pyrophyllite</b> for full
        pyrophyllite identification.</p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength ~2066-2078 nm, Band 2: depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, pyrophyllite entry
        (AusSpec International 2005). Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe2066DAlgorithm()
