"""
Linear Filter Algorithm for QGIS Processing

Applies a 3×3 spatial convolution kernel to each band of an ENVI
hyperspectral image.  Includes built-in presets (smoothing, Laplacian
edge-enhance) as well as a fully user-definable 3×3 kernel with
bias and offset parameters.

  output = bias * (kernel ⊛ input) + offset

Border pixels (1-pixel margin) are set to zero in the output.

Ported from HyPy convolve.py / tkFilter.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original HyPy Copyright (C) 2010-2022 Wim Bakker, University of Twente

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import os
import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterEnum,
    QgsProcessingParameterString,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis,
)

from ..core.envi_header import (
    get_wavelengths_from_dataset,
    get_bbl_from_dataset,
    find_hdr,
    parse_hdr,
)

gdal.UseExceptions()


# ── Pre-defined kernels (row-major, 3×3) ─────────────────────────────────────

_KERNEL_SMOOTHING = np.ones((3, 3), dtype=np.float64)

_KERNEL_LAPLACE = np.array([
    [ 0, -1,  0],
    [-1,  4, -1],
    [ 0, -1,  0],
], dtype=np.float64)

_KERNEL_SHARPEN = np.array([
    [ 0, -1,  0],
    [-1,  5, -1],
    [ 0, -1,  0],
], dtype=np.float64)

_KERNEL_EMBOSS = np.array([
    [-2, -1,  0],
    [-1,  1,  1],
    [ 0,  1,  2],
], dtype=np.float64)

PRESET_KERNELS = {
    'smoothing': _KERNEL_SMOOTHING,
    'laplace':   _KERNEL_LAPLACE,
    'sharpen':   _KERNEL_SHARPEN,
    'emboss':    _KERNEL_EMBOSS,
}

PRESET_LABELS = [
    'Smoothing (3×3 box average)',
    'Laplacian edge-enhance',
    'Sharpen',
    'Emboss',
    'Custom (use kernel values below)',
]


def _parse_kernel_string(s):
    """Parse 9 whitespace/comma separated floats into a 3×3 kernel."""
    s = s.replace(',', ' ')
    vals = list(map(float, s.split()))
    if len(vals) != 9:
        raise ValueError(f"Expected 9 kernel values, got {len(vals)}")
    return np.array(vals, dtype=np.float64).reshape(3, 3)


def _apply_kernel_band(data2d, kernel, bias, offset):
    """
    Apply a 3×3 kernel to a 2D (lines, samples) float64 array.
    Returns result with a 1-pixel zero border.
    """
    lines, samples = data2d.shape
    result = np.zeros_like(data2d)

    for dj in range(3):
        for di in range(3):
            w = kernel[dj, di]
            if w == 0.0:
                continue
            result[1:-1, 1:-1] += w * data2d[dj:lines - 2 + dj,
                                               di:samples - 2 + di]

    result[1:-1, 1:-1] = bias * result[1:-1, 1:-1] + offset
    return result


def _write_envi_sidecar(path, lines, samples, bands, dtype_str,
                        wavelengths=None, band_names=None,
                        map_info=None, coord_sys=None, description=''):
    gdal_to_envi = {
        'float64': 5, 'float32': 4, 'int16': 2, 'uint16': 12,
        'int32': 3, 'uint32': 13, 'uint8': 1,
    }
    envi_dt = gdal_to_envi.get(dtype_str, 5)
    hdr_lines = ['ENVI']
    if description:
        hdr_lines.append(f'description = {{{description}}}')
    hdr_lines += [
        f'samples = {samples}',
        f'lines   = {lines}',
        f'bands   = {bands}',
        f'header offset = 0',
        f'file type = ENVI Standard',
        f'data type = {envi_dt}',
        f'interleave = bsq',
        f'byte order = 0',
    ]
    if band_names:
        hdr_lines.append('band names = {' + ', '.join(band_names) + '}')
    if wavelengths:
        hdr_lines.append('wavelength = {' +
                         ', '.join(f'{w:.4f}' for w in wavelengths) + '}')
        hdr_lines.append('wavelength units = Nanometers')
    if map_info:
        hdr_lines.append(f'map info = {map_info}')
    if coord_sys:
        hdr_lines.append(f'coordinate system string = {coord_sys}')

    hdr_path = path + '.hdr'
    with open(hdr_path, 'w') as f:
        f.write('\n'.join(hdr_lines) + '\n')


class LinearFilterAlgorithm(QgsProcessingAlgorithm):
    """
    Apply a 3×3 spatial linear convolution filter to each band of a
    hyperspectral image.

        output = bias * (kernel ⊛ input) + offset

    Includes smoothing, Laplacian, sharpening, and emboss presets as well
    as a fully user-definable 3×3 kernel.
    """

    INPUT         = 'INPUT'
    SORT_WAV      = 'SORT_WAV'
    USE_BBL       = 'USE_BBL'
    PRESET        = 'PRESET'
    KERNEL_ROW0   = 'KERNEL_ROW0'
    KERNEL_ROW1   = 'KERNEL_ROW1'
    KERNEL_ROW2   = 'KERNEL_ROW2'
    BIAS          = 'BIAS'
    OFFSET        = 'OFFSET'
    OUTPUT        = 'OUTPUT'

    def initAlgorithm(self, config=None):

        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT,
                'Input Hyperspectral Image (ENVI)',
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.SORT_WAV,
                'Sort bands by ascending wavelength before filtering',
                defaultValue=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.USE_BBL,
                'Exclude bad bands (use Bad Band List from header)',
                defaultValue=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.PRESET,
                'Kernel Preset',
                options=PRESET_LABELS,
                defaultValue=0,
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.KERNEL_ROW0,
                'Custom kernel — Row 0 (3 values, space-separated)',
                defaultValue='0 -1 0',
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.KERNEL_ROW1,
                'Custom kernel — Row 1',
                defaultValue='-1 4 -1',
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.KERNEL_ROW2,
                'Custom kernel — Row 2',
                defaultValue='0 -1 0',
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.BIAS,
                'Bias (multiplier applied to kernel result)',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=1.0,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.OFFSET,
                'Offset (additive constant after bias)',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=0.0,
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                'Output Filtered Image',
            )
        )

    # ── processAlgorithm ────────────────────────────────────────────────────

    def processAlgorithm(self, parameters, context, feedback):

        input_layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        raster_path = input_layer.source()
        sort_wav    = self.parameterAsBoolean(parameters, self.SORT_WAV, context)
        use_bbl     = self.parameterAsBoolean(parameters, self.USE_BBL, context)
        preset_idx  = self.parameterAsEnum(parameters, self.PRESET, context)
        bias        = self.parameterAsDouble(parameters, self.BIAS, context)
        offset      = self.parameterAsDouble(parameters, self.OFFSET, context)
        fout        = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        feedback.pushInfo("=== HypPy Linear Filter ===")
        feedback.pushInfo(f"Input: {raster_path}")

        # ── Build kernel ─────────────────────────────────────────────────
        preset_keys = ['smoothing', 'laplace', 'sharpen', 'emboss', 'custom']
        preset_key  = preset_keys[preset_idx]

        if preset_key == 'custom':
            r0 = self.parameterAsString(parameters, self.KERNEL_ROW0, context).strip()
            r1 = self.parameterAsString(parameters, self.KERNEL_ROW1, context).strip()
            r2 = self.parameterAsString(parameters, self.KERNEL_ROW2, context).strip()
            try:
                v0 = list(map(float, r0.split()))
                v1 = list(map(float, r1.split()))
                v2 = list(map(float, r2.split()))
                if len(v0) != 3 or len(v1) != 3 or len(v2) != 3:
                    raise ValueError("Each row must have exactly 3 values.")
                kernel = np.array([v0, v1, v2], dtype=np.float64)
            except Exception as e:
                raise QgsProcessingException(f"Invalid custom kernel: {e}")
        else:
            kernel = PRESET_KERNELS[preset_key].copy()

        feedback.pushInfo(f"Kernel ({PRESET_LABELS[preset_idx]}):")
        for row in kernel:
            feedback.pushInfo("  " + "  ".join(f"{v:7.3f}" for v in row))
        feedback.pushInfo(f"Bias={bias}  Offset={offset}")

        # ── Open dataset ─────────────────────────────────────────────────
        ds = gdal.Open(raster_path, gdal.GA_ReadOnly)
        if ds is None:
            raise QgsProcessingException(f"Cannot open raster: {raster_path}")

        n_bands_raw = ds.RasterCount
        n_lines     = ds.RasterYSize
        n_samps     = ds.RasterXSize
        gt          = ds.GetGeoTransform()
        proj        = ds.GetProjection()

        # ── Wavelengths and BBL ─────────────────────────────────────────
        wavelengths = get_wavelengths_from_dataset(ds, n_bands_raw, raster_path, feedback)
        bbl_raw     = get_bbl_from_dataset(ds, n_bands_raw, raster_path, feedback)

        order = list(range(n_bands_raw))
        if sort_wav and wavelengths is not None:
            order = sorted(order, key=lambda i: wavelengths[i])
        if use_bbl and bbl_raw is not None:
            order = [i for i in order if bbl_raw[i]]
            feedback.pushInfo(f"After BBL filter: {len(order)} good bands")

        n_bands = len(order)
        wav_out = ([wavelengths[i] for i in order]
                   if wavelengths is not None else None)

        # Map info
        map_info_str  = None
        coord_sys_str = None
        hdr_path = find_hdr(raster_path)
        if hdr_path:
            hdr = parse_hdr(hdr_path)
            map_info_str  = hdr.get('map info', None)
            coord_sys_str = hdr.get('coordinate system string', None)

        # ── Create output ────────────────────────────────────────────────
        drv    = gdal.GetDriverByName('GTiff')
        ds_out = drv.Create(fout, n_samps, n_lines, n_bands, gdal.GDT_Float64)
        if ds_out is None:
            raise QgsProcessingException(f"Cannot create output: {fout}")
        if gt:
            ds_out.SetGeoTransform(gt)
        if proj:
            ds_out.SetProjection(proj)

        # ── Apply filter band by band ────────────────────────────────────
        feedback.pushInfo(f"Filtering {n_bands} bands...")
        for out_b, src_b in enumerate(order):
            if feedback.isCanceled():
                del ds_out
                raise QgsProcessingException("Cancelled by user.")

            band = ds.GetRasterBand(src_b + 1)
            data = band.ReadAsArray().astype(np.float64)

            result = _apply_kernel_band(data, kernel, bias, offset)

            out_band = ds_out.GetRasterBand(out_b + 1)
            out_band.WriteArray(result)

            # Carry description / nodata
            desc = band.GetDescription()
            if not desc and wav_out:
                desc = f"{wav_out[out_b]:.4f}"
            if desc:
                out_band.SetDescription(desc)
            nd = band.GetNoDataValue()
            if nd is not None:
                out_band.SetNoDataValue(nd)

            feedback.setProgress(int(100 * (out_b + 1) / n_bands))

        ds_out.FlushCache()
        del ds_out, ds

        # ── ENVI sidecar ─────────────────────────────────────────────────
        _write_envi_sidecar(
            fout,
            lines=n_lines, samples=n_samps, bands=n_bands,
            dtype_str='float64',
            wavelengths=wav_out,
            map_info=map_info_str,
            coord_sys=coord_sys_str,
            description=f'Linear filter ({PRESET_LABELS[preset_idx]}) of '
                        f'{os.path.basename(raster_path)}',
        )

        feedback.pushInfo(f"Output: {fout}")
        feedback.pushInfo("Linear Filter completed.")
        return {self.OUTPUT: fout}

    # ── Metadata ────────────────────────────────────────────────────────────

    def name(self):
        return 'linear_filter'

    def displayName(self):
        return 'Linear Filter (3×3 Convolution)'

    def group(self):
        return '6 - Spectral Processing Tools'

    def groupId(self):
        return '6_spectral_processing'

    def shortHelpString(self):
        return (
            'Applies a 3×3 spatial convolution kernel independently to each band '
            'of a hyperspectral image:\n\n'
            '    output = bias × (kernel ⊛ input) + offset\n\n'
            'The 1-pixel border of each output band is set to zero.\n\n'
            'PRESETS\n'
            '  Smoothing       — uniform 3×3 box average (all weights = 1)\n'
            '  Laplacian       — edge-enhance (highlight spectral gradients)\n'
            '  Sharpen         — centre-weighted sharpening kernel\n'
            '  Emboss          — directional emboss effect\n'
            '  Custom          — enter your own 3×3 kernel values in the\n'
            '                    three Row fields below\n\n'
            'CUSTOM KERNEL\n'
            '  Enter three space-separated values per row, e.g.:\n'
            '    Row 0: 0 -1  0\n'
            '    Row 1: -1  4 -1\n'
            '    Row 2: 0 -1  0\n\n'
            'BIAS AND OFFSET\n'
            '  bias=1.0, offset=0.0 — standard convolution (defaults)\n'
            '  bias=1/9, offset=0.0 — normalised smoothing\n\n'
            'Ported from HyPy convolve.py (Wim Bakker, University of Twente).'
        )

    def createInstance(self):
        return LinearFilterAlgorithm()
