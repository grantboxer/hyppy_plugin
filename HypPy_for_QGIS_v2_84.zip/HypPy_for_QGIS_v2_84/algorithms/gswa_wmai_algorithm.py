"""
GSWA Table 5 — White mica and Al-smectite abundance index (WMai)

Algorithm: Intensity of the wavelength minimum between 2140 and 2240 nm
           using 4th order polynomial fit (2200D).
Masks:     Gascoyne: MertonNDVI > 0.15 AND 2200D/2160D > 3.0 AND 2160D > 0.03
           Pilbara:  MertonNDVI > 0.2  AND 2200D < 0.04      AND 2160D > 0.03
Stretch:   Gascoyne linear: Blue=0.02, Red=0.18
           Pilbara  linear: Blue=0.02, Red=0.16
Targeted:  White mica ± Al-smectite  (challenge: kaolinite)

The key discriminator from ASai is the 2200D/2160D ratio > 3.0:
white mica has a strong 2200 nm feature relative to the 2160 nm shoulder,
while kaolinite has a more balanced ratio.

Reference:
    Laukamp et al. (2025) GSWA Report 261, Table 5.

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

from ..core.envi_header import get_wavelengths_from_dataset
from .gswa_index_utils import (
    compute_ndvi, read_wom_band, write_index,
    apply_ndvi_mask, log_gswa_stretch,
)

WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Cube (NDVI) + FE12-2200W WoM + FE10-2160D WoM.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""

GSWA_STRETCH = {
    'gascoyne': 'linear: Blue=0.02 (low), Red=0.18 (high)',
    'pilbara':  'linear: Blue=0.02 (low), Red=0.16 (high)',
}

REFERENCE = 'Laukamp et al. (2025) GSWA Report 261, Table 5 (WMai)'


class GswaWmaiAlgorithm(QgsProcessingAlgorithm):
    """GSWA Table 5 — White mica and Al-smectite abundance index (WMai)."""

    CUBE          = 'CUBE'
    WOM_2200      = 'WOM_2200'
    WOM_2160      = 'WOM_2160'
    NDVI_THRESH   = 'NDVI_THRESH'
    RATIO_THRESH  = 'RATIO_THRESH'
    DEPTH_2160_THRESH = 'DEPTH_2160_THRESH'
    OUTPUT        = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.CUBE,    'Hyperspectral cube  (for MertonNDVI)'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2200, 'FE12-2200W WoM raster  (Band 2 = 2200D depth)'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2160, 'FE10-2160D WoM raster  (Band 2 = 2160D depth)'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NDVI_THRESH,
            'MertonNDVI threshold (mask above)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.15, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.RATIO_THRESH,
            '2200D/2160D ratio threshold — keep pixels ABOVE this (white mica dominance)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=3.0, minValue=0.1, maxValue=20.0))
        self.addParameter(QgsProcessingParameterNumber(
            self.DEPTH_2160_THRESH,
            '2160D minimum depth threshold — keep pixels ABOVE this',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.03, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT, 'Output WMai raster'))

    def processAlgorithm(self, parameters, context, feedback):
        cube_layer    = self.parameterAsRasterLayer(parameters, self.CUBE, context)
        wom_2200      = self.parameterAsRasterLayer(parameters, self.WOM_2200, context)
        wom_2160      = self.parameterAsRasterLayer(parameters, self.WOM_2160, context)
        ndvi_thresh   = self.parameterAsDouble(parameters, self.NDVI_THRESH, context)
        ratio_thresh  = self.parameterAsDouble(parameters, self.RATIO_THRESH, context)
        d2160_thresh  = self.parameterAsDouble(parameters, self.DEPTH_2160_THRESH, context)
        out_path      = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        feedback.setProgress(5)
        feedback.pushInfo('Reading 2200D depth …')
        d2200, gt, proj, rows, cols = read_wom_band(wom_2200, 2, '2200D', feedback)
        feedback.pushInfo('Reading 2160D depth …')
        d2160, *_ = read_wom_band(wom_2160, 2, '2160D', feedback)

        feedback.setProgress(20)
        feedback.pushInfo('Computing MertonNDVI …')
        cube_ds     = gdal.Open(cube_layer.source())
        wavelengths = get_wavelengths_from_dataset(
            cube_ds, cube_ds.RasterCount, cube_layer.source(), feedback)
        if wavelengths is None:
            raise QgsProcessingException('No wavelength metadata found in cube.')
        nodata = cube_ds.GetRasterBand(1).GetNoDataValue()
        ndvi   = compute_ndvi(cube_ds, wavelengths, nodata, feedback)
        del cube_ds

        feedback.setProgress(60)
        feedback.pushInfo('Applying GSWA Table 5 masks …')
        wmai = d2200.copy()
        wmai = apply_ndvi_mask(wmai, ndvi, ndvi_thresh, 'WMai', feedback)

        # 2200D/2160D ratio > ratio_thresh (keep white-mica-dominant pixels)
        with np.errstate(invalid='ignore', divide='ignore'):
            ratio = np.where(d2160 > 0, d2200 / d2160, np.nan)
        low_ratio = ~np.isnan(ratio) & (ratio <= ratio_thresh)
        feedback.pushInfo(
            f'  WMai: 2200D/2160D≤{ratio_thresh} mask: {int(np.sum(low_ratio))} px masked')
        wmai[low_ratio] = np.nan

        # 2160D > d2160_thresh (ensure some Al-OH signal at 2160 nm)
        shallow = ~np.isnan(d2160) & (d2160 <= d2160_thresh)
        feedback.pushInfo(
            f'  WMai: 2160D≤{d2160_thresh} mask: {int(np.sum(shallow))} px masked')
        wmai[shallow] = np.nan

        feedback.setProgress(85)
        feedback.pushInfo('Writing WMai …')
        write_index(
            out_path, wmai, gt, proj,
            product_name='WMai',
            description='White mica + Al-smectite abundance index (2200D masked by ratio)',
            gswa_stretch=GSWA_STRETCH,
            reference=REFERENCE,
            extra_meta={
                'GSWA_ratio_condition': f'2200D/2160D > {ratio_thresh}',
                'GSWA_depth_condition': f'2160D > {d2160_thresh}',
            }
        )

        log_gswa_stretch(feedback, 'WMai (White mica + Al-smectite abundance)', GSWA_STRETCH)
        feedback.pushInfo(
            'Targeted minerals: white mica ± Al-smectite  '
            '(2200D/2160D ratio > 3.0 separates from kaolinite-dominated pixels)')
        feedback.setProgress(100)
        return {self.OUTPUT: out_path}

    def name(self):        return 'gswa_wmai'
    def displayName(self): return 'GSWA-WMai  (White Mica Abundance)'
    def group(self):       return '9 - GSWA Mineral Map Indices'
    def groupId(self):     return 'nine_gswa_indices'

    def shortHelpString(self):
        return WORKFLOW_NOTE + f"""
        <b>White Mica and Al-smectite Abundance Index (WMai)</b>
        <p>GSWA Report 261, Table 5. 2200D depth masked to retain only pixels where
        white mica/Al-smectite dominates over kaolinite, using the 2200D/2160D ratio.</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Mask condition</th><th>Rationale</th>
          </tr>
          <tr><td>MertonNDVI &gt; threshold</td><td>Remove vegetation</td></tr>
          <tr><td>2200D / 2160D &gt; 3.0</td>
              <td>White mica: strong 2200 nm, weak 2160 nm shoulder</td></tr>
          <tr><td>2160D &gt; 0.03</td>
              <td>Require minimum Al-OH signal at 2160 nm</td></tr>
          <tr style="background:#fff3e0">
            <td><b>Gascoyne stretch</b></td>
            <td>linear: Blue=0.02, Red=0.18</td></tr>
          <tr style="background:#fff3e0">
            <td><b>Pilbara stretch</b></td>
            <td>linear: Blue=0.02, Red=0.16</td></tr>
        </table>

        <p><i>Reference: Laukamp et al. (2025) GSWA Report 261, Table 5.</i></p>
        """

    def createInstance(self): return GswaWmaiAlgorithm()
