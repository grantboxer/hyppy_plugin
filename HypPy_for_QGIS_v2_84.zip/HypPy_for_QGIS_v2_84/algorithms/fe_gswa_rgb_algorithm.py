"""
Feature Extraction — Mineral Groups False Colour RGB  (GSWA Table 4)

Combines three polynomial-fit depth rasters into a false-colour RGB composite:
    R = 2200D  (Al-OH; white mica, kaolinite, Al-smectite, tourmaline)
    G = 2250D  (Fe/Mg-OH; chlorite, dark mica, epidote, jarosite, tourmaline)
    B = 2160D  (Al-OH shoulder; kaolinite, pyrophyllite, alunite)

Reference:
    Laukamp, C., Miles, A.J., Lampinen, H.M. et al. (2025).
    Spaceborne Mineral Maps for Critical Metals Exploration in the
    Gascoyne and Pilbara.  Geological Survey of Western Australia,
    Report 261.  Table 4 (Combined base product — Mineral Groups False Colour RGB).

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterNumber,
    QgsProcessingException,
)


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Three depth rasters from the FE tools below.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""

# GSWA Table 4 recommended stretch values per channel
# Gascoyne/Pilbara: R - min=0.02, max=0.15; G - min=0.02, max=0.15; B - min=0.02, max=0.15
GSWA_STRETCH = {
    'R': (0.02, 0.15),
    'G': (0.02, 0.15),
    'B': (0.02, 0.15),
}


class FeGswaRgbAlgorithm(QgsProcessingAlgorithm):
    """GSWA Mineral Groups False Colour RGB (R=2200D, G=2250D, B=2160D)."""

    INPUT_2200D = 'INPUT_2200D'
    INPUT_2250D = 'INPUT_2250D'
    INPUT_2160D = 'INPUT_2160D'
    R_MIN       = 'R_MIN'
    R_MAX       = 'R_MAX'
    G_MIN       = 'G_MIN'
    G_MAX       = 'G_MAX'
    B_MIN       = 'B_MIN'
    B_MAX       = 'B_MAX'
    OUTPUT      = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT_2200D,
            'Red channel — 2200D depth raster  '
            '(WoM Band 2, from FE12-2200W or WoM 2140–2240 nm)'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT_2250D,
            'Green channel — 2250D depth raster  '
            '(WoM Band 2, from FE14-2250W or WoM 2230–2280 nm)'))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT_2160D,
            'Blue channel — 2160D depth raster  '
            '(WoM Band 2, from FE10-2160D or WoM 2140–2200 nm)'))

        # Stretch parameters — default to GSWA Table 4 recommended values
        for ch, param_min, param_max, default_min, default_max in [
            ('Red (2200D)',   self.R_MIN, self.R_MAX,
             GSWA_STRETCH['R'][0], GSWA_STRETCH['R'][1]),
            ('Green (2250D)', self.G_MIN, self.G_MAX,
             GSWA_STRETCH['G'][0], GSWA_STRETCH['G'][1]),
            ('Blue (2160D)',  self.B_MIN, self.B_MAX,
             GSWA_STRETCH['B'][0], GSWA_STRETCH['B'][1]),
        ]:
            self.addParameter(QgsProcessingParameterNumber(
                param_min,
                f'{ch} — stretch minimum depth',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=default_min, minValue=0.0, maxValue=1.0))
            self.addParameter(QgsProcessingParameterNumber(
                param_max,
                f'{ch} — stretch maximum depth',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=default_max, minValue=0.0, maxValue=1.0))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT,
            'Output Mineral Groups RGB composite'))

    def processAlgorithm(self, parameters, context, feedback):
        lyr_r = self.parameterAsRasterLayer(parameters, self.INPUT_2200D, context)
        lyr_g = self.parameterAsRasterLayer(parameters, self.INPUT_2250D, context)
        lyr_b = self.parameterAsRasterLayer(parameters, self.INPUT_2160D, context)

        r_min = self.parameterAsDouble(parameters, self.R_MIN, context)
        r_max = self.parameterAsDouble(parameters, self.R_MAX, context)
        g_min = self.parameterAsDouble(parameters, self.G_MIN, context)
        g_max = self.parameterAsDouble(parameters, self.G_MAX, context)
        b_min = self.parameterAsDouble(parameters, self.B_MIN, context)
        b_max = self.parameterAsDouble(parameters, self.B_MAX, context)

        out_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        for name, lyr in [('2200D (R)', lyr_r),
                           ('2250D (G)', lyr_g),
                           ('2160D (B)', lyr_b)]:
            if lyr is None:
                raise QgsProcessingException(f'Invalid input layer: {name}')

        def open_band1(lyr, label):
            ds = gdal.Open(lyr.source())
            if ds is None:
                raise QgsProcessingException(
                    f'Cannot open raster: {lyr.source()} ({label})')
            # Accept either Band 1 (single-band depth raster) or
            # Band 2 from a WoM raster (band 1 = wavelength, band 2 = depth)
            n = ds.RasterCount
            band_idx = 2 if n >= 2 else 1
            feedback.pushInfo(
                f'{label}: reading band {band_idx} of {n} '
                f'from {lyr.source()}')
            arr  = ds.GetRasterBand(band_idx).ReadAsArray().astype(np.float32)
            nd   = ds.GetRasterBand(band_idx).GetNoDataValue()
            if nd is not None:
                arr[arr == nd] = np.nan
            gt   = ds.GetGeoTransform()
            proj = ds.GetProjection()
            rows = ds.RasterYSize
            cols = ds.RasterXSize
            del ds
            return arr, gt, proj, rows, cols

        feedback.setProgress(10)
        arr_r, gt, proj, rows, cols = open_band1(lyr_r, '2200D (R)')
        feedback.setProgress(30)
        arr_g, *_ = open_band1(lyr_g, '2250D (G)')
        feedback.setProgress(50)
        arr_b, *_ = open_band1(lyr_b, '2160D (B)')

        # Validate spatial dimensions
        if arr_g.shape != arr_r.shape or arr_b.shape != arr_r.shape:
            raise QgsProcessingException(
                f'Input rasters have different spatial dimensions: '
                f'2200D={arr_r.shape}, 2250D={arr_g.shape}, 2160D={arr_b.shape}.  '
                'All three must cover the same area at the same resolution.')

        feedback.setProgress(55)
        feedback.pushInfo('Applying linear stretch and converting to uint8 …')

        def stretch(arr, vmin, vmax):
            """Linear stretch to 0–255 uint8."""
            with np.errstate(invalid='ignore'):
                out = np.clip((arr - vmin) / max(vmax - vmin, 1e-9), 0.0, 1.0)
            out = (out * 255).astype(np.uint8)
            # Pixels that were NaN → 0 (transparent-friendly)
            out[np.isnan(arr)] = 0
            return out

        r8 = stretch(arr_r, r_min, r_max)
        g8 = stretch(arr_g, g_min, g_max)
        b8 = stretch(arr_b, b_min, b_max)

        feedback.setProgress(75)
        feedback.pushInfo('Writing RGB output …')

        driver = gdal.GetDriverByName('GTiff')
        out_ds = driver.Create(out_path, cols, rows, 3, gdal.GDT_Byte,
                               options=['COMPRESS=LZW', 'TILED=YES',
                                        'PHOTOMETRIC=RGB'])
        out_ds.SetGeoTransform(gt)
        out_ds.SetProjection(proj)

        for i, (band_arr, desc, colour) in enumerate([
            (r8, '2200D (Al-OH: white mica, kaolinite, Al-smectite)',   'Red'),
            (g8, '2250D (Fe/Mg-OH: chlorite, dark mica, epidote)',      'Green'),
            (b8, '2160D (Al-OH shoulder: kaolinite, pyrophyllite)',     'Blue'),
        ], start=1):
            b = out_ds.GetRasterBand(i)
            b.WriteArray(band_arr)
            b.SetDescription(desc)
            b.SetColorInterpretation(
                gdal.GCI_RedBand   if colour == 'Red'   else
                gdal.GCI_GreenBand if colour == 'Green' else
                gdal.GCI_BlueBand)

        out_ds.SetMetadataItem('GSWA_RGB_R', f'2200D stretch {r_min:.3f}–{r_max:.3f}')
        out_ds.SetMetadataItem('GSWA_RGB_G', f'2250D stretch {g_min:.3f}–{g_max:.3f}')
        out_ds.SetMetadataItem('GSWA_RGB_B', f'2160D stretch {b_min:.3f}–{b_max:.3f}')
        out_ds.SetMetadataItem(
            'GSWA_RGB_reference',
            'GSWA Report 261, Table 4 (Laukamp et al. 2025)')

        out_ds.FlushCache()
        del out_ds

        feedback.setProgress(95)
        feedback.pushInfo('')
        feedback.pushInfo('─' * 60)
        feedback.pushInfo('GSWA Report 261 Table 4 — Mineral Groups False Colour RGB')
        feedback.pushInfo(f'  Red   (2200D): stretch {r_min:.3f}–{r_max:.3f}  '
                          '→ white mica, kaolinite, Al-smectite, tourmaline')
        feedback.pushInfo(f'  Green (2250D): stretch {g_min:.3f}–{g_max:.3f}  '
                          '→ chlorite, dark mica, epidote, jarosite, tourmaline')
        feedback.pushInfo(f'  Blue  (2160D): stretch {b_min:.3f}–{b_max:.3f}  '
                          '→ kaolinite, pyrophyllite, alunite')
        feedback.pushInfo('─' * 60)
        feedback.pushInfo('Mineral Groups RGB complete.')
        feedback.setProgress(100)

        return {self.OUTPUT: out_path}

    def name(self):        return 'fe_gswa_rgb'
    def displayName(self): return 'FE-GSWA-RGB  (Mineral Groups False Colour RGB)'
    def group(self):       return '7 - Feature Extraction'
    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Mineral Groups False Colour RGB  (GSWA Report 261, Table 4)</b>

        <p>Combines three absorption depth rasters into a false-colour RGB image
        that simultaneously displays the relative abundance of three major SWIR
        mineral groups:</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Channel</th><th>Depth Raster</th>
            <th>GSWA Stretch (Gascoyne/Pilbara)</th><th>Targeted Minerals</th>
          </tr>
          <tr style="background:#ffcccc">
            <td><b>Red</b></td><td>2200D</td>
            <td>min = 0.02, max = 0.15</td>
            <td>White mica, kaolinite, Al-smectite, tourmaline</td>
          </tr>
          <tr style="background:#ccffcc">
            <td><b>Green</b></td><td>2250D</td>
            <td>min = 0.02, max = 0.15</td>
            <td>Chlorite, dark mica, epidote, jarosite, tourmaline</td>
          </tr>
          <tr style="background:#ccccff">
            <td><b>Blue</b></td><td>2160D</td>
            <td>min = 0.02, max = 0.15</td>
            <td>Kaolinite (shoulder), pyrophyllite, alunite</td>
          </tr>
        </table>

        <p><b>Inputs:</b> The three depth rasters (Band 2 from WoM output, or
        single-band depth from FE tools) must cover the same spatial extent
        and resolution.  The GSWA default stretch values are pre-loaded.</p>

        <p><b>Colour mixing guide:</b></p>
        <ul>
          <li><b>Red pixels</b> — dominantly Al-OH bearing (white mica / kaolinite)</li>
          <li><b>Green pixels</b> — dominantly Fe/Mg-OH bearing (chlorite / dark mica)</li>
          <li><b>Blue pixels</b> — strong pyrophyllite / alunite Al-OH shoulder</li>
          <li><b>Yellow</b> (R+G) — mixed Al-OH + Fe/Mg-OH (e.g. mixed-layer clays, altered mafics)</li>
          <li><b>Cyan</b> (G+B) — chlorite + kaolinite/pyrophyllite mixtures</li>
          <li><b>Magenta</b> (R+B) — white mica + pyrophyllite (advanced argillic alteration)</li>
          <li><b>White</b> (R+G+B) — all three absorptions present</li>
          <li><b>Black</b> — no significant SWIR absorptions (aspectral or masked)</li>
        </ul>

        <p><b>Workflow:</b></p>
        <ol>
          <li>Run <b>FE12-2200W</b> (WoM 2140–2240 nm) → use Band 2 (depth) as Red input</li>
          <li>Run <b>FE14-2250W</b> (WoM 2230–2280 nm) → use Band 2 (depth) as Green input</li>
          <li>Run <b>FE10-2160D</b> (WoM 2138–2179 nm) → use Band 2 (depth) as Blue input</li>
          <li>Run this tool with the three depth outputs above</li>
        </ol>

        <p><i>Algorithm: GSWA Report 261, Table 4, Combined base product
        (Laukamp, C., Miles, A.J., Lampinen, H.M. et al., 2025,
        Geological Survey of Western Australia, Report 261).
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return FeGswaRgbAlgorithm()
