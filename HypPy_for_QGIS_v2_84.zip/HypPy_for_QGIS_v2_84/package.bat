@echo off
REM Package HypPy for QGIS
REM Run from inside the plugin folder (where metadata.txt lives).
REM Creates HypPy_for_QGIS_v<version>.zip ready for QGIS Install from ZIP.
REM
REM Usage:
REM   cd \path\to\HypPy_for_QGIS
REM   package.bat

setlocal enabledelayedexpansion

set PLUGIN_NAME=HypPy_for_QGIS

REM Read version from metadata.txt
for /f "tokens=2 delims==" %%a in ('findstr "^version=" metadata.txt') do set VERSION=%%a
set VERSION=%VERSION: =%
set OUTPUT_FILE=%PLUGIN_NAME%_v%VERSION%.zip

REM Determine parent directory (one level up from the plugin folder)
for %%i in ("%~dp0..") do set PARENT_DIR=%%~fi

echo Packaging %PLUGIN_NAME% v%VERSION% ...

REM Remove old package if it exists
if exist "%~dp0%OUTPUT_FILE%" (
    del "%~dp0%OUTPUT_FILE%"
    echo   Removed old %OUTPUT_FILE%
)

REM Build the zip from the parent directory so the top-level folder inside
REM the zip is exactly PLUGIN_NAME — which must match what QGIS imports.
cd /d "%PARENT_DIR%"

powershell -NoProfile -Command ^
  "$src = '%PLUGIN_NAME%'; $out = '%~dp0%OUTPUT_FILE%'; " ^
  "Add-Type -Assembly System.IO.Compression.FileSystem; " ^
  "$zip = [System.IO.Compression.ZipFile]::Open($out, 'Create'); " ^
  "Get-ChildItem -Path $src -Recurse -File | Where-Object { " ^
    "$_.FullName -notmatch '__pycache__' -and " ^
    "$_.FullName -notmatch '\.pyc$' -and " ^
    "$_.FullName -notmatch '\.git' -and " ^
    "$_.Name -ne 'package.bat' -and " ^
    "$_.Name -ne 'package.sh' -and " ^
    "$_.Name -notmatch '^HypPy_for_QGIS_v.*\.zip$' " ^
  "} | ForEach-Object { " ^
    "$entry = $_.FullName.Substring((Get-Item .).FullName.Length + 1).Replace('\', '/'); " ^
    "[System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $_.FullName, $entry, 'Optimal') | Out-Null " ^
  "}; $zip.Dispose()"

echo.
echo Package created: %~dp0%OUTPUT_FILE%
echo.
echo To install:
echo   1. Open QGIS
echo   2. Plugins -^> Manage and Install Plugins -^> Install from ZIP
echo   3. Select %OUTPUT_FILE%
echo.
pause
