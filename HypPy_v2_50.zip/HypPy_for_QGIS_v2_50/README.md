# Hyperspectral Analysis Tools for QGIS

A comprehensive QGIS plugin for hyperspectral image analysis, ported from the HyPy (Hyperspectral Python) toolkit.

## About

This plugin brings advanced hyperspectral image analysis capabilities to QGIS, originally developed as HyPy by **Wim Bakker** at the **University of Twente, Faculty ITC**.

### Original HyPy Credits
- **Author:** Wim Bakker
- **Institution:** University of Twente, Faculty ITC
- **Contact:** w.h.bakker@utwente.nl
- **Location:** Hengelosestraat 99, 7514 AE Enschede, Netherlands
- **License:** GPL v3

## Features

### Currently Available:
- **Spectral Angle Mapper (SAM)** - Spectral classification algorithm
  - Multiple similarity measures (SAM, Bray-Curtis, SID, Euclidean, Intensity Difference)
  - Works with spectral libraries
  - Generates both rule images and classification maps
  
- **Wavelength of Minimum** - Absorption feature analysis
  - Finds wavelength position of absorption features
  - Calculates feature depth and narrowness
  - Identifies up to 3 local minima
  - Essential for mineral identification
  
- **Wavelength Mapping** - Feature visualization
  - Creates color-coded RGB maps from wavelength features
  - Hue represents wavelength, brightness represents depth
  - Intuitive visualization of absorption features
  - Perfect for mineral and material mapping

### Coming Soon:
- Principal Component Analysis (PCA)
- Linear Spectral Unmixing
- Band Mathematics and Ratios
- Spectral Filters (Median, Gradient, Edge)
- Convex Hull Removal
- Preprocessing Tools (Destriping, Normalization)
- Spectral Library Viewer (Interactive GUI)
- Interactive Spectral Display
- Mars/Planetary Science Tools

## Installation

### From ZIP File:
1. Download the plugin ZIP file
2. In QGIS, go to **Plugins → Manage and Install Plugins**
3. Click **Install from ZIP**
4. Select the downloaded ZIP file
5. Click **Install Plugin**

### Manual Installation:
1. Extract the plugin to your QGIS plugins directory:
   - **Windows:** `C:\Users\YourName\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`
   - **Linux:** `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
   - **macOS:** `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`

2. Restart QGIS
3. Enable the plugin in **Plugins → Manage and Install Plugins**

## Usage

### Spectral Angle Mapper (SAM)

1. Open QGIS Processing Toolbox (**Processing → Toolbox**)
2. Navigate to **Hyperspectral Tools → Classification → Spectral Angle Mapper (SAM)**
3. Configure parameters:
   - **Input Hyperspectral Image:** Your multi-band raster
   - **Spectral Library:** CSV file with reference spectra
   - **Similarity Measure:** Choose from SAM, BC, SID, ED, or ID
   - **Output Rule Image:** Path for similarity values output
   - **Output Classification Image (optional):** Path for classified output

4. Click **Run**

### Spectral Library Format

The spectral library should be a CSV file with the following format:

```csv
wavelength,400,450,500,550,600,650,700
Vegetation,0.05,0.04,0.06,0.25,0.30,0.40,0.45
Water,0.02,0.015,0.01,0.008,0.005,0.003,0.002
Soil,0.15,0.18,0.20,0.22,0.25,0.27,0.28
```

- **First line:** Wavelengths in nanometers
- **Following lines:** Class name, followed by reflectance values

## Requirements

- **QGIS 3.16** or higher

### Python Dependencies

All required packages are typically bundled with a standard QGIS installation:

| Package | Version | Purpose | Bundled with QGIS? |
|---------|---------|---------|---------------------|
| **numpy** | ≥ 1.20 | Array operations, spectral math, parabola fitting | Yes |
| **GDAL** (osgeo) | ≥ 3.0 | Raster I/O, coordinate systems, GeoTIFF read/write | Yes |
| **PyQt5** / **Qt bindings** | — | UI components (via QGIS) | Yes |

### Verifying Dependencies

You can check that all dependencies are available from the QGIS Python Console (**Plugins → Python Console**):

```python
import numpy; print(f"numpy {numpy.__version__}")
from osgeo import gdal; print(f"GDAL {gdal.__version__}")
```

### Notes

- **scipy is not required** as of v1.1.0 — parabola fitting now uses `numpy.polyfit`.
- All QGIS Processing framework classes (`QgsProcessingAlgorithm`, etc.) are provided by QGIS itself.
- The plugin uses only the Python standard library modules `os`, `math`, and `colorsys` beyond the packages listed above.

## Development

### Project Structure

```
hyperspectral_tools/
├── __init__.py                 # Plugin initialization
├── metadata.txt               # Plugin metadata
├── hyperspectral_plugin.py    # Main plugin class
├── hyppy_provider.py          # Processing provider
├── algorithms/                # Processing algorithms
│   ├── __init__.py
│   └── sam_algorithm.py       # SAM implementation
├── core/                      # Core spectral functions
│   └── __init__.py            # Spectral math library
├── ui/                        # Future: Custom UI widgets
└── resources/                 # Icons and resources
```

### Adding New Algorithms

To add a new algorithm from HyPy:

1. Create a new file in `algorithms/` (e.g., `pca_algorithm.py`)
2. Implement a class inheriting from `QgsProcessingAlgorithm`
3. Import and register it in `hyppy_provider.py`
4. Port the core logic from the corresponding HyPy module

Example template:

```python
from qgis.core import QgsProcessingAlgorithm

class MyAlgorithm(QgsProcessingAlgorithm):
    def initAlgorithm(self, config=None):
        # Define parameters
        pass
    
    def processAlgorithm(self, parameters, context, feedback):
        # Implement algorithm
        pass
    
    def name(self):
        return 'my_algorithm'
    
    def displayName(self):
        return 'My Algorithm'
    
    def createInstance(self):
        return MyAlgorithm()
```

## Contributing

Contributions are welcome! This is an open-source port of HyPy to QGIS.

### How to Contribute:
1. Fork the repository
2. Create a feature branch
3. Port an algorithm from HyPy
4. Test thoroughly
5. Submit a pull request

### Priority Algorithms to Port:
- [ ] PCA (Principal Component Analysis)
- [ ] Linear Spectral Unmixing
- [ ] Band Math
- [ ] Convex Hull Removal
- [ ] Spectral Filters
- [ ] Normalization
- [ ] Destriping

## License

This program is free software: you can redistribute it and/or modify it under the terms of the **GNU General Public License** as published by the Free Software Foundation, either **version 3** of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but **WITHOUT ANY WARRANTY**; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

## Acknowledgments

- **Original HyPy Development:** Wim Bakker, University of Twente
- **QGIS Port:** Grant Boxer (boxerg@iinet.net.au)
- **Community Contributors:** [List contributors]

## Support

- **Issues:** Report bugs and request features on GitHub
- **Original HyPy:** Contact Wim Bakker at w.h.bakker@utwente.nl
- **QGIS Plugin:** Contact Grant Boxer at boxerg@iinet.net.au

## References

### SAM (Spectral Angle Mapper):
- Kruse, F. A., et al. (1993). "The Spectral Image Processing System (SIPS)—Interactive Visualization and Analysis of Imaging Spectrometer Data." *Remote Sensing of Environment*, 44, 145-163.

### Hyperspectral Analysis:
- For more background on hyperspectral analysis techniques, refer to the original HyPy documentation and academic literature on imaging spectroscopy.

### HyPy Software:
- Bakker, W.H., 2010–2022. HyPy — Hyperspectral Python. University of Twente, Faculty ITC.
- Bakker, W. et al., 2024. Hyperspectral Python: HypPy. *Algorithms*, 17(8), Article 337. https://doi.org/10.3390/a17080337

---

**Made with ❤️ for the hyperspectral remote sensing community**
