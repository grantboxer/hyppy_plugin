"""
DT Mineral Map Decision Tree Classification Algorithm for QGIS Processing

Implements the dt_mineral_map decision tree from Figure 2 of Laukamp et al.

Inputs (all derived from WoM rasters):
  D1  - depth of deepest absorption feature, 2100-2400 nm  (WoM-C Band 2)
  W1  - wavelength of deepest feature, 2100-2400 nm        (WoM-C Band 1)
  W2  - wavelength of second deepest feature, 2100-2400 nm (WoM-C Band 3)
  Ix  - illite crystallinity = D1 / depth(1850-2100 nm)    (WoM-C B2 / WoM-B B2)

Classes:
  aspectral, other, ill-musc-sw, ill-musc-unspec, ill-musc, ill-musc-hx,
  ill-musc-lx, kaolinite, ill-musc-lw-unspec, ill-musc-lw, ill-musc-lw-hx,
  ill-musc-lw-lx, phengite, Fe-chlt-unspec, Fe-chlt-1, Fe-chlt-2, chlt

Abbreviations: ill=illite, musc=muscovite, chlt=chlorite, unspec=unspecified,
  hx=high crystallinity, lx=low crystallinity, lw=long wavelength, sw=short wavelength.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)


# ---------------------------------------------------------------------------
# Class definitions  (id, name, R, G, B)
# Colours match the decision-tree diagram as closely as possible.
# ---------------------------------------------------------------------------
MINERAL_CLASSES = [
    (0,  'unclassified',      0,   0,   0  ),
    (1,  'aspectral',         0,   0,   0  ),   # black
    (2,  'other',             200, 200, 200),   # grey
    (3,  'ill-musc-sw',       255, 255, 180),   # pale yellow
    (4,  'ill-musc-unspec',   255, 255, 0  ),   # yellow
    (5,  'ill-musc',          255, 220, 0  ),   # yellow-gold
    (6,  'ill-musc-hx',       0,   200, 200),   # cyan
    (7,  'ill-musc-lx',       160, 160, 160),   # grey
    (8,  'kaolinite',         0,   160, 160),   # teal
    (9,  'ill-musc-lw-unspec',255, 120, 40 ),   # orange
    (10, 'ill-musc-lw',       220, 120, 0  ),   # dark orange
    (11, 'ill-musc-lw-hx',    100, 80,  220),   # blue-purple
    (12, 'ill-musc-lw-lx',    140, 100, 200),   # mid purple
    (13, 'phengite',          139, 69,  19 ),   # brown
    (14, 'Fe-chlt-unspec',    160, 200, 160),   # pale green
    (15, 'Fe-chlt-1',         0,   160, 0  ),   # green
    (16, 'Fe-chlt-2',         100, 200, 100),   # light green
    (17, 'chlt',              150, 0,   200),   # purple-violet
]

NAME_TO_ID = {m[1]: m[0] for m in MINERAL_CLASSES}
ID_TO_NAME = {m[0]: m[1] for m in MINERAL_CLASSES}
ID_TO_RGB  = {m[0]: (m[2], m[3], m[4]) for m in MINERAL_CLASSES}


# ---------------------------------------------------------------------------
# Decision tree
# ---------------------------------------------------------------------------

def classify_pixel(d1, w1, w2, ix):
    """
    Apply the dt_mineral_map decision tree to a single pixel.

    Follows Figure 2 exactly. In the diagram, horizontal (T) arrows point to
    mineral classes, and downward (F) arrows continue to the next node.
    The W1 thresholds increase going downward, so the cascade is equivalent
    to checking from the highest threshold first (descending order).

    Decision tree structure (descending W1 cascade):
      D1 <= 0.05                              -> aspectral
      D1 >  0.05:
        W1 >  2360                            -> chlt
        W1 in (2300, 2360]:
          W2 in (2340, 2400]                  -> other
          else                                -> Fe-chlt-2
        W1 in (2260, 2300]:
          W2 in (2340, 2400]                  -> Fe-chlt-unspec
          else                                -> Fe-chlt-1
        W1 in (2240, 2260]                    -> phengite
        W1 in (2220, 2240]:
          W2 in (2340, 2400]                  -> ill-musc-lw-unspec
          Ix > 3.25                           -> ill-musc-lw
          Ix > 2.0                            -> ill-musc-lw-hx
          else                                -> ill-musc-lw-lx
        W1 in (2210, 2220]:
          W2 in (2160, 2180]                  -> Ix sub-tree (ill-musc/hx/lx)
          else                                -> kaolinite
            Ix sub-tree: W2 in (2340, 2400]  -> ill-musc-unspec
                         Ix > 3.25           -> ill-musc
                         Ix > 2.0            -> ill-musc-hx
                         else                -> ill-musc-lx
        W1 in (2200, 2210]                    -> ill-musc-sw
        W1 <= 2200                            -> other

    Parameters
    ----------
    d1 : float  depth of deepest absorption feature, 2100-2400 nm (WoM-C Band 2)
    w1 : float  wavelength of deepest feature in nm               (WoM-C Band 1)
    w2 : float  wavelength of second deepest feature in nm        (WoM-C Band 3)
    ix : float  illite crystallinity = D1 / depth(1850-2100 nm)

    Returns
    -------
    int  mineral class id
    """

    def ix_classes(high_name, hx_name, lx_name):
        """Shared Ix sub-tree: Ix>3.25 → high_name, Ix>2.0 → hx_name, else → lx_name."""
        if ix > 3.25:
            return NAME_TO_ID[high_name]
        if ix > 2.0:
            return NAME_TO_ID[hx_name]
        return NAME_TO_ID[lx_name]

    # Root: spectral quality gate
    if d1 <= 0.05:
        return NAME_TO_ID['aspectral']

    # Descending W1 cascade (highest threshold first)

    if w1 > 2360:
        return NAME_TO_ID['chlt']

    if w1 > 2300:
        if 2340 < w2 <= 2400:
            return NAME_TO_ID['other']
        return NAME_TO_ID['Fe-chlt-2']

    if w1 > 2260:
        if 2340 < w2 <= 2400:
            return NAME_TO_ID['Fe-chlt-unspec']
        return NAME_TO_ID['Fe-chlt-1']

    if w1 > 2240:
        return NAME_TO_ID['phengite']

    if w1 > 2220:
        if 2340 < w2 <= 2400:
            return NAME_TO_ID['ill-musc-lw-unspec']
        return ix_classes('ill-musc-lw', 'ill-musc-lw-hx', 'ill-musc-lw-lx')

    if w1 > 2210:
        if 2160 < w2 <= 2180:
            if 2340 < w2 <= 2400:          # logically unreachable but matches diagram
                return NAME_TO_ID['ill-musc-unspec']
            return ix_classes('ill-musc', 'ill-musc-hx', 'ill-musc-lx')
        return NAME_TO_ID['kaolinite']

    if w1 > 2200:
        return NAME_TO_ID['ill-musc-sw']

    # W1 <= 2200 → other
    return NAME_TO_ID['other']


# Vectorised version for numpy array processing
_classify_vec = np.vectorize(classify_pixel)


# ---------------------------------------------------------------------------
# QGIS Processing Algorithm
# ---------------------------------------------------------------------------

class DtMineralMapAlgorithm(QgsProcessingAlgorithm):
    """
    DT Mineral Map Classification

    Applies the dt_mineral_map decision tree (Figure 2, Laukamp et al.) to
    classify hyperspectral pixels into illite/muscovite, kaolinite, chlorite,
    phengite and related mineral classes.
    """

    WOM_C         = 'WOM_C'
    WOM_B         = 'WOM_B'
    D1_THRESHOLD  = 'D1_THRESHOLD'
    OUTPUT_CLASS  = 'OUTPUT_CLASS'
    OUTPUT_RGB    = 'OUTPUT_RGB'

    def initAlgorithm(self, config=None):

        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_C,
            'WoM-C raster (2100-2400 nm) — from Workflow A'))

        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_B,
            'WoM-B raster (1850-2100 nm) — from Workflow A'))

        self.addParameter(QgsProcessingParameterNumber(
            self.D1_THRESHOLD,
            'D1 depth threshold (pixels <= threshold = aspectral)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.05, minValue=0.0, maxValue=1.0))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_CLASS, 'Output class raster'))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_RGB, 'Output RGB colour raster (optional)',
            optional=True, createByDefault=False))

    def processAlgorithm(self, parameters, context, feedback):

        wom_c_layer  = self.parameterAsRasterLayer(parameters, self.WOM_C, context)
        wom_b_layer  = self.parameterAsRasterLayer(parameters, self.WOM_B, context)
        d1_thresh    = self.parameterAsDouble(parameters, self.D1_THRESHOLD, context)
        out_class    = self.parameterAsOutputLayer(parameters, self.OUTPUT_CLASS, context)
        out_rgb      = self.parameterAsOutputLayer(parameters, self.OUTPUT_RGB, context) \
                       if self.OUTPUT_RGB in parameters and parameters[self.OUTPUT_RGB] else None

        # ---- Open rasters ---------------------------------------------------
        wom_c_ds = gdal.Open(wom_c_layer.source(), gdal.GA_ReadOnly)
        wom_b_ds = gdal.Open(wom_b_layer.source(), gdal.GA_ReadOnly)
        if wom_c_ds is None:
            raise QgsProcessingException('Cannot open WoM-C raster')
        if wom_b_ds is None:
            raise QgsProcessingException('Cannot open WoM-B raster')

        cols = wom_c_ds.RasterXSize
        rows = wom_c_ds.RasterYSize

        if wom_c_ds.RasterCount < 3:
            raise QgsProcessingException(
                f'WoM-C raster needs at least 3 bands (has {wom_c_ds.RasterCount}). '
                'Re-run Workflow A with Features >= 2.')
        if wom_b_ds.RasterCount < 2:
            raise QgsProcessingException(
                f'WoM-B raster needs at least 2 bands (has {wom_b_ds.RasterCount}). '
                'Re-run Workflow A with Features >= 1.')

        feedback.pushInfo('Reading WoM-C Band 1 — W1 (primary wavelength) ...')
        w1 = wom_c_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        feedback.pushInfo('Reading WoM-C Band 2 — D1 (feature depth) ...')
        d1 = wom_c_ds.GetRasterBand(2).ReadAsArray().astype(np.float32)
        feedback.pushInfo('Reading WoM-C Band 3 — W2 (second wavelength) ...')
        w2 = wom_c_ds.GetRasterBand(3).ReadAsArray().astype(np.float32)
        feedback.pushInfo('Reading WoM-B Band 2 — D_B (1850-2100 nm depth, Ix denominator) ...')
        d_b = wom_b_ds.GetRasterBand(2).ReadAsArray().astype(np.float32)

        # Compute Ix = D1 / D_B  (guard against div-by-zero)
        feedback.pushInfo('Computing Ix (illite crystallinity) = D1 / D_B ...')
        with np.errstate(divide='ignore', invalid='ignore'):
            ix = np.where(d_b > 0, d1 / d_b, 0.0).astype(np.float32)

        # ---- Diagnostics ----------------------------------------------------
        spectral_mask = d1 > d1_thresh
        n_spec = int(np.sum(spectral_mask))
        feedback.pushInfo('')
        feedback.pushInfo(f'Spectral pixels (D1 > {d1_thresh}): {n_spec} of {d1.size} ({100*n_spec/d1.size:.1f}%)')
        if n_spec > 0:
            feedback.pushInfo(f'  W1 : min={float(np.nanmin(w1[spectral_mask])):.1f}  '
                              f'max={float(np.nanmax(w1[spectral_mask])):.1f}  '
                              f'mean={float(np.nanmean(w1[spectral_mask])):.1f} nm')
            feedback.pushInfo(f'  D1 : min={float(np.nanmin(d1[spectral_mask])):.4f}  '
                              f'max={float(np.nanmax(d1[spectral_mask])):.4f}  '
                              f'mean={float(np.nanmean(d1[spectral_mask])):.4f}')
            feedback.pushInfo(f'  W2 : min={float(np.nanmin(w2[spectral_mask])):.1f}  '
                              f'max={float(np.nanmax(w2[spectral_mask])):.1f}  '
                              f'mean={float(np.nanmean(w2[spectral_mask])):.1f} nm')
            feedback.pushInfo(f'  Ix : min={float(np.nanmin(ix[spectral_mask])):.3f}  '
                              f'max={float(np.nanmax(ix[spectral_mask])):.3f}  '
                              f'mean={float(np.nanmean(ix[spectral_mask])):.3f}')
        feedback.pushInfo('')

        # ---- Apply decision tree --------------------------------------------
        feedback.pushInfo('Applying dt_mineral_map decision tree ...')
        feedback.setProgress(20)

        nodata_mask = np.isnan(w1) | np.isnan(d1) | np.isnan(w2)

        w1_s = np.nan_to_num(w1, nan=0.0)
        d1_s = np.nan_to_num(d1, nan=0.0)
        w2_s = np.nan_to_num(w2, nan=0.0)
        ix_s = np.nan_to_num(ix, nan=0.0)

        class_data = _classify_vec(d1_s, w1_s, w2_s, ix_s).astype(np.uint8)
        class_data[nodata_mask]   = 0
        class_data[w1_s == 0]     = 0

        feedback.setProgress(70)

        # ---- Classification summary -----------------------------------------
        feedback.pushInfo('Classification summary:')
        unique, counts = np.unique(class_data, return_counts=True)
        total = class_data.size
        for uid, cnt in zip(unique, counts):
            pct = 100.0 * cnt / total
            feedback.pushInfo(
                f'  {ID_TO_NAME.get(int(uid), "?"):22s}  '
                f'(id={uid:2d})  {cnt:8d} px  {pct:5.1f}%')
        feedback.pushInfo('')

        driver = gdal.GetDriverByName('GTiff')

        # ---- Write class raster ---------------------------------------------
        feedback.pushInfo('Writing integer class raster ...')
        ct = gdal.ColorTable()
        for mid, name, r, g, b in MINERAL_CLASSES:
            ct.SetColorEntry(mid, (r, g, b, 255))

        class_ds = driver.Create(out_class, cols, rows, 1, gdal.GDT_Byte,
                                 options=['COMPRESS=LZW', 'TILED=YES'])
        class_ds.SetGeoTransform(wom_c_ds.GetGeoTransform())
        class_ds.SetProjection(wom_c_ds.GetProjection())
        band = class_ds.GetRasterBand(1)
        band.SetNoDataValue(0)
        band.SetDescription('Mineral Class')
        band.SetRasterColorTable(ct)
        band.SetRasterColorInterpretation(gdal.GCI_PaletteIndex)
        band.WriteArray(class_data)
        band.FlushCache()

        # Raster Attribute Table
        rat = gdal.RasterAttributeTable()
        rat.CreateColumn('Value', gdal.GFT_Integer, gdal.GFU_MinMax)
        rat.CreateColumn('Class', gdal.GFT_String,  gdal.GFU_Name)
        rat.CreateColumn('R',     gdal.GFT_Integer, gdal.GFU_Red)
        rat.CreateColumn('G',     gdal.GFT_Integer, gdal.GFU_Green)
        rat.CreateColumn('B',     gdal.GFT_Integer, gdal.GFU_Blue)
        for row_idx, (mid, name, r, g, b) in enumerate(MINERAL_CLASSES):
            rat.SetValueAsInt   (row_idx, 0, mid)
            rat.SetValueAsString(row_idx, 1, name)
            rat.SetValueAsInt   (row_idx, 2, r)
            rat.SetValueAsInt   (row_idx, 3, g)
            rat.SetValueAsInt   (row_idx, 4, b)
        band.SetDefaultRAT(rat)
        class_ds = None

        feedback.setProgress(85)
        result = {self.OUTPUT_CLASS: out_class}

        # ---- Write RGB raster (optional) ------------------------------------
        if out_rgb:
            feedback.pushInfo('Writing RGB colour raster ...')
            rgb_r = np.zeros((rows, cols), dtype=np.uint8)
            rgb_g = np.zeros((rows, cols), dtype=np.uint8)
            rgb_b = np.zeros((rows, cols), dtype=np.uint8)
            for mid, name, r, g, b in MINERAL_CLASSES:
                mask = class_data == mid
                rgb_r[mask] = r
                rgb_g[mask] = g
                rgb_b[mask] = b
            rgb_ds = driver.Create(out_rgb, cols, rows, 3, gdal.GDT_Byte,
                                   options=['COMPRESS=LZW', 'TILED=YES'])
            rgb_ds.SetGeoTransform(wom_c_ds.GetGeoTransform())
            rgb_ds.SetProjection(wom_c_ds.GetProjection())
            for idx, (arr, lbl) in enumerate(
                    [(rgb_r, 'Red'), (rgb_g, 'Green'), (rgb_b, 'Blue')], start=1):
                bnd = rgb_ds.GetRasterBand(idx)
                bnd.WriteArray(arr)
                bnd.SetDescription(lbl)
                bnd.FlushCache()
            rgb_ds = None
            result[self.OUTPUT_RGB] = out_rgb

        wom_c_ds = None
        wom_b_ds = None

        feedback.setProgress(100)
        feedback.pushInfo('dt_mineral_map classification complete.')
        feedback.pushInfo('')
        feedback.pushInfo('Mineral Class Legend:')
        feedback.pushInfo(f'  {"ID":>3}  {"Name":<22}  {"R":>3} {"G":>3} {"B":>3}')
        for mid, name, r, g, b in MINERAL_CLASSES:
            feedback.pushInfo(f'  {mid:>3}  {name:<22}  {r:>3} {g:>3} {b:>3}')

        return result

    # -----------------------------------------------------------------------
    def name(self):        return 'dt_mineral_map'
    def displayName(self): return 'DT Mineral Map Classification'
    def group(self):       return '4 - Decision Tree Classification'
    def groupId(self):     return '4_decision_tree'

    def shortHelpString(self):
        class_list = '\n'.join(
            f'          <li><b>{m[1]}</b> (id={m[0]})</li>'
            for m in MINERAL_CLASSES if m[0] > 0)
        return f"""
        <b>DT Mineral Map Classification</b>

        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> WoM-C (2100–2400 nm, &ge;2 features) and WoM-B (1850–2100 nm, &ge;1 feature).<br/>
        Run <i>Workflow A</i> to generate both rasters.
        </p>

        <p>Implements the <i>dt_mineral_map</i> decision tree (Figure 2, Laukamp et al.)
        classifying pixels into illite/muscovite, kaolinite, chlorite, phengite
        and related mineral classes based on absorption feature position,
        secondary feature position, and illite crystallinity.</p>

        <p><b>Decision tree variables:</b></p>
        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Variable</th><th>Description</th><th>Source</th>
          </tr>
          <tr><td><b>D1</b></td><td>Depth of deepest absorption feature</td>
              <td>WoM-C Band 2</td></tr>
          <tr><td><b>W1</b></td><td>Wavelength of deepest feature (nm)</td>
              <td>WoM-C Band 1</td></tr>
          <tr><td><b>W2</b></td><td>Wavelength of second deepest feature (nm)</td>
              <td>WoM-C Band 3</td></tr>
          <tr><td><b>Ix</b></td><td>Illite crystallinity = D1 / depth(1850–2100 nm)</td>
              <td>WoM-C B2 / WoM-B B2</td></tr>
        </table>

        <p><b>Mineral classes produced:</b></p>
        <ul>
{class_list}
        </ul>

        <p><b>Abbreviations:</b> ill = illite, musc = muscovite, chlt = chlorite,
        unspec = unspecified, hx = high crystallinity, lx = low crystallinity,
        lw = long wavelength, sw = short wavelength.</p>

        <p><i>Decision tree after Laukamp et al. Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return DtMineralMapAlgorithm()
