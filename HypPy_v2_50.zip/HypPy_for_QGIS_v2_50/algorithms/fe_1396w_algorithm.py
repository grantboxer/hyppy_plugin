"""
Feature Extraction — 1396W  (Pyrophyllite OH Absorption)

Targets the single sharp OH absorption of pyrophyllite at ~1396 nm.

From GMEX pyrophyllite (AusSpec International 2005):
  ~1396 nm — OH stretch.
    GMEX annotation: "Single sharp absorption."
    Pyrophyllite shows a single OH band here, in contrast to kaolinite's
    diagnostic doublet at ~1400/1412 nm and dickite's doublet at
    ~1384/1418 nm.  The single-peak character and slightly shorter
    position (~1396 nm) distinguish pyrophyllite from the kandite group.

WoM range:  1380-1420 nm  (tightly focused on the single pyrophyllite peak)
Stretch:    1388-1406 nm  (resolves position vs kaolinite ~1400-1412 nm)

Note: This range overlaps with FE13-1400D (kaolinite doublet 1385-1430 nm)
and FE15-1384D (dickite doublet 1370-1435 nm).  This tool uses a narrower
range and tighter stretch to resolve the pyrophyllite single-peak character.
All three tools are useful together for kandite + pyrophyllite discrimination
from satellite data (atmospheric water vapour absorption typically masks
this region in airborne data).

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
)
import processing
import os


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with wavelength metadata.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""

BBL_NOTE = """
        <p style="background-color:#E3F2FD; padding:6px; border-left:4px solid #1976D2;">
        <b>Note — atmospheric water vapour absorption:</b><br/>
        The ~1400 nm region is strongly affected by atmospheric water vapour absorption
        in airborne hyperspectral data and is typically masked as a Bad Band
        (BBL = 0) in ENVI headers.  This tool is primarily useful with
        <b>satellite data</b> (EnMAP, PRISMA, Sentinel-2) where this region
        is accessible.  Enable BBL masking to skip masked bands automatically.
        </p>
"""


class Fe1396WAlgorithm(QgsProcessingAlgorithm):
    """Feature Extraction — 1396W (Pyrophyllite OH Absorption)."""

    INPUT         = 'INPUT'
    NUM_FEATURES  = 'NUM_FEATURES'
    OUTPUT_WOM    = 'OUTPUT_WOM'
    OUTPUT_MAP    = 'OUTPUT_MAP'
    LEGEND_OUTPUT = 'LEGEND_OUTPUT'

    WOM_START = 1380.0
    WOM_END   = 1420.0
    MAP_MIN   = 1388.0
    MAP_MAX   = 1406.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.15

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract (1-9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=1, minValue=1, maxValue=9))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_WOM,
            'Output WoM raster (1380-1420 nm)'))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_MAP,
            'Output Wavelength Map RGB (1388-1406 nm stretch)'))
        self.addParameter(QgsProcessingParameterFileDestination(
            self.LEGEND_OUTPUT,
            'Output Colour Legend (PNG)',
            fileFilter='PNG Files (*.png)',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        cube        = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n           = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        out_wom     = self.parameterAsOutputLayer(parameters, self.OUTPUT_WOM, context)
        out_map     = self.parameterAsOutputLayer(parameters, self.OUTPUT_MAP, context)
        legend_path = self.parameterAsFileOutput(parameters, self.LEGEND_OUTPUT, context)

        self._legend_path = None

        feedback.setProgress(5)
        feedback.pushInfo('Step 1/2  Wavelength of Minimum  1380-1420 nm ...')
        feedback.pushInfo('  (Pyrophyllite single OH absorption ~1396 nm)')
        feedback.pushInfo('  Single peak: pyrophyllite ~1396 nm')
        feedback.pushInfo('  Doublet:     kaolinite ~1400/1412 nm  |  dickite ~1384/1418 nm')
        wom_result = processing.run(
            'hyppy:wavelength_of_minimum',
            {
                'INPUT':            cube,
                'START_WAVELENGTH': self.WOM_START,
                'END_WAVELENGTH':   self.WOM_END,
                'MODE':             0,
                'NUM_FEATURES':     n,
                'BROAD':            False,
                'USE_BBL':          True,
                'OUTPUT':           out_wom,
            },
            context=context,
            feedback=feedback,
            is_child_algorithm=True,
        )
        if feedback.isCanceled():
            return {}

        wom_path = wom_result['OUTPUT']
        feedback.pushInfo(f'  WoM raster saved: {wom_path}')

        feedback.setProgress(50)
        feedback.pushInfo('Step 2/2  Wavelength Mapping  1388-1406 nm stretch ...')

        from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
        wma     = WavelengthMappingAlgorithm()
        palette = wma.create_rainbow_palette()

        map_path = wma._run_colour_mapping(
            wom_path, palette,
            self.MAP_MIN, self.MAP_MAX,
            self.DEPTH_MIN, self.DEPTH_MAX,
            out_map, feedback,
        )

        feedback.setProgress(88)
        feedback.pushInfo(f'  Wavelength map saved: {map_path}')

        if not legend_path:
            wom_dir     = os.path.dirname(wom_path)
            legend_path = os.path.join(wom_dir, '1396W_legend.png')
        try:
            saved = wma.create_legend(
                legend_path, palette,
                self.MAP_MIN, self.MAP_MAX,
                self.DEPTH_MIN, self.DEPTH_MAX,
                feedback,
            )
            if saved:
                self._legend_path = saved
                feedback.pushInfo(f'  Colour legend saved: {saved}')
        except Exception as e:
            feedback.pushWarning(f'Legend generation failed: {e}')

        feedback.setProgress(100)
        feedback.pushInfo('Feature Extraction 1396W complete.')

        return {
            self.OUTPUT_WOM:    wom_path,
            self.OUTPUT_MAP:    map_path,
            self.LEGEND_OUTPUT: self._legend_path or '',
        }

    def postProcessAlgorithm(self, context, feedback):
        if getattr(self, '_legend_path', None):
            from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
            WavelengthMappingAlgorithm()._show_legend_dock(self._legend_path, feedback)
        return {}

    def name(self):        return 'fe_1396w'
    def displayName(self): return 'FE18 - 1396W  (Pyrophyllite OH)'
    def group(self):       return '7 - Feature Extraction'
    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + BBL_NOTE + """
        <b>Feature Extraction — 1396W  (Pyrophyllite OH Absorption)</b>

        <p>Targets the single sharp OH absorption of pyrophyllite at <b>~1396 nm</b>,
        derived from the USGS GMEX pyrophyllite reference spectrum
        (AusSpec International 2005).</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>1380-1420 nm</b>.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>1388-1406 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>1380-1420 nm</td></tr>
          <tr><td>Colour stretch min</td><td>1388 nm</td></tr>
          <tr><td>Colour stretch max</td><td>1406 nm</td></tr>
          <tr><td>Default features</td><td>1 (single pyrophyllite peak)</td></tr>
          <tr><td>Depth max scale</td><td>0.15</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>~1396 nm OH character comparison (GMEX):</b></p>
        <ul>
          <li><b>Pyrophyllite</b> — single peak ~1396 nm; "Single sharp absorption"</li>
          <li><b>Kaolinite</b> — doublet ~1400/1412 nm (wider, longer wavelength)</li>
          <li><b>Dickite</b> — doublet ~1384/1418 nm (wider separation, shorter short-wave peak)</li>
        </ul>

        <p>The single-peak character at ~1396 nm and the absence of a longer-wavelength
        companion peak distinguishes pyrophyllite from the kandite group in satellite data.
        Pair with <b>FE17-2066D</b> (doublet) and <b>DT Pyrophyllite</b> for comprehensive
        pyrophyllite mapping.</p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength ~1396 nm, Band 2: depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, pyrophyllite entry
        (AusSpec International 2005). Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe1396WAlgorithm()
