"""
Feature Extraction — 2290W

WoM range 2270-2320 nm, wavelength map stretch 2279-2338 nm.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
)
import processing
import os


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with wavelength metadata.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""


class Fe2290WAlgorithm(QgsProcessingAlgorithm):
    """Feature Extraction — 2290W."""

    INPUT         = 'INPUT'
    NUM_FEATURES  = 'NUM_FEATURES'
    OUTPUT_WOM    = 'OUTPUT_WOM'
    OUTPUT_MAP    = 'OUTPUT_MAP'
    LEGEND_OUTPUT = 'LEGEND_OUTPUT'

    WOM_START = 2270.0
    WOM_END   = 2320.0
    MAP_MIN   = 2279.0
    MAP_MAX   = 2338.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract (1-9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=1, minValue=1, maxValue=9))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_WOM,
            'Output WoM raster (2270-2320 nm)'))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_MAP,
            'Output Wavelength Map RGB (2279-2338 nm stretch)'))
        self.addParameter(QgsProcessingParameterFileDestination(
            self.LEGEND_OUTPUT,
            'Output Colour Legend (PNG)',
            fileFilter='PNG Files (*.png)',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        cube        = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n           = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        out_wom     = self.parameterAsOutputLayer(parameters, self.OUTPUT_WOM, context)
        out_map     = self.parameterAsOutputLayer(parameters, self.OUTPUT_MAP, context)
        legend_path = self.parameterAsFileOutput(parameters, self.LEGEND_OUTPUT, context)

        self._legend_path = None

        # Step 1: Wavelength of Minimum 2270-2320 nm
        feedback.setProgress(5)
        feedback.pushInfo('Step 1/2  Wavelength of Minimum  2270-2320 nm ...')
        wom_result = processing.run(
            'hyppy:wavelength_of_minimum',
            {
                'INPUT':            cube,
                'START_WAVELENGTH': self.WOM_START,
                'END_WAVELENGTH':   self.WOM_END,
                'MODE':             0,
                'NUM_FEATURES':     n,
                'BROAD':            False,
                'USE_BBL':          True,
                'OUTPUT':           out_wom,
            },
            context=context,
            feedback=feedback,
            is_child_algorithm=True,
        )
        if feedback.isCanceled():
            return {}

        wom_path = wom_result['OUTPUT']
        feedback.pushInfo(f'  WoM raster saved: {wom_path}')

        # Step 2: Wavelength Mapping 2279-2338 nm
        feedback.setProgress(50)
        feedback.pushInfo('Step 2/2  Wavelength Mapping  2279-2338 nm stretch ...')

        from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
        wma     = WavelengthMappingAlgorithm()
        palette = wma.create_rainbow_palette()

        map_path = wma._run_colour_mapping(
            wom_path, palette,
            self.MAP_MIN, self.MAP_MAX,
            self.DEPTH_MIN, self.DEPTH_MAX,
            out_map, feedback,
        )

        feedback.setProgress(88)
        feedback.pushInfo(f'  Wavelength map saved: {map_path}')

        # Step 3: Legend - default filename is <tool_label>_legend.png
        # beside the WoM output so it is easy to find and clearly named.
        if not legend_path:
            wom_dir     = os.path.dirname(wom_path)
            legend_path = os.path.join(wom_dir, '2290W_legend.png')
        try:
            saved = wma.create_legend(
                legend_path, palette,
                self.MAP_MIN, self.MAP_MAX,
                self.DEPTH_MIN, self.DEPTH_MAX,
                feedback,
            )
            if saved:
                self._legend_path = saved
                feedback.pushInfo(f'  Colour legend saved: {saved}')
        except Exception as e:
            feedback.pushWarning(f'Legend generation failed: {e}')

        feedback.setProgress(100)
        feedback.pushInfo('Feature Extraction 2290W complete.')

        return {
            self.OUTPUT_WOM:    wom_path,
            self.OUTPUT_MAP:    map_path,
            self.LEGEND_OUTPUT: self._legend_path or '',
        }

    def postProcessAlgorithm(self, context, feedback):
        if getattr(self, '_legend_path', None):
            from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
            WavelengthMappingAlgorithm()._show_legend_dock(self._legend_path, feedback)
        return {}

    def name(self):        return 'fe_2290w'
    def displayName(self): return 'FE08 - 2290W'
    def group(self):       return '7 - Feature Extraction'
    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2290W</b>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>2270-2320 nm</b>.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>2279-2338 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>2270-2320 nm</td></tr>
          <tr><td>Colour stretch min</td><td>2279 nm</td></tr>
          <tr><td>Colour stretch max</td><td>2338 nm</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> - Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> - colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> - 2-D legend; auto-displayed as a floating panel.</li>
        </ul>
        """

    def createInstance(self): return Fe2290WAlgorithm()
