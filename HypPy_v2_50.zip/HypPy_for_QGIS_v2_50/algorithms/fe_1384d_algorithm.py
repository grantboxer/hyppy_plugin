"""
Feature Extraction — 1384D  (Dickite OH Doublet)

Targets the dickite OH stretch doublet at ~1384 and ~1418 nm.

From GMEX dickite (USGS Spectral Library):
  ~1384 + 1418 nm — "Diagnostic doublet. Note difference in wavelengths
  and intensities relative to Kaolinite and Halloysite."
  "Dickites may not always display as intense absorptions for the doublets,
  especially that around 1400nm."

  Compared to kaolinite (~1400/1412 nm):
    - Dickite shorter-wave peak shifts to ~1384 nm  (kaolinite ~1400 nm)
    - Dickite longer-wave peak shifts to ~1418 nm   (kaolinite ~1412 nm)
    - Intensity ratio differs: the ~1384 nm peak is typically stronger
      relative to the ~1418 nm peak in dickite vs kaolinite

WoM range:  1370-1435 nm  (captures both doublet peaks for dickite)
Stretch:    1378-1425 nm  (wider than kaolinite 1400D to resolve ~1384 nm)

Note: The 1400 nm region overlaps with atmospheric water vapour absorption.
In airborne data this region may be masked by BBL.  In well-corrected
satellite data (EnMAP, PRISMA) the doublet is often resolvable.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
)
import processing
import os


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with wavelength metadata.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""

WATER_NOTE = """        <p style="background-color:#e8f4fd; padding:6px; border-left:4px solid #1565c0;">
        <b>Note:</b> The ~1384-1418 nm region falls within or adjacent to the atmospheric
        water vapour absorption band. In airborne data it is typically masked by BBL.
        In satellite data with good atmospheric correction (EnMAP, PRISMA) the doublet
        is often resolvable. If BBL masking is active this tool may return no valid
        pixels in this range.
        </p>
"""


class Fe1384DAlgorithm(QgsProcessingAlgorithm):
    """Feature Extraction — 1384D (Dickite OH Doublet)."""

    INPUT         = 'INPUT'
    NUM_FEATURES  = 'NUM_FEATURES'
    OUTPUT_WOM    = 'OUTPUT_WOM'
    OUTPUT_MAP    = 'OUTPUT_MAP'
    LEGEND_OUTPUT = 'LEGEND_OUTPUT'

    WOM_START = 1370.0
    WOM_END   = 1435.0
    MAP_MIN   = 1378.0
    MAP_MAX   = 1425.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.15

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract (1-9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=2, minValue=1, maxValue=9))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_WOM,
            'Output WoM raster (1370-1435 nm)'))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_MAP,
            'Output Wavelength Map RGB (1378-1425 nm stretch)'))
        self.addParameter(QgsProcessingParameterFileDestination(
            self.LEGEND_OUTPUT,
            'Output Colour Legend (PNG)',
            fileFilter='PNG Files (*.png)',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        cube        = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n           = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        out_wom     = self.parameterAsOutputLayer(parameters, self.OUTPUT_WOM, context)
        out_map     = self.parameterAsOutputLayer(parameters, self.OUTPUT_MAP, context)
        legend_path = self.parameterAsFileOutput(parameters, self.LEGEND_OUTPUT, context)

        self._legend_path = None

        # Step 1: Wavelength of Minimum 1370-1435 nm
        feedback.setProgress(5)
        feedback.pushInfo('Step 1/2  Wavelength of Minimum  1370-1435 nm ...')
        feedback.pushInfo('  (Dickite OH doublet ~1384/1418 nm — different from kaolinite ~1400/1412 nm)')
        feedback.pushInfo('  Note: BBL masking active — atmospheric water band may exclude this region.')
        wom_result = processing.run(
            'hyppy:wavelength_of_minimum',
            {
                'INPUT':            cube,
                'START_WAVELENGTH': self.WOM_START,
                'END_WAVELENGTH':   self.WOM_END,
                'MODE':             0,
                'NUM_FEATURES':     n,
                'BROAD':            False,
                'USE_BBL':          True,
                'OUTPUT':           out_wom,
            },
            context=context,
            feedback=feedback,
            is_child_algorithm=True,
        )
        if feedback.isCanceled():
            return {}

        wom_path = wom_result['OUTPUT']
        feedback.pushInfo(f'  WoM raster saved: {wom_path}')

        # Step 2: Wavelength Mapping 1378-1425 nm
        feedback.setProgress(50)
        feedback.pushInfo('Step 2/2  Wavelength Mapping  1378-1425 nm stretch ...')
        feedback.pushInfo('  Blue = ~1378 nm (dickite shorter peak)  Red = ~1425 nm (longer peak)')

        from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
        wma     = WavelengthMappingAlgorithm()
        palette = wma.create_rainbow_palette()

        map_path = wma._run_colour_mapping(
            wom_path, palette,
            self.MAP_MIN, self.MAP_MAX,
            self.DEPTH_MIN, self.DEPTH_MAX,
            out_map, feedback,
        )

        feedback.setProgress(88)
        feedback.pushInfo(f'  Wavelength map saved: {map_path}')

        # Step 3: Legend
        if not legend_path:
            wom_dir     = os.path.dirname(wom_path)
            legend_path = os.path.join(wom_dir, '1384D_legend.png')
        try:
            saved = wma.create_legend(
                legend_path, palette,
                self.MAP_MIN, self.MAP_MAX,
                self.DEPTH_MIN, self.DEPTH_MAX,
                feedback,
            )
            if saved:
                self._legend_path = saved
                feedback.pushInfo(f'  Colour legend saved: {saved}')
        except Exception as e:
            feedback.pushWarning(f'Legend generation failed: {e}')

        feedback.setProgress(100)
        feedback.pushInfo('Feature Extraction 1384D complete.')

        return {
            self.OUTPUT_WOM:    wom_path,
            self.OUTPUT_MAP:    map_path,
            self.LEGEND_OUTPUT: self._legend_path or '',
        }

    def postProcessAlgorithm(self, context, feedback):
        if getattr(self, '_legend_path', None):
            from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
            WavelengthMappingAlgorithm()._show_legend_dock(self._legend_path, feedback)
        return {}

    def name(self):        return 'fe_1384d'
    def displayName(self): return 'FE15 - 1384D  (Dickite OH Doublet)'
    def group(self):       return '7 - Feature Extraction'
    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + WATER_NOTE + """
        <b>Feature Extraction — 1384D  (Dickite OH Doublet)</b>

        <p>Targets the dickite OH stretch doublet at <b>~1384 and ~1418 nm</b>,
        derived from the USGS GMEX dickite reference spectrum.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>1370-1435 nm</b>
              (wider range than kaolinite 1400D to capture ~1384 nm short-wave peak).</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>1378-1425 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>1370-1435 nm</td></tr>
          <tr><td>Colour stretch min</td><td>1378 nm (dickite short-wave peak)</td></tr>
          <tr><td>Colour stretch max</td><td>1425 nm (dickite long-wave peak)</td></tr>
          <tr><td>Default features</td><td>2 (to detect both doublet peaks)</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>GMEX dickite — 1384D doublet characteristics:</b></p>
        <ul>
          <li><b>"Diagnostic doublet. Note difference in wavelengths and intensities
              relative to Kaolinite and Halloysite."</b></li>
          <li><b>"Dickites may not always display as intense absorptions for the doublets,
              especially that around 1400 nm."</b></li>
          <li>Shorter-wave peak at <b>~1384 nm</b> (kaolinite at ~1400 nm — 16 nm shorter)</li>
          <li>Longer-wave peak at <b>~1418 nm</b> (kaolinite at ~1412 nm — 6 nm longer)</li>
          <li>Total doublet separation (~34 nm) wider than kaolinite (~12 nm)</li>
        </ul>

        <p><b>Kaolin-group mineral discrimination using 1400 nm region doublets:</b></p>
        <ul>
          <li><b>Dickite</b>  — doublet at ~1384 + 1418 nm, wider separation</li>
          <li><b>Kaolinite</b> — doublet at ~1400 + 1412 nm, narrower separation</li>
          <li><b>Halloysite</b> — doublet weakened or absent due to interlayer water</li>
        </ul>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, dickite entry.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe1384DAlgorithm()
