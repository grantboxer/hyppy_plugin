"""
Feature Extraction — 2206W  (Kaolinite Primary Al-OH)

Targets the primary Al-OH absorption of kaolinite at ~2206 nm.

From GMEX kaolinite2 (USGS Spectral Library):
  ~2206 nm — deepest absorption; the main diagnostic feature of kaolinite.
  The 2162/2206 doublet is characteristic of kaolinite spectra.
  Variations in crystallinity shift and broaden this feature.
  Wavelength distinguishes kaolinite (~2206 nm) from illite (~2200 nm)
  and smectite (~2207-2210 nm).

WoM range:  2162-2245 nm  (captures the full 2162/2206 doublet)
Stretch:    2197-2215 nm  (resolves kaolinite vs illite vs smectite)

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
)
import processing
import os


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with wavelength metadata.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""


class Fe2206WAlgorithm(QgsProcessingAlgorithm):
    """Feature Extraction — 2206W (Kaolinite Primary Al-OH)."""

    INPUT         = 'INPUT'
    NUM_FEATURES  = 'NUM_FEATURES'
    OUTPUT_WOM    = 'OUTPUT_WOM'
    OUTPUT_MAP    = 'OUTPUT_MAP'
    LEGEND_OUTPUT = 'LEGEND_OUTPUT'

    WOM_START = 2162.0
    WOM_END   = 2245.0
    MAP_MIN   = 2197.0
    MAP_MAX   = 2215.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract (1-9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=1, minValue=1, maxValue=9))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_WOM,
            'Output WoM raster (2162-2245 nm)'))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_MAP,
            'Output Wavelength Map RGB (2197-2215 nm stretch)'))
        self.addParameter(QgsProcessingParameterFileDestination(
            self.LEGEND_OUTPUT,
            'Output Colour Legend (PNG)',
            fileFilter='PNG Files (*.png)',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        cube        = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n           = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        out_wom     = self.parameterAsOutputLayer(parameters, self.OUTPUT_WOM, context)
        out_map     = self.parameterAsOutputLayer(parameters, self.OUTPUT_MAP, context)
        legend_path = self.parameterAsFileOutput(parameters, self.LEGEND_OUTPUT, context)

        self._legend_path = None

        # Step 1: Wavelength of Minimum 2162-2245 nm
        feedback.setProgress(5)
        feedback.pushInfo('Step 1/2  Wavelength of Minimum  2162-2245 nm ...')
        feedback.pushInfo('  (Kaolinite 2162/2206 nm doublet region)')
        wom_result = processing.run(
            'hyppy:wavelength_of_minimum',
            {
                'INPUT':            cube,
                'START_WAVELENGTH': self.WOM_START,
                'END_WAVELENGTH':   self.WOM_END,
                'MODE':             0,
                'NUM_FEATURES':     n,
                'BROAD':            False,
                'USE_BBL':          True,
                'OUTPUT':           out_wom,
            },
            context=context,
            feedback=feedback,
            is_child_algorithm=True,
        )
        if feedback.isCanceled():
            return {}

        wom_path = wom_result['OUTPUT']
        feedback.pushInfo(f'  WoM raster saved: {wom_path}')

        # Step 2: Wavelength Mapping 2197-2215 nm
        feedback.setProgress(50)
        feedback.pushInfo('Step 2/2  Wavelength Mapping  2197-2215 nm stretch ...')
        feedback.pushInfo('  Blue = kaolinite (~2197 nm)  Red = smectite/shifted (~2215 nm)')

        from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
        wma     = WavelengthMappingAlgorithm()
        palette = wma.create_rainbow_palette()

        map_path = wma._run_colour_mapping(
            wom_path, palette,
            self.MAP_MIN, self.MAP_MAX,
            self.DEPTH_MIN, self.DEPTH_MAX,
            out_map, feedback,
        )

        feedback.setProgress(88)
        feedback.pushInfo(f'  Wavelength map saved: {map_path}')

        # Step 3: Legend
        if not legend_path:
            wom_dir     = os.path.dirname(wom_path)
            legend_path = os.path.join(wom_dir, '2206W_legend.png')
        try:
            saved = wma.create_legend(
                legend_path, palette,
                self.MAP_MIN, self.MAP_MAX,
                self.DEPTH_MIN, self.DEPTH_MAX,
                feedback,
            )
            if saved:
                self._legend_path = saved
                feedback.pushInfo(f'  Colour legend saved: {saved}')
        except Exception as e:
            feedback.pushWarning(f'Legend generation failed: {e}')

        feedback.setProgress(100)
        feedback.pushInfo('Feature Extraction 2206W complete.')

        return {
            self.OUTPUT_WOM:    wom_path,
            self.OUTPUT_MAP:    map_path,
            self.LEGEND_OUTPUT: self._legend_path or '',
        }

    def postProcessAlgorithm(self, context, feedback):
        if getattr(self, '_legend_path', None):
            from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
            WavelengthMappingAlgorithm()._show_legend_dock(self._legend_path, feedback)
        return {}

    def name(self):        return 'fe_2206w'
    def displayName(self): return 'FE12 - 2206W  (Kaolinite Al-OH)'
    def group(self):       return '7 - Feature Extraction'
    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2206W  (Kaolinite Primary Al-OH)</b>

        <p>Targets the primary diagnostic absorption of kaolinite at <b>~2206 nm</b>
        derived from the USGS GMEX kaolinite2 reference spectrum.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>2162-2245 nm</b>
              (the full kaolinite 2162/2206 doublet region).</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>2197-2215 nm</b>
              to resolve kaolinite from illite and smectite.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>2162-2245 nm</td></tr>
          <tr><td>Colour stretch min</td><td>2197 nm (kaolinite)</td></tr>
          <tr><td>Colour stretch max</td><td>2215 nm (smectite / shifted)</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue = kaolinite, Red = shifted)</td></tr>
        </table>

        <p><b>GMEX kaolinite2 diagnostic features (USGS Spectral Library):</b></p>
        <ul>
          <li>~1400 + 1412 nm — OH stretch doublet (crystallinity indicator)</li>
          <li>~1830 nm — H₂O/OH (present in highly crystalline kaolinites)</li>
          <li>~2162 nm — Al-OH combination shoulder</li>
          <li><b>~2206 nm — Primary Al-OH (deepest, main diagnostic)</b></li>
          <li>~2312, ~2350, ~2380 nm — weaker Al-OH features</li>
        </ul>

        <p><b>Mineral discrimination (colour stretch 2197-2215 nm):</b></p>
        <ul>
          <li><b>Blue (~2197-2203 nm)</b> — well-ordered kaolinite</li>
          <li><b>Green (~2203-2207 nm)</b> — kaolinite / mixed</li>
          <li><b>Yellow-Red (~2207-2215 nm)</b> — smectite or disordered kaolinite</li>
        </ul>

        <p><i>Use FE12 together with FE5-2160D to compute the kaolinite crystallinity
        index (DT-Kaol-Cryst tool). See also dt_ill_kaol for illite/kaolinite
        discrimination.</i></p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, kaolinite2 entry.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe2206WAlgorithm()
