"""
Feature Extraction — 2178D  (Dickite Al-OH Shoulder)

Targets the Al-OH combination shoulder of dickite at ~2178 nm.

From GMEX dickite (USGS Spectral Library):
  ~2178 nm — "Diagnostic doublet. Note difference in wavelength position
  and intensity of 2178 nm absorption relative to kaolinite."
  "This absorption persists in mixed spectra."

  Dickite's 2178 nm feature is shifted to LONGER wavelengths compared to
  kaolinite's ~2162 nm shoulder.  This ~16 nm shift is the primary
  spectral discriminator between the two minerals in the 2100-2250 nm
  region.

  The 2178/2206 nm pair in dickite corresponds to the 2162/2206 nm pair
  in kaolinite — same fundamental Al-OH doublet structure but shifted.

WoM range:  2155-2196 nm  (isolates the 2178 nm dickite feature,
                            excluding the longer-wave 2206 nm peak)
Stretch:    2168-2190 nm  (resolves dickite ~2178 nm from kaolinite ~2162 nm)

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
)
import processing
import os


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with wavelength metadata.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""


class Fe2178DAlgorithm(QgsProcessingAlgorithm):
    """Feature Extraction — 2178D (Dickite Al-OH Shoulder)."""

    INPUT         = 'INPUT'
    NUM_FEATURES  = 'NUM_FEATURES'
    OUTPUT_WOM    = 'OUTPUT_WOM'
    OUTPUT_MAP    = 'OUTPUT_MAP'
    LEGEND_OUTPUT = 'LEGEND_OUTPUT'

    WOM_START = 2155.0
    WOM_END   = 2196.0
    MAP_MIN   = 2168.0
    MAP_MAX   = 2190.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.2

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract (1-9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=1, minValue=1, maxValue=9))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_WOM,
            'Output WoM raster (2155-2196 nm)'))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_MAP,
            'Output Wavelength Map RGB (2168-2190 nm stretch)'))
        self.addParameter(QgsProcessingParameterFileDestination(
            self.LEGEND_OUTPUT,
            'Output Colour Legend (PNG)',
            fileFilter='PNG Files (*.png)',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        cube        = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n           = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        out_wom     = self.parameterAsOutputLayer(parameters, self.OUTPUT_WOM, context)
        out_map     = self.parameterAsOutputLayer(parameters, self.OUTPUT_MAP, context)
        legend_path = self.parameterAsFileOutput(parameters, self.LEGEND_OUTPUT, context)

        self._legend_path = None

        # Step 1: Wavelength of Minimum 2155-2196 nm
        feedback.setProgress(5)
        feedback.pushInfo('Step 1/2  Wavelength of Minimum  2155-2196 nm ...')
        feedback.pushInfo('  (Dickite 2178 nm Al-OH shoulder — key discriminator vs kaolinite 2162 nm)')
        wom_result = processing.run(
            'hyppy:wavelength_of_minimum',
            {
                'INPUT':            cube,
                'START_WAVELENGTH': self.WOM_START,
                'END_WAVELENGTH':   self.WOM_END,
                'MODE':             0,
                'NUM_FEATURES':     n,
                'BROAD':            False,
                'USE_BBL':          True,
                'OUTPUT':           out_wom,
            },
            context=context,
            feedback=feedback,
            is_child_algorithm=True,
        )
        if feedback.isCanceled():
            return {}

        wom_path = wom_result['OUTPUT']
        feedback.pushInfo(f'  WoM raster saved: {wom_path}')

        # Step 2: Wavelength Mapping 2168-2190 nm
        feedback.setProgress(50)
        feedback.pushInfo('Step 2/2  Wavelength Mapping  2168-2190 nm stretch ...')
        feedback.pushInfo('  Blue = kaolinite shoulder (~2162 nm)  Red = dickite shoulder (~2178 nm)')

        from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
        wma     = WavelengthMappingAlgorithm()
        palette = wma.create_rainbow_palette()

        map_path = wma._run_colour_mapping(
            wom_path, palette,
            self.MAP_MIN, self.MAP_MAX,
            self.DEPTH_MIN, self.DEPTH_MAX,
            out_map, feedback,
        )

        feedback.setProgress(88)
        feedback.pushInfo(f'  Wavelength map saved: {map_path}')

        # Step 3: Legend
        if not legend_path:
            wom_dir     = os.path.dirname(wom_path)
            legend_path = os.path.join(wom_dir, '2178D_legend.png')
        try:
            saved = wma.create_legend(
                legend_path, palette,
                self.MAP_MIN, self.MAP_MAX,
                self.DEPTH_MIN, self.DEPTH_MAX,
                feedback,
            )
            if saved:
                self._legend_path = saved
                feedback.pushInfo(f'  Colour legend saved: {saved}')
        except Exception as e:
            feedback.pushWarning(f'Legend generation failed: {e}')

        feedback.setProgress(100)
        feedback.pushInfo('Feature Extraction 2178D complete.')

        return {
            self.OUTPUT_WOM:    wom_path,
            self.OUTPUT_MAP:    map_path,
            self.LEGEND_OUTPUT: self._legend_path or '',
        }

    def postProcessAlgorithm(self, context, feedback):
        if getattr(self, '_legend_path', None):
            from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
            WavelengthMappingAlgorithm()._show_legend_dock(self._legend_path, feedback)
        return {}

    def name(self):        return 'fe_2178d'
    def displayName(self): return 'FE14 - 2178D  (Dickite Al-OH Shoulder)'
    def group(self):       return '7 - Feature Extraction'
    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 2178D  (Dickite Al-OH Shoulder)</b>

        <p>Targets the Al-OH combination shoulder of dickite at <b>~2178 nm</b>,
        derived from the USGS GMEX dickite reference spectrum.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>2155-2196 nm</b>
              (isolates the 2178 nm dickite feature).</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>2168-2190 nm</b>
              to separate dickite from kaolinite.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>2155-2196 nm</td></tr>
          <tr><td>Colour stretch min</td><td>2168 nm (kaolinite-side)</td></tr>
          <tr><td>Colour stretch max</td><td>2190 nm (dickite-side)</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue = kaolinite, Red = dickite)</td></tr>
        </table>

        <p><b>GMEX dickite — 2178D diagnostic notes:</b></p>
        <ul>
          <li><b>"Diagnostic doublet. Note difference in wavelength position and
              intensity of 2178 nm absorption relative to kaolinite."</b></li>
          <li><b>"This absorption persists in mixed spectra"</b> — useful even
              in kaolinite/dickite mixtures.</li>
          <li>Dickite shoulder at ~2178 nm vs kaolinite shoulder at ~2162 nm —
              a ~16 nm shift that is the primary 2100-2250 nm discriminator.</li>
        </ul>

        <p><b>Kaolin-group mineral discrimination (2168-2190 nm stretch):</b></p>
        <ul>
          <li><b>Blue (~2168-2172 nm)</b> — kaolinite-dominant</li>
          <li><b>Green (~2172-2181 nm)</b> — mixed / transitional</li>
          <li><b>Red (~2181-2190 nm)</b> — dickite-dominant</li>
        </ul>

        <p><i>Use FE14 together with FE5-2160D and FE12-2206W to run the
        DT Dick-Kaol Classification for dickite vs kaolinite mapping.</i></p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, dickite entry.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe2178DAlgorithm()
