"""
HypPy for QGIS — Main Plugin Class

Registers the Processing provider and creates a toolbar with:
  - HypPy dropdown menu button listing all algorithms in hierarchical submenus
    (the Spectrum Viewer toggle lives inside Spectral Processing Tools)

Each leaf algorithm item calls processing.execAlgorithmDialog() with the
correct fully-qualified algorithm ID  (provider_id:algorithm_name).
The Spectrum Viewer item is a checkable QAction that toggles the dock.

Copyright (C) 2025 Grant Boxer
Original HyPy Copyright (C) 2010-2022 Wim Bakker, University of Twente
GPL v3 or later.
"""

import os
from qgis.PyQt.QtCore    import Qt
from qgis.PyQt.QtGui     import QIcon, QFont
from qgis.PyQt.QtWidgets import (
    QAction, QToolBar, QToolButton, QMenu
)

from .core.qt_compat import Enums as E
from qgis.core import QgsApplication

from .hyppy_provider import HyppyProvider


# ── Sentinel for the Spectrum Viewer toggle entry ─────────────────────────────
# Used in _MENU_STRUCTURE so _populate_menu can create the checkable action.
_SPECTRUM_VIEWER = '__spectrum_viewer__'


# ── Menu structure ─────────────────────────────────────────────────────────────
#
# Each element is one of:
#   None                              → separator
#   (label, 'provider:alg_id')        → leaf algorithm item
#   (label, _SPECTRUM_VIEWER)         → Spectrum Viewer toggle (checkable)
#   (label, [ … ])                    → submenu
# ──────────────────────────────────────────────────────────────────────────────

_MENU_STRUCTURE = [

    # ── 1 · Workflow Guide ─────────────────────────────────────────────────
    ('Workflow Guide', [
        ('Open Workflow Guide',                 'hyppy:getting_started'),
    ]),

    None,

    # ── 2 · Data Import ────────────────────────────────────────────────────
    ('Data Import', [
        ('Build Overviews (Fast Display)',       'hyppy:build_overviews'),
        ('Subset',                              'hyppy:subset'),
    ]),

    None,

    # ── 3 · Generate WoM Rasters ──────────────────────────────────────────
    ('Generate WoM Rasters', [
        ('Generate All Three WoM Rasters',      'hyppy:generate_all_wom'),
        None,
        ('Generate WoM-A  (750–1300 nm)',       'hyppy:generate_wom_a'),
        ('Generate WoM-B  (1850–2100 nm)',      'hyppy:generate_wom_b'),
        ('Generate WoM-C  (2100–2400 nm)',      'hyppy:generate_wom_c'),
        None,
        ('Wavelength of Minimum (custom range)','hyppy:wavelength_of_minimum'),
        ('Wavelength Mapping',                  'hyppy:wavelength_mapping'),
    ]),

    None,

    # ── 4 · Decision Tree Classifiers ─────────────────────────────────────
    ('Decision Tree Classifiers', [
        ('DT Mineral Map (full pipeline)',      'hyppy:dt_mineral_map'),
        None,
        ('DT 2100–2400 Mineral',               'hyppy:dt_2100_2400'),
        ('DT Albedo',                           'hyppy:dt_albedo'),
        ('DT Fedrop  (Fe drop)',                'hyppy:dt_fedrop'),
        ('DT Illcryst  (Illite crystallinity)', 'hyppy:dt_illcryst'),
        ('DT Ill-Kaol  (Illite / Kaolinite)',   'hyppy:dt_ill_kaol'),
        ('DT Kaol-Cryst  (Kaolinite cryst.)',   'hyppy:dt_kaol_cryst'),
        ('DT Dick-Kaol  (Dickite / Kaolinite)', 'hyppy:dt_dick_kaol'),
        ('DT Kandite  (Kaolin group)',           'hyppy:dt_kandite'),
        ('DT Pyrophyllite',                     'hyppy:dt_pyrophyllite'),
    ]),

    None,

    # ── 5 · SAM Classifier ────────────────────────────────────────────────
    ('SAM Classifier', [
        ('Spectral Angle Mapper (SAM)',         'hyppy:sam'),
    ]),

    None,

    # ── 6 · Spectral Processing Tools ─────────────────────────────────────
    ('Spectral Processing Tools', [
        ('Spectrum Viewer',                     _SPECTRUM_VIEWER),
        None,
        ('Convex Hull Removal',                 'hyppy:convexhullremoval'),
        ('Band Ratio',                          'hyppy:bandratio'),
        ('Band Ratios  (Sequential)',           'hyppy:bandratios'),
        ('Band Depths',                         'hyppy:banddepths'),
        ('Band Math',                           'hyppy:bandmathfull'),
        ('Spectra Math',                        'hyppy:spectramathfull'),
        ('Log Residuals',                       'hyppy:logresiduals'),
        ('Zonal Statistics',                    'hyppy:zonal_statistics'),
    ]),

    None,

    # ── 7 · Feature Extraction Tools ──────────────────────────────────────
    ('Feature Extraction Tools', [
        ('FE00 - Run All Feature Extractions',  'hyppy:fe_all'),
        None,
        ('FE01 - 1480W  (Carbonate / Chlorite)','hyppy:fe_1480w'),
        ('FE02 - 1550W  (Carbonate)',            'hyppy:fe_1550w'),
        ('FE03 - 1760W  (Carbonate)',            'hyppy:fe_1760w'),
        ('FE04 - 2080D  (Carbonate doublet)',    'hyppy:fe_2080d'),
        ('FE05 - 2160D  (Al-OH / Pyrophyllite)','hyppy:fe_2160d'),
        ('FE06 - 2200W  (Al-OH / Kaolinite)',   'hyppy:fe_2200w'),
        ('FE07 - 2250W  (Fe-OH / Chlorite)',    'hyppy:fe_2250w'),
        ('FE08 - 2290W  (Mg-OH / Chlorite)',    'hyppy:fe_2290w'),
        ('FE09 - 2320W  (Mg-OH / Chlorite)',    'hyppy:fe_2320w'),
        ('FE10 - 2350W  (Mg-OH / Amphibole)',   'hyppy:fe_2350w'),
        ('FE11 - 2390W  (Mg-OH / Talc)',        'hyppy:fe_2390w'),
        None,
        ('FE12 - 2206W  (Kaolinite Al-OH)',     'hyppy:fe_2206w'),
        ('FE13 - 1400D  (Kaolinite OH doublet)','hyppy:fe_1400d'),
        ('FE14 - 2178D  (Dickite Al-OH)',        'hyppy:fe_2178d'),
        ('FE15 - 1384D  (Dickite OH doublet)',   'hyppy:fe_1384d'),
        ('FE16 - 1900W  (Halloysite H2O)',       'hyppy:fe_1900w'),
        ('FE17 - 2066D  (Pyrophyllite doublet)', 'hyppy:fe_2066d'),
        ('FE18 - 1396W  (Pyrophyllite OH)',      'hyppy:fe_1396w'),
        None,
        ('FE-REE - Neodymium VNIR',             'hyppy:fe_ree_nd'),
    ]),

    None,

    # ── 8 · Convert Tools ─────────────────────────────────────────────────
    ('Convert Tools', [
        ('Convert Image to ENVI',               'hyppy:convert_image_to_envi'),
        ('Convert EOS HDF to ENVI',             'hyppy:convert_eos_hdf'),
        ('Convert ASTER HDF to ENVI',           'hyppy:convert_aster_hdf'),
        ('Convert EMIT L2A to ENVI',            'hyppy:convert_emit_l2a'),
    ]),
]


class HyperspectralPlugin:
    """QGIS Plugin Implementation for HypPy for QGIS."""

    def __init__(self, iface):
        self.iface      = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.provider   = None
        self._dock      = None
        self._toolbar   = None
        self._act_viewer = None   # checkable menu action for the Spectrum Viewer

    # ── Processing provider ───────────────────────────────────────────────────

    def initProcessing(self):
        self.provider = HyppyProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    # ── GUI ───────────────────────────────────────────────────────────────────

    def initGui(self):
        self.initProcessing()

        # Spectrum Viewer dock
        try:
            from .ui.spectrum_viewer_dock import SpectrumViewerDock
            self._dock = SpectrumViewerDock(self.iface)
            self.iface.mainWindow().addDockWidget(
                E.RightDockWidgetArea, self._dock)
            self._dock.hide()
        except Exception as e:
            self.iface.messageBar().pushWarning(
                'HypPy', f'Spectrum Viewer could not be loaded: {e}')

        # Toolbar — single HypPy menu button, no separate Viewer button
        self._toolbar = QToolBar('HypPy', self.iface.mainWindow())
        self._toolbar.setObjectName('HyppyToolbar')
        self.iface.mainWindow().addToolBar(self._toolbar)

        icon_path = os.path.join(self.plugin_dir, 'icon.svg')
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        # ── Single HypPy dropdown menu button ────────────────────────────
        self._menu_btn = QToolButton()
        self._menu_btn.setIcon(icon)
        self._menu_btn.setText(' HypPy ')
        self._menu_btn.setToolTip('Run HypPy algorithms')
        self._menu_btn.setToolButtonStyle(E.ToolButtonTextBesideIcon)
        self._menu_btn.setPopupMode(E.ToolButtonInstantPopup)
        # Build menu now (creates self._act_viewer as a side effect)
        self._menu_btn.setMenu(self._build_menu())
        self._toolbar.addWidget(self._menu_btn)

        # Keep the Spectrum Viewer menu item checked state in sync with the dock
        if self._dock and self._act_viewer:
            self._dock.visibilityChanged.connect(self._act_viewer.setChecked)

    # ── Menu construction ─────────────────────────────────────────────────────

    def _build_menu(self):
        """Build the root dropdown menu with hierarchical submenus."""
        root = QMenu(self.iface.mainWindow())
        self._populate_menu(root, _MENU_STRUCTURE)
        return root

    def _populate_menu(self, menu, items):
        """
        Recursively populate *menu* from *items*.

        items is a list of:
          None                          -> separator
          (label, alg_id_str)           -> leaf algorithm action
          (label, _SPECTRUM_VIEWER)     -> checkable Spectrum Viewer toggle
          (label, list)                 -> submenu
        """
        for item in items:
            if item is None:
                menu.addSeparator()

            elif isinstance(item, tuple):
                label, target = item

                if isinstance(target, list):
                    # ── Submenu ──────────────────────────────────────────
                    sub = QMenu(label, menu)
                    self._populate_menu(sub, target)
                    menu.addMenu(sub)

                elif target is _SPECTRUM_VIEWER:
                    # ── Spectrum Viewer toggle ────────────────────────────
                    act = QAction(label, menu)
                    act.setCheckable(True)
                    act.setChecked(
                        self._dock.isVisible() if self._dock else False
                    )
                    act.setToolTip(
                        'Show / hide the Spectrum Viewer\n'
                        'Click pixels on the map to display and compare spectra.'
                    )
                    act.triggered.connect(self._toggle_viewer)
                    menu.addAction(act)
                    self._act_viewer = act   # store reference for dock sync

                else:
                    # ── Leaf algorithm action ─────────────────────────────
                    alg_id = target
                    act = QAction(label, menu)
                    act.triggered.connect(
                        lambda checked, aid=alg_id: self._run_algorithm(aid)
                    )
                    menu.addAction(act)

    # ── Slots ─────────────────────────────────────────────────────────────────

    def _toggle_viewer(self, checked=None):
        if self._dock is None:
            return
        if checked is None:
            checked = not self._dock.isVisible()
        if checked:
            self._dock.show_and_raise()
        else:
            self._dock.hide()

    def _run_algorithm(self, alg_id):
        try:
            import processing
            processing.execAlgorithmDialog(alg_id)
        except Exception as e:
            self.iface.messageBar().pushWarning(
                'HypPy', f'Could not open "{alg_id}": {e}')

    # ── Public API ────────────────────────────────────────────────────────────

    def show_spectrum_viewer(self):
        """Called from Getting Started algorithm."""
        if self._dock:
            self._dock.show_and_raise()
        if self._act_viewer:
            self._act_viewer.setChecked(True)

    # ── Cleanup ───────────────────────────────────────────────────────────────

    def unload(self):
        if self._dock:
            self._dock.close()
            self.iface.mainWindow().removeDockWidget(self._dock)
            self._dock.deleteLater()
            self._dock = None

        if self._toolbar:
            self.iface.mainWindow().removeToolBar(self._toolbar)
            self._toolbar.deleteLater()
            self._toolbar = None

        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None
