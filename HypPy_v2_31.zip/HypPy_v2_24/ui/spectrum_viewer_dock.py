"""
Spectrum Viewer Dock + Map Tool
================================
Interactive pixel-click spectral viewer for HypPy for QGIS.

Modelled on the HypPy 3.0.1 Spectral Library Viewer (tkSpecLib.py)
by Wim Bakker, University of Twente.

v2.20 changes
-------------
Plot widget:
  - matplotlib C0–C9 colour cycle, white background, grey grid, black spines
  - X label "wavelength (Micrometers)" from ENVI header (xlabel() replication)
  - Library spectra on true Y scale, right axis

Dock:
  - Full menubar matching HypPy SpecLib Viewer:  File | Select | View | Math
      File     — Open library (respects library type), Exit
      Select   — Select all, Deselect all
      View     — No hull removal / CR by division / CR by subtraction (radio)
                 ── Plot spectra / Plot + average / View values
                 ── Legend on / Legend off (radio)
                 ── Set xlabel / Set ylabel / Set title / Set axes / Reset axes
      Math     — Math expression on S (runs bandmath)
  - Library type selector: ENVI Speclib / ASCII file / ASCII dir / recursive
  - REE Neodymium marker toggle — draws vertical lines at 580/740/800/870 nm
  - Wavelength units propagated to plot and Values tab column header

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
Original HypPy tkSpecLib concept: Copyright (C) Wim Bakker, Univ. of Twente.
"""

import os
import sip
import numpy as np

from qgis.PyQt.QtCore    import Qt, QSize
from qgis.PyQt.QtGui     import QColor, QCursor, QFont
from qgis.PyQt.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QFileDialog,
    QSizePolicy, QFrame, QApplication, QListWidget,
    QAbstractItemView, QTextEdit,
    QLineEdit, QCheckBox, QRadioButton, QButtonGroup,
    QTabWidget, QTableWidget, QTableWidgetItem,
    QGroupBox, QHeaderView, QMessageBox,
    QMenuBar, QMenu, QAction, QActionGroup,
    QInputDialog, QDialog, QDialogButtonBox,
    QFormLayout, QDoubleSpinBox
)
from qgis.core import QgsRasterLayer, QgsProject
from qgis.gui  import QgsMapTool

try:
    from osgeo import gdal
    _GDAL = True
except ImportError:
    _GDAL = False

from ..core.envi_header         import get_wavelengths_from_dataset
from ..core.spectral_library_io import (load_spectral_library,
                                         load_envi_spectral_library,
                                         load_csv_spectral_library,
                                         parse_envi_header,
                                         resolve_envi_paths)
from ..core.convex_hull         import hull_resampled
from ..core.spectrum            import Spectrum
from .spectrum_plot_widget      import SpectrumPlotWidget

# ── REE Neodymium absorption wavelengths (Boesche et al. 2015) ───────────────
_REE_ND_MARKERS = [
    (580, '#c0392b', '580'),
    (740, '#c0392b', '740'),
    (800, '#c0392b', '800'),
    (870, '#c0392b', '870'),
]


def _hrule():
    f = QFrame()
    f.setFrameShape(QFrame.HLine)
    f.setFrameShadow(QFrame.Sunken)
    return f


# ══════════════════════════════════════════════════════════════════════════════
# Axes dialog
# ══════════════════════════════════════════════════════════════════════════════

class _SetAxesDialog(QDialog):
    """Set axes dialog — mirrors HypPy View > Set axes."""

    def __init__(self, parent, x0, x1, y0, y1):
        super().__init__(parent)
        self.setWindowTitle('Set Axes')
        layout = QFormLayout(self)

        def _spin(val, lo=-1e9, hi=1e9):
            s = QDoubleSpinBox()
            s.setRange(lo, hi)
            s.setDecimals(4)
            s.setValue(val if val is not None else 0.0)
            s.setStepType(QDoubleSpinBox.AdaptiveDecimalStepType)
            return s

        self._x0 = _spin(x0); layout.addRow('X min:', self._x0)
        self._x1 = _spin(x1); layout.addRow('X max:', self._x1)
        self._y0 = _spin(y0); layout.addRow('Y min:', self._y0)
        self._y1 = _spin(y1); layout.addRow('Y max:', self._y1)

        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addRow(btns)

    def values(self):
        return (self._x0.value(), self._x1.value(),
                self._y0.value(), self._y1.value())


# ══════════════════════════════════════════════════════════════════════════════
# Map Tool
# ══════════════════════════════════════════════════════════════════════════════

class PixelSpectrumTool(QgsMapTool):
    def __init__(self, canvas, dock):
        super().__init__(canvas)
        self._dock = dock
        self.setCursor(QCursor(Qt.CrossCursor))

    def activate(self):
        super().activate()
        self._dock._on_tool_activated()

    def deactivate(self):
        super().deactivate()
        self._dock._on_tool_deactivated()

    def canvasReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._dock._read_pixel(self.toMapCoordinates(event.pos()))
        elif event.button() == Qt.RightButton:
            self.canvas().unsetMapTool(self)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.canvas().unsetMapTool(self)


# ══════════════════════════════════════════════════════════════════════════════
# Dock Widget
# ══════════════════════════════════════════════════════════════════════════════

class SpectrumViewerDock(QDockWidget):
    """Dockable Spectrum Viewer — HypPy SpecLib Viewer style."""

    _LIB_ENVI      = 'envi'
    _LIB_ASC       = 'ascfile'
    _LIB_ASCDIR    = 'ascdir'
    _LIB_ASCDIRREC = 'ascdirrecursive'

    def __init__(self, iface):
        super().__init__('Spectrum Viewer', iface.mainWindow())
        self._iface  = iface
        self._canvas = iface.mapCanvas()
        self._tool   = PixelSpectrumTool(self._canvas, self)
        self._prev_tool = None

        self._lib_path         = None
        self._lib_spectra      = []
        self._lib_names        = []
        self._lib_wavs         = None
        self._lib_wav_units    = None
        self._lib_descriptions = []
        self._lib_type         = self._LIB_ENVI

        self._remove_hull  = False
        self._hull_mode    = 'div'
        self._legend_on    = True
        self._ree_markers  = False

        self._build_ui()

        QgsProject.instance().layersAdded.connect(self._refresh_layer_label)
        QgsProject.instance().layersRemoved.connect(self._refresh_layer_label)
        self._canvas.currentLayerChanged.connect(self._refresh_layer_label)

    # ══════════════════════════════════════════════════════════════════════════
    # UI
    # ══════════════════════════════════════════════════════════════════════════

    def _build_ui(self):
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea |
                             Qt.BottomDockWidgetArea)
        self.setMinimumWidth(400)
        self.setMinimumHeight(460)

        root = QWidget()
        root.setStyleSheet('QWidget { font-family: Arial; font-size: 9pt; }')
        main_vbox = QVBoxLayout(root)
        main_vbox.setSpacing(3)
        main_vbox.setContentsMargins(4, 2, 4, 4)

        # ── Menubar (File | Select | View | Math) ─────────────────────────────
        menubar = QMenuBar()
        menubar.setNativeMenuBar(False)  # keep it in the dock, not the macOS bar
        main_vbox.addWidget(menubar)

        # ── File menu ─────────────────────────────────────────────────────────
        file_menu = menubar.addMenu('File')
        act_open = QAction('Open library…', self)
        act_open.triggered.connect(self._browse_library)
        file_menu.addAction(act_open)
        file_menu.addSeparator()
        act_exit = QAction('Close viewer', self)
        act_exit.triggered.connect(self.hide)
        file_menu.addAction(act_exit)

        # ── Select menu ───────────────────────────────────────────────────────
        sel_menu = menubar.addMenu('Select')
        act_all = QAction('Select all', self)
        act_all.triggered.connect(lambda: self._listbox.selectAll())
        sel_menu.addAction(act_all)
        act_none = QAction('Deselect all', self)
        act_none.triggered.connect(lambda: self._listbox.clearSelection())
        sel_menu.addAction(act_none)

        # ── View menu ─────────────────────────────────────────────────────────
        view_menu = menubar.addMenu('View')

        # Hull removal group — "No hull removal / CR by division / CR by subtraction"
        hull_grp = QActionGroup(self)
        hull_grp.setExclusive(True)

        self._act_no_hull = QAction('No hull removal', self, checkable=True)
        self._act_no_hull.setChecked(True)
        self._act_cr_div  = QAction('CR by division',    self, checkable=True)
        self._act_cr_sub  = QAction('CR by subtraction', self, checkable=True)
        for a in (self._act_no_hull, self._act_cr_div, self._act_cr_sub):
            hull_grp.addAction(a)
            view_menu.addAction(a)
        self._act_no_hull.triggered.connect(lambda: self._set_hull(False, 'div'))
        self._act_cr_div.triggered.connect(lambda:  self._set_hull(True,  'div'))
        self._act_cr_sub.triggered.connect(lambda:  self._set_hull(True,  'sub'))

        view_menu.addSeparator()

        # Plot / View values / Plot + average
        act_plot = QAction('Plot spectra', self)
        act_plot.triggered.connect(self._plot_selected)
        view_menu.addAction(act_plot)

        act_plot_avg = QAction('Plot + average', self)
        act_plot_avg.triggered.connect(self._plot_and_average)
        view_menu.addAction(act_plot_avg)

        act_view_vals = QAction('View values', self)
        act_view_vals.triggered.connect(self._view_values)
        view_menu.addAction(act_view_vals)

        view_menu.addSeparator()

        # Legend on / off
        leg_grp = QActionGroup(self)
        leg_grp.setExclusive(True)
        self._act_leg_on  = QAction('Legend on',  self, checkable=True)
        self._act_leg_off = QAction('Legend off', self, checkable=True)
        self._act_leg_on.setChecked(True)
        for a in (self._act_leg_on, self._act_leg_off):
            leg_grp.addAction(a)
            view_menu.addAction(a)
        self._act_leg_on.triggered.connect(lambda:  self._set_legend(True))
        self._act_leg_off.triggered.connect(lambda: self._set_legend(False))

        view_menu.addSeparator()

        # Set xlabel / ylabel / title
        act_xlabel = QAction('Set xlabel', self)
        act_xlabel.triggered.connect(self._set_xlabel)
        view_menu.addAction(act_xlabel)

        act_ylabel = QAction('Set ylabel', self)
        act_ylabel.triggered.connect(self._set_ylabel)
        view_menu.addAction(act_ylabel)

        act_title = QAction('Set title', self)
        act_title.triggered.connect(self._set_title)
        view_menu.addAction(act_title)

        view_menu.addSeparator()

        # Set axes / Reset axes
        act_set_axes   = QAction('Set axes',   self)
        act_reset_axes = QAction('Reset axes', self)
        act_set_axes.triggered.connect(self._set_axes)
        act_reset_axes.triggered.connect(self._reset_axes)
        view_menu.addAction(act_set_axes)
        view_menu.addAction(act_reset_axes)

        view_menu.addSeparator()

        act_reset_leg = QAction('Reset legend position', self)
        act_reset_leg.triggered.connect(lambda: self._plot.reset_legend_position())
        view_menu.addAction(act_reset_leg)

        view_menu.addSeparator()

        # REE Nd marker toggle
        self._act_ree = QAction('REE Nd markers  (580/740/800/870 nm)',
                                self, checkable=True)
        self._act_ree.setChecked(False)
        self._act_ree.triggered.connect(self._toggle_ree_markers)
        view_menu.addAction(self._act_ree)

        # ── Math menu ─────────────────────────────────────────────────────────
        math_menu = menubar.addMenu('Math')
        act_run_math = QAction('Run expression on S…', self)
        act_run_math.triggered.connect(self._run_bandmath)
        math_menu.addAction(act_run_math)

        # ── Tabs ──────────────────────────────────────────────────────────────
        self._tabs = QTabWidget()
        main_vbox.addWidget(self._tabs)

        # TAB 1: Plot
        tab_plot = QWidget()
        vbox = QVBoxLayout(tab_plot)
        vbox.setSpacing(4)
        vbox.setContentsMargins(4, 4, 4, 4)

        vbox.addWidget(QLabel('<b>Pixel Spectrum</b>'))

        row1 = QHBoxLayout()
        self._lbl_layer = QLabel('Active layer: (none)')
        self._lbl_layer.setWordWrap(True)
        self._lbl_layer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        row1.addWidget(self._lbl_layer)
        vbox.addLayout(row1)

        row2 = QHBoxLayout()
        self._btn_pick = QPushButton('▶  Pick pixel')
        self._btn_pick.setCheckable(True)
        self._btn_pick.setToolTip(
            'Click to activate the pixel picker, then click on the map.\n'
            'Right-click on map or Escape to deactivate.')
        self._btn_pick.toggled.connect(self._toggle_tool)
        self._btn_pick.setMinimumHeight(26)
        row2.addWidget(self._btn_pick)
        btn_clr_px = QPushButton('Clear pixel')
        btn_clr_px.clicked.connect(self._clear_pixel)
        row2.addWidget(btn_clr_px)
        vbox.addLayout(row2)

        self._lbl_pixel = QLabel('')
        self._lbl_pixel.setStyleSheet('color:#555555; font-style:italic;')
        vbox.addWidget(self._lbl_pixel)

        vbox.addWidget(_hrule())

        # Plot widget
        self._plot = SpectrumPlotWidget()
        self._plot.setMinimumHeight(200)
        self._plot.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        vbox.addWidget(self._plot, stretch=1)

        vbox.addWidget(_hrule())

        # Spectral Library section
        vbox.addWidget(QLabel('<b>Spectral Library</b>'))

        # Library type — mirrors HypPy radio buttons
        type_grp = QGroupBox('Library type')
        type_grp.setStyleSheet('QGroupBox { font-size:8pt; padding-top:4px; }')
        type_vbox = QVBoxLayout(type_grp)
        type_vbox.setSpacing(1)
        type_vbox.setContentsMargins(6, 2, 6, 4)
        self._rb_envi    = QRadioButton('ENVI Speclib  (.sli / .hdr)')
        self._rb_asc     = QRadioButton('ASCII file  (.csv / .txt)')
        self._rb_ascdir  = QRadioButton('ASCII directory')
        self._rb_ascdirr = QRadioButton('ASCII directory  (recursive)')
        self._rb_envi.setChecked(True)
        bg = QButtonGroup(self)
        for rb in (self._rb_envi, self._rb_asc, self._rb_ascdir, self._rb_ascdirr):
            bg.addButton(rb)
            type_vbox.addWidget(rb)
        self._rb_envi.toggled.connect(lambda: self._set_lib_type(self._LIB_ENVI))
        self._rb_asc.toggled.connect(lambda:  self._set_lib_type(self._LIB_ASC))
        self._rb_ascdir.toggled.connect(lambda: self._set_lib_type(self._LIB_ASCDIR))
        self._rb_ascdirr.toggled.connect(lambda: self._set_lib_type(self._LIB_ASCDIRREC))
        vbox.addWidget(type_grp)

        row3 = QHBoxLayout()
        self._lbl_lib = QLabel('No library loaded')
        self._lbl_lib.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self._lbl_lib.setWordWrap(True)
        row3.addWidget(self._lbl_lib)
        btn_browse = QPushButton('Browse…')
        btn_browse.setMaximumWidth(72)
        btn_browse.clicked.connect(self._browse_library)
        row3.addWidget(btn_browse)
        vbox.addLayout(row3)

        # Spectrum list (EXTENDED — matches HypPy Listbox selectmode=EXTENDED)
        self._listbox = QListWidget()
        self._listbox.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self._listbox.setMinimumHeight(80)
        self._listbox.setMaximumHeight(140)
        self._listbox.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self._listbox.itemSelectionChanged.connect(self._on_selection_changed)
        vbox.addWidget(self._listbox)

        # Continuum Removal row (also in View menu — kept here for convenience)
        hull_row = QHBoxLayout()
        self._chk_hull = QCheckBox('Remove Convex Hull')
        self._chk_hull.setChecked(False)
        self._chk_hull.toggled.connect(self._on_hull_chk_toggled)
        hull_row.addWidget(self._chk_hull)
        self._rb_div = QRadioButton('divide')
        self._rb_div.setChecked(True)
        self._rb_div.toggled.connect(self._on_hull_rb_changed)
        hull_row.addWidget(self._rb_div)
        self._rb_sub = QRadioButton('subtract')
        self._rb_sub.toggled.connect(self._on_hull_rb_changed)
        hull_row.addWidget(self._rb_sub)
        hull_row.addStretch()
        vbox.addLayout(hull_row)

        # Description
        self._description = QTextEdit()
        self._description.setReadOnly(True)
        self._description.setMaximumHeight(50)
        self._description.setPlaceholderText('Spectrum description…')
        self._description.setStyleSheet('font-size:8pt; color:#444444;')
        vbox.addWidget(self._description)

        # Button row — Plot | View Values | Average | Clear plot
        btn_row = QHBoxLayout()
        self._btn_plot = QPushButton('Plot')
        self._btn_plot.setEnabled(False)
        self._btn_plot.clicked.connect(self._plot_selected)
        btn_row.addWidget(self._btn_plot)

        self._btn_view_vals = QPushButton('View Values')
        self._btn_view_vals.setEnabled(False)
        self._btn_view_vals.clicked.connect(self._view_values)
        btn_row.addWidget(self._btn_view_vals)

        self._btn_average = QPushButton('Average')
        self._btn_average.setEnabled(False)
        self._btn_average.clicked.connect(self._average_selected)
        btn_row.addWidget(self._btn_average)

        self._btn_clear_lib = QPushButton('Clear plot')
        self._btn_clear_lib.setEnabled(False)
        self._btn_clear_lib.clicked.connect(self._clear_library_overlays)
        btn_row.addWidget(self._btn_clear_lib)
        vbox.addLayout(btn_row)

        # Legend radio (convenience row — synced with View menu)
        leg_row = QHBoxLayout()
        self._rb_leg_on  = QRadioButton('legend on')
        self._rb_leg_off = QRadioButton('legend off')
        self._rb_leg_on.setChecked(True)
        self._rb_leg_on.toggled.connect(lambda c: self._set_legend(c))
        leg_row.addWidget(self._rb_leg_on)
        leg_row.addWidget(self._rb_leg_off)

        # REE marker checkbox (convenience — synced with View menu)
        self._chk_ree = QCheckBox('REE Nd markers')
        self._chk_ree.setChecked(False)
        self._chk_ree.setToolTip(
            'Show vertical lines at Neodymium absorption bands:\n'
            '580, 740, 800, 870 nm\n'
            '(Boesche et al. 2015)')
        self._chk_ree.toggled.connect(self._on_ree_chk_toggled)
        leg_row.addStretch()
        leg_row.addWidget(self._chk_ree)
        vbox.addLayout(leg_row)

        # Math expression
        vbox.addWidget(_hrule())
        math_grp = QGroupBox('Math Expression on Spectrum  S:')
        math_vbox = QVBoxLayout(math_grp)
        math_vbox.setSpacing(3)
        self._expression = QLineEdit()
        self._expression.setPlaceholderText(
            'e.g.  S.nohull()  or  S[2200.0]  or  S.mean()')
        self._expression.returnPressed.connect(self._run_bandmath)
        math_row2 = QHBoxLayout()
        math_row2.addWidget(self._expression)
        self._btn_go = QPushButton('Go')
        self._btn_go.clicked.connect(self._run_bandmath)
        math_row2.addWidget(self._btn_go)
        math_vbox.addLayout(math_row2)
        self._math_result = QLabel('')
        self._math_result.setWordWrap(True)
        self._math_result.setStyleSheet('color:#1B3A5C; font-size:8pt;')
        math_vbox.addWidget(self._math_result)
        vbox.addWidget(math_grp)

        # Status bar
        vbox.addWidget(_hrule())
        self._status = QLabel('Ready')
        self._status.setStyleSheet('color:#666666; font-size:8pt;')
        vbox.addWidget(self._status)

        self._tabs.addTab(tab_plot, 'Plot')

        # TAB 2: Values
        tab_vals = QWidget()
        val_vbox = QVBoxLayout(tab_vals)
        val_vbox.setContentsMargins(4, 4, 4, 4)
        val_vbox.addWidget(
            QLabel('<b>Wavelength / Value table</b>  (for selected spectrum)'))
        self._vals_table = QTableWidget(0, 2)
        self._vals_table.setHorizontalHeaderLabels(['Wavelength', 'Value'])
        self._vals_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self._vals_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._vals_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        val_vbox.addWidget(self._vals_table, stretch=1)
        btn_copy = QPushButton('Copy as CSV')
        btn_copy.clicked.connect(self._copy_vals_csv)
        val_vbox.addWidget(btn_copy)
        self._tabs.addTab(tab_vals, 'Values')

        self.setWidget(root)
        self._refresh_layer_label()

    # ══════════════════════════════════════════════════════════════════════════
    # Library type
    # ══════════════════════════════════════════════════════════════════════════

    def _set_lib_type(self, lib_type):
        self._lib_type = lib_type

    # ══════════════════════════════════════════════════════════════════════════
    # View menu handlers
    # ══════════════════════════════════════════════════════════════════════════

    def _set_hull(self, remove, mode):
        self._remove_hull = remove
        self._hull_mode   = mode
        # Sync the checkbox row
        self._chk_hull.setChecked(remove)
        if mode == 'div':
            self._rb_div.setChecked(True)
        else:
            self._rb_sub.setChecked(True)

    def _set_legend(self, on):
        self._legend_on = on
        self._act_leg_on.setChecked(on)
        self._act_leg_off.setChecked(not on)
        self._rb_leg_on.setChecked(on)
        self._rb_leg_off.setChecked(not on)
        self._plot.set_legend_visible(on)

    def _set_xlabel(self):
        cur = self._plot._xlabel_ovr or ''
        text, ok = QInputDialog.getText(
            self, 'Set xlabel', 'X axis label:', text=cur)
        if ok:
            self._plot.set_xlabel_override(text)
            self._status.setText(f'xlabel: {text or "(auto)"}')

    def _set_ylabel(self):
        cur = self._plot._ylabel_ovr or ''
        text, ok = QInputDialog.getText(
            self, 'Set ylabel', 'Y axis label:', text=cur)
        if ok:
            self._plot.set_ylabel_override(text)
            self._status.setText(f'ylabel: {text or "(auto)"}')

    def _set_title(self):
        cur = self._plot._title_ovr or ''
        text, ok = QInputDialog.getText(
            self, 'Set title', 'Plot title:', text=cur)
        if ok:
            self._plot.set_title_override(text)
            self._status.setText(f'title: {text or "(none)"}')

    def _set_axes(self):
        x0, x1 = self._plot._effective_xlim()
        y0, y1 = self._plot._effective_ylim()
        dlg = _SetAxesDialog(self,
                             x0 or 0.0, x1 or 1.0,
                             y0 or 0.0, y1 or 1.0)
        if dlg.exec_() == QDialog.Accepted:
            xa, xb, ya, yb = dlg.values()
            self._plot.set_axes_override(xa, xb, ya, yb)
            self._status.setText(
                f'Axes: X [{xa:.4g},{xb:.4g}]  Y [{ya:.4g},{yb:.4g}]')

    def _reset_axes(self):
        self._plot.reset_axes()
        self._status.setText('Axes reset to auto')

    def _toggle_ree_markers(self, checked):
        self._ree_markers = checked
        self._chk_ree.setChecked(checked)
        self._act_ree.setChecked(checked)
        if checked:
            self._plot.set_markers(_REE_ND_MARKERS)
            self._status.setText(
                'REE Nd markers: 580 / 740 / 800 / 870 nm  '
                '(Boesche et al. 2015)')
        else:
            self._plot.clear_markers()
            self._status.setText('REE Nd markers cleared')

    def _on_ree_chk_toggled(self, checked):
        self._toggle_ree_markers(checked)

    # ══════════════════════════════════════════════════════════════════════════
    # Pick tool
    # ══════════════════════════════════════════════════════════════════════════

    def _toggle_tool(self, checked):
        if checked:
            self._prev_tool = self._canvas.mapTool()
            self._canvas.setMapTool(self._tool)
        else:
            if self._canvas.mapTool() is self._tool:
                self._canvas.unsetMapTool(self._tool)
            if self._prev_tool:
                self._canvas.setMapTool(self._prev_tool)

    def _on_tool_activated(self):
        if sip.isdeleted(self._btn_pick) or sip.isdeleted(self._status):
            return
        self._btn_pick.setChecked(True)
        self._btn_pick.setText('■  Picking…  (Esc or right-click to stop)')
        self._status.setText('Click on the map to read a pixel spectrum')

    def _on_tool_deactivated(self):
        if sip.isdeleted(self._btn_pick) or sip.isdeleted(self._status):
            return
        self._btn_pick.setChecked(False)
        self._btn_pick.setText('▶  Pick pixel')
        self._status.setText('Ready')

    # ══════════════════════════════════════════════════════════════════════════
    # Layer label
    # ══════════════════════════════════════════════════════════════════════════

    def _refresh_layer_label(self, *args):
        layer = self._canvas.currentLayer()
        if layer and isinstance(layer, QgsRasterLayer):
            self._lbl_layer.setText(f'Active layer: <b>{layer.name()}</b>')
            self._lbl_layer.setStyleSheet('color:#1B3A5C;')
        elif layer:
            self._lbl_layer.setText(
                f'Active layer: {layer.name()}'
                ' <span style="color:orange;">(not a raster)</span>')
        else:
            self._lbl_layer.setText('Active layer: (none)')

    # ══════════════════════════════════════════════════════════════════════════
    # Pixel reading
    # ══════════════════════════════════════════════════════════════════════════

    def _read_pixel(self, map_point):
        if sip.isdeleted(self._plot) or sip.isdeleted(self._status):
            return
        layer = self._canvas.currentLayer()
        if not layer or not isinstance(layer, QgsRasterLayer):
            self._status.setText('⚠  Please select a raster layer in the Layers panel')
            return
        if not _GDAL:
            self._status.setText('⚠  GDAL not available')
            return

        ds = gdal.Open(layer.source(), gdal.GA_ReadOnly)
        if ds is None:
            self._status.setText(f'⚠  Cannot open: {layer.source()}')
            return

        n_bands = ds.RasterCount
        geo     = ds.GetGeoTransform()
        if geo[1] == 0:
            ds = None
            self._status.setText('⚠  Raster has no valid geotransform')
            return

        col = int((map_point.x() - geo[0]) / geo[1])
        row = int((map_point.y() - geo[3]) / geo[5])

        if col < 0 or row < 0 or col >= ds.RasterXSize or row >= ds.RasterYSize:
            ds = None
            self._status.setText('⚠  Click is outside raster extent')
            return

        values     = np.zeros(n_bands, dtype=np.float64)
        nodata_val = ds.GetRasterBand(1).GetNoDataValue()
        for b in range(n_bands):
            arr = ds.GetRasterBand(b + 1).ReadAsArray(col, row, 1, 1)
            values[b] = float(arr[0, 0]) if arr is not None else np.nan

        if nodata_val is not None:
            values[np.isclose(values, nodata_val)] = np.nan

        wavelengths = get_wavelengths_from_dataset(ds, n_bands, layer.source())
        ds = None

        if wavelengths is None:
            wavelengths = np.arange(1, n_bands + 1, dtype=float)
            wav_label   = 'Band number'
        else:
            wav_label = 'Wavelength (nm)'

        label = f'{layer.name()}  row {row}, col {col}'
        self._plot.set_pixel_spectrum(wavelengths, values, label=label,
                                      legend_visible=self._legend_on)
        if self._lib_wav_units is not None:
            self._plot.set_wav_units(self._lib_wav_units)

        self._lbl_pixel.setText(
            f'<span style="color:#1B3A5C;">{label}</span><br/>'
            f'X={map_point.x():.2f}, Y={map_point.y():.2f}  |  '
            f'{n_bands} bands')
        self._status.setText(f'Pixel read: {n_bands} bands  ({wav_label})')

    def _clear_pixel(self):
        self._plot.set_pixel_spectrum(np.array([]), np.array([]))
        self._lbl_pixel.setText('')
        self._status.setText('Pixel spectrum cleared')

    # ══════════════════════════════════════════════════════════════════════════
    # Library loading
    # ══════════════════════════════════════════════════════════════════════════

    def _browse_library(self):
        lib_type = self._lib_type
        if lib_type in (self._LIB_ASCDIR, self._LIB_ASCDIRREC):
            path = QFileDialog.getExistingDirectory(
                self, 'Open ASCII Spectrum Directory', '')
        else:
            filt = ('ENVI Spectral Libraries (*.sli *.hdr);;'
                    'ASCII Libraries (*.csv *.txt);;All files (*)'
                    if lib_type == self._LIB_ENVI
                    else 'ASCII Libraries (*.csv *.txt);;All files (*)')
            path, _ = QFileDialog.getOpenFileName(
                self, 'Open Spectral Library', '', filt)
        if path:
            self._load_library(path)

    def _load_library(self, path):
        self._status.setText('Loading spectral library…')
        QApplication.processEvents()
        try:
            if self._lib_type == self._LIB_ENVI:
                spectra, names, wavs = load_envi_spectral_library(
                    path, log=lambda m: self._status.setText(m))
                _, hdr_path = resolve_envi_paths(path)
                self._lib_wav_units = None
                if hdr_path:
                    hdr = parse_envi_header(hdr_path)
                    self._lib_wav_units = hdr.get('wavelength_units')
            else:
                spectra, names, wavs = load_csv_spectral_library(
                    path, log=lambda m: self._status.setText(m))
                self._lib_wav_units = None
        except Exception as e:
            self._status.setText(f'⚠  Failed to load library: {e}')
            return

        self._lib_path         = path
        self._lib_spectra      = spectra
        self._lib_names        = names
        self._lib_wavs         = wavs
        self._lib_descriptions = [''] * len(names)

        self._plot.set_wav_units(self._lib_wav_units)

        fname = os.path.basename(path)
        units_hint = f'  [{self._lib_wav_units}]' if self._lib_wav_units else ''
        self._lbl_lib.setText(
            f'<b>{fname}</b>  ({len(spectra)} spectra){units_hint}')

        self._listbox.clear()
        for name in names:
            self._listbox.addItem(name)

        self._plot.clear_library_spectra()
        self._btn_clear_lib.setEnabled(False)
        self._description.clear()
        self._status.setText(
            f'Library loaded: {len(spectra)} spectra from {fname}{units_hint}')

    # ══════════════════════════════════════════════════════════════════════════
    # Hull helpers
    # ══════════════════════════════════════════════════════════════════════════

    def _on_hull_chk_toggled(self, checked):
        self._remove_hull = checked
        if checked:
            (self._act_cr_div if self._hull_mode == 'div'
             else self._act_cr_sub).setChecked(True)
        else:
            self._act_no_hull.setChecked(True)

    def _on_hull_rb_changed(self):
        self._hull_mode = 'div' if self._rb_div.isChecked() else 'sub'
        if self._remove_hull:
            (self._act_cr_div if self._hull_mode == 'div'
             else self._act_cr_sub).setChecked(True)

    def _apply_hull(self, wav, spec, name):
        if not self._remove_hull:
            return wav, spec, name
        try:
            wav_arr  = np.asarray(wav,  dtype=float)
            spec_arr = np.asarray(spec, dtype=float)
            mask = np.isfinite(wav_arr) & np.isfinite(spec_arr)
            if mask.sum() < 3:
                return wav, spec, name
            hull = hull_resampled(
                np.column_stack((wav_arr[mask], spec_arr[mask])))
            from scipy.interpolate import interp1d
            f_hull    = interp1d(hull[:, 0], hull[:, 1], kind='linear',
                                 bounds_error=False, fill_value=np.nan)
            hull_full = f_hull(wav_arr)
            if self._hull_mode == 'div':
                out    = np.where(hull_full > 0, spec_arr / hull_full, np.nan)
                suffix = ' / CH'
            else:
                out    = 1.0 + (spec_arr - hull_full)
                suffix = ' - CH + 1'
            return wav_arr, out, name + suffix
        except Exception:
            return wav, spec, name

    def _make_spectrum_obj(self, idx):
        wav  = self._lib_wavs
        spec = self._lib_spectra[idx]
        name = self._lib_names[idx]
        if wav is None:
            wav = np.arange(1, len(spec) + 1, dtype=float)
        wav, spec, name = self._apply_hull(wav, spec, name)
        return Spectrum(wavelength=wav, spectrum=spec, name=name)

    # ══════════════════════════════════════════════════════════════════════════
    # Plot / Average / View Values
    # ══════════════════════════════════════════════════════════════════════════

    def _selected_indices(self):
        return [self._listbox.row(item) for item in self._listbox.selectedItems()]

    def _on_selection_changed(self):
        has = bool(self._listbox.selectedItems())
        self._btn_plot.setEnabled(has)
        self._btn_average.setEnabled(has)
        self._btn_view_vals.setEnabled(has)
        sel = self._selected_indices()
        if len(sel) == 1 and sel[0] < len(self._lib_descriptions):
            self._description.setText(self._lib_descriptions[sel[0]])
        else:
            self._description.clear()

    def _plot_selected(self):
        indices = self._selected_indices()
        if not indices:
            self._status.setText('⚠  No spectrum selected')
            return
        self._plot.clear_library_spectra()
        for idx in indices:
            wav  = self._lib_wavs
            spec = self._lib_spectra[idx]
            name = self._lib_names[idx]
            if wav is None:
                wav = np.arange(1, len(spec) + 1, dtype=float)
            wav, spec, name = self._apply_hull(wav, spec, name)
            self._plot.add_library_spectrum(
                wav, spec, name=name,
                legend_visible=self._legend_on,
                wav_units=self._lib_wav_units)
        self._btn_clear_lib.setEnabled(True)
        self._status.setText(f'Plotted {len(indices)} spectrum(a)')

    def _plot_and_average(self):
        """Plot spectra + average — mirrors HypPy View > Plot + average."""
        self._plot_selected()
        self._average_selected()

    def _average_selected(self):
        indices = self._selected_indices()
        if not indices:
            return
        try:
            S_list = [self._make_spectrum_obj(i) for i in indices]
            result = S_list[0]
            for S in S_list[1:]:
                result = result + S
            result = result / len(S_list)
        except Exception as e:
            self._status.setText(f'⚠  Average failed: {e}')
            return
        self._plot.add_library_spectrum(
            result.w, result.s, name='Average',
            legend_visible=self._legend_on,
            wav_units=self._lib_wav_units)
        self._btn_clear_lib.setEnabled(True)
        self._status.setText(f'Average of {len(indices)} spectra plotted')
        self._populate_values_table(result.w, result.s, 'Average')
        self._tabs.setCurrentIndex(1)

    def _view_values(self):
        indices = self._selected_indices()
        if not indices:
            return
        idx  = indices[0]
        wav  = self._lib_wavs
        spec = self._lib_spectra[idx]
        name = self._lib_names[idx]
        if wav is None:
            wav = np.arange(1, len(spec) + 1, dtype=float)
        wav, spec, name = self._apply_hull(wav, spec, name)
        self._populate_values_table(wav, spec, name)
        self._tabs.setCurrentIndex(1)
        self._status.setText(f'Values: {name}')

    def _populate_values_table(self, wav, spec, name=''):
        wav  = np.asarray(wav,  dtype=float)
        spec = np.asarray(spec, dtype=float)
        units_lbl = ('Wavelength (µm)' if self._plot._display_in_um
                     else 'Wavelength (nm)')
        self._vals_table.setHorizontalHeaderLabels([units_lbl, 'Value'])
        self._vals_table.setRowCount(0)
        self._vals_table.setRowCount(len(wav))
        for i, (w, v) in enumerate(zip(wav, spec)):
            disp_w = w / 1000.0 if self._plot._display_in_um else w
            fmt    = f'{disp_w:.4f}' if self._plot._display_in_um else f'{disp_w:.2f}'
            self._vals_table.setItem(i, 0, QTableWidgetItem(fmt))
            self._vals_table.setItem(i, 1, QTableWidgetItem(f'{v:.6g}'))

    def _copy_vals_csv(self):
        rows = self._vals_table.rowCount()
        if rows == 0:
            return
        hdr   = self._vals_table.horizontalHeaderItem(0).text()
        lines = [f'{hdr},value']
        for i in range(rows):
            w = self._vals_table.item(i, 0)
            v = self._vals_table.item(i, 1)
            if w and v:
                lines.append(f'{w.text()},{v.text()}')
        QApplication.clipboard().setText('\n'.join(lines))
        self._status.setText('Values copied to clipboard as CSV')

    def _clear_library_overlays(self):
        self._plot.clear_library_spectra()
        self._btn_clear_lib.setEnabled(False)
        self._status.setText('Library spectra cleared from plot')

    # ══════════════════════════════════════════════════════════════════════════
    # Math expression  (mirrors HypPy bandmath_spec)
    # ══════════════════════════════════════════════════════════════════════════

    def _run_bandmath(self):
        exp = self._expression.text().strip()
        if not exp:
            exp_in, ok = QInputDialog.getText(
                self, 'Math Expression on Spectrum S',
                'Expression:', text='S.nohull()')
            if not ok or not exp_in.strip():
                return
            exp = exp_in.strip()
            self._expression.setText(exp)

        indices = self._selected_indices()
        if not indices:
            self._status.setText('⚠  Select a spectrum first')
            return

        results = []
        for idx in indices:
            S = self._make_spectrum_obj(idx)   # noqa: F841
            try:
                result = eval(exp)
            except Exception as e:
                self._math_result.setText(f'Error: {e}')
                self._status.setText(f'⚠  Expression error: {e}')
                return

            name_out = f'{S.name}  →  {exp}'

            if isinstance(result, Spectrum):
                self._plot.add_library_spectrum(
                    result.w, result.s, name=name_out,
                    legend_visible=self._legend_on,
                    wav_units=self._lib_wav_units)
                self._btn_clear_lib.setEnabled(True)
                results.append(f'{S.name}: <Spectrum>')
                self._populate_values_table(result.w, result.s, name_out)
            elif isinstance(result, np.ndarray):
                wav = (self._lib_wavs if self._lib_wavs is not None
                       else np.arange(1, len(result) + 1, dtype=float))
                if len(result) == len(wav):
                    self._plot.add_library_spectrum(
                        wav, result, name=name_out,
                        legend_visible=self._legend_on,
                        wav_units=self._lib_wav_units)
                    self._btn_clear_lib.setEnabled(True)
                results.append(f'{S.name}: array len={len(result)}')
            else:
                results.append(f'{S.name}: {result}')

        self._math_result.setText('\n'.join(results))
        self._status.setText('Expression evaluated')

    # ══════════════════════════════════════════════════════════════════════════
    # Public convenience
    # ══════════════════════════════════════════════════════════════════════════

    def show_and_raise(self):
        self.show()
        self.raise_()

    def load_library_from_path(self, path):
        self._load_library(path)

    def closeEvent(self, event):
        if self._canvas.mapTool() is self._tool:
            self._canvas.unsetMapTool(self._tool)
        super().closeEvent(event)
