"""
Spectral Library I/O
====================
Load ENVI (.sli/.hdr) and CSV spectral libraries.

Extracted from sam_algorithm.py so it can be shared between the SAM
Processing algorithm and the interactive Spectrum Viewer dock.

Returns (spectra, spec_names, wavelengths) where:
  spectra       – list of 1-D numpy float64 arrays
  spec_names    – list of str
  wavelengths   – numpy float64 array of wavelengths in nm, or None

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import os
import re
import numpy as np

try:
    from osgeo import gdal
    _GDAL = True
except ImportError:
    _GDAL = False


# ── ENVI header parser ────────────────────────────────────────────────────────

def parse_envi_header(hdr_path):
    """
    Parse an ENVI .hdr file and return a dict with keys:
      samples, lines, bands, data_type, byte_order, header_offset,
      wavelengths (np.array or None), spectra_names (list of str),
      wavelength_units (str or None)
    """
    result = {
        'samples': 0, 'lines': 0, 'bands': 1,
        'data_type': 4, 'byte_order': 0, 'header_offset': 0,
        'wavelengths': None, 'spectra_names': [], 'wavelength_units': None,
    }

    with open(hdr_path, 'r', errors='replace') as f:
        content = f.read()

    for key, rkey, conv in [
        ('samples',       'samples',       int),
        ('lines',         'lines',         int),
        ('bands',         'bands',         int),
        ('data type',     'data_type',     int),
        ('byte order',    'byte_order',    int),
        ('header offset', 'header_offset', int),
    ]:
        m = re.search(rf'^{key}\s*=\s*(\S+)', content, re.MULTILINE | re.IGNORECASE)
        if m:
            try:
                result[rkey] = conv(m.group(1))
            except ValueError:
                pass

    m = re.search(r'^wavelength units\s*=\s*(.+)', content, re.MULTILINE | re.IGNORECASE)
    if m:
        result['wavelength_units'] = m.group(1).strip()

    def parse_braced(field):
        pat = rf'{field}\s*=\s*\{{([^}}]*)\}}'
        m = re.search(pat, content, re.DOTALL | re.IGNORECASE)
        return m.group(1) if m else None

    wl_str = parse_braced('wavelength')
    if wl_str:
        try:
            result['wavelengths'] = np.array(
                [float(w.strip()) for w in wl_str.split(',') if w.strip()])
        except ValueError:
            pass

    names_str = parse_braced('spectra names')
    if names_str:
        parts = re.split(r',\s*\n\s*', names_str.strip())
        if len(parts) <= 1:
            parts = [n.strip() for n in names_str.split(',')]
        result['spectra_names'] = [n.strip() for n in parts if n.strip()]

    return result


# ── Path resolution ───────────────────────────────────────────────────────────

def resolve_envi_paths(speclib_path):
    """Return (sli_path, hdr_path) for an ENVI spectral library."""
    base = os.path.splitext(speclib_path)[0]
    ext  = os.path.splitext(speclib_path)[1].lower()

    if ext == '.hdr':
        hdr_path = speclib_path
        sli_path = None
        for data_ext in ['.sli', '.dat', '.img', '.bin', '']:
            cand = base + data_ext
            if os.path.exists(cand) and cand != speclib_path:
                sli_path = cand
                break
    else:
        sli_path = speclib_path
        hdr_path = base + '.hdr'
        if not os.path.exists(hdr_path):
            hdr_path = None

    return sli_path, hdr_path


# ── ENVI spectral library loader ──────────────────────────────────────────────

def load_envi_spectral_library(speclib_path, log=None):
    """
    Load an ENVI spectral library (.sli + .hdr).

    Parameters
    ----------
    speclib_path : str  — path to either the .sli or the .hdr file
    log          : callable or None  — receives info strings

    Returns
    -------
    spectra        : list of numpy float64 arrays
    spec_names     : list of str
    wavelengths    : numpy float64 array or None
    """
    def info(msg):
        if log:
            log(msg)

    sli_path, hdr_path = resolve_envi_paths(speclib_path)
    if hdr_path is None:
        raise ValueError(f'Cannot find .hdr for: {speclib_path}')
    if sli_path is None:
        raise ValueError(f'Cannot find .sli data file for: {speclib_path}')

    hdr = parse_envi_header(hdr_path)
    num_samples      = hdr['samples']
    num_lines        = hdr['lines']
    data_type        = hdr['data_type']
    byte_order       = hdr['byte_order']
    header_offset    = hdr['header_offset']
    spec_wavelengths = hdr['wavelengths']
    raw_names        = hdr['spectra_names']

    if num_samples == 0:
        raise ValueError('ENVI header has samples = 0')

    envi_dtypes = {1:'u1', 2:'i2', 3:'i4', 4:'f4', 5:'f8',
                   12:'u2', 13:'u4', 14:'i8', 15:'u8'}
    base_dtype = envi_dtypes.get(data_type, 'f4')
    endian     = '<' if byte_order == 0 else '>'
    dtype      = np.dtype(f'{endian}{base_dtype}')

    file_size  = os.path.getsize(sli_path) - header_offset
    bytes_per  = num_samples * dtype.itemsize
    actual     = file_size // bytes_per
    if actual != num_lines:
        info(f'Header says {num_lines} lines; file has {actual}. Using {actual}.')
        num_lines = actual

    spectra = []
    loaded  = False

    if _GDAL:
        try:
            ds = gdal.Open(sli_path, gdal.GA_ReadOnly)
            if ds and ds.RasterXSize == num_samples and ds.RasterYSize == num_lines:
                data = ds.GetRasterBand(1).ReadAsArray().astype(np.float64)
                if data is not None:
                    if data.ndim == 1:
                        data = data.reshape(1, -1)
                    data[data < -1e30] = np.nan
                    for i in range(data.shape[0]):
                        spectra.append(data[i, :])
                    loaded = True
                    info(f'Read {len(spectra)} spectra via GDAL')
            ds = None
        except Exception as e:
            info(f'GDAL read failed ({e}); using direct binary read')

    if not loaded:
        with open(sli_path, 'rb') as f:
            if header_offset > 0:
                f.seek(header_offset)
            raw = f.read()
        data = np.frombuffer(raw, dtype=dtype).reshape(num_lines, num_samples).astype(np.float64)
        data[data < -1e30] = np.nan
        for i in range(data.shape[0]):
            spectra.append(data[i, :])
        info(f'Read {len(spectra)} spectra via direct binary read')

    spec_names = [raw_names[i] if i < len(raw_names) else f'Spectrum_{i+1}'
                  for i in range(len(spectra))]

    # Normalise wavelengths to nm if in µm
    if spec_wavelengths is not None and np.nanmax(spec_wavelengths) < 100:
        spec_wavelengths = spec_wavelengths * 1000.0
        info('Wavelengths converted µm → nm')

    return spectra, spec_names, spec_wavelengths


# ── CSV spectral library loader ───────────────────────────────────────────────

def load_csv_spectral_library(speclib_path, log=None):
    """
    Load a CSV spectral library.

    Expected format:
      Row 1: [name_column_label,] wavelength1, wavelength2, ...
      Row 2+: spectrum_name, value1, value2, ...

    Returns (spectra, spec_names, wavelengths).
    """
    def info(msg):
        if log:
            log(msg)

    spectra, spec_names, spec_wavelengths = [], [], None

    with open(speclib_path, 'r', errors='replace') as f:
        lines = f.readlines()

    if len(lines) < 2:
        raise ValueError('Spectral library file has fewer than 2 rows')

    header = lines[0].strip().split(',')
    start  = 0
    try:
        float(header[0])
    except ValueError:
        start = 1

    try:
        wl = [float(x) for x in header[start:]]
        if wl:
            spec_wavelengths = np.array(wl)
            if np.nanmax(spec_wavelengths) < 100:
                spec_wavelengths = spec_wavelengths * 1000.0
                info('Wavelengths converted µm → nm')
    except ValueError:
        info('Could not parse wavelengths from CSV header')

    for i, line in enumerate(lines[1:]):
        parts = line.strip().split(',')
        if len(parts) < 2:
            continue
        try:
            spectra.append(np.array([float(x) for x in parts[1:]]))
            spec_names.append(parts[0].strip())
        except ValueError:
            info(f'Skipping invalid row at line {i+2}')

    return spectra, spec_names, spec_wavelengths


# ── Main entry point ──────────────────────────────────────────────────────────

def load_spectral_library(speclib_path, log=None):
    """
    Auto-detect format and load a spectral library.

    Returns (spectra, spec_names, wavelengths).
    """
    ext = os.path.splitext(speclib_path)[1].lower()
    if ext in ('.sli', '.hdr'):
        return load_envi_spectral_library(speclib_path, log)
    elif ext in ('.csv', '.txt'):
        return load_csv_spectral_library(speclib_path, log)
    else:
        # Try ENVI first, then CSV
        try:
            return load_envi_spectral_library(speclib_path, log)
        except Exception:
            return load_csv_spectral_library(speclib_path, log)
