"""
spectrum.py  —  HyPy Spectrum class for Hyppy-for-QGIS
=======================================================

A faithful port of Wim Bakker's spectrum.py from HyPy 3.0.1, trimmed of
GUI/pylab/colour-science dependencies that are unavailable inside QGIS.

Key capabilities (all present in the original):
  • __getitem__  : float wavelength → nearest-band interpolated value
                   slice of floats → sub-spectrum
                   int             → raw index
  • __call__     : S(wav) — synonym for S[wav]
  • __coerce__   : resamples two Spectrum objects onto their overlapping
                   wavelength union before any arithmetic operator
  • resample()   : linear (scipy interp1d) resampling to new wavelengths
  • Full numpy method set: log, exp, sqrt, sin, cos, abs, clip, mean, …
  • Arithmetic operators: +, -, *, /, ** with scalars and other Spectra
  • Comparison operators: <, <=, ==, !=, >=, >
  • hull() / nohull() / peaks() for continuum removal
  • localmin / localmax / minwav for absorption-feature detection
  • wavelength2index() with LRU hint cache

Original Author: Wim Bakker, University of Twente
Original Copyright (C) 2012- Wim Bakker (GPL v3)
QGIS adaptation: Grant Boxer, 2025
"""

import collections
import math
import numpy
import os

from scipy.interpolate import interp1d
import scipy.spatial


# ── primitive helpers ─────────────────────────────────────────────────────────

def _interpol(s1, w1, w):
    """Linear interpolation of spectrum s1 with wavelengths w1 at wavelength w."""
    i_right = w1.searchsorted(w)
    if i_right == 0:
        return s1[0]
    elif i_right == len(w1):
        return s1[-1]
    else:
        i_left = i_right - 1
        w_left, w_right = w1[i_left], w1[i_right]
        a = (w_right - w) / (w_right - w_left)
        return a * s1[i_left] + (1 - a) * s1[i_right]


def _resample(s1, w1, w2):
    """Resample spectrum s1 (wavelengths w1) to wavelengths w2 by linear interp."""
    sout = numpy.zeros((len(w2),))
    w1 = numpy.array(w1)
    for i in range(len(w2)):
        sout[i] = _interpol(s1, w1, w2[i])
    return sout


# ── Class Spectrum ─────────────────────────────────────────────────────────────

class Spectrum:
    """
    Hyperspectral spectrum with wavelength-aware indexing.

    Wavelengths are assumed to be sorted.

    Indexing examples (matching HyPy original behaviour):
        S[0]          → scalar value at integer index 0
        S[2200.0]     → value at nearest wavelength to 2200 nm  (float index)
        S[2000:2400]  → sub-spectrum from 2000 to 2400 nm       (float slice)
        S(2200.0)     → same as S[2200.0]                       (__call__)
    """

    def __init__(self, wavelength=None, spectrum=None, name=None,
                 description='', wavelength_units=None, fwhm=None):
        self.wavelength = numpy.array(wavelength, dtype=numpy.float64)
        self.spectrum   = numpy.array(spectrum,   dtype=numpy.float64)
        self.shape      = self.spectrum.shape
        self.name       = name
        self.description = description
        self.wavelength_units = wavelength_units
        self.fwhm       = fwhm
        self.index      = 0
        # shorthand aliases (as in original)
        self.w = self.wavelength
        self.s = self.spectrum
        # wavelength→index hint cache
        self._wavelength2index_hints = {}

    # ── iteration ─────────────────────────────────────────────────────────────

    def __iter__(self):
        return self[...]

    def __next__(self):
        if self.index < len(self):
            result = self.wavelength[self.index], self.spectrum[self.index]
            self.index += 1
            return result
        raise StopIteration

    def __len__(self):
        return len(self.spectrum)

    # ── indexing machinery ────────────────────────────────────────────────────

    def _index(self, s):
        """Translate any index / slice / float / string to proper integer index(es)."""
        if s is None:
            return None
        elif isinstance(s, slice):
            start, stop = s.start, s.stop
            step = 1 if s.step is None else s.step
            if step < 0:
                start, stop, step = stop, start, -step
            start = 0         if start is None else self._index(start)
            stop  = len(self) if stop  is None else self._index(stop)
            stop  = min(len(self), stop + 1)
            return list(range(start, stop, step))
        elif isinstance(s, float):
            return self.wavelength2index(s)
        elif isinstance(s, int):
            if s < 0:
                s = s % len(self)
            return s
        elif isinstance(s, str):
            return self.wavelength.searchsorted(s)
        elif isinstance(s, collections.abc.Iterable):
            return list(map(self._index, s))
        else:
            return s

    def __getitem__(self, i):
        """
        Flexible indexing — integers, floats (wavelengths), slices, tuples.

        Float index:  S[2200.0]   → scalar value at nearest wavelength
        Float slice:  S[2000:2400] → Spectrum sub-range
        Int index:    S[5]        → scalar at band 5
        Ellipsis:     S[...]      → copy of self
        """
        if i is Ellipsis:
            return Spectrum(wavelength=self.wavelength.copy(),
                            spectrum=self.spectrum.copy(),
                            name=self.name, description=self.description)
        else:
            idx = self._index(i)
            if isinstance(idx, collections.abc.Iterable) and idx:
                idx = sorted(set(numpy.r_[tuple(idx)]))
            s = self.spectrum[idx]
            w = self.wavelength[idx]
            if numpy.shape(s):          # array result → new Spectrum
                return Spectrum(wavelength=w, spectrum=s,
                                name=self.name, description=self.description)
            else:                       # scalar result
                return float(s)

    def __setitem__(self, i, value):
        if i is Ellipsis:
            self.spectrum = value
        else:
            idx = self._index(i)
            if isinstance(idx, collections.abc.Iterable) and idx:
                idx = sorted(set(numpy.r_[tuple(idx)]))
            self.spectrum[idx] = value

    def __call__(self, wav):
        """S(wav) — return value at wavelength wav.  Equivalent to S[wav]."""
        return self[wav]

    # ── wavelength ↔ index helpers ────────────────────────────────────────────

    def wavelength2index(self, wavelength):
        """Return index of band with wavelength closest to *wavelength*."""
        if wavelength in self._wavelength2index_hints:
            return self._wavelength2index_hints[wavelength]
        index = int(numpy.argmin(numpy.abs(self.wavelength - wavelength)))
        self._wavelength2index_hints[wavelength] = index
        return index

    def index2wavelength(self, index):
        return self.wavelength[index]

    # ── resampling ────────────────────────────────────────────────────────────

    def resample(self, w=None, step=None, mode='linear'):
        """Resample spectrum to wavelengths *w* (array) or uniform *step*."""
        if step:
            delta = 1e-6
            if w is None:
                w = numpy.arange(self.wavelength.min(),
                                 self.wavelength.max() + delta, step)
            else:
                w = numpy.arange(numpy.min(w), numpy.max(w) + delta, step)
        if w is None:
            return self
        s = interp1d(self.wavelength, self.spectrum, kind=mode,
                     bounds_error=False, fill_value=numpy.nan)(w)
        return Spectrum(wavelength=w, spectrum=s,
                        name=self.name, description=self.description)

    def resampled(self, w=None, step=None, mode='linear'):
        """Return resampled spectrum values as numpy array."""
        return self.resample(w=w, step=step, mode=mode).spectrum

    def interpol(self, w):
        """Linear interpolation at wavelength w."""
        return _interpol(self.spectrum, self.wavelength, w)

    # ── coercion (the missing piece!) ─────────────────────────────────────────

    def __coerce__(self, other):
        """
        Coerce two Spectrum objects onto their overlapping wavelength union.

        When *other* is a scalar or array this is a no-op.
        Explicitly called from every arithmetic/comparison operator — Python 3
        does NOT call __coerce__ automatically (it was a Python 2 mechanism).
        """
        if isinstance(other, Spectrum):
            wmin = max(self.wavelength.min(), other.wavelength.min())
            wmax = min(self.wavelength.max(), other.wavelength.max())
            w = numpy.array(sorted(set(self.wavelength) | set(other.wavelength)))
            w = w[(wmin <= w) & (w <= wmax)]
            return self.resample(w), other.resample(w)
        return self, other

    # ── arithmetic operators ──────────────────────────────────────────────────

    def __add__(self, other):
        self, other = self.__coerce__(other)
        return Spectrum(wavelength=self.wavelength,
                        spectrum=self.spectrum + getattr(other, 'spectrum', other),
                        name=self.name, description=self.description)

    def __radd__(self, other):
        self, other = self.__coerce__(other)
        return self.__add__(other)

    def __sub__(self, other):
        self, other = self.__coerce__(other)
        return Spectrum(wavelength=self.wavelength,
                        spectrum=self.spectrum - getattr(other, 'spectrum', other),
                        name=self.name, description=self.description)

    def __rsub__(self, other):
        self, other = self.__coerce__(other)
        return Spectrum(wavelength=self.wavelength,
                        spectrum=getattr(other, 'spectrum', other) - self.spectrum,
                        name=self.name, description=self.description)

    def __mul__(self, other):
        self, other = self.__coerce__(other)
        return Spectrum(wavelength=self.wavelength,
                        spectrum=self.spectrum * getattr(other, 'spectrum', other),
                        name=self.name, description=self.description)

    def __rmul__(self, other):
        self, other = self.__coerce__(other)
        return self.__mul__(other)

    def __truediv__(self, other):
        self, other = self.__coerce__(other)
        return Spectrum(wavelength=self.wavelength,
                        spectrum=self.spectrum / getattr(other, 'spectrum', other),
                        name=self.name, description=self.description)

    def __rtruediv__(self, other):
        self, other = self.__coerce__(other)
        return Spectrum(wavelength=self.wavelength,
                        spectrum=getattr(other, 'spectrum', other) / self.spectrum,
                        name=self.name, description=self.description)

    def __pow__(self, other):
        self, other = self.__coerce__(other)
        return Spectrum(wavelength=self.wavelength,
                        spectrum=self.spectrum ** getattr(other, 'spectrum', other),
                        name=self.name, description=self.description)

    def __rpow__(self, other):
        self, other = self.__coerce__(other)
        return Spectrum(wavelength=self.wavelength,
                        spectrum=getattr(other, 'spectrum', other) ** self.spectrum,
                        name=self.name, description=self.description)

    def __neg__(self):
        return Spectrum(wavelength=self.wavelength, spectrum=-self.spectrum,
                        name=self.name, description=self.description)

    def __pos__(self):
        return Spectrum(wavelength=self.wavelength, spectrum=+self.spectrum,
                        name=self.name, description=self.description)

    def __abs__(self):
        return Spectrum(wavelength=self.wavelength,
                        spectrum=numpy.abs(self.spectrum),
                        name=self.name, description=self.description)

    # ── comparison operators ──────────────────────────────────────────────────

    def __lt__(self, other):
        self, other = self.__coerce__(other)
        return Spectrum(wavelength=self.wavelength,
                        spectrum=self.spectrum < getattr(other, 'spectrum', other),
                        name=self.name, description=self.description)

    def __le__(self, other):
        self, other = self.__coerce__(other)
        return Spectrum(wavelength=self.wavelength,
                        spectrum=self.spectrum <= getattr(other, 'spectrum', other),
                        name=self.name, description=self.description)

    def __eq__(self, other):
        self, other = self.__coerce__(other)
        return Spectrum(wavelength=self.wavelength,
                        spectrum=numpy.equal(self.spectrum,
                                             getattr(other, 'spectrum', other)),
                        name=self.name, description=self.description)

    def __ne__(self, other):
        self, other = self.__coerce__(other)
        return Spectrum(wavelength=self.wavelength,
                        spectrum=self.spectrum != getattr(other, 'spectrum', other),
                        name=self.name, description=self.description)

    def __ge__(self, other):
        self, other = self.__coerce__(other)
        return Spectrum(wavelength=self.wavelength,
                        spectrum=self.spectrum >= getattr(other, 'spectrum', other),
                        name=self.name, description=self.description)

    def __gt__(self, other):
        self, other = self.__coerce__(other)
        return Spectrum(wavelength=self.wavelength,
                        spectrum=self.spectrum > getattr(other, 'spectrum', other),
                        name=self.name, description=self.description)

    # ── numpy method set (full set from HyPy original) ────────────────────────

    def _wrap1(self, fn):
        return Spectrum(wavelength=self.wavelength,
                        spectrum=fn(self.spectrum),
                        name=self.name, description=self.description)

    def _wrap2(self, other, fn):
        self, other = self.__coerce__(other)
        return Spectrum(wavelength=self.wavelength,
                        spectrum=fn(self.spectrum, getattr(other, 'spectrum', other)),
                        name=self.name, description=self.description)

    def log(self):        return self._wrap1(numpy.log)
    def log2(self):       return self._wrap1(numpy.log2)
    def log10(self):      return self._wrap1(numpy.log10)
    def exp(self):        return self._wrap1(numpy.exp)
    def exp2(self):       return self._wrap1(numpy.exp2)
    def sqrt(self):       return self._wrap1(numpy.sqrt)
    def square(self):     return self._wrap1(numpy.square)
    def reciprocal(self): return self._wrap1(numpy.reciprocal)
    def negative(self):   return self._wrap1(numpy.negative)
    def absolute(self):   return self._wrap1(numpy.absolute)
    def sign(self):       return self._wrap1(numpy.sign)
    def sin(self):        return self._wrap1(numpy.sin)
    def cos(self):        return self._wrap1(numpy.cos)
    def tan(self):        return self._wrap1(numpy.tan)
    def arcsin(self):     return self._wrap1(numpy.arcsin)
    def arccos(self):     return self._wrap1(numpy.arccos)
    def arctan(self):     return self._wrap1(numpy.arctan)
    def sinh(self):       return self._wrap1(numpy.sinh)
    def cosh(self):       return self._wrap1(numpy.cosh)
    def tanh(self):       return self._wrap1(numpy.tanh)
    def arcsinh(self):    return self._wrap1(numpy.arcsinh)
    def arccosh(self):    return self._wrap1(numpy.arccosh)
    def arctanh(self):    return self._wrap1(numpy.arctanh)
    def deg2rad(self):    return self._wrap1(numpy.deg2rad)
    def rad2deg(self):    return self._wrap1(numpy.rad2deg)
    def round(self, *a):  return self._wrap1(numpy.round)

    def add(self, other):          return self._wrap2(other, numpy.add)
    def subtract(self, other):     return self._wrap2(other, numpy.subtract)
    def multiply(self, other):     return self._wrap2(other, numpy.multiply)
    def divide(self, other):       return self._wrap2(other, numpy.divide)
    def power(self, other):        return self._wrap2(other, numpy.power)
    def arctan2(self, other):      return self._wrap2(other, numpy.arctan2)
    def hypot(self, other):        return self._wrap2(other, numpy.hypot)
    def greater(self, other):      return self._wrap2(other, numpy.greater)
    def greater_equal(self, other):return self._wrap2(other, numpy.greater_equal)
    def less(self, other):         return self._wrap2(other, numpy.less)
    def less_equal(self, other):   return self._wrap2(other, numpy.less_equal)
    def not_equal(self, other):    return self._wrap2(other, numpy.not_equal)
    def equal(self, other):        return self._wrap2(other, numpy.equal)
    def maximum(self, other):      return self._wrap2(other, numpy.maximum)
    def minimum(self, other):      return self._wrap2(other, numpy.minimum)

    def clip(self, a, b, *args):
        return Spectrum(wavelength=self.wavelength,
                        spectrum=numpy.clip(self.spectrum, a, b),
                        name=self.name, description=self.description)

    def copy(self):
        return Spectrum(wavelength=self.wavelength.copy(),
                        spectrum=self.spectrum.copy(),
                        name=self.name, description=self.description)

    def cumprod(self, *a):
        return Spectrum(wavelength=self.wavelength,
                        spectrum=numpy.cumprod(self.spectrum),
                        name=self.name, description=self.description)

    def cumsum(self, *a):
        return Spectrum(wavelength=self.wavelength,
                        spectrum=numpy.cumsum(self.spectrum),
                        name=self.name, description=self.description)

    def astype(self, t):
        return Spectrum(wavelength=self.wavelength,
                        spectrum=self.spectrum.astype(t),
                        name=self.name, description=self.description)

    def int(self):   return self.astype('int')
    def float(self): return self.astype('float')

    # scalar reductions
    def mean(self, *a):  return float(numpy.mean(self.spectrum))
    def min(self, *a):   return float(numpy.min(self.spectrum))
    def max(self, *a):   return float(numpy.max(self.spectrum))
    def sum(self, *a):   return float(numpy.sum(self.spectrum))
    def prod(self, *a):  return float(numpy.prod(self.spectrum))
    def std(self, *a):   return float(numpy.std(self.spectrum))
    def var(self, *a):   return float(numpy.var(self.spectrum))
    def all(self, *a):   return bool(numpy.all(self.spectrum))
    def any(self, *a):   return bool(numpy.any(self.spectrum))

    # ── spectral shape operations ─────────────────────────────────────────────

    def nonan(self):
        idx = numpy.where(numpy.isfinite(self.spectrum))[0]
        return Spectrum(wavelength=self.wavelength[idx],
                        spectrum=self.spectrum[idx],
                        name=self.name, description=self.description)

    def hull(self):
        """Return convex hull as a Spectrum."""
        S = self.nonan()
        if len(S) < 2:
            return numpy.nan
        try:
            Hvert = scipy.spatial.ConvexHull(
                numpy.vstack((S.wavelength, S.spectrum)).T
            ).vertices[::-1]
            idx = numpy.roll(Hvert, -Hvert.argmin())
            idx = idx[:idx.argmax() + 1]
        except Exception:
            idx = numpy.array([0, len(S) - 1])
        return Spectrum(wavelength=S.wavelength[idx],
                        spectrum=S.spectrum[idx],
                        name=self.name, description=self.description)

    def nohull(self, mode='div'):
        """Continuum-removed spectrum ('div' or 'sub')."""
        if mode == 'div':
            return self / self.hull()
        elif mode == 'sub':
            return 1 + (self - self.hull())
        return self

    def peaks(self):
        """Absorption peaks = hull – spectrum."""
        return self.hull() - self

    def localminidx(self, n=None):
        a = self.spectrum
        idx = numpy.where((a[1:-1] < a[:-2]) & (a[1:-1] < a[2:]))[0] + 1
        if n and len(idx):
            s = self.spectrum[idx]
            s, idx = list(zip(*sorted(sorted(zip(s, idx))[:n],
                                      key=lambda x: x[1])))
        return numpy.array(idx)

    def localminfit(self, n=None, broad=False):
        idx = self.localminidx(n)
        return self._fitparabola_broad(idx) if broad else self._fitparabola(idx)

    def _fitparabola(self, idx):
        w, s = self.wavelength, self.spectrum
        new_w, new_s = [], []
        for i in idx:
            x = [w[i-1], w[i], w[i+1]]
            y = [s[i-1], s[i], s[i+1]]
            coef = numpy.polyfit(x, y, 2)
            a, b, c = coef
            x_ext = -b / (2 * a)
            new_w.append(x_ext)
            new_s.append(numpy.polyval(coef, x_ext))
        return pSpectrum(wavelength=new_w, spectrum=new_s,
                         name=self.name, description=self.description)

    def _fitparabola_broad(self, idx):
        w, s = self.wavelength, self.spectrum
        new_w, new_s = [], []
        for i in idx:
            lo = i - 1
            while lo - 1 > 0 and s[lo-1] <= (s[i]+1)/2:
                lo -= 1
            hi = i + 1
            while hi + 1 < len(s) - 1 and s[hi+1] <= (s[i]+1)/2:
                hi += 1
            coef = numpy.polyfit(w[lo:hi+1], s[lo:hi+1], 2)
            a, b, c = coef
            x_ext = -b / (2 * a)
            new_w.append(x_ext)
            new_s.append(numpy.polyval(coef, x_ext))
        return pSpectrum(wavelength=new_w, spectrum=new_s,
                         name=self.name, description=self.description)

    def localmin(self, n=None):
        idx = self.localminidx(n)
        return pSpectrum(wavelength=self.wavelength[idx],
                         spectrum=self.spectrum[idx],
                         name=self.name, description=self.description)

    def localmaxidx(self, n=None):
        a = self.spectrum
        idx = numpy.where((a[1:-1] > a[:-2]) & (a[1:-1] > a[2:]))[0] + 1
        if n and len(idx):
            s = self.spectrum[idx]
            s, idx = list(zip(*sorted(sorted(zip(s, idx), reverse=True)[:n],
                                      key=lambda x: x[1])))
        return numpy.array(idx)

    def localmax(self, n=None):
        idx = self.localmaxidx(n)
        return pSpectrum(wavelength=self.wavelength[idx],
                         spectrum=self.spectrum[idx],
                         name=self.name, description=self.description)

    def minwav(self, n=None, mode='div', broad=False):
        S = 1 - self.nohull(mode=mode).localminfit(n, broad=broad)
        return pSpectrum(wavelength=S.wavelength, spectrum=S.spectrum,
                         name=self.name, description=self.description)

    def smooth(self, n=1):
        s = self.spectrum
        for _ in range(n):
            s = numpy.hstack((s[0],
                               (2*s[1:-1] + s[:-2] + s[2:]) / 4.0,
                               s[-1]))
        return Spectrum(wavelength=self.wavelength, spectrum=s,
                        name=self.name, description=self.description)

    def gradient(self):
        s = self.spectrum
        w = self.wavelength
        s = numpy.hstack((0, (s[2:] - s[:-2]) / (w[2:] - w[:-2]), 0))
        return Spectrum(wavelength=self.wavelength, spectrum=s,
                        name=self.name, description=self.description)

    def second(self):
        s = self.spectrum
        w = self.wavelength
        s = numpy.hstack((0,
                           (s[2:] - 2*s[1:-1] + s[:-2]) /
                           ((w[2:] - w[1:-1]) * (w[1:-1] - w[:-2])),
                           0))
        return Spectrum(wavelength=self.wavelength, spectrum=s,
                        name=self.name, description=self.description)

    def convolve(self, kernel):
        s = self.spectrum
        a, b, c = kernel
        sm = sum(kernel)
        s = numpy.hstack((sm*s[0],
                           (a*s[:-2] + b*s[1:-1] + c*s[2:]),
                           sm*s[-1]))
        return Spectrum(wavelength=self.wavelength, spectrum=s,
                        name=self.name, description=self.description)

    def cut(self, w1=None, w2=None):
        if w1 is None: w1 = self.wavelength[0]
        if w2 is None: w2 = self.wavelength[-1]
        if w1 > w2:    w1, w2 = w2, w1
        i1 = self.wavelength.searchsorted(w1)
        i2 = self.wavelength.searchsorted(w2, 'right')
        w  = self.wavelength[i1:i2]
        s  = self.spectrum[i1:i2]
        if w1 not in self.wavelength:
            w = numpy.hstack((w1, w))
            s = numpy.hstack((self.interpol(w1), s))
        if w2 not in self.wavelength or len(w) == 1:
            w = numpy.hstack((w, w2))
            s = numpy.hstack((s, self.interpol(w2)))
        return Spectrum(wavelength=w, spectrum=s,
                        name=self.name, description=self.description)

    def busyness(self):
        return float(numpy.sum(numpy.abs(
            self.spectrum[:-1] - self.spectrum[1:])))

    def sort(self, reverse=False):
        pairs = sorted(zip(self.wavelength, self.spectrum), reverse=reverse)
        w, s  = zip(*pairs)
        return Spectrum(wavelength=list(w), spectrum=list(s),
                        name=self.name, description=self.description)

    def sortvalues(self, reverse=False):
        pairs = sorted(zip(self.wavelength, self.spectrum),
                       key=lambda x: x[1], reverse=reverse)
        w, s  = zip(*pairs)
        return Spectrum(wavelength=list(w), spectrum=list(s),
                        name=self.name, description=self.description)

    def fit(self, n=1):
        coef = numpy.polyfit(self.wavelength, self.spectrum, n)
        return Spectrum(wavelength=self.wavelength,
                        spectrum=numpy.polyval(coef, self.wavelength),
                        name=self.name, description=self.description)

    def where(self):
        return numpy.where(self.spectrum)

    def dict(self):
        return collections.OrderedDict(zip(self.wavelength, self.spectrum))

    def tuple(self):
        return tuple(zip(self.wavelength, self.spectrum))

    # ── repr / str ────────────────────────────────────────────────────────────

    def __repr__(self):
        lines = ['%s %s' % (w, s)
                 for w, s in zip(self.wavelength, self.spectrum)]
        return '\n'.join(lines) + '\n'

    def __str__(self):
        return ' '.join('%s %s' % (w, s)
                        for w, s in zip(self.wavelength, self.spectrum))


# ── pSpectrum (point spectrum) ────────────────────────────────────────────────

class pSpectrum(Spectrum):
    """
    A pSpectrum is a Spectrum whose points do not need to be sorted and
    that plots as points (dots) rather than lines.
    Inherits all Spectrum behaviour.
    """

    def sort(self, reverse=False):
        pairs = sorted(zip(self.wavelength, self.spectrum), reverse=reverse)
        w, s  = zip(*pairs)
        return pSpectrum(wavelength=list(w), spectrum=list(s),
                         name=self.name, description=self.description)

    def sortvalues(self, reverse=False):
        pairs = sorted(zip(self.wavelength, self.spectrum),
                       key=lambda x: x[1], reverse=reverse)
        w, s  = zip(*pairs)
        return pSpectrum(wavelength=list(w), spectrum=list(s),
                         name=self.name, description=self.description)
