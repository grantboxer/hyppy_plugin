@echo off
REM Package QGIS Plugin for Windows
REM Creates a ZIP file ready for installation in QGIS

setlocal enabledelayedexpansion

set PLUGIN_NAME=hyperspectral_tools

REM Read version from metadata.txt
for /f "tokens=2 delims==" %%a in ('findstr "version=" metadata.txt') do set VERSION=%%a
set OUTPUT_FILE=%PLUGIN_NAME%_v%VERSION%.zip

echo Packaging %PLUGIN_NAME% version %VERSION%...
echo.

REM Remove old package if exists
if exist "%OUTPUT_FILE%" (
    del "%OUTPUT_FILE%"
    echo Removed old package
)

REM Create temporary directory
set TEMP_DIR=%TEMP%\qgis_plugin_%RANDOM%
set PLUGIN_DIR=%TEMP_DIR%\%PLUGIN_NAME%
mkdir "%PLUGIN_DIR%"
mkdir "%PLUGIN_DIR%\algorithms"
mkdir "%PLUGIN_DIR%\core"
mkdir "%PLUGIN_DIR%\ui"
mkdir "%PLUGIN_DIR%\resources"

echo Copying files...

REM Copy files
copy __init__.py "%PLUGIN_DIR%\" >nul && echo   * __init__.py
copy metadata.txt "%PLUGIN_DIR%\" >nul && echo   * metadata.txt
copy hyperspectral_plugin.py "%PLUGIN_DIR%\" >nul && echo   * hyperspectral_plugin.py
copy hyppy_provider.py "%PLUGIN_DIR%\" >nul && echo   * hyppy_provider.py
copy README.md "%PLUGIN_DIR%\" >nul && echo   * README.md
copy INSTALL.md "%PLUGIN_DIR%\" >nul && echo   * INSTALL.md
copy DEVELOPER.md "%PLUGIN_DIR%\" >nul && echo   * DEVELOPER.md
copy icon.svg "%PLUGIN_DIR%\" >nul && echo   * icon.svg
copy example_spectral_library.csv "%PLUGIN_DIR%\" >nul && echo   * example_spectral_library.csv

copy algorithms\__init__.py "%PLUGIN_DIR%\algorithms\" >nul && echo   * algorithms\__init__.py
copy algorithms\sam_algorithm.py "%PLUGIN_DIR%\algorithms\" >nul && echo   * algorithms\sam_algorithm.py

copy core\__init__.py "%PLUGIN_DIR%\core\" >nul && echo   * core\__init__.py

REM Create ZIP using PowerShell
echo.
echo Creating ZIP archive...
powershell -Command "Compress-Archive -Path '%PLUGIN_DIR%' -DestinationPath '%OUTPUT_FILE%' -Force"

REM Cleanup
rmdir /s /q "%TEMP_DIR%"

echo.
echo Package created: %OUTPUT_FILE%
echo.
echo To install:
echo   1. Open QGIS
echo   2. Go to Plugins -^> Manage and Install Plugins
echo   3. Click 'Install from ZIP'
echo   4. Select %OUTPUT_FILE%
echo.
pause
