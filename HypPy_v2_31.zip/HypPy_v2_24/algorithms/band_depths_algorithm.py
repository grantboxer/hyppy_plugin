"""
Band Depths Algorithm for QGIS Processing

Computes band depths for all bands in a hyperspectral image.
Band depth = (top - middle) / top, where top = (left + right) / 2.

Ported from HyPy banddepths.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original Copyright (C) 2010-2022 Wim Bakker

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis
)

from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset


class BandDepthsAlgorithm(QgsProcessingAlgorithm):
    """
    Band Depths Algorithm

    For each band i (from delta to n_bands-delta), computes:
        top    = (band[i-delta] + band[i+delta]) / 2
        depth  = (top - band[i]) / top

    Positive values indicate absorption features (band centre is below neighbours).
    Output has (n_bands - 2*delta) bands.
    """

    INPUT = 'INPUT'
    DELTA = 'DELTA'
    USE_BBL = 'USE_BBL'
    OUTPUT = 'OUTPUT'

    def initAlgorithm(self, config=None):
        """Define inputs and outputs."""

        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT,
                'Input Hyperspectral Image',
                optional=False
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.DELTA,
                'Delta (band shift between centre and shoulders)',
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=1,
                minValue=1,
                optional=False
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.USE_BBL,
                'Use Bad Band List (BBL) from metadata',
                defaultValue=True,
                optional=True
            )
        )

        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                'Output Band Depths Image'
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """Execute the band depths algorithm."""

        input_layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        delta = self.parameterAsInt(parameters, self.DELTA, context)
        use_bbl = self.parameterAsBoolean(parameters, self.USE_BBL, context)
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if input_layer is None:
            raise QgsProcessingException('Invalid input layer')

        ds = gdal.Open(input_layer.source())
        if ds is None:
            raise QgsProcessingException(f'Cannot open raster: {input_layer.source()}')

        n_bands = ds.RasterCount
        n_rows = ds.RasterYSize
        n_cols = ds.RasterXSize

        if 2 * delta >= n_bands:
            raise QgsProcessingException(
                f'2 * delta ({2*delta}) must be less than number of bands ({n_bands})'
            )

        n_out_bands = n_bands - 2 * delta
        feedback.pushInfo(f'Input bands: {n_bands}, Delta: {delta}, Output bands: {n_out_bands}')

        raster_path = input_layer.source()
        wavelengths = get_wavelengths_from_dataset(ds, n_bands, raster_path, feedback)
        nodata = ds.GetRasterBand(1).GetNoDataValue()

        # Create output
        driver = gdal.GetDriverByName('GTiff')
        out_ds = driver.Create(output_path, n_cols, n_rows, n_out_bands, gdal.GDT_Float64)
        out_ds.SetGeoTransform(ds.GetGeoTransform())
        out_ds.SetProjection(ds.GetProjection())

        old_settings = np.seterr(all='ignore')

        for i in range(delta, n_bands - delta):
            if feedback.isCanceled():
                break
            out_i = i - delta
            feedback.setProgress(int(out_i * 100 / n_out_bands))

            b_left   = ds.GetRasterBand(i - delta + 1).ReadAsArray().astype(np.float64)
            b_middle = ds.GetRasterBand(i + 1).ReadAsArray().astype(np.float64)
            b_right  = ds.GetRasterBand(i + delta + 1).ReadAsArray().astype(np.float64)

            if nodata is not None:
                b_left[b_left == nodata] = np.nan
                b_middle[b_middle == nodata] = np.nan
                b_right[b_right == nodata] = np.nan

            top = (b_left + b_right) / 2.0
            depth = (top - b_middle) / top

            out_band = out_ds.GetRasterBand(out_i + 1)
            out_band.WriteArray(depth)
            out_band.SetNoDataValue(np.nan)

            if wavelengths is not None:
                out_band.SetDescription(
                    f'Depth at {wavelengths[i]:.2f}nm (shoulders {wavelengths[i-delta]:.2f}/{wavelengths[i+delta]:.2f}nm)'
                )
            else:
                out_band.SetDescription(
                    f'Depth band {i+1} (shoulders {i-delta+1}/{i+delta+1})'
                )

        np.seterr(**old_settings)

        # Write metadata
        metadata = {'band_depths_delta': str(delta)}
        if wavelengths is not None:
            wav_out = wavelengths[delta:n_bands - delta]
            metadata['wavelength'] = '{' + ', '.join([f'{w:.4f}' for w in wav_out]) + '}'
            metadata['wavelength_units'] = 'Nanometers'
        out_ds.SetMetadata(metadata)

        out_ds.FlushCache()
        del ds, out_ds

        feedback.pushInfo(f'Band depths completed. {n_out_bands} output bands written.')
        return {self.OUTPUT: output_path}

    # _get_wavelengths removed — use get_wavelengths_from_dataset from core.envi_header
    def name(self):
        return 'banddepths'

    def displayName(self):
        return 'Band Depths'

    def group(self):
        return '5 - Spectral Processing Tools'

    def groupId(self):
        return '5_spectral_processing_tools'

    def shortHelpString(self):
        return (
            'Computes band depths for all bands in a hyperspectral image.\n\n'
            'For each centre band i, the depth is computed as:\n'
            '    top   = (band[i-delta] + band[i+delta]) / 2\n'
            '    depth = (top - band[i]) / top\n\n'
            'Positive values indicate absorption features (the centre band is '
            'below the mean of its neighbours).\n\n'
            'Output has (n_bands - 2*delta) bands.\n\n'
            'Delta controls the distance to the shoulder bands used to compute '
            'the continuum top.'
        )

    def createInstance(self):
        return BandDepthsAlgorithm()
