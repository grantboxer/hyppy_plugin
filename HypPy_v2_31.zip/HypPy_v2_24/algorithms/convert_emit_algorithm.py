"""
Convert EMIT L2A NetCDF to ENVI Algorithm for QGIS Processing

Reads an EMIT L2A NetCDF4 file and writes four ENVI flat-binary files:
  <basename>_refl   — reflectance cube (BIL, float32, with wavelengths/fwhm/bbl)
  <basename>_lonlat — longitude + latitude bands (BSQ)
  <basename>_elev   — elevation band (BSQ)
  <basename>_glt    — GLT x/y bands for orthorectification (BSQ, int32)

Ported from HyPy convemit.py
Original Author: Wim Bakker, University of Twente (created 2024-12-06)

Copyright (C) 2025 Grant Boxer
Original HyPy Copyright (C) 2010-2022 Wim Bakker, University of Twente

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import os
import sys

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingException,
    QgsMessageLog,
    Qgis,
)


# ── ENVI header writer ─────────────────────────────────────────────────────

def _write_envi_hdr(path, lines, samples, bands, data_type_str,
                    interleave='bsq', band_names=None,
                    wavelength=None, fwhm=None, bbl=None,
                    description=''):
    """Write an ENVI .hdr sidecar file."""

    _DTYPE_MAP = {
        'uint8':   1,  'int16':   2,  'int32':   3,
        'float32': 4,  'float64': 5,  'uint16': 12,
        'uint32': 13,  'int64':  14,  'uint64': 15,
    }
    dtype_num = _DTYPE_MAP.get(str(data_type_str), 4)
    byte_order = 0 if sys.byteorder == 'little' else 1

    hdr_path = path + '.hdr'
    with open(hdr_path, 'w') as f:
        f.write("ENVI\n")
        if description:
            f.write("description = { %s }\n" % description)
        f.write("samples = %d\n" % samples)
        f.write("lines = %d\n" % lines)
        f.write("bands = %d\n" % bands)
        f.write("header offset = 0\n")
        f.write("file type = ENVI Standard\n")
        f.write("data type = %d\n" % dtype_num)
        f.write("interleave = %s\n" % interleave)
        f.write("byte order = %d\n" % byte_order)

        if band_names:
            f.write("band names = {\n  " + ",\n  ".join(str(n) for n in band_names) + " }\n")
        if wavelength is not None and len(wavelength):
            f.write("wavelength units = Nanometers\n")
            f.write("wavelength = {\n  " + ",\n  ".join("%.4f" % w for w in wavelength) + " }\n")
        if fwhm is not None and len(fwhm):
            f.write("fwhm = {\n  " + ",\n  ".join("%.4f" % v for v in fwhm) + " }\n")
        if bbl is not None and len(bbl):
            f.write("bbl = {\n  " + ", ".join(str(int(v)) for v in bbl) + " }\n")

    return hdr_path


# ── Core conversion ────────────────────────────────────────────────────────

def _convert_emit(filename, feedback=None):
    """Read EMIT L2A NetCDF4 and write ENVI files."""

    def log(msg):
        if feedback:
            feedback.pushInfo(str(msg))
        else:
            print(msg)

    # ── netCDF4 ────────────────────────────────────────────────────────
    try:
        from netCDF4 import Dataset
    except ImportError:
        return False, (
            "The 'netCDF4' Python package is required for EMIT conversion.\n"
            "Install it with:  pip install netCDF4  (or via your Python/conda env)."
        )

    try:
        import numpy as np
    except ImportError:
        return False, "NumPy is required but not available."

    basename = os.path.splitext(filename)[0]
    log("Input:  %s" % filename)
    log("Output base: %s" % basename)

    try:
        rootgrp = Dataset(filename, 'r')
    except Exception as e:
        return False, "Cannot open NetCDF4 file: %s" % str(e)

    log("Title: %s" % getattr(rootgrp, 'title', '(no title)'))

    if 'reflectance' not in rootgrp.variables:
        rootgrp.close()
        return False, "No 'reflectance' variable found in the dataset."

    # ── Reflectance cube ───────────────────────────────────────────────
    log("Reading reflectance ...")
    refl_var = rootgrp.variables['reflectance']
    dims = refl_var.get_dims()
    lines, samples, bands = dims[0].size, dims[1].size, dims[2].size
    data_type = refl_var.dtype.type
    log("  Lines=%d  Samples=%d  Bands=%d  dtype=%s" % (lines, samples, bands, data_type))

    sbp = rootgrp.groups['sensor_band_parameters']
    wavelengths = sbp.variables['wavelengths'][...].data.tolist()
    fwhm        = sbp.variables['fwhm'][...].data.tolist()
    bbl         = sbp.variables['good_wavelengths'][...].data.tolist()

    refl_path = basename + '_refl'
    refl_data = rootgrp.variables['reflectance'][...]  # (lines, samples, bands)

    # Write BIL: reshape to (lines, bands, samples) then dump
    bil = np.transpose(refl_data.data, (0, 2, 1))   # (lines, bands, samples)
    bil.tofile(refl_path)
    _write_envi_hdr(refl_path, lines, samples, bands,
                    str(np.dtype(data_type)),
                    interleave='bil',
                    wavelength=wavelengths, fwhm=fwhm, bbl=bbl,
                    description=os.path.basename(filename))
    log("  Written: %s" % refl_path)
    if feedback:
        feedback.setProgress(30)

    # ── Location group: lon/lat ─────────────────────────────────────────
    log("Reading location (lon/lat) ...")
    loc = rootgrp.groups['location']
    lon_dims = loc.variables['lon'].get_dims()
    loc_lines, loc_samples = lon_dims[0].size, lon_dims[1].size
    ll_dtype = str(loc.variables['lon'].dtype)

    lonlat_path = basename + '_lonlat'
    lon_data = loc.variables['lon'][...].data          # (lines, samples)
    lat_data = loc.variables['lat'][...].data

    # BSQ: band0=lon, band1=lat → stack and write
    import numpy as np
    lonlat = np.stack([lon_data, lat_data], axis=0)    # (2, lines, samples)
    lonlat.tofile(lonlat_path)
    _write_envi_hdr(lonlat_path, loc_lines, loc_samples, 2,
                    ll_dtype, interleave='bsq',
                    band_names=['longitude', 'latitude'],
                    description=os.path.basename(filename))
    log("  Written: %s" % lonlat_path)
    if feedback:
        feedback.setProgress(55)

    # ── Elevation ──────────────────────────────────────────────────────
    log("Reading elevation ...")
    elev_dims = loc.variables['elev'].get_dims()
    elev_lines, elev_samples = elev_dims[0].size, elev_dims[1].size
    elev_dtype = str(loc.variables['elev'].dtype)
    elev_data = loc.variables['elev'][...].data[np.newaxis, ...]  # (1, lines, samples)

    elev_path = basename + '_elev'
    elev_data.tofile(elev_path)
    _write_envi_hdr(elev_path, elev_lines, elev_samples, 1,
                    elev_dtype, interleave='bsq',
                    band_names=['elevation'],
                    description=os.path.basename(filename))
    log("  Written: %s" % elev_path)
    if feedback:
        feedback.setProgress(75)

    # ── GLT ────────────────────────────────────────────────────────────
    log("Reading GLT ...")
    glt_dims = loc.variables['glt_x'].get_dims()
    glt_lines, glt_samples = glt_dims[0].size, glt_dims[1].size
    glt_dtype = str(loc.variables['glt_x'].dtype)
    glt_x = loc.variables['glt_x'][...].data
    glt_y = loc.variables['glt_y'][...].data
    glt = np.stack([glt_x, glt_y], axis=0)             # (2, lines, samples)

    glt_path = basename + '_glt'
    glt.tofile(glt_path)
    _write_envi_hdr(glt_path, glt_lines, glt_samples, 2,
                    glt_dtype, interleave='bsq',
                    band_names=['glt_x', 'glt_y'],
                    description=os.path.basename(filename))
    log("  Written: %s" % glt_path)
    if feedback:
        feedback.setProgress(100)

    rootgrp.close()

    log("")
    log("Completed. Four output files written:")
    log("  %s" % refl_path)
    log("  %s" % lonlat_path)
    log("  %s" % elev_path)
    log("  %s" % glt_path)

    return True, "EMIT conversion completed — 4 ENVI files written."


# ── QGIS Algorithm wrapper ─────────────────────────────────────────────────

class ConvertEmitAlgorithm(QgsProcessingAlgorithm):
    """Convert an EMIT L2A NetCDF4 file to ENVI flat-binary format."""

    INPUT = 'INPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT,
                'Input EMIT L2A NetCDF4 File',
                behavior=QgsProcessingParameterFile.File,
                fileFilter='NetCDF Files (*.nc *.nc4);;All Files (*)',
                optional=False,
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        fin = self.parameterAsFile(parameters, self.INPUT, context)

        feedback.pushInfo("=== Convert EMIT L2A to ENVI ===")
        ok, msg = _convert_emit(fin, feedback=feedback)
        if not ok:
            raise QgsProcessingException(msg)

        feedback.pushInfo(msg)
        return {}

    # ── Metadata ────────────────────────────────────────────────────────

    def name(self):
        return 'convert_emit_l2a'

    def displayName(self):
        return 'G04 - Convert EMIT L2A to ENVI'

    def group(self):
        return '7 - Convert Tools'

    def groupId(self):
        return 'convert_tools'

    def shortHelpString(self):
        return (
            "Convert an EMIT (Earth Surface Mineral Dust Source Investigation) "
            "L2A NetCDF4 reflectance file to ENVI flat-binary format.\n\n"
            "Four output files are written next to the input file:\n"
            "  _refl   — reflectance cube (BIL, with wavelengths/fwhm/bbl)\n"
            "  _lonlat — longitude + latitude arrays\n"
            "  _elev   — elevation\n"
            "  _glt    — GLT x/y for orthorectification\n\n"
            "Requires the 'netCDF4' Python package:\n"
            "  pip install netCDF4\n\n"
            "Ported from HyPy convemit.py (Wim Bakker, University of Twente, 2024)."
        )

    def createInstance(self):
        return ConvertEmitAlgorithm()
