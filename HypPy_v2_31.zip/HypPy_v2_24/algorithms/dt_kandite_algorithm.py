"""
DT Kandite Group Classification Algorithm for QGIS Processing

Classifies Al-OH pixels into the five kandite (kaolin) group minerals:
  Kaolinite, Dickite, Halloysite (hydrated), Halloysite (dehydrated), Nacrite

Based on USGS GMEX kandite group comparison spectra (kaolinite, dickite,
halloysite, halloysite dehydrated, nacrite).

============================  SPECTRAL LOGIC  ================================

Step 1 — GATE: Is there a primary Al-OH feature?
  depth(2206) <= threshold  ->  aspectral

Step 2 — GATE: Is the primary Al-OH in the kaolinite-group window?
  wl(2206) not in (2197, 2215]  ->  not_kandite

Step 3 — HALLOYSITE GATE: Is there a deep interlayer water band?
  depth(1900) > halloysite_threshold:
    wl(2206) and depth(2206)/depth(1900) considered:
      strongly hydrated (depth_1900 > hi_thresh)  ->  halloysite_hydrated
      moderately hydrated                          ->  halloysite_dehydrated
  (Halloysite is identified BEFORE shoulder position because the 1900 nm
   band is the most reliable discriminator and can be assessed independently
   of the 2162/2178 shoulder position which may be blurred in halloysite)

Step 4 — NACRITE CHECK: distinctive feature at ~2206 nm with deep narrow
  character and absence of strong 2162/2178 shoulder.
  shoulder_wl > 2190 AND wl(2206) in (2200, 2210]:
    depth(2206) > nacrite_depth_threshold  ->  nacrite
  (Nacrite has its primary doublet shifted slightly and a characteristically
   deep narrow 2200-2210 nm feature relative to its shoulder)

Step 5 — DICKITE vs KAOLINITE: shoulder wavelength position
  shoulder_wl <= 2167  ->  kaolinite  (~2162 nm shoulder)
  shoulder_wl <= 2173  ->  kaol_mixed
  shoulder_wl <= 2183  ->  dick_mixed
  shoulder_wl >  2183  ->  dickite    (~2178 nm shoulder)

============================  INPUTS  ========================================
  WoM_2206     — FE12-2206W output (Band 1=wl, Band 2=depth of primary Al-OH)
  WoM_shoulder — WoM over 2138-2196 nm (Band 1=shoulder wavelength)
  WoM_1900     — FE16-1900W output (Band 2=depth of water band)

============================  THRESHOLDS  ====================================
  depth_2206_threshold   — min depth to classify as Al-OH present (default 0.05)
  halloysite_lo_threshold — depth(1900) to flag as halloysite dehydrated (default 0.05)
  halloysite_hi_threshold — depth(1900) for strongly hydrated halloysite (default 0.12)
  nacrite_shoulder_min   — shoulder wl above which nacrite is tested (default 2188)

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

import numpy as np
from osgeo import gdal
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

KANDITE_CLASSES = [
    (0,  'unclassified',         0,   0,   0  ),
    (1,  'aspectral',            0,   0,   0  ),   # black
    (2,  'not_kandite',          128, 128, 128),   # grey
    (3,  'kaolinite',            0,   200,  50),   # green
    (4,  'kaol_mixed',           150, 230, 100),   # yellow-green
    (5,  'dick_mixed',           255, 200,  50),   # orange
    (6,  'dickite',              220,  80,   0),   # orange-red
    (7,  'nacrite',              160,   0, 200),   # purple
    (8,  'halloysite_dehydrated',  0, 180, 220),   # cyan
    (9,  'halloysite_hydrated',    0,  80, 255),   # bright blue
]
NAME_TO_ID = {m[1]: m[0] for m in KANDITE_CLASSES}
ID_TO_NAME = {m[0]: m[1] for m in KANDITE_CLASSES}

# Kaolinite-group primary Al-OH wavelength gate (nm)
KAOL_GROUP_WL_MIN = 2197.0
KAOL_GROUP_WL_MAX = 2215.0

# Shoulder wavelength boundaries for dickite/kaolinite split (nm)
KAOL_MAX      = 2167.0
KAOL_MIX_MAX  = 2173.0
DICK_MIX_MAX  = 2183.0
# > DICK_MIX_MAX -> dickite

# Nacrite shoulder threshold — shoulder must be above this to test nacrite
NACRITE_SHOULDER_MIN_DEFAULT = 2188.0


class DtKanditeAlgorithm(QgsProcessingAlgorithm):

    WOM_2206        = 'WOM_2206'
    WOM_SHOULDER    = 'WOM_SHOULDER'
    WOM_1900        = 'WOM_1900'
    DEPTH_2206_THRESH = 'DEPTH_2206_THRESH'
    HALL_LO_THRESH  = 'HALL_LO_THRESH'
    HALL_HI_THRESH  = 'HALL_HI_THRESH'
    OUTPUT_CLASS    = 'OUTPUT_CLASS'
    OUTPUT_RGB      = 'OUTPUT_RGB'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2206,
            'WoM 2206 raster — FE12-2206W output  '
            '(Band 1=primary Al-OH wavelength, Band 2=depth)'))

        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_SHOULDER,
            'WoM Shoulder raster — WoM over 2138-2196 nm  '
            '(Band 1=shoulder wavelength — use custom WoM with start=2138, end=2196)'))

        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_1900,
            'WoM 1900 raster — FE16-1900W output  '
            '(Band 2=depth of interlayer water band — halloysite discriminator)'))

        self.addParameter(QgsProcessingParameterNumber(
            self.DEPTH_2206_THRESH,
            'Minimum depth(2206) to classify as Al-OH present',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.05, minValue=0.0, maxValue=1.0))

        self.addParameter(QgsProcessingParameterNumber(
            self.HALL_LO_THRESH,
            'depth(1900) threshold — dehydrated halloysite  (lower bound)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.05, minValue=0.0, maxValue=1.0))

        self.addParameter(QgsProcessingParameterNumber(
            self.HALL_HI_THRESH,
            'depth(1900) threshold — hydrated halloysite  (upper bound)',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.12, minValue=0.0, maxValue=1.0))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_CLASS, 'Output: Kandite group class raster'))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_RGB, 'Output: Kandite group RGB raster',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        wom_2206_layer   = self.parameterAsRasterLayer(parameters, self.WOM_2206,          context)
        wom_shldr_layer  = self.parameterAsRasterLayer(parameters, self.WOM_SHOULDER,      context)
        wom_1900_layer   = self.parameterAsRasterLayer(parameters, self.WOM_1900,          context)
        depth_2206_thresh = self.parameterAsDouble    (parameters, self.DEPTH_2206_THRESH, context)
        hall_lo_thresh   = self.parameterAsDouble     (parameters, self.HALL_LO_THRESH,    context)
        hall_hi_thresh   = self.parameterAsDouble     (parameters, self.HALL_HI_THRESH,    context)
        out_class        = self.parameterAsOutputLayer(parameters, self.OUTPUT_CLASS,      context)
        out_rgb          = self.parameterAsOutputLayer(parameters, self.OUTPUT_RGB,        context) \
                           if self.OUTPUT_RGB in parameters else None

        # ── Open WoM 2206 ─────────────────────────────────────────────────
        ds_2206 = gdal.Open(wom_2206_layer.source(), gdal.GA_ReadOnly)
        if ds_2206 is None:
            raise QgsProcessingException('Cannot open WoM 2206 raster')
        cols, rows = ds_2206.RasterXSize, ds_2206.RasterYSize
        if ds_2206.RasterCount < 2:
            raise QgsProcessingException(
                'WoM 2206 raster needs >= 2 bands (Band1=wavelength, Band2=depth)')
        feedback.pushInfo(f'WoM 2206 raster: {cols} x {rows}, {ds_2206.RasterCount} bands')
        wl_2206    = ds_2206.GetRasterBand(1).ReadAsArray().astype(np.float32)
        depth_2206 = ds_2206.GetRasterBand(2).ReadAsArray().astype(np.float32)

        # ── Open WoM shoulder ─────────────────────────────────────────────
        ds_shldr = gdal.Open(wom_shldr_layer.source(), gdal.GA_ReadOnly)
        if ds_shldr is None:
            raise QgsProcessingException('Cannot open shoulder WoM raster')
        if ds_shldr.RasterXSize != cols or ds_shldr.RasterYSize != rows:
            raise QgsProcessingException(
                f'Shoulder WoM size mismatch ({ds_shldr.RasterXSize}x{ds_shldr.RasterYSize} '
                f'vs {cols}x{rows})')
        feedback.pushInfo('Reading shoulder WoM Band 1...')
        wl_shoulder = ds_shldr.GetRasterBand(1).ReadAsArray().astype(np.float32)
        ds_shldr = None

        # ── Open WoM 1900 ─────────────────────────────────────────────────
        ds_1900 = gdal.Open(wom_1900_layer.source(), gdal.GA_ReadOnly)
        if ds_1900 is None:
            raise QgsProcessingException('Cannot open WoM 1900 raster')
        if ds_1900.RasterXSize != cols or ds_1900.RasterYSize != rows:
            raise QgsProcessingException(
                f'WoM 1900 size mismatch ({ds_1900.RasterXSize}x{ds_1900.RasterYSize} '
                f'vs {cols}x{rows})')
        if ds_1900.RasterCount < 2:
            raise QgsProcessingException(
                'WoM 1900 raster needs >= 2 bands (Band1=wavelength, Band2=depth)')
        feedback.pushInfo('Reading WoM 1900 Band 2 (water band depth)...')
        depth_1900 = ds_1900.GetRasterBand(2).ReadAsArray().astype(np.float32)
        ds_1900 = None

        # ── Sanitise ──────────────────────────────────────────────────────
        nodata = (np.isnan(wl_2206) | np.isnan(depth_2206) |
                  np.isnan(wl_shoulder) | np.isnan(depth_1900))

        wl_2206s    = np.nan_to_num(wl_2206,    nan=0.0)
        depth_2206s = np.nan_to_num(depth_2206, nan=0.0)
        wl_shldrs   = np.nan_to_num(wl_shoulder, nan=0.0)
        depth_1900s = np.nan_to_num(depth_1900, nan=0.0)

        # ── Log thresholds ────────────────────────────────────────────────
        feedback.pushInfo('')
        feedback.pushInfo('Kandite classification thresholds:')
        feedback.pushInfo(f'  depth(2206) gate:       > {depth_2206_thresh}')
        feedback.pushInfo(f'  Al-OH wavelength gate:  {KAOL_GROUP_WL_MIN}-{KAOL_GROUP_WL_MAX} nm')
        feedback.pushInfo(f'  Halloysite dehydrated:  depth(1900) > {hall_lo_thresh}')
        feedback.pushInfo(f'  Halloysite hydrated:    depth(1900) > {hall_hi_thresh}')
        feedback.pushInfo(f'  Kaolinite shoulder:     <= {KAOL_MAX} nm')
        feedback.pushInfo(f'  Kaol/Dick transitional: {KAOL_MAX}-{DICK_MIX_MAX} nm')
        feedback.pushInfo(f'  Dickite shoulder:       > {DICK_MIX_MAX} nm')
        feedback.pushInfo('Applying kandite decision tree...')
        feedback.setProgress(20)

        class_data = np.zeros((rows, cols), dtype=np.uint8)

        # ── Step 1: aspectral ─────────────────────────────────────────────
        mask_asp = depth_2206s <= depth_2206_thresh
        class_data[mask_asp] = NAME_TO_ID['aspectral']

        # ── Step 2: not kandite ───────────────────────────────────────────
        mask_not = (~mask_asp) & (
            (wl_2206s <= KAOL_GROUP_WL_MIN) | (wl_2206s > KAOL_GROUP_WL_MAX))
        class_data[mask_not] = NAME_TO_ID['not_kandite']

        # Al-OH kandite pixels
        mask_k = (~mask_asp) & (~mask_not)

        # ── Step 3: halloysite (water band gate) ──────────────────────────
        mask_hall_hi = mask_k & (depth_1900s > hall_hi_thresh)
        mask_hall_lo = mask_k & (depth_1900s > hall_lo_thresh) & (~mask_hall_hi)

        class_data[mask_hall_hi] = NAME_TO_ID['halloysite_hydrated']
        class_data[mask_hall_lo] = NAME_TO_ID['halloysite_dehydrated']

        # Remaining: dry kandite pixels
        mask_dry = mask_k & (~mask_hall_hi) & (~mask_hall_lo)

        # ── Step 4: nacrite (high shoulder, deep primary) ─────────────────
        # Nacrite: shoulder pushed to >2188 nm (beyond dickite) with deep 2200-2210 nm
        mask_nacrite = (mask_dry &
                        (wl_shldrs > NACRITE_SHOULDER_MIN_DEFAULT) &
                        (wl_2206s > 2199.0) & (wl_2206s <= 2212.0))
        class_data[mask_nacrite] = NAME_TO_ID['nacrite']

        # ── Step 5: dickite vs kaolinite ──────────────────────────────────
        mask_dk = mask_dry & (~mask_nacrite)

        class_data[mask_dk & (wl_shldrs <= KAOL_MAX)]                                     = NAME_TO_ID['kaolinite']
        class_data[mask_dk & (wl_shldrs >  KAOL_MAX)    & (wl_shldrs <= KAOL_MIX_MAX)]   = NAME_TO_ID['kaol_mixed']
        class_data[mask_dk & (wl_shldrs >  KAOL_MIX_MAX) & (wl_shldrs <= DICK_MIX_MAX)]  = NAME_TO_ID['dick_mixed']
        class_data[mask_dk & (wl_shldrs >  DICK_MIX_MAX)]                                 = NAME_TO_ID['dickite']

        class_data[nodata]        = 0
        class_data[wl_2206s == 0] = 0
        feedback.setProgress(65)

        # ── Summary ───────────────────────────────────────────────────────
        feedback.pushInfo('')
        feedback.pushInfo('Classification summary:')
        unique, counts = np.unique(class_data, return_counts=True)
        total = class_data.size
        for uid, cnt in zip(unique, counts):
            pct = 100.0 * cnt / total
            feedback.pushInfo(
                f'  {ID_TO_NAME.get(int(uid), "?"):25s}  (id={uid:2d})  {cnt:8d} px  {pct:5.1f}%')

        # Water band depth stats
        if mask_k.any():
            d1900_k = depth_1900s[mask_k & (depth_1900s > 0)]
            if d1900_k.size > 0:
                feedback.pushInfo('')
                feedback.pushInfo('1900 nm water band depth (kandite pixels):')
                feedback.pushInfo(f'  min={d1900_k.min():.3f}  max={d1900_k.max():.3f}  '
                                  f'mean={d1900_k.mean():.3f}  median={np.median(d1900_k):.3f}')
                pct_hall = 100.0 * (mask_hall_hi | mask_hall_lo).sum() / max(mask_k.sum(), 1)
                feedback.pushInfo(f'  halloysite pixels: {pct_hall:.1f}% of kandite group')

        driver = gdal.GetDriverByName('GTiff')

        # ── Class raster ──────────────────────────────────────────────────
        feedback.pushInfo('Writing integer class raster...')
        ct = gdal.ColorTable()
        for mid, name, r, g, bv in KANDITE_CLASSES:
            ct.SetColorEntry(mid, (r, g, bv, 255))

        class_ds = driver.Create(out_class, cols, rows, 1, gdal.GDT_Byte,
                                 options=['COMPRESS=LZW', 'TILED=YES'])
        class_ds.SetGeoTransform(ds_2206.GetGeoTransform())
        class_ds.SetProjection(ds_2206.GetProjection())
        b = class_ds.GetRasterBand(1)
        b.SetNoDataValue(0)
        b.SetDescription('Kandite Group Class')
        b.SetRasterColorTable(ct)
        b.SetRasterColorInterpretation(gdal.GCI_PaletteIndex)
        b.WriteArray(class_data)
        b.FlushCache()

        rat = gdal.RasterAttributeTable()
        rat.CreateColumn('Value', gdal.GFT_Integer, gdal.GFU_MinMax)
        rat.CreateColumn('Class', gdal.GFT_String,  gdal.GFU_Name)
        rat.CreateColumn('R',     gdal.GFT_Integer, gdal.GFU_Red)
        rat.CreateColumn('G',     gdal.GFT_Integer, gdal.GFU_Green)
        rat.CreateColumn('B',     gdal.GFT_Integer, gdal.GFU_Blue)
        for row_idx, (mid, name, r, g, bv) in enumerate(KANDITE_CLASSES):
            rat.SetValueAsInt   (row_idx, 0, mid)
            rat.SetValueAsString(row_idx, 1, name)
            rat.SetValueAsInt   (row_idx, 2, r)
            rat.SetValueAsInt   (row_idx, 3, g)
            rat.SetValueAsInt   (row_idx, 4, bv)
        b.SetDefaultRAT(rat)
        class_ds = None
        result = {self.OUTPUT_CLASS: out_class}

        # ── Optional RGB raster ───────────────────────────────────────────
        if out_rgb:
            feedback.pushInfo('Writing RGB colour raster...')
            rgb_r = np.zeros((rows, cols), dtype=np.uint8)
            rgb_g = np.zeros((rows, cols), dtype=np.uint8)
            rgb_b_arr = np.zeros((rows, cols), dtype=np.uint8)
            for mid, name, r, g, bv in KANDITE_CLASSES:
                mask = class_data == mid
                rgb_r[mask], rgb_g[mask], rgb_b_arr[mask] = r, g, bv
            rgb_ds = driver.Create(out_rgb, cols, rows, 3, gdal.GDT_Byte,
                                   options=['COMPRESS=LZW', 'TILED=YES'])
            rgb_ds.SetGeoTransform(ds_2206.GetGeoTransform())
            rgb_ds.SetProjection(ds_2206.GetProjection())
            for idx, (arr, lbl) in enumerate(
                    [(rgb_r, 'Red'), (rgb_g, 'Green'), (rgb_b_arr, 'Blue')], 1):
                band = rgb_ds.GetRasterBand(idx)
                band.WriteArray(arr)
                band.SetDescription(lbl)
                band.FlushCache()
            rgb_ds = None
            feedback.setProgress(92)
            result[self.OUTPUT_RGB] = out_rgb

        ds_2206 = None
        feedback.setProgress(100)
        feedback.pushInfo('DT Kandite Group classification complete.')
        return result

    def name(self):        return 'dt_kandite'
    def displayName(self): return 'DT Kandite Group Classification'
    def group(self):       return '3 - Decision Tree Classification'
    def groupId(self):     return '3_decision_tree_classification'

    def shortHelpString(self):
        return """
        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required inputs (run these first):</b><br/>
        1. <b>FE12-2206W</b> — primary Al-OH WoM raster<br/>
        2. <b>Wavelength of Minimum</b> with range <b>2138-2196 nm</b> — shoulder WoM<br/>
        3. <b>FE16-1900W</b> — halloysite water band WoM raster
        </p>

        <b>DT Kandite Group Classification</b>

        <p>Classifies Al-OH pixels into all five kaolin (kandite) group minerals using
        three spectral parameters derived from USGS GMEX reference spectra:</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Source</th><th>Discriminates</th>
          </tr>
          <tr><td>depth(2206)</td><td>FE12-2206W Band 2</td>
              <td>Gate: Al-OH present vs aspectral</td></tr>
          <tr><td>wl(2206)</td><td>FE12-2206W Band 1</td>
              <td>Gate: kandite group vs other minerals</td></tr>
          <tr><td>depth(1900)</td><td>FE16-1900W Band 2</td>
              <td><b>Halloysite vs all dry kandites</b></td></tr>
          <tr><td>shoulder_wl</td><td>WoM 2138-2196 Band 1</td>
              <td><b>Kaolinite vs Dickite vs Nacrite</b></td></tr>
        </table>

        <p><b>Decision tree (in order of priority):</b></p>
        <ol>
          <li>depth(2206) &le; threshold &rarr; <b>aspectral</b></li>
          <li>wl(2206) &notin; (2197, 2215] nm &rarr; <b>not_kandite</b></li>
          <li>depth(1900) &gt; hi_threshold &rarr;
              <b>halloysite_hydrated</b> <span style="color:#0050FF">&#9632;</span> (blue)</li>
          <li>depth(1900) &gt; lo_threshold &rarr;
              <b>halloysite_dehydrated</b> <span style="color:#00B4DC">&#9632;</span> (cyan)</li>
          <li>shoulder_wl &gt; 2188 nm AND wl(2206) in (2199, 2212] &rarr;
              <b>nacrite</b> <span style="color:#A000C8">&#9632;</span> (purple)</li>
          <li>shoulder_wl &le; 2167 nm &rarr;
              <b>kaolinite</b> <span style="color:#00C832">&#9632;</span> (green)</li>
          <li>shoulder_wl &le; 2173 nm &rarr;
              <b>kaol_mixed</b> <span style="color:#96E664">&#9632;</span> (yellow-green)</li>
          <li>shoulder_wl &le; 2183 nm &rarr;
              <b>dick_mixed</b> <span style="color:#FFC832">&#9632;</span> (orange)</li>
          <li>shoulder_wl &gt; 2183 nm &rarr;
              <b>dickite</b> <span style="color:#DC5000">&#9632;</span> (orange-red)</li>
        </ol>

        <p><b>GMEX kandite group spectral basis:</b></p>
        <ul>
          <li><b>Halloysite (hydrated)</b> — deep broad ~1900 nm H₂O band; all others absent</li>
          <li><b>Halloysite (dehydrated)</b> — reduced ~1900 nm, dehydration collapses interlayer</li>
          <li><b>Kaolinite</b> — Al-OH shoulder ~2162 nm; 1900 nm absent</li>
          <li><b>Dickite</b> — Al-OH shoulder ~2178 nm (+16 nm shift); "persists in mixed spectra"</li>
          <li><b>Nacrite</b> — distinct doublet character, shoulder shifted beyond dickite</li>
        </ul>

        <p><b>Processing log reports:</b> 1900 nm water band depth statistics and
        percentage halloysite of all kandite pixels — useful for threshold review.</p>

        <p><i>Feature parameters from USGS GMEX Spectral Library, kandite group entries.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return DtKanditeAlgorithm()
