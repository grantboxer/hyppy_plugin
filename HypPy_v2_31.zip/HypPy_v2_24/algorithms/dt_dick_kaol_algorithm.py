"""
DT Dickite-Kaolinite Classification Algorithm for QGIS Processing

Classifies Al-OH pixels into dickite vs kaolinite using the wavelength
position of the 2162-2206 nm shoulder feature.

From USGS GMEX reference spectra:
  Kaolinite (kaolinite2): shoulder at ~2162 nm
  Dickite   (dickite):    shoulder at ~2178 nm — "Diagnostic doublet.
    Note difference in wavelength position and intensity of 2178 nm
    absorption relative to kaolinite. This absorption persists in
    mixed spectra."

The ~16 nm shift in the shoulder position is the primary spectral
discriminator between dickite and kaolinite in the SWIR 2100-2250 nm
region.  Because the GMEX notes that "this absorption persists in mixed
spectra", the shoulder wavelength from FE5-2160D / FE14-2178D provides
a reliable mapping parameter even in mixtures.

Decision tree:
  depth(2206) <= threshold             -> aspectral
  wavelength(2206) not in (2197, 2215] -> not_kaolin_group
  wavelength of shoulder:
    shoulder_wl <= 2167                -> kaolinite    (shoulder at ~2162 nm)
    shoulder_wl <= 2173                -> kaol_mixed   (transitional)
    shoulder_wl <= 2183                -> dick_mixed   (transitional)
    shoulder_wl >  2183                -> dickite      (shoulder at ~2178 nm)

Inputs:
  WoM_shoulder  — WoM over 2138-2196 nm (captures both 2162 and 2178 nm
                  shoulder positions; use FE5-2160D range extended to 2196 nm,
                  or run a custom WoM with start=2138 end=2196)
  WoM_2206      — WoM from FE12-2206W (2162-2245 nm)
                  Band 1 = wavelength of 2206 nm primary feature (gate check)
                  Band 2 = depth (threshold gate)

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

import numpy as np
from osgeo import gdal
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

DICK_KAOL_CLASSES = [
    (0, 'unclassified',      0,   0,   0  ),
    (1, 'aspectral',         0,   0,   0  ),   # black
    (2, 'not_kaolin_group',  128, 128, 128),   # grey
    (3, 'kaolinite',         0,   200,  50),   # green  (~2162 nm shoulder)
    (4, 'kaol_mixed',        150, 230, 100),   # yellow-green (transitional)
    (5, 'dick_mixed',        255, 200,  50),   # orange (transitional)
    (6, 'dickite',           220,  80,   0),   # orange-red (~2178 nm shoulder)
]
NAME_TO_ID = {m[1]: m[0] for m in DICK_KAOL_CLASSES}
ID_TO_NAME = {m[0]: m[1] for m in DICK_KAOL_CLASSES}

# Gate: primary Al-OH feature must be in kaolinite-group wavelength range
KAOL_WL_MIN = 2197.0
KAOL_WL_MAX = 2215.0

# Shoulder wavelength boundaries (nm)
# kaolinite shoulder  ~2162 nm  -> classified kaolinite if <= 2167
# dickite shoulder    ~2178 nm  -> classified dickite   if >  2183
KAOL_MAX    = 2167.0
KAOL_MIX_MAX = 2173.0
DICK_MIX_MAX = 2183.0
# > DICK_MIX_MAX -> dickite


class DtDickKaolAlgorithm(QgsProcessingAlgorithm):

    WOM_SHOULDER = 'WOM_SHOULDER'
    WOM_2206     = 'WOM_2206'
    DEPTH_THRESH = 'DEPTH_THRESH'
    OUTPUT_CLASS = 'OUTPUT_CLASS'
    OUTPUT_RGB   = 'OUTPUT_RGB'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2206,
            'WoM 2206 raster — FE12-2206W output  '
            '(Band 1=wavelength of primary Al-OH, Band 2=depth)'))

        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_SHOULDER,
            'WoM Shoulder raster — WoM over 2138-2196 nm  '
            '(Band 1=shoulder wavelength — use FE5-2160D extended, or custom WoM)'))

        self.addParameter(QgsProcessingParameterNumber(
            self.DEPTH_THRESH,
            'Minimum depth(2206) to classify as Al-OH present',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.05, minValue=0.0, maxValue=1.0))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_CLASS, 'Output: Dickite-Kaolinite class raster'))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_RGB, 'Output: Dickite-Kaolinite RGB raster',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        wom_2206_layer    = self.parameterAsRasterLayer(parameters, self.WOM_2206,     context)
        wom_shldr_layer   = self.parameterAsRasterLayer(parameters, self.WOM_SHOULDER, context)
        depth_thresh      = self.parameterAsDouble     (parameters, self.DEPTH_THRESH, context)
        out_class         = self.parameterAsOutputLayer(parameters, self.OUTPUT_CLASS, context)
        out_rgb           = self.parameterAsOutputLayer(parameters, self.OUTPUT_RGB,   context) \
                            if self.OUTPUT_RGB in parameters else None

        # ── Open WoM 2206 raster ─────────────────────────────────────────
        ds_2206 = gdal.Open(wom_2206_layer.source(), gdal.GA_ReadOnly)
        if ds_2206 is None:
            raise QgsProcessingException('Cannot open WoM 2206 raster')
        cols, rows = ds_2206.RasterXSize, ds_2206.RasterYSize
        if ds_2206.RasterCount < 2:
            raise QgsProcessingException(
                'WoM 2206 raster needs >= 2 bands (Band1=wavelength, Band2=depth)')

        feedback.pushInfo(f'WoM 2206 raster: {cols} x {rows}, {ds_2206.RasterCount} bands')
        feedback.pushInfo('Reading WoM 2206 Band 1 — primary Al-OH wavelength...')
        wl_2206    = ds_2206.GetRasterBand(1).ReadAsArray().astype(np.float32)
        feedback.pushInfo('Reading WoM 2206 Band 2 — feature depth...')
        depth_2206 = ds_2206.GetRasterBand(2).ReadAsArray().astype(np.float32)

        # ── Open WoM shoulder raster ─────────────────────────────────────
        ds_shldr = gdal.Open(wom_shldr_layer.source(), gdal.GA_ReadOnly)
        if ds_shldr is None:
            raise QgsProcessingException('Cannot open shoulder WoM raster')
        if ds_shldr.RasterXSize != cols or ds_shldr.RasterYSize != rows:
            raise QgsProcessingException(
                f'Shoulder WoM raster size ({ds_shldr.RasterXSize}x{ds_shldr.RasterYSize}) '
                f'does not match WoM 2206 size ({cols}x{rows})')

        feedback.pushInfo('Reading shoulder WoM Band 1 — shoulder wavelength (2138-2196 nm)...')
        wl_shoulder = ds_shldr.GetRasterBand(1).ReadAsArray().astype(np.float32)
        ds_shldr = None

        # ── Classify ─────────────────────────────────────────────────────
        feedback.pushInfo(f'Depth threshold: depth_2206 > {depth_thresh} = Al-OH present')
        feedback.pushInfo(f'Kaolinite group wavelength gate: {KAOL_WL_MIN}-{KAOL_WL_MAX} nm')
        feedback.pushInfo(f'Shoulder boundaries: kaolinite <= {KAOL_MAX} nm, '
                          f'kaol_mixed <= {KAOL_MIX_MAX} nm, '
                          f'dick_mixed <= {DICK_MIX_MAX} nm, '
                          f'dickite > {DICK_MIX_MAX} nm')
        feedback.pushInfo('Applying dickite-kaolinite decision tree...')
        feedback.setProgress(20)

        nodata = (np.isnan(wl_2206) | np.isnan(depth_2206) | np.isnan(wl_shoulder))

        wl_2206s    = np.nan_to_num(wl_2206,    nan=0.0)
        depth_2206s = np.nan_to_num(depth_2206, nan=0.0)
        wl_shldrs   = np.nan_to_num(wl_shoulder, nan=0.0)

        class_data = np.zeros((rows, cols), dtype=np.uint8)

        # aspectral
        mask_asp = depth_2206s <= depth_thresh
        class_data[mask_asp] = NAME_TO_ID['aspectral']

        # not kaolinite group
        mask_not = (~mask_asp) & (
            (wl_2206s <= KAOL_WL_MIN) | (wl_2206s > KAOL_WL_MAX))
        class_data[mask_not] = NAME_TO_ID['not_kaolin_group']

        # Al-OH pixels — classify by shoulder wavelength
        mask_aloh = (~mask_asp) & (~mask_not)

        class_data[mask_aloh & (wl_shldrs <= KAOL_MAX)]                                    = NAME_TO_ID['kaolinite']
        class_data[mask_aloh & (wl_shldrs >  KAOL_MAX)    & (wl_shldrs <= KAOL_MIX_MAX)]  = NAME_TO_ID['kaol_mixed']
        class_data[mask_aloh & (wl_shldrs >  KAOL_MIX_MAX) & (wl_shldrs <= DICK_MIX_MAX)] = NAME_TO_ID['dick_mixed']
        class_data[mask_aloh & (wl_shldrs >  DICK_MIX_MAX)]                                = NAME_TO_ID['dickite']

        class_data[nodata]        = 0
        class_data[wl_2206s == 0] = 0
        feedback.setProgress(65)

        # ── Summary ──────────────────────────────────────────────────────
        feedback.pushInfo('')
        feedback.pushInfo('Classification summary:')
        unique, counts = np.unique(class_data, return_counts=True)
        total = class_data.size
        for uid, cnt in zip(unique, counts):
            pct = 100.0 * cnt / total
            feedback.pushInfo(
                f'  {ID_TO_NAME.get(int(uid), "?"):20s}  (id={uid:2d})  {cnt:8d} px  {pct:5.1f}%')

        # ── Shoulder wavelength stats for Al-OH pixels ────────────────────
        if mask_aloh.any():
            sh = wl_shldrs[mask_aloh & (wl_shldrs > 0)]
            if sh.size > 0:
                feedback.pushInfo('')
                feedback.pushInfo('Shoulder wavelength statistics (Al-OH pixels):')
                feedback.pushInfo(f'  min={sh.min():.1f}  max={sh.max():.1f}  '
                                  f'mean={sh.mean():.1f}  median={np.median(sh):.1f} nm')
                feedback.pushInfo(f'  kaolinite threshold: <= {KAOL_MAX} nm')
                feedback.pushInfo(f'  dickite threshold:   >  {DICK_MIX_MAX} nm')

        driver = gdal.GetDriverByName('GTiff')

        # ── Class raster ─────────────────────────────────────────────────
        feedback.pushInfo('Writing integer class raster...')
        ct = gdal.ColorTable()
        for mid, name, r, g, bv in DICK_KAOL_CLASSES:
            ct.SetColorEntry(mid, (r, g, bv, 255))

        class_ds = driver.Create(out_class, cols, rows, 1, gdal.GDT_Byte,
                                 options=['COMPRESS=LZW', 'TILED=YES'])
        class_ds.SetGeoTransform(ds_2206.GetGeoTransform())
        class_ds.SetProjection(ds_2206.GetProjection())
        b = class_ds.GetRasterBand(1)
        b.SetNoDataValue(0)
        b.SetDescription('Dickite-Kaolinite Class')
        b.SetRasterColorTable(ct)
        b.SetRasterColorInterpretation(gdal.GCI_PaletteIndex)
        b.WriteArray(class_data)
        b.FlushCache()

        rat = gdal.RasterAttributeTable()
        rat.CreateColumn('Value', gdal.GFT_Integer, gdal.GFU_MinMax)
        rat.CreateColumn('Class', gdal.GFT_String,  gdal.GFU_Name)
        rat.CreateColumn('R',     gdal.GFT_Integer, gdal.GFU_Red)
        rat.CreateColumn('G',     gdal.GFT_Integer, gdal.GFU_Green)
        rat.CreateColumn('B',     gdal.GFT_Integer, gdal.GFU_Blue)
        for row_idx, (mid, name, r, g, bv) in enumerate(DICK_KAOL_CLASSES):
            rat.SetValueAsInt   (row_idx, 0, mid)
            rat.SetValueAsString(row_idx, 1, name)
            rat.SetValueAsInt   (row_idx, 2, r)
            rat.SetValueAsInt   (row_idx, 3, g)
            rat.SetValueAsInt   (row_idx, 4, bv)
        b.SetDefaultRAT(rat)
        class_ds = None
        result = {self.OUTPUT_CLASS: out_class}

        # ── Optional RGB raster ───────────────────────────────────────────
        if out_rgb:
            feedback.pushInfo('Writing RGB colour raster...')
            rgb_r = np.zeros((rows, cols), dtype=np.uint8)
            rgb_g = np.zeros((rows, cols), dtype=np.uint8)
            rgb_b = np.zeros((rows, cols), dtype=np.uint8)
            for mid, name, r, g, bv in DICK_KAOL_CLASSES:
                mask = class_data == mid
                rgb_r[mask], rgb_g[mask], rgb_b[mask] = r, g, bv
            rgb_ds = driver.Create(out_rgb, cols, rows, 3, gdal.GDT_Byte,
                                   options=['COMPRESS=LZW', 'TILED=YES'])
            rgb_ds.SetGeoTransform(ds_2206.GetGeoTransform())
            rgb_ds.SetProjection(ds_2206.GetProjection())
            for idx, (arr, lbl) in enumerate(
                    [(rgb_r, 'Red'), (rgb_g, 'Green'), (rgb_b, 'Blue')], 1):
                band = rgb_ds.GetRasterBand(idx)
                band.WriteArray(arr)
                band.SetDescription(lbl)
                band.FlushCache()
            rgb_ds = None
            feedback.setProgress(92)
            result[self.OUTPUT_RGB] = out_rgb

        ds_2206 = None
        feedback.setProgress(100)
        feedback.pushInfo('DT Dickite-Kaolinite classification complete.')
        return result

    def name(self):        return 'dt_dick_kaol'
    def displayName(self): return 'DT Dick-Kaol Classification'
    def group(self):       return '3 - Decision Tree Classification'
    def groupId(self):     return '3_decision_tree_classification'

    def shortHelpString(self):
        return """
        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b><br/>
        1. Run <b>FE12-2206W</b> to get the primary Al-OH WoM raster.<br/>
        2. Run <b>Wavelength of Minimum</b> with range <b>2138-2196 nm</b> to get the
           shoulder WoM raster (captures both kaolinite ~2162 nm and dickite ~2178 nm).
        </p>

        <b>DT Dickite-Kaolinite Classification</b>

        <p>Classifies Al-OH mineral pixels into dickite or kaolinite using the
        <b>wavelength position of the 2162/2178 nm shoulder feature</b>, derived
        from USGS GMEX reference spectra for kaolinite2 and dickite.</p>

        <p><b>Scientific basis (GMEX dickite):</b><br/>
        The dickite spectrum shows its shoulder at <b>~2178 nm</b> vs kaolinite's
        <b>~2162 nm</b> — a ~16 nm shift that GMEX describes as a
        "diagnostic doublet" with "difference in wavelength position and intensity
        relative to kaolinite." Critically, "this absorption persists in mixed spectra",
        making it reliable even in partially mixed pixels.</p>

        <p><b>Inputs:</b></p>
        <ul>
          <li><b>WoM 2206 raster</b> — from FE12-2206W.
              Provides gating: depth (Band 2) and wavelength (Band 1).</li>
          <li><b>WoM Shoulder raster</b> — WoM over 2138-2196 nm.
              Band 1 shoulder wavelength determines dickite vs kaolinite class.</li>
        </ul>

        <p><b>Decision tree:</b></p>
        <ul>
          <li>depth(2206) &le; threshold &rarr; <b>aspectral</b></li>
          <li>wavelength(2206) &notin; (2197, 2215] nm &rarr; <b>not_kaolin_group</b></li>
          <li>shoulder_wl &le; 2167 nm &rarr;
              <b>kaolinite</b> <span style="color:#00C832">&#9632;</span> (green)</li>
          <li>shoulder_wl &le; 2173 nm &rarr;
              <b>kaol_mixed</b> <span style="color:#96E664">&#9632;</span> (yellow-green)</li>
          <li>shoulder_wl &le; 2183 nm &rarr;
              <b>dick_mixed</b> <span style="color:#FFC832">&#9632;</span> (orange)</li>
          <li>shoulder_wl &gt; 2183 nm &rarr;
              <b>dickite</b> <span style="color:#DC5000">&#9632;</span> (orange-red)</li>
        </ul>

        <p><b>Colour legend:</b></p>
        <ul>
          <li><span style="color:#00C832">&#9632;</span> Green — kaolinite (shoulder ~2162 nm)</li>
          <li><span style="color:#96E664">&#9632;</span> Yellow-green — kaol_mixed (transitional)</li>
          <li><span style="color:#FFC832">&#9632;</span> Orange — dick_mixed (transitional)</li>
          <li><span style="color:#DC5000">&#9632;</span> Orange-red — dickite (shoulder ~2178 nm)</li>
          <li><span style="color:#808080">&#9632;</span> Grey — not kaolinite group</li>
          <li><span style="color:#000000">&#9632;</span> Black — aspectral</li>
        </ul>

        <p><b>Processing log reports:</b> shoulder wavelength statistics
        (min/max/mean/median) for all Al-OH pixels, enabling threshold review.</p>

        <p><i>Feature parameters from USGS GMEX Spectral Library, kaolinite2 and
        dickite entries. Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return DtDickKaolAlgorithm()
