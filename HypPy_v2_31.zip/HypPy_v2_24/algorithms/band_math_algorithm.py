"""
Band Math Algorithm for QGIS Processing
========================================

Applies a band-oriented Python expression to one or more input images.
Each input image is wrapped in an Image proxy that supports:

  i1(2200.0)          → 2D band array at wavelength 2200 nm   (__call__)
  i1[band_index]      → 2D band array at integer band index   (__getitem__)
  i1[j, i]            → 1D spectrum at pixel (row j, col i)
  i1[j, i, b]         → scalar at row j, col i, band b

This matches the HyPy Image interface (envi2/image.py) as closely as possible
within QGIS, where data is held in memory rather than a memory-map.

All numpy functions are available in expressions (from numpy import *).

Example expressions:
  i1(2200.0) / i1(2100.0)          → wavelength ratio (2D output)
  (i1(2200.0) - i1(2100.0)) /
  (i1(2200.0) + i1(2100.0))        → NDVI-style ratio
  i1[0]                            → first band (2D)
  i1[5, 10, :]                     → spectrum at row 5, col 10

Ported from HyPy bandmath.py (Wim Bakker, University of Twente)
Original Copyright (C) 2018 Wim Bakker (GPL v3)
QGIS adaptation Copyright (C) 2025 Grant Boxer (GPL v3)
"""

import collections
import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterString,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis,
)

from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset


# ── Image proxy ────────────────────────────────────────────────────────────────

class _Image:
    """
    In-memory proxy for a hyperspectral image cube that mirrors the HyPy
    envi2.Image interface used in Band Math expressions.

    Internal storage is always (bands, rows, cols) i.e. BSQ order.

    Indexing behaviour (matching HyPy Image, which presents data as BIP):
      im[b]           → 2D array (rows, cols) for band index b
      im[j, i]        → 1D spectrum at row j, col i
      im[j, i, b]     → scalar value
      im(wavelength)  → 2D array for the band nearest to wavelength
    """

    def __init__(self, data, wavelength, name='i'):
        """
        Parameters
        ----------
        data       : np.ndarray  shape (bands, rows, cols)
        wavelength : np.ndarray  1-D wavelength array, or None
        name       : str
        """
        self._data       = data            # (bands, rows, cols)
        self.wavelength  = wavelength      # 1-D array or None
        self.name        = name
        self.bands       = data.shape[0]
        self.lines       = data.shape[1]   # rows
        self.samples     = data.shape[2]   # cols
        self.shape       = data.shape
        self._wl_hints   = {}

    def wavelength2index(self, wav):
        """Return index of the band with wavelength closest to *wav*."""
        if wav in self._wl_hints:
            return self._wl_hints[wav]
        if self.wavelength is None:
            raise ValueError(f'Image {self.name!r} has no wavelength metadata.')
        idx = int(np.argmin(np.abs(self.wavelength - wav)))
        self._wl_hints[wav] = idx
        return idx

    def __call__(self, wav):
        """
        im(wavelength) → 2D numpy array (rows, cols) for the nearest band.
        Mirrors HyPy Image.__call__.
        """
        return self._data[self.wavelength2index(wav)]

    def __getitem__(self, idx):
        """
        Flexible indexing — mirrors HyPy Image.__getitem__:
          im[b]        → 2D band array (rows, cols)
          im[j, i]     → 1D spectrum
          im[j, i, b]  → scalar
          im[...]      → entire cube (bands, rows, cols)
        """
        if idx is Ellipsis:
            return self._data
        elif not isinstance(idx, tuple):
            # one index → band
            return self._data[idx]
        elif len(idx) == 2:
            j, i = idx
            return self._data[:, j, i]
        elif len(idx) == 3:
            j, i, b = idx
            return self._data[b, j, i]
        else:
            raise IndexError(f'_Image: invalid index {idx!r}')

    def __len__(self):
        return self.bands


# ── Algorithm ──────────────────────────────────────────────────────────────────

class BandMathAlgorithm(QgsProcessingAlgorithm):
    """
    Band Math — applies a 2D numpy expression across a hyperspectral image.

    Unlike Spectra Math (which loops pixel-by-pixel), Band Math operates on
    entire 2D band arrays at once, making it faster for simple band combinations.
    """

    INPUTS     = 'INPUTS'
    EXPRESSION = 'EXPRESSION'
    USE_BBL    = 'USE_BBL'
    OUTPUT     = 'OUTPUT'

    # ------------------------------------------------------------------ #

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUTS,
                'Input Hyperspectral Image(s)  (i1, i2, … in expression)',
                layerType=QgsProcessing.TypeRaster,
                optional=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.EXPRESSION,
                'Band Math Expression',
                defaultValue='i1(2200.0) / i1(2100.0)',
                multiLine=True,
                optional=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.USE_BBL,
                'Use Bad Band List (BBL) from metadata',
                defaultValue=True,
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                'Output Image',
            )
        )

    # ------------------------------------------------------------------ #

    def processAlgorithm(self, parameters, context, feedback):

        layers      = self.parameterAsLayerList(parameters, self.INPUTS, context)
        expression  = self.parameterAsString(parameters, self.EXPRESSION, context).strip()
        use_bbl     = self.parameterAsBoolean(parameters, self.USE_BBL, context)
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if not layers:
            raise QgsProcessingException('No input layers supplied.')
        if not expression:
            raise QgsProcessingException('Expression is empty.')

        feedback.pushInfo(f'Expression: {expression}')
        feedback.pushInfo(f'Inputs: {len(layers)} image(s)')

        # ── Load input images ────────────────────────────────────────────
        images = {}
        geo, proj = None, None

        for k, lyr in enumerate(layers):
            ds = gdal.Open(lyr.source())
            if ds is None:
                raise QgsProcessingException(f'Cannot open: {lyr.source()}')

            nb = ds.RasterCount
            wl = get_wavelengths_from_dataset(ds, nb, lyr.source(), feedback)
            bl = get_bbl_from_dataset(ds, nb, lyr.source(), feedback) if use_bbl else None

            # Determine valid bands
            if bl is not None:
                vb = [i for i, good in enumerate(bl) if good]
                feedback.pushInfo(f'  i{k+1}: BBL → {len(vb)} of {nb} bands valid')
            else:
                vb = list(range(nb))

            if geo is None:
                geo  = ds.GetGeoTransform()
                proj = ds.GetProjection()
                n_rows = ds.RasterYSize
                n_cols = ds.RasterXSize

            # Read data into (bands, rows, cols)
            feedback.pushInfo(f'Reading i{k+1}...')
            nd  = ds.GetRasterBand(1).GetNoDataValue()
            arr = np.zeros((len(vb), n_rows, n_cols), dtype=np.float64)
            for bi, b in enumerate(vb):
                a = ds.GetRasterBand(b + 1).ReadAsArray().astype(np.float64)
                if nd is not None:
                    a[a == nd] = np.nan
                arr[bi] = a

            wl_vb = wl[vb] if wl is not None else None
            img   = _Image(arr, wl_vb, name=f'i{k+1}')
            images[f'i{k+1}'] = img
            del ds

        # ── Evaluate expression ──────────────────────────────────────────
        feedback.pushInfo('Evaluating expression...')
        math_ns = self._math_namespace()
        eval_ns = {**math_ns, **images}

        try:
            result = eval(expression, eval_ns)
        except Exception as e:
            raise QgsProcessingException(f'Expression error: {e}')

        # ── Normalise result to (bands, rows, cols) ───────────────────────
        result = np.asarray(result, dtype=np.float64)

        if result.ndim == 0:
            # scalar → broadcast to single-band image
            result = np.full((1, n_rows, n_cols), float(result))
        elif result.ndim == 2:
            # (rows, cols) → single band
            result = result[np.newaxis, :, :]
        elif result.ndim == 3:
            # already (bands, rows, cols)
            pass
        else:
            raise QgsProcessingException(
                f'Expression returned array with unexpected shape: {result.shape}')

        out_bands, out_rows, out_cols = result.shape
        feedback.pushInfo(f'Output: {out_bands} band(s), {out_rows}×{out_cols}')

        # ── Write output GeoTIFF ──────────────────────────────────────────
        drv    = gdal.GetDriverByName('GTiff')
        out_ds = drv.Create(output_path, out_cols, out_rows, out_bands,
                            gdal.GDT_Float64,
                            options=['COMPRESS=LZW', 'BIGTIFF=IF_SAFER'])
        out_ds.SetGeoTransform(geo)
        out_ds.SetProjection(proj)

        for b in range(out_bands):
            band = out_ds.GetRasterBand(b + 1)
            band.WriteArray(result[b])
            band.SetNoDataValue(np.nan)

        out_ds.FlushCache()
        del out_ds

        feedback.setProgress(100)
        feedback.pushInfo('Band Math completed successfully.')
        return {self.OUTPUT: output_path}

    # ------------------------------------------------------------------ #

    def _math_namespace(self):
        """numpy functions available in expressions (mirrors 'from numpy import *')."""
        import numpy as np
        ns = {name: getattr(np, name)
              for name in dir(np) if not name.startswith('_')}
        ns['np'] = np
        return ns

    def name(self):        return 'bandmathfull'
    def displayName(self): return 'Band Math'
    def group(self):       return '5 - Spectral Processing Tools'
    def groupId(self):     return '5_spectral_processing_tools'

    def shortHelpString(self):
        return (
            'Applies a band-oriented numpy expression to one or more hyperspectral images.\n\n'
            'Input images are available as i1, i2, … in the expression.\n\n'
            'WAVELENGTH ADDRESSING (the key feature):\n'
            '  i1(2200.0)          → 2D band at wavelength 2200 nm  (__call__)\n'
            '  i1[band_index]      → 2D band at integer index\n\n'
            'PIXEL/BAND INDEXING (HyPy Image interface):\n'
            '  i1[j, i]            → 1D spectrum at row j, col i\n'
            '  i1[j, i, b]         → scalar at row j, col i, band b\n'
            '  i1[...]             → full cube (bands, rows, cols)\n\n'
            'EXAMPLE EXPRESSIONS:\n'
            '  i1(2200.0) / i1(2100.0)\n'
            '  (i1(2200.0) - i1(2100.0)) / (i1(2200.0) + i1(2100.0))\n'
            '  log(i1(2200.0)) - log(i1(2100.0))\n'
            '  i1[0] + i1[1]    (first two bands)\n\n'
            'Note: Band Math operates on full 2D band arrays — use Spectra Math\n'
            'for per-pixel spectral operations with wavelength slices.\n\n'
            'Ported from HyPy bandmath.py (Wim Bakker, University of Twente).'
        )

    def createInstance(self):
        return BandMathAlgorithm()
