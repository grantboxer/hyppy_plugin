"""
Log Residuals Algorithm for QGIS Processing

Normalises hyperspectral imagery using Log Residuals or Kwik Residuals.

Log Residuals (3-pass):
  Pass 1 – Normalise each pixel spectrum by its geometric mean (albedo removal)
  Pass 2 – Compute a Robust Least Upper Bound (RLUB) per band
            using the geometric mean ± N standard deviations, capped at the 99th percentile
  Pass 3 – Divide the normalised spectra by the RLUB

Kwik Residuals – as above but uses arithmetic mean instead of geometric mean/log
                  (faster, less theoretically rigorous)

Optionally outputs an Albedo raster (geometric mean per pixel) and a
RLUB text file (wavelength vs RLUB value per band).

Ported from HyPy logresiduals.py
Original Author: Wim Bakker, University of Twente
Modified: WHB 20091105 (NaN safe), WHB 20100210 (true Log Residuals)

Copyright (C) 2025 Grant Boxer
Original HyPy Copyright (C) 2010-2022 Wim Bakker, University of Twente

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterEnum,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis,
)

from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset


class LogResidualsAlgorithm(QgsProcessingAlgorithm):
    """
    Log Residuals / Kwik Residuals normalisation algorithm.

    Removes albedo effects and broad spectral trends from hyperspectral imagery,
    highlighting subtle mineralogical absorption features.
    """

    INPUT        = 'INPUT'
    MODE         = 'MODE'
    N_STDDEV     = 'N_STDDEV'
    USE_BBL      = 'USE_BBL'
    OUTPUT       = 'OUTPUT'
    OUTPUT_ALBEDO = 'OUTPUT_ALBEDO'
    OUTPUT_RLUB  = 'OUTPUT_RLUB'

    MODES = ['Log Residuals (geometric mean)', 'Kwik Residuals (arithmetic mean)']

    # ------------------------------------------------------------------ #
    #  Algorithm definition                                                #
    # ------------------------------------------------------------------ #

    def initAlgorithm(self, config=None):

        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT,
                'Input Hyperspectral Image',
                optional=False,
            )
        )

        self.addParameter(
            QgsProcessingParameterEnum(
                self.MODE,
                'Residuals Mode',
                options=self.MODES,
                defaultValue=0,
                optional=False,
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.N_STDDEV,
                'Number of Standard Deviations for RLUB',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=3.0,
                minValue=0.5,
                maxValue=10.0,
                optional=False,
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.USE_BBL,
                'Use Bad Band List (BBL) from metadata',
                defaultValue=True,
                optional=True,
            )
        )

        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                'Output Log-Residuals Image',
            )
        )

        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_ALBEDO,
                'Output Albedo Image (optional)',
                optional=True,
                createByDefault=False,
            )
        )

        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.OUTPUT_RLUB,
                'Output RLUB Text File (optional)',
                fileFilter='Text files (*.txt)',
                optional=True,
                createByDefault=False,
            )
        )

    # ------------------------------------------------------------------ #
    #  Core processing                                                     #
    # ------------------------------------------------------------------ #

    def processAlgorithm(self, parameters, context, feedback):

        # ── Collect parameters ──────────────────────────────────────────
        input_layer   = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        mode          = self.parameterAsEnum(parameters, self.MODE, context)
        n_stddev      = self.parameterAsDouble(parameters, self.N_STDDEV, context)
        use_bbl       = self.parameterAsBoolean(parameters, self.USE_BBL, context)
        output_path   = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        albedo_path = None
        if self.OUTPUT_ALBEDO in parameters and parameters[self.OUTPUT_ALBEDO]:
            albedo_path = self.parameterAsOutputLayer(parameters, self.OUTPUT_ALBEDO, context)

        rlub_path = None
        if self.OUTPUT_RLUB in parameters and parameters[self.OUTPUT_RLUB]:
            rlub_path = self.parameterAsFileOutput(parameters, self.OUTPUT_RLUB, context)

        if input_layer is None:
            raise QgsProcessingException('Invalid input layer')

        # ── Open raster ─────────────────────────────────────────────────
        ds = gdal.Open(input_layer.source())
        if ds is None:
            raise QgsProcessingException(f'Cannot open raster: {input_layer.source()}')

        n_bands = ds.RasterCount
        n_rows  = ds.RasterYSize
        n_cols  = ds.RasterXSize
        geo     = ds.GetGeoTransform()
        proj    = ds.GetProjection()

        feedback.pushInfo(f'Input: {n_bands} bands, {n_rows} rows, {n_cols} cols')
        feedback.pushInfo(f'Mode: {self.MODES[mode]}')
        feedback.pushInfo(f'N stddev: {n_stddev}')

        # ── Wavelengths & BBL ───────────────────────────────────────────
        raster_path = input_layer.source()
        wavelengths = get_wavelengths_from_dataset(ds, n_bands, raster_path, feedback)
        bbl         = get_bbl_from_dataset(ds, n_bands, raster_path, feedback) if use_bbl else None

        # Build list of valid band indices (0-based)
        if bbl is not None:
            valid_bands = [i for i, good in enumerate(bbl) if good]
            feedback.pushInfo(f'BBL: {len(valid_bands)} of {n_bands} bands valid')
        else:
            valid_bands = list(range(n_bands))

        if len(valid_bands) < 2:
            raise QgsProcessingException('Not enough valid bands for residuals computation')

        # ── Read all input data ─────────────────────────────────────────
        feedback.pushInfo('Reading input bands...')
        nodata_val = ds.GetRasterBand(1).GetNoDataValue()

        data = np.zeros((n_bands, n_rows, n_cols), dtype=np.float64)
        for b in range(n_bands):
            arr = ds.GetRasterBand(b + 1).ReadAsArray().astype(np.float64)
            if nodata_val is not None:
                arr[arr == nodata_val] = np.nan
            data[b] = arr

        # ── Create output datasets (GeoTIFF + sidecar .hdr) ────────────────
        # Write GeoTIFF so QGIS Processing loads the output at the path it
        # was given.  Wavelength metadata is written into a companion .hdr
        # sidecar (file.tif.hdr) which envi_header.py finds automatically.
        import os
        gtiff_drv = gdal.GetDriverByName('GTiff')
        gtiff_opts = ['COMPRESS=LZW', 'BIGTIFF=IF_SAFER']

        out_ds = gtiff_drv.Create(output_path, n_cols, n_rows, n_bands,
                                  gdal.GDT_Float64, options=gtiff_opts)
        out_ds.SetGeoTransform(geo)
        out_ds.SetProjection(proj)

        # Optionally create albedo dataset (1 band)
        alb_ds = None
        if albedo_path:
            alb_ds = gtiff_drv.Create(albedo_path, n_cols, n_rows, 1,
                                      gdal.GDT_Float64, options=gtiff_opts)
            alb_ds.SetGeoTransform(geo)
            alb_ds.SetProjection(proj)

        # ── Pass 1: normalise each spectrum by albedo ───────────────────
        feedback.pushInfo('Pass 1: normalising spectra by albedo...')
        old_settings = np.seterr(all='ignore')

        norm = np.full_like(data, np.nan)
        albedo_arr = np.full((n_rows, n_cols), np.nan)

        total = n_rows * n_cols
        step  = max(1, n_rows // 100)

        for j in range(n_rows):
            if feedback.isCanceled():
                break
            if j % step == 0:
                feedback.setProgress(int(j * 33 / n_rows))

            for i in range(n_cols):
                spec = data[:, j, i].copy()

                # Use only valid bands for mean computation
                vspec = spec[valid_bands].copy()
                vspec[vspec <= 0.0] = np.nan

                if mode == 0:
                    # Geometric mean via log
                    log_spec = np.log(vspec)
                    m = np.e ** np.nanmean(log_spec)
                else:
                    # Arithmetic mean
                    m = np.nanmean(vspec)

                if np.isnan(m) or m == 0.0:
                    continue

                norm[:, j, i] = spec / m
                albedo_arr[j, i] = m

        # ── Pass 2: compute RLUB per band ───────────────────────────────
        feedback.pushInfo('Pass 2: computing Robust Least Upper Bound (RLUB)...')
        feedback.pushInfo(f'  Using {n_stddev} standard deviations, capped at 99th percentile')

        slub = np.zeros(n_bands)

        for b in range(n_bands):
            if feedback.isCanceled():
                break
            feedback.setProgress(33 + int(b * 33 / n_bands))

            band = norm[b].flatten()
            band = band[~np.isnan(band)]

            if len(band) < 2:
                slub[b] = 1.0
                continue

            if mode == 0:
                # Log domain for true log residuals
                band_log = np.log(np.where(band > 0, band, np.nan))
                band_log = band_log[~np.isnan(band_log)]
                if len(band_log) < 2:
                    slub[b] = 1.0
                    continue
                m = np.nanmean(band_log)
                s = np.nanstd(band_log)
                band_sorted = np.sort(band_log)
                mx = band_sorted[int(len(band_sorted) * 0.99)]
                slub[b] = np.e ** min(m + n_stddev * s, mx)
            else:
                m = np.nanmean(band)
                s = np.nanstd(band)
                band_sorted = np.sort(band)
                mx = band_sorted[int(len(band_sorted) * 0.99)]
                slub[b] = min(m + n_stddev * s, mx)

        # ── Pass 3: divide spectra by RLUB ──────────────────────────────
        feedback.pushInfo('Pass 3: dividing spectra by RLUB...')

        result = np.full_like(data, np.nan)
        for j in range(n_rows):
            if feedback.isCanceled():
                break
            if j % step == 0:
                feedback.setProgress(66 + int(j * 33 / n_rows))

            for i in range(n_cols):
                spec = norm[:, j, i]
                if not np.all(np.isnan(spec)):
                    result[:, j, i] = spec / slub

        np.seterr(**old_settings)

        # ── Write band data ─────────────────────────────────────────────
        feedback.pushInfo('Writing output raster...')
        mode_str = 'logres' if mode == 0 else 'kwikres'
        for b in range(n_bands):
            out_band = out_ds.GetRasterBand(b + 1)
            out_band.WriteArray(result[b])
            out_band.SetNoDataValue(np.nan)
            # Carry original band description forward (wavelength value or name)
            orig_desc = ds.GetRasterBand(b + 1).GetDescription()
            if orig_desc:
                out_band.SetDescription(orig_desc)
            elif wavelengths is not None:
                out_band.SetDescription(f'{wavelengths[b]:.4f}')
            else:
                out_band.SetDescription(f'Band {b+1}')

        # ── Flush GeoTIFF and write sidecar .hdr with wavelength metadata ─
        # GeoTIFF embedded metadata is not reliably read back by GDAL's ENVI
        # domain, so we write a companion .hdr sidecar (output.tif.hdr) that
        # envi_header.py finds automatically via its find_hdr() lookup.
        input_envi_meta    = ds.GetMetadata('ENVI') or {}
        input_default_meta = ds.GetMetadata('') or {}

        out_ds.FlushCache()
        del out_ds
        feedback.pushInfo(f'Output GeoTIFF written: {output_path}')

        # Build sidecar .hdr content from input ENVI metadata
        hdr_lines = ['ENVI']
        # Copy all input ENVI fields
        for k, v in input_envi_meta.items():
            hdr_lines.append(f'{k} = {v}')
        # Overwrite/add wavelength with re-serialised array
        if wavelengths is not None:
            wav_str = '{' + ', '.join(f'{w:.4f}' for w in wavelengths) + '}'
            # Replace if already written from input_envi_meta
            hdr_lines = [l for l in hdr_lines if not l.lower().startswith('wavelength =')
                         and not l.lower().startswith('wavelength=')]
            hdr_lines.append(f'wavelength = {wav_str}')
        # Wavelength units
        if not any(l.lower().startswith('wavelength units') for l in hdr_lines):
            wu = (input_envi_meta.get('wavelength units') or
                  input_envi_meta.get('wavelength_units') or
                  input_default_meta.get('wavelength_units') or 'Nanometers')
            hdr_lines.append(f'wavelength units = {wu}')
        # Provenance tags
        hdr_lines.append(f'log_residuals_mode = {mode_str}')
        hdr_lines.append(f'log_residuals_n_stddev = {n_stddev}')

        hdr_path = output_path + '.hdr'
        with open(hdr_path, 'w') as hf:
            hf.write('\n'.join(hdr_lines) + '\n')
        feedback.pushInfo(f'Sidecar .hdr written: {hdr_path}')

        # ── Write albedo raster ─────────────────────────────────────────
        if alb_ds is not None:
            feedback.pushInfo('Writing albedo raster...')
            b = alb_ds.GetRasterBand(1)
            b.WriteArray(albedo_arr)
            b.SetNoDataValue(np.nan)
            b.SetDescription('Albedo (geometric/arithmetic mean per pixel)')
            alb_ds.FlushCache()
            del alb_ds
            # Minimal sidecar for albedo (no wavelengths — single band)
            alb_hdr = albedo_path + '.hdr'
            with open(alb_hdr, 'w') as hf:
                hf.write('ENVI\n')
                hf.write(f'description = Albedo ({mode_str}) from Log Residuals\n')

        # ── Write RLUB text file ────────────────────────────────────────
        if rlub_path:
            feedback.pushInfo(f'Writing RLUB to: {rlub_path}')
            with open(rlub_path, 'w') as f:
                if wavelengths is not None:
                    f.write('Wavelength_nm RLUB\n')
                    for b in range(n_bands):
                        f.write(f'{wavelengths[b]:.4f} {slub[b]:.6f}\n')
                else:
                    f.write('Band RLUB\n')
                    for b in range(n_bands):
                        f.write(f'{b+1} {slub[b]:.6f}\n')

        del ds
        feedback.setProgress(100)
        feedback.pushInfo('Log Residuals completed successfully.')

        result_dict = {self.OUTPUT: output_path}
        if albedo_path:
            result_dict[self.OUTPUT_ALBEDO] = albedo_path
        if rlub_path:
            result_dict[self.OUTPUT_RLUB] = rlub_path
        return result_dict

    # ------------------------------------------------------------------ #
    #  Helpers                                                             #
    # ------------------------------------------------------------------ #

    # _get_wavelengths removed — use shared utility from core.envi_header

    # _get_bbl removed — use shared utility from core.envi_header

    def name(self):
        return 'logresiduals'

    def displayName(self):
        return 'Log Residuals'

    def group(self):
        return '5 - Spectral Processing Tools'

    def groupId(self):
        return '5_spectral_processing_tools'

    def shortHelpString(self):
        return (
            'Normalises hyperspectral imagery using Log Residuals or Kwik Residuals.\n\n'
            'Log Residuals (3-pass algorithm):\n'
            '  Pass 1 – Divide each pixel spectrum by its geometric mean (removes albedo/brightness)\n'
            '  Pass 2 – Compute a Robust Least Upper Bound (RLUB) per band\n'
            '           using geometric mean ± N standard deviations, capped at the 99th percentile\n'
            '  Pass 3 – Divide normalised spectra by the RLUB (removes broad spectral slope)\n\n'
            'Kwik Residuals – the same 3-pass approach but using arithmetic means instead of\n'
            'geometric means/logarithms. Faster but less theoretically rigorous.\n\n'
            'The result highlights subtle absorption features useful for mineral identification.\n\n'
            'Optional outputs:\n'
            '  Albedo Image – geometric (or arithmetic) mean per pixel (single band)\n'
            '  RLUB Text File – wavelength vs RLUB per band (for QC or plotting)\n\n'
            'Ported from HyPy logresiduals.py (Wim Bakker, University of Twente).'
        )

    def createInstance(self):
        return LogResidualsAlgorithm()
