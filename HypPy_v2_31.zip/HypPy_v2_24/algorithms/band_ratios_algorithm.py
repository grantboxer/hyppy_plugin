"""
Band Ratios Algorithm for QGIS Processing

Computes sequential band ratios for all bands in a hyperspectral image:
band[i] / band[i+delta] for each i.

Ported from HyPy ratios.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original Copyright (C) 2010-2022 Wim Bakker

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis
)

from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset


class BandRatiosAlgorithm(QgsProcessingAlgorithm):
    """
    Band Ratios Algorithm

    Computes sequential band ratios for all bands:
        output band i = input band i / input band (i + delta)

    The output has (n_bands - delta) bands. Wavelength metadata is preserved
    for the numerator bands.
    """

    INPUT = 'INPUT'
    DELTA = 'DELTA'
    USE_BBL = 'USE_BBL'
    OUTPUT = 'OUTPUT'

    def initAlgorithm(self, config=None):
        """Define inputs and outputs."""

        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT,
                'Input Hyperspectral Image',
                optional=False
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.DELTA,
                'Delta (band shift between numerator and denominator)',
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=1,
                minValue=1,
                optional=False
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.USE_BBL,
                'Use Bad Band List (BBL) from metadata',
                defaultValue=True,
                optional=True
            )
        )

        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                'Output Band Ratios Image'
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """Execute the band ratios algorithm."""

        input_layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        delta = self.parameterAsInt(parameters, self.DELTA, context)
        use_bbl = self.parameterAsBoolean(parameters, self.USE_BBL, context)
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if input_layer is None:
            raise QgsProcessingException('Invalid input layer')

        ds = gdal.Open(input_layer.source())
        if ds is None:
            raise QgsProcessingException(f'Cannot open raster: {input_layer.source()}')

        n_bands = ds.RasterCount
        n_rows = ds.RasterYSize
        n_cols = ds.RasterXSize

        if delta >= n_bands:
            raise QgsProcessingException(
                f'Delta ({delta}) must be less than number of bands ({n_bands})'
            )

        n_out_bands = n_bands - delta
        feedback.pushInfo(f'Input bands: {n_bands}, Delta: {delta}, Output bands: {n_out_bands}')

        raster_path = input_layer.source()
        wavelengths = get_wavelengths_from_dataset(ds, n_bands, raster_path, feedback)
        nodata = ds.GetRasterBand(1).GetNoDataValue()

        # Create output
        driver = gdal.GetDriverByName('GTiff')
        out_ds = driver.Create(output_path, n_cols, n_rows, n_out_bands, gdal.GDT_Float64)
        out_ds.SetGeoTransform(ds.GetGeoTransform())
        out_ds.SetProjection(ds.GetProjection())

        old_settings = np.seterr(all='ignore')

        for i in range(n_out_bands):
            if feedback.isCanceled():
                break
            feedback.setProgress(int(i * 100 / n_out_bands))

            # Read numerator and denominator bands
            b1 = ds.GetRasterBand(i + 1).ReadAsArray().astype(np.float64)
            b2 = ds.GetRasterBand(i + 1 + delta).ReadAsArray().astype(np.float64)

            if nodata is not None:
                b1[b1 == nodata] = np.nan
                b2[b2 == nodata] = np.nan

            ratio = b1 / b2

            out_band = out_ds.GetRasterBand(i + 1)
            out_band.WriteArray(ratio)
            out_band.SetNoDataValue(np.nan)

            if wavelengths is not None:
                out_band.SetDescription(
                    f'Ratio {wavelengths[i]:.2f}nm / {wavelengths[i+delta]:.2f}nm'
                )
            else:
                out_band.SetDescription(f'Ratio band {i+1} / band {i+1+delta}')

        np.seterr(**old_settings)

        # Write metadata
        metadata = {'band_ratios_delta': str(delta)}
        if wavelengths is not None:
            wav_out = wavelengths[:n_out_bands]
            metadata['wavelength'] = '{' + ', '.join([f'{w:.4f}' for w in wav_out]) + '}'
            metadata['wavelength_units'] = 'Nanometers'
        out_ds.SetMetadata(metadata)

        out_ds.FlushCache()
        del ds, out_ds

        feedback.pushInfo(f'Band ratios completed. {n_out_bands} output bands written.')
        return {self.OUTPUT: output_path}

    # _get_wavelengths removed — use get_wavelengths_from_dataset from core.envi_header
    def name(self):
        return 'bandratios'

    def displayName(self):
        return 'Band Ratios (Sequential)'

    def group(self):
        return '5 - Spectral Processing Tools'

    def groupId(self):
        return '5_spectral_processing_tools'

    def shortHelpString(self):
        return (
            'Computes sequential band ratios for all bands in a hyperspectral image.\n\n'
            'For each band i, computes: output[i] = input[i] / input[i + delta]\n\n'
            'The output image has (n_bands - delta) bands.\n\n'
            'Delta controls the offset between numerator and denominator bands.\n'
            'A delta of 1 ratios each band with its immediate neighbour.\n\n'
            'Wavelength metadata is preserved for the numerator bands.'
        )

    def createInstance(self):
        return BandRatiosAlgorithm()
