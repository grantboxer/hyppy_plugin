"""
Feature Extraction — REE  (Rare Earth Element — Neodymium absorptions)
=======================================================================
Targets four characteristic VNIR absorption features associated with
neodymium (Nd³⁺) in REE-bearing minerals, principally monazite,
and carbonatite host rocks.

Absorption bands (Boesche et al. 2015, Figure 1):
  ~580 nm   — Nd³⁺ absorption  (⁴G₅/₂ + ⁴G₇/₂  Stark-split group)
  ~740 nm   — Nd³⁺ absorption  (⁴F₇/₂ + ⁴S₃/₂)
  ~800 nm   — Nd³⁺ absorption  (⁴F₅/₂ + ²H₉/₂)
  ~870 nm   — Nd³⁺ absorption  (⁴F₃/₂)

Reference:
  Boesche, N.K., Rogass, C., Lubitz, C., Brell, M., Herrmann, S.,
  Mielke, C., Tonn, S., Appelt, O., Altenberger, U., Kaufmann, H.,
  2015. Hyperspectral REE (Rare Earth Element) Mapping of Outcrops—
  Applications for Neodymium Detection. Remote Sensing, 7(5), 5160-5186.
  https://doi.org/10.3390/rs70505160

  Boesche et al. 2014 (graph source, modified in 2015 publication):
  Two reference spectra for monazite and a monazite-rich carbonatite
  (Fen complex) showing Nd absorptions at 580, 740, 800, 870 nm.

WoM range:  530–910 nm  (covers all four Nd absorption bands)
Map stretch: 560–900 nm  (places the four features in colour space)
Colour:      Rainbow (Blue ~560 nm → Red ~900 nm)

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
)
import processing
import os


WORKFLOW_NOTE = """\
        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with VNIR coverage (≥ 530–910 nm)
        and wavelength metadata (ENVI format).<br/>
        Sensors: <b>EnMAP, PRISMA, HySpex, AVIRIS, ASD FieldSpec</b>.
        Sentinel-2 does not have sufficient spectral resolution for this analysis.
        </p>
"""

REE_NOTE = """\
        <p style="background-color:#e8f4fd; padding:6px; border-left:4px solid #1565c0;">
        <b>Neodymium (Nd³⁺) absorption features:</b>
        The four absorption bands at ~580, ~740, ~800, and ~870 nm are characteristic
        electronic transitions of the Nd³⁺ ion in the crystal field of host minerals.
        These are the same bands marked on Figure 1 of Boesche et al. (2015).
        </p>
"""


class FeReeAlgorithm(QgsProcessingAlgorithm):
    """Feature Extraction — REE Neodymium VNIR absorptions (580/740/800/870 nm)."""

    INPUT         = 'INPUT'
    NUM_FEATURES  = 'NUM_FEATURES'
    OUTPUT_WOM    = 'OUTPUT_WOM'
    OUTPUT_MAP    = 'OUTPUT_MAP'
    LEGEND_OUTPUT = 'LEGEND_OUTPUT'

    # WoM range covers all four Nd bands with margin
    WOM_START  = 530.0
    WOM_END    = 910.0

    # Colour stretch: 560–900 nm places the four bands in colour space
    MAP_MIN    = 560.0
    MAP_MAX    = 900.0
    DEPTH_MIN  = 0.0
    DEPTH_MAX  = 0.05   # Nd absorptions are typically shallow (< 5 % depth)

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube (VNIR, ≥530–910 nm)'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract (1–9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=4, minValue=1, maxValue=9))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_WOM,
            'Output WoM raster  (530–910 nm)'))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_MAP,
            'Output Wavelength Map RGB  (560–900 nm stretch)'))
        self.addParameter(QgsProcessingParameterFileDestination(
            self.LEGEND_OUTPUT,
            'Output Colour Legend (PNG)',
            fileFilter='PNG Files (*.png)',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        cube        = self.parameterAsRasterLayer(parameters, self.INPUT,  context)
        n           = self.parameterAsInt(parameters, self.NUM_FEATURES,   context)
        out_wom     = self.parameterAsOutputLayer(parameters, self.OUTPUT_WOM, context)
        out_map     = self.parameterAsOutputLayer(parameters, self.OUTPUT_MAP, context)
        legend_path = self.parameterAsFileOutput(parameters, self.LEGEND_OUTPUT, context)

        self._legend_path = None

        # Step 1: Wavelength of Minimum  530–910 nm
        feedback.setProgress(5)
        feedback.pushInfo('Step 1/2  Wavelength of Minimum  530–910 nm ...')
        feedback.pushInfo('  Targeting Nd³⁺ absorptions: ~580 nm, ~740 nm, ~800 nm, ~870 nm')
        feedback.pushInfo('  (Boesche et al. 2015 — neodymium VNIR electronic transitions)')
        feedback.pushInfo(f'  Extracting up to {n} features per pixel')

        wom_result = processing.run(
            'hyppy:wavelength_of_minimum',
            {
                'INPUT':            cube,
                'START_WAVELENGTH': self.WOM_START,
                'END_WAVELENGTH':   self.WOM_END,
                'MODE':             0,          # Division continuum removal
                'NUM_FEATURES':     n,
                'BROAD':            False,
                'USE_BBL':          True,
                'OUTPUT':           out_wom,
            },
            context=context,
            feedback=feedback,
            is_child_algorithm=True,
        )
        if feedback.isCanceled():
            return {}

        wom_path = wom_result['OUTPUT']
        feedback.pushInfo(f'  WoM raster saved: {wom_path}')

        # Step 2: Wavelength Mapping  560–900 nm
        feedback.setProgress(50)
        feedback.pushInfo('Step 2/2  Wavelength Mapping  560–900 nm stretch ...')
        feedback.pushInfo('  Blue  = ~560 nm  |  Cyan = ~740 nm  |  '
                          'Green = ~800 nm  |  Red = ~900 nm')

        from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
        wma     = WavelengthMappingAlgorithm()
        palette = wma.create_rainbow_palette()

        map_path = wma._run_colour_mapping(
            wom_path, palette,
            self.MAP_MIN, self.MAP_MAX,
            self.DEPTH_MIN, self.DEPTH_MAX,
            out_map, feedback,
        )

        feedback.setProgress(88)
        feedback.pushInfo(f'  Wavelength map saved: {map_path}')

        # Step 3: Legend
        if not legend_path:
            legend_path = os.path.join(
                os.path.dirname(wom_path), 'REE_Nd_legend.png')
        try:
            saved = wma.create_legend(
                legend_path, palette,
                self.MAP_MIN, self.MAP_MAX,
                self.DEPTH_MIN, self.DEPTH_MAX,
                feedback,
            )
            if saved:
                self._legend_path = saved
                feedback.pushInfo(f'  Colour legend saved: {saved}')
        except Exception as e:
            feedback.pushWarning(f'Legend generation failed: {e}')

        feedback.setProgress(100)
        feedback.pushInfo('Feature Extraction REE-Nd complete.')
        feedback.pushInfo('')
        feedback.pushInfo('Colour key:')
        feedback.pushInfo('  ~580 nm  — violet/blue  (Nd³⁺ ⁴G₅/₂ + ⁴G₇/₂ transitions)')
        feedback.pushInfo('  ~740 nm  — cyan         (Nd³⁺ ⁴F₇/₂ + ⁴S₃/₂ transitions)')
        feedback.pushInfo('  ~800 nm  — green        (Nd³⁺ ⁴F₅/₂ + ²H₉/₂ transitions)')
        feedback.pushInfo('  ~870 nm  — orange/red   (Nd³⁺ ⁴F₃/₂ transitions)')

        return {
            self.OUTPUT_WOM:    wom_path,
            self.OUTPUT_MAP:    map_path,
            self.LEGEND_OUTPUT: self._legend_path or '',
        }

    def postProcessAlgorithm(self, context, feedback):
        if getattr(self, '_legend_path', None):
            from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
            WavelengthMappingAlgorithm()._show_legend_dock(
                self._legend_path, feedback)
        return {}

    def name(self):        return 'fe_ree_nd'
    def displayName(self): return 'FE-REE  Neodymium VNIR  (580/740/800/870 nm)'
    def group(self):       return '6 - Feature Extraction'
    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + REE_NOTE + """
        <b>Feature Extraction — REE Neodymium VNIR Absorptions</b>

        <p>Targets four characteristic VNIR absorption bands of the Nd³⁺ ion as
        described in <b>Boesche et al. (2015)</b>, which demonstrated these features
        in reflectance spectra of monazite and monazite-rich carbonatites:</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Band (nm)</th><th>Ion Transition</th><th>Map Colour</th><th>Mineral context</th>
          </tr>
          <tr><td>~580</td><td>Nd³⁺ ⁴G₅/₂ + ⁴G₇/₂</td><td>Blue/violet</td>
              <td>Monazite, allanite, apatite</td></tr>
          <tr><td>~740</td><td>Nd³⁺ ⁴F₇/₂ + ⁴S₃/₂</td><td>Cyan</td>
              <td>Monazite, bastnäsite</td></tr>
          <tr><td>~800</td><td>Nd³⁺ ⁴F₅/₂ + ²H₉/₂</td><td>Green</td>
              <td>Monazite, xenotime (weak)</td></tr>
          <tr><td>~870</td><td>Nd³⁺ ⁴F₃/₂</td><td>Orange/red</td>
              <td>Monazite, carbonatite matrix</td></tr>
        </table>

        <p><b>WoM search range:</b> 530–910 nm  (covers all four bands)<br/>
        <b>Colour stretch:</b> 560–900 nm<br/>
        <b>Default features:</b> 4  (to detect all four Nd absorption bands)<br/>
        <b>Typical absorption depth:</b> shallow (&lt;5 %); use low depth threshold</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>530–910 nm</b>.</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>560–900 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <p><b>Minerals detectable via Nd³⁺ absorptions:</b></p>
        <ul>
          <li><b>Monazite</b> — (Ce,La,Nd,Th)PO₄ — primary REE phosphate</li>
          <li><b>Bastnäsite</b> — (Ce,La,Nd)CO₃F — primary REE fluorocarbonate</li>
          <li><b>Allanite</b> — Ca(Ce,La,Y,Nd)Al₂Fe(Si₂O₇)(SiO₄)O(OH) — REE epidote</li>
          <li><b>Apatite</b> — Ca₅(PO₄)₃(OH,F,Cl) with REE substitution</li>
          <li><b>Carbonatite host rocks</b> — Nd features visible in matrix reflectance</li>
        </ul>

        <p><b>Interpretation notes:</b></p>
        <ul>
          <li>The Nd absorptions are shallow (&lt;5 % depth) compared to SWIR
              clay/carbonate features — good atmospheric correction is essential.</li>
          <li>All four bands present simultaneously strongly indicates Nd-bearing phases.</li>
          <li>The ~580 nm band can be masked by ferric iron absorption (goethite, hematite)
              — check the 740 and 870 nm bands as confirmatory features.</li>
          <li>Carbonatite and alkaline intrusive terranes are the primary targets.</li>
        </ul>

        <p><b>Reference:</b><br/>
        Boesche, N.K. et al. (2015). Hyperspectral REE Mapping of Outcrops—
        Applications for Neodymium Detection.
        <i>Remote Sensing</i>, 7(5), 5160–5186.
        <a href="https://doi.org/10.3390/rs70505160">doi:10.3390/rs70505160</a></p>
        """

    def createInstance(self):
        return FeReeAlgorithm()
