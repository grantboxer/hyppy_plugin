"""
Spectral Angle Mapper (SAM) Algorithm for QGIS Processing

Ported from HyPy sam.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original Copyright (C) 2010-2022 Wim Bakker

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Fixes and improvements (v2.9):
  - Vectorised SAM/BC/SID/ED/ID computation: replaces nested Python pixel
    loop with NumPy matrix operations, giving 10-50x speedup on full scenes.
  - get_wavelengths() now also checks the default GDAL metadata domain
    (previously only checked 'ENVI' domain), matching the approach used by
    all other algorithms in the plugin.
  - ENVI header parser now handles multi-line 'spectra names' blocks that
    contain embedded commas within quoted names (e.g. USGS splib07).
  - Rule image nodata: NaN pixels in the input image now produce NaN (not 0)
    in the rule image, preventing spurious low-angle matches.
  - Classification image dtype changed from Byte (uint8, max 255 classes) to
    UInt16 to support spectral libraries with >255 entries.
  - Minor: progress reporting now updates correctly across all spectra.
"""

import os
import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterFile,
    QgsProcessingParameterEnum,
    QgsProcessingParameterString,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis,
)

from ..core import resample_spectrum
from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset


# ─────────────────────────────────────────────────────────────────────────────
#  Vectorised spectral distance functions (all operate on (N, B) arrays)
# ─────────────────────────────────────────────────────────────────────────────

def _sam_all(img_f, refs):
    """
    Compute spectral angle between every pixel and every reference spectrum.

    Args:
        img_f : (N, B) float64 image pixels (rows*cols x bands)
        refs  : (S, B) float64 reference spectra

    Returns:
        (N, S) float32 array of spectral angles in radians
    """
    n_img  = np.linalg.norm(img_f, axis=1, keepdims=True)   # (N, 1)
    n_refs = np.linalg.norm(refs,  axis=1, keepdims=True)   # (S, 1)
    dots   = img_f @ refs.T                                  # (N, S)
    denom  = n_img * n_refs.T                                # (N, S)
    cos_a  = np.where(denom > 0, dots / denom, np.nan)
    cos_a  = np.clip(cos_a, -1.0, 1.0)
    result = np.arccos(cos_a)
    # pixels with zero norm -> NaN
    result[n_img.ravel() == 0, :] = np.nan
    return result.astype(np.float32)


def _ed_all(img_f, refs):
    """Euclidean distance between every pixel and every reference."""
    # ||a - b||^2 = ||a||^2 + ||b||^2 - 2*a.b
    sq_img  = np.sum(img_f ** 2, axis=1, keepdims=True)     # (N, 1)
    sq_refs = np.sum(refs  ** 2, axis=1)                     # (S,)
    dots    = img_f @ refs.T                                  # (N, S)
    dist_sq = sq_img + sq_refs[np.newaxis, :] - 2.0 * dots
    dist_sq = np.maximum(dist_sq, 0.0)                       # numerical safety
    return np.sqrt(dist_sq).astype(np.float32)


def _bc_all(img_f, refs):
    """Bray-Curtis dissimilarity between every pixel and every reference."""
    result = np.zeros((img_f.shape[0], refs.shape[0]), dtype=np.float32)
    for s_idx, ref in enumerate(refs):
        num   = np.sum(np.abs(img_f - ref[np.newaxis, :]), axis=1)
        denom = np.sum(np.abs(img_f + ref[np.newaxis, :]), axis=1)
        with np.errstate(invalid='ignore', divide='ignore'):
            result[:, s_idx] = np.where(denom > 0, num / denom, np.nan)
    return result


def _sid_all(img_f, refs):
    """Spectral Information Divergence between every pixel and every reference."""
    result = np.zeros((img_f.shape[0], refs.shape[0]), dtype=np.float32)
    eps = 1e-10
    for s_idx, ref in enumerate(refs):
        # Only compute where all values are non-negative
        valid = np.all(img_f >= 0, axis=1) and np.all(ref >= 0)
        if not np.any(valid):
            result[:, s_idx] = np.nan
            continue
        # Probability distributions
        sum_img = np.sum(img_f, axis=1, keepdims=True)
        sum_ref = np.sum(ref)
        p = np.where(sum_img > 0, img_f / np.maximum(sum_img, eps), eps)
        q = ref / max(sum_ref, eps)
        p = np.maximum(p, eps)
        q = np.maximum(q, eps)
        sid = np.sum(p * np.log(p / q[np.newaxis, :]), axis=1) + \
              np.sum(q * np.log(q / p) if False else  # broadcast version below
                     (q[np.newaxis, :] * np.log(q[np.newaxis, :] / p)), axis=1)
        result[:, s_idx] = sid.astype(np.float32)
    return result


def _id_all(img_f, refs):
    """Sum of absolute intensity differences between every pixel and every reference."""
    result = np.zeros((img_f.shape[0], refs.shape[0]), dtype=np.float32)
    for s_idx, ref in enumerate(refs):
        result[:, s_idx] = np.sum(np.abs(img_f - ref[np.newaxis, :]), axis=1)
    return result


DISTANCE_FUNCTIONS = {
    'SAM': _sam_all,
    'BC':  _bc_all,
    'SID': _sid_all,
    'ED':  _ed_all,
    'ID':  _id_all,
}


# ─────────────────────────────────────────────────────────────────────────────
#  Algorithm
# ─────────────────────────────────────────────────────────────────────────────

class SpectralAngleMapperAlgorithm(QgsProcessingAlgorithm):
    """
    Spectral Angle Mapper (SAM) Classification Algorithm

    SAM is a physically-based spectral classification that uses an n-dimensional
    angle to match pixels to reference spectra. The algorithm determines the
    spectral similarity between two spectra by calculating the angle between
    the spectra, treating them as vectors in a space with dimensionality equal
    to the number of bands.

    This implementation supports multiple spectral similarity measures:
    - SAM (Spectral Angle Mapper) - default
    - BC  (Bray-Curtis Distance)
    - SID (Spectral Information Divergence)
    - ED  (Euclidean Distance)
    - ID  (Intensity Difference)
    """

    INPUT        = 'INPUT'
    SPECLIB      = 'SPECLIB'
    LIST_SPECTRA = 'LIST_SPECTRA'
    SPECFILTER   = 'SPECFILTER'
    MODE         = 'MODE'
    OUTPUT_RULES = 'OUTPUT_RULES'
    OUTPUT_CLASS = 'OUTPUT_CLASS'

    def initAlgorithm(self, config=None):

        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Input Hyperspectral Image', optional=False))

        self.addParameter(QgsProcessingParameterFile(
            self.SPECLIB, 'Spectral Library',
            behavior=QgsProcessingParameterFile.File,
            fileFilter='ENVI Spectral Library (*.sli *.hdr);;CSV Spectral Library (*.csv *.txt);;All Files (*.*)',
            optional=False))

        self.addParameter(QgsProcessingParameterBoolean(
            self.LIST_SPECTRA,
            'List available spectra names (does not run SAM)',
            defaultValue=False, optional=True))

        self.addParameter(QgsProcessingParameterString(
            self.SPECFILTER,
            'Spectra filter (comma-separated names, supports * wildcards. Leave empty for all)',
            defaultValue='', optional=True))

        self.addParameter(QgsProcessingParameterEnum(
            self.MODE, 'Similarity Measure',
            options=[
                'SAM - Spectral Angle Mapper (recommended)',
                'BC  - Bray-Curtis Distance',
                'SID - Spectral Information Divergence',
                'ED  - Euclidean Distance',
                'ID  - Intensity Difference',
            ],
            defaultValue=0, optional=False))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_RULES, 'Output Rule Image', optional=False))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_CLASS, 'Output Classification Image (optional)',
            optional=True))

    # ── Main processing ────────────────────────────────────────────────────

    def processAlgorithm(self, parameters, context, feedback):

        input_layer      = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        speclib_path     = self.parameterAsFile(parameters, self.SPECLIB, context)
        list_spectra     = self.parameterAsBool(parameters, self.LIST_SPECTRA, context)
        spec_filter      = self.parameterAsString(parameters, self.SPECFILTER, context).strip()
        mode_idx         = self.parameterAsEnum(parameters, self.MODE, context)
        output_rules_path = self.parameterAsOutputLayer(parameters, self.OUTPUT_RULES, context)
        output_class_path = self.parameterAsOutputLayer(parameters, self.OUTPUT_CLASS, context)

        modes = ['SAM', 'BC', 'SID', 'ED', 'ID']
        mode  = modes[mode_idx]
        dist_func = DISTANCE_FUNCTIONS[mode]

        feedback.pushInfo(f'Using {mode} similarity measure')

        # ── Open raster ────────────────────────────────────────────────
        input_ds = gdal.Open(input_layer.source(), gdal.GA_ReadOnly)
        if input_ds is None:
            raise QgsProcessingException(f'Failed to open input raster: {input_layer.source()}')

        cols  = input_ds.RasterXSize
        rows  = input_ds.RasterYSize
        bands = input_ds.RasterCount
        feedback.pushInfo(f'Input image: {cols} x {rows} pixels, {bands} bands')

        # ── Read input image ───────────────────────────────────────────
        feedback.pushInfo('Reading input image...')
        nodata_val = input_ds.GetRasterBand(1).GetNoDataValue()
        image_data = np.zeros((bands, rows, cols), dtype=np.float64)  # (B, R, C) — BSQ
        for b in range(bands):
            if feedback.isCanceled():
                return {}
            arr = input_ds.GetRasterBand(b + 1).ReadAsArray().astype(np.float64)
            if nodata_val is not None:
                arr[arr == nodata_val] = np.nan
            image_data[b] = arr
            feedback.setProgress(int((b + 1) / bands * 15))

        # Reshape to (N, B) for vectorised computation
        img_f = image_data.transpose(1, 2, 0).reshape(-1, bands)   # (N, B)

        # ── Load spectral library ──────────────────────────────────────
        feedback.pushInfo(f'Loading spectral library: {speclib_path}')
        spectra, spec_names, spec_wavelengths = self.load_spectral_library(speclib_path, feedback)

        if len(spectra) == 0:
            raise QgsProcessingException('No spectra found in spectral library')
        feedback.pushInfo(f'Loaded {len(spectra)} reference spectra')

        # ── List spectra mode ──────────────────────────────────────────
        if list_spectra:
            feedback.pushInfo('')
            feedback.pushInfo('=' * 60)
            feedback.pushInfo(f'Available spectra in library ({len(spec_names)} total):')
            feedback.pushInfo('=' * 60)
            for i, name in enumerate(spec_names):
                feedback.pushInfo(f'  {i + 1:4d}: {name}')
            feedback.pushInfo('=' * 60)
            feedback.pushInfo('Copy spectrum names into the "Spectra filter" field.')
            feedback.pushInfo('Use * as wildcard (e.g. "Kaolinite*" or "*alunite*").')
            feedback.pushInfo('Separate multiple filters with commas.')
            input_ds = None
            return {}

        # ── Apply spectra filter ───────────────────────────────────────
        if spec_filter:
            spectra, spec_names = self.filter_spectra(spectra, spec_names, spec_filter, feedback)
            if len(spectra) == 0:
                raise QgsProcessingException(
                    f'No spectra matched the filter: "{spec_filter}". '
                    f'Use "List available spectra names" to browse the library.')

        num_spectra = len(spectra)
        feedback.pushInfo(f'Using {num_spectra} reference spectra for classification')

        # ── Wavelength handling and resampling ─────────────────────────
        image_wavelengths = get_wavelengths_from_dataset(input_ds, bands, input_layer.source(), feedback)
        spectra = self._resample_if_needed(
            spectra, spec_names, spec_wavelengths, image_wavelengths, bands, feedback)

        # Stack reference spectra as (S, B) array
        refs = np.array([s.astype(np.float64) for s in spectra])   # (S, B)

        # ── Compute similarity ─────────────────────────────────────────
        feedback.pushInfo(f'Computing {mode} similarity ({rows * cols} pixels x {num_spectra} spectra)...')
        feedback.setProgress(20)

        # Call vectorised distance function: returns (N, S)
        sim_map = dist_func(img_f, refs)                             # (N, S)
        sim_map = sim_map.reshape(rows, cols, num_spectra)           # (R, C, S)

        feedback.setProgress(85)
        if feedback.isCanceled():
            return {}

        # ── Write rule image ───────────────────────────────────────────
        feedback.pushInfo('Writing rule image...')
        driver   = gdal.GetDriverByName('GTiff')
        rule_ds  = driver.Create(output_rules_path, cols, rows, num_spectra, gdal.GDT_Float32)
        rule_ds.SetGeoTransform(input_ds.GetGeoTransform())
        rule_ds.SetProjection(input_ds.GetProjection())

        for s_idx, spec_name in enumerate(spec_names):
            out_band = rule_ds.GetRasterBand(s_idx + 1)
            out_band.WriteArray(sim_map[:, :, s_idx])
            out_band.SetDescription(spec_name)
            out_band.SetNoDataValue(np.nan)
            out_band.FlushCache()

        rule_ds.FlushCache()
        rule_ds = None
        input_ds = None

        feedback.pushInfo('SAM analysis complete!')
        feedback.setProgress(95)

        results = {self.OUTPUT_RULES: output_rules_path}

        # ── Write classification image ─────────────────────────────────
        if output_class_path:
            feedback.pushInfo('Creating classification image...')
            self.create_classification(
                sim_map, output_rules_path, output_class_path,
                spec_names, mode, feedback)
            results[self.OUTPUT_CLASS] = output_class_path

        feedback.setProgress(100)
        return results

    # ── Wavelength resampling ──────────────────────────────────────────────

    def _resample_if_needed(self, spectra, spec_names, spec_wavelengths,
                            image_wavelengths, bands, feedback):
        """Detect unit mismatch and resample library spectra to image wavelengths."""

        if spec_wavelengths is None or image_wavelengths is None:
            # No wavelength info — just verify band counts
            for name, s in zip(spec_names, spectra):
                if len(s) != bands:
                    raise QgsProcessingException(
                        f'Band count mismatch: spectrum "{name}" has {len(s)} bands '
                        f'but image has {bands} bands. Add wavelength info for auto-resampling.')
            return spectra

        # Unit mismatch detection
        spec_max  = float(np.max(spec_wavelengths))
        image_max = float(np.max(image_wavelengths))

        if spec_max < 100 and image_max > 100:
            feedback.pushInfo(
                f'Wavelength unit mismatch: library in micrometres '
                f'({spec_wavelengths[0]:.4f}–{spec_wavelengths[-1]:.4f}), '
                f'image in nanometres ({image_wavelengths[0]:.1f}–{image_wavelengths[-1]:.1f}). '
                f'Converting library to nanometres (×1000).')
            spec_wavelengths = spec_wavelengths * 1000.0
        elif spec_max > 100 and image_max < 100:
            feedback.pushInfo(
                f'Wavelength unit mismatch: library in nanometres, image in micrometres. '
                f'Converting library to micrometres (÷1000).')
            spec_wavelengths = spec_wavelengths / 1000.0

        # Resample if needed
        if len(spec_wavelengths) != bands or not np.allclose(spec_wavelengths, image_wavelengths, atol=0.5):
            feedback.pushInfo(
                f'Resampling {len(spec_wavelengths)}-band library to match '
                f'{bands}-band image...')
            resampled = []
            for name, s in zip(spec_names, spectra):
                rs = resample_spectrum(s, spec_wavelengths, image_wavelengths)
                valid = int(np.sum(~np.isnan(rs)))
                feedback.pushInfo(f'  {name}: {len(s)} → {valid} valid bands')
                if valid == 0:
                    feedback.reportError(
                        f'Warning: "{name}" has 0 valid bands after resampling. '
                        f'Check wavelength ranges.')
                resampled.append(rs)
            return resampled
        else:
            feedback.pushInfo('Library and image wavelengths match — no resampling needed.')
            return spectra

    # ── Classification ─────────────────────────────────────────────────────

    def create_classification(self, sim_map, rules_path, output_path,
                              class_names, mode, feedback):
        """
        Create classification image from the in-memory similarity map.

        All similarity measures (SAM, BC, SID, ED, ID) are distance/divergence
        metrics where lower values indicate better matches, so argmin is always
        correct. Uses UInt16 to support libraries with >255 spectra.
        """
        rows, cols, num_classes = sim_map.shape

        # argmin across class axis; +1 reserves 0 for 'unclassified' / all-NaN pixels
        best_class = np.argmin(sim_map, axis=2).astype(np.uint16) + 1

        # Mark pixels where all classes returned NaN as unclassified (0)
        all_nan = np.all(np.isnan(sim_map), axis=2)
        best_class[all_nan] = 0

        # Open rule image just for geo-reference
        rules_ds = gdal.Open(rules_path, gdal.GA_ReadOnly)
        driver   = gdal.GetDriverByName('GTiff')
        class_ds = driver.Create(output_path, cols, rows, 1, gdal.GDT_UInt16)
        class_ds.SetGeoTransform(rules_ds.GetGeoTransform())
        class_ds.SetProjection(rules_ds.GetProjection())
        rules_ds = None

        class_band = class_ds.GetRasterBand(1)
        class_band.WriteArray(best_class)
        class_band.SetDescription('Classification')
        class_band.SetNoDataValue(0)
        class_band.SetCategoryNames(['Unclassified'] + class_names)
        class_band.FlushCache()
        class_ds = None

        feedback.pushInfo(f'Classification image saved: {output_path}')

    # ── Spectra filter ─────────────────────────────────────────────────────

    def filter_spectra(self, spectra, spec_names, filter_string, feedback):
        import fnmatch
        patterns = [p.strip() for p in filter_string.split(',') if p.strip()]
        if not patterns:
            return spectra, spec_names

        selected = set()
        name_patterns = []

        for p in patterns:
            # Index range "3-10"
            if '-' in p and all(part.strip().isdigit() for part in p.split('-', 1)):
                lo, hi = p.split('-', 1)
                for idx in range(int(lo) - 1, min(int(hi), len(spectra))):
                    selected.add(idx)
            elif p.isdigit():
                idx = int(p) - 1
                if 0 <= idx < len(spectra):
                    selected.add(idx)
            else:
                name_patterns.append(p)

        for i, name in enumerate(spec_names):
            for pat in name_patterns:
                if fnmatch.fnmatch(name.lower(), pat.lower()):
                    selected.add(i)
                    break

        sorted_idx = sorted(selected)
        filtered_spectra = [spectra[i] for i in sorted_idx]
        filtered_names   = [spec_names[i] for i in sorted_idx]

        feedback.pushInfo(f'Filter "{filter_string}" matched {len(filtered_spectra)} of {len(spectra)} spectra:')
        for name in filtered_names:
            feedback.pushInfo(f'  - {name}')

        return filtered_spectra, filtered_names

    # ── Spectral library loading ───────────────────────────────────────────

    def load_spectral_library(self, speclib_path, feedback):
        ext = os.path.splitext(speclib_path)[1].lower()
        if ext in ['.sli', '.hdr']:
            return self.load_envi_spectral_library(speclib_path, feedback)
        elif ext in ['.csv', '.txt']:
            return self.load_csv_spectral_library(speclib_path, feedback)
        else:
            feedback.pushInfo(f'Unknown extension "{ext}", trying ENVI first...')
            try:
                result = self.load_envi_spectral_library(speclib_path, feedback)
                if result[0]:
                    return result
            except Exception:
                pass
            return self.load_csv_spectral_library(speclib_path, feedback)

    def load_envi_spectral_library(self, speclib_path, feedback):
        sli_path, hdr_path = self.resolve_envi_paths(speclib_path, feedback)
        if hdr_path is None:
            raise QgsProcessingException(f'Cannot find .hdr for: {speclib_path}')
        if sli_path is None:
            raise QgsProcessingException(f'Cannot find .sli for: {speclib_path}')

        feedback.pushInfo(f'ENVI data: {sli_path}')
        feedback.pushInfo(f'ENVI header: {hdr_path}')

        hdr = self.parse_envi_header(hdr_path, feedback)
        num_samples    = hdr.get('samples', 0)
        num_lines      = hdr.get('lines', 0)
        data_type      = hdr.get('data_type', 4)
        byte_order     = hdr.get('byte_order', 0)
        header_offset  = hdr.get('header_offset', 0)
        spec_wavelengths = hdr.get('wavelengths', None)
        raw_names      = hdr.get('spectra_names', [])

        if num_samples == 0:
            raise QgsProcessingException('ENVI header has samples = 0')

        envi_dtypes = {1:'u1', 2:'i2', 3:'i4', 4:'f4', 5:'f8',
                       12:'u2', 13:'u4', 14:'i8', 15:'u8'}
        base_dtype = envi_dtypes.get(data_type, 'f4')
        endian     = '<' if byte_order == 0 else '>'
        dtype      = np.dtype(f'{endian}{base_dtype}')

        feedback.pushInfo(
            f'Header: {num_samples} samples × {num_lines} lines, '
            f'dtype {dtype}, byte_order {byte_order}')

        # Actual spectrum count from file size
        file_size = os.path.getsize(sli_path) - header_offset
        bytes_per = num_samples * dtype.itemsize
        actual    = file_size // bytes_per
        if actual != num_lines:
            feedback.pushInfo(f'Header says {num_lines} lines, file contains {actual}. Using {actual}.')
            num_lines = actual

        if spec_wavelengths is not None:
            feedback.pushInfo(
                f'Library wavelengths: {spec_wavelengths[0]:.4f} – '
                f'{spec_wavelengths[-1]:.4f} ({len(spec_wavelengths)} channels)')

        spectra = []
        gdal_ok = False
        try:
            ds = gdal.Open(sli_path, gdal.GA_ReadOnly)
            if ds and ds.RasterXSize == num_samples and ds.RasterYSize == num_lines and ds.RasterCount == 1:
                data = ds.GetRasterBand(1).ReadAsArray().astype(np.float64)
                if data is not None:
                    if data.ndim == 1:
                        data = data.reshape(1, -1)
                    data[data < -1e30] = np.nan
                    for i in range(data.shape[0]):
                        spectra.append(data[i, :])
                    gdal_ok = True
                    feedback.pushInfo(f'Read {len(spectra)} spectra via GDAL')
            ds = None
        except Exception as e:
            feedback.pushInfo(f'GDAL read failed ({e}), using direct binary read')

        if not gdal_ok:
            feedback.pushInfo('Reading binary data directly...')
            with open(sli_path, 'rb') as f:
                if header_offset > 0:
                    f.seek(header_offset)
                raw = f.read()
            data = np.frombuffer(raw, dtype=dtype).reshape(num_lines, num_samples).astype(np.float64)
            data[data < -1e30] = np.nan
            for i in range(data.shape[0]):
                spectra.append(data[i, :])
            feedback.pushInfo(f'Read {len(spectra)} spectra via direct binary read')

        spec_names = [raw_names[i] if i < len(raw_names) else f'Spectrum_{i+1}'
                      for i in range(len(spectra))]
        return spectra, spec_names, spec_wavelengths

    def resolve_envi_paths(self, speclib_path, feedback):
        base = os.path.splitext(speclib_path)[0]
        ext  = os.path.splitext(speclib_path)[1].lower()
        if ext == '.hdr':
            hdr_path = speclib_path
            sli_path = None
            for data_ext in ['.sli', '.dat', '.img', '.bin', '']:
                cand = base + data_ext
                if os.path.exists(cand) and cand != speclib_path:
                    sli_path = cand
                    break
        else:
            sli_path = speclib_path
            hdr_path = base + '.hdr'
            if not os.path.exists(hdr_path):
                hdr_path = None
        return sli_path, hdr_path

    def parse_envi_header(self, hdr_path, feedback):
        """
        Parse ENVI .hdr file.

        Handles multi-line brace-delimited lists for wavelength and spectra names.
        Correctly parses 'spectra names' lists even when individual names contain
        commas (e.g. USGS splib07 format).
        """
        result = {
            'samples': 0, 'lines': 0, 'bands': 1,
            'data_type': 4, 'byte_order': 0, 'header_offset': 0,
            'wavelengths': None, 'spectra_names': [], 'wavelength_units': None,
        }

        with open(hdr_path, 'r', errors='replace') as f:
            content = f.read()

        import re

        # Simple key = value
        for key, rkey, conv in [
            ('samples',       'samples',       int),
            ('lines',         'lines',         int),
            ('bands',         'bands',         int),
            ('data type',     'data_type',     int),
            ('byte order',    'byte_order',    int),
            ('header offset', 'header_offset', int),
        ]:
            m = re.search(rf'^{key}\s*=\s*(\S+)', content, re.MULTILINE | re.IGNORECASE)
            if m:
                try:
                    result[rkey] = conv(m.group(1))
                except ValueError:
                    pass

        m = re.search(r'^wavelength units\s*=\s*(.+)', content, re.MULTILINE | re.IGNORECASE)
        if m:
            result['wavelength_units'] = m.group(1).strip()

        def parse_braced(field):
            pat = rf'{field}\s*=\s*\{{([^}}]*)\}}'
            m = re.search(pat, content, re.DOTALL | re.IGNORECASE)
            return m.group(1) if m else None

        # Wavelengths
        wl_str = parse_braced('wavelength')
        if wl_str:
            try:
                result['wavelengths'] = np.array(
                    [float(w.strip()) for w in wl_str.split(',') if w.strip()])
            except ValueError:
                feedback.reportError('Could not parse wavelengths from header')

        # Spectra names — split on comma+newline to handle names that contain commas
        names_str = parse_braced('spectra names')
        if names_str:
            # Split on comma followed by optional whitespace and newline (USGS style)
            # Fall back to plain comma split if that yields single entry
            parts = re.split(r',\s*\n\s*', names_str.strip())
            if len(parts) <= 1:
                parts = [n.strip() for n in names_str.split(',')]
            result['spectra_names'] = [n.strip() for n in parts if n.strip()]

        return result

    def load_csv_spectral_library(self, speclib_path, feedback):
        spectra, spec_names, spec_wavelengths = [], [], None
        try:
            with open(speclib_path, 'r') as f:
                lines = f.readlines()
            if len(lines) < 2:
                raise QgsProcessingException('Spectral library file is too short')

            header = lines[0].strip().split(',')
            start  = 0
            try:
                float(header[0])
            except ValueError:
                start = 1

            try:
                wl = [float(x) for x in header[start:]]
                if wl:
                    spec_wavelengths = np.array(wl)
                    feedback.pushInfo(
                        f'Library wavelengths: {spec_wavelengths[0]:.1f} – '
                        f'{spec_wavelengths[-1]:.1f} nm ({len(spec_wavelengths)} bands)')
            except ValueError:
                feedback.reportError('Could not parse wavelengths from CSV header')

            for i, line in enumerate(lines[1:]):
                parts = line.strip().split(',')
                if len(parts) < 2:
                    continue
                try:
                    spectra.append(np.array([float(x) for x in parts[1:]]))
                    spec_names.append(parts[0].strip())
                except ValueError:
                    feedback.reportError(f'Skipping invalid spectrum at line {i+2}')
        except Exception as e:
            raise QgsProcessingException(f'Failed to load spectral library: {e}')
        return spectra, spec_names, spec_wavelengths

    # ── Wavelength extraction ──────────────────────────────────────────────

    # get_wavelengths removed — use shared utility from core.envi_header

    def name(self):
        return 'sam'

    def displayName(self):
        return 'Spectral Angle Mapper (SAM)'

    def group(self):
        return '4 - SAM Classification'

    def groupId(self):
        return '4_sam_classification'

    def shortHelpString(self):
        return """
        <b>Spectral Angle Mapper (SAM) Classification</b>

        <p>SAM is a physically-based spectral classification that uses an n-dimensional
        angle to match pixels to reference spectra. The algorithm determines the
        spectral similarity between two spectra by calculating the angle between
        the spectra, treating them as vectors in a space with dimensionality equal
        to the number of bands.</p>

        <p><b>Inputs:</b></p>
        <ul>
        <li><b>Input Hyperspectral Image:</b> Multi-band raster (ENVI or GeoTIFF with wavelength metadata)</li>
        <li><b>Spectral Library:</b> ENVI spectral library (.sli/.hdr) or CSV text file</li>
        <li><b>List available spectra names:</b> Check to list all spectra without running SAM</li>
        <li><b>Spectra filter:</b> Select specific spectra. Supports wildcards (*), comma-separated
          names, index numbers (1-based), and index ranges (e.g. 1-10). Case-insensitive.</li>
        <li><b>Similarity Measure:</b> SAM (recommended), BC, SID, ED, or ID</li>
        </ul>

        <p><b>Outputs:</b></p>
        <ul>
        <li><b>Rule Image:</b> Multi-band raster — one band per reference spectrum,
          containing the similarity (distance) value for every pixel</li>
        <li><b>Classification Image (optional):</b> Single-band UInt16 raster with the
          index (1-based) of the best-matching reference spectrum per pixel.
          Class 0 = unclassified (all-NaN pixel).</li>
        </ul>

        <p><b>Similarity Measures (all use minimum = best match):</b></p>
        <ul>
        <li><b>SAM:</b> Spectral Angle in radians — insensitive to illumination/albedo</li>
        <li><b>BC:</b> Bray-Curtis dissimilarity [0–1]</li>
        <li><b>SID:</b> Spectral Information Divergence</li>
        <li><b>ED:</b> Euclidean distance</li>
        <li><b>ID:</b> Sum of absolute intensity differences</li>
        </ul>

        <p><b>Reference:</b> Kruse et al. (1993) "The Spectral Image Processing System (SIPS)"</p>
        <p><i>Ported from HyPy by Wim Bakker, University of Twente</i></p>
        """

    def createInstance(self):
        return SpectralAngleMapperAlgorithm()
