"""
Wavelength Mapping Algorithm for QGIS Processing

Creates RGB color-coded maps of absorption feature wavelength and depth.

Ported from HyPy wavemap.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original Copyright (C) 2010-2022 Wim Bakker

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import numpy as np
import colorsys
import math
import os
from osgeo import gdal

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterEnum,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingException,
)


class WavelengthMappingAlgorithm(QgsProcessingAlgorithm):
    """
    Wavelength Mapping Algorithm
    
    Creates color-coded RGB maps from wavelength-of-minimum outputs.
    Uses HSV color space where:
    - Hue represents wavelength position
    - Value (brightness) represents feature depth
    
    This creates intuitive visualizations where different absorption 
    features are shown in different colors, with brightness indicating 
    feature strength.
    """

    INPUT = 'INPUT'
    WAVELENGTH_MIN = 'WAVELENGTH_MIN'
    WAVELENGTH_MAX = 'WAVELENGTH_MAX'
    DEPTH_MIN = 'DEPTH_MIN'
    DEPTH_MAX = 'DEPTH_MAX'
    COLOR_SCHEME = 'COLOR_SCHEME'
    OUTPUT = 'OUTPUT'
    LEGEND_OUTPUT = 'LEGEND_OUTPUT'

    def initAlgorithm(self, config=None):
        """Define inputs and outputs."""
        
        # Input must be output from Wavelength of Minimum
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT,
                'Input Wavelength Features (from Wavelength of Minimum)',
                optional=False
            )
        )
        
        # Wavelength stretch range
        self.addParameter(
            QgsProcessingParameterNumber(
                self.WAVELENGTH_MIN,
                'Minimum Wavelength for Display (nm)',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=2100.0,
                optional=False
            )
        )
        
        self.addParameter(
            QgsProcessingParameterNumber(
                self.WAVELENGTH_MAX,
                'Maximum Wavelength for Display (nm)',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=2350.0,
                optional=False
            )
        )
        
        # Depth stretch range
        self.addParameter(
            QgsProcessingParameterNumber(
                self.DEPTH_MIN,
                'Minimum Depth for Display',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=0.0,
                minValue=0.0,
                maxValue=1.0,
                optional=False
            )
        )
        
        self.addParameter(
            QgsProcessingParameterNumber(
                self.DEPTH_MAX,
                'Maximum Depth for Display',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=0.2,
                minValue=0.0,
                maxValue=1.0,
                optional=False
            )
        )
        
        # Color scheme
        self.addParameter(
            QgsProcessingParameterEnum(
                self.COLOR_SCHEME,
                'Color Scheme',
                options=[
                    'Rainbow (Blue → Red)',
                    'Rainbow with Steps'
                ],
                defaultValue=0,
                optional=False
            )
        )
        
        # Output RGB image
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                'Output Wavelength Map (RGB)',
                optional=False
            )
        )

        # Output legend PNG
        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.LEGEND_OUTPUT,
                'Output Wavelength Map Legend (PNG)',
                fileFilter='PNG Files (*.png)',
                optional=False
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """Execute the algorithm."""
        input_layer       = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        wav_min           = self.parameterAsDouble(parameters, self.WAVELENGTH_MIN, context)
        wav_max           = self.parameterAsDouble(parameters, self.WAVELENGTH_MAX, context)
        depth_min         = self.parameterAsDouble(parameters, self.DEPTH_MIN, context)
        depth_max         = self.parameterAsDouble(parameters, self.DEPTH_MAX, context)
        color_scheme      = self.parameterAsEnum(parameters, self.COLOR_SCHEME, context)
        output_path       = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        legend_output_path = self.parameterAsFileOutput(parameters, self.LEGEND_OUTPUT, context)

        palette = self.create_rainbow_palette() if color_scheme == 0 else self.create_stepped_palette()

        output_path = self._run_colour_mapping(
            input_layer, palette, wav_min, wav_max, depth_min, depth_max, output_path, feedback
        )
        if output_path is None:
            return {}

        # Generate legend — dock shown in postProcessAlgorithm on GUI thread
        self._legend_path = None
        try:
            saved = self.create_legend(
                legend_output_path, palette, wav_min, wav_max, depth_min, depth_max, feedback
            )
            if saved:
                self._legend_path = saved
                feedback.pushInfo(f'Legend saved to: {saved}')
        except Exception as e:
            feedback.pushWarning(f'Legend generation failed: {str(e)}')

        return {self.OUTPUT: output_path}

    def _run_colour_mapping(self, input_layer, palette, wav_min, wav_max,
                            depth_min, depth_max, output_path, feedback):
        """
        Core raster colour-mapping shared by processAlgorithm and Feature Extraction.
        Accepts either a QgsRasterLayer or a file path string as input_layer.
        Returns the output_path on success, or None if cancelled.
        """
        import numpy as np

        # Accept path string or layer object
        if isinstance(input_layer, str):
            src_path = input_layer
        else:
            src_path = input_layer.source()

        feedback.pushInfo(f'Wavelength range: {wav_min} - {wav_max} nm')
        feedback.pushInfo(f'Depth range: {depth_min} - {depth_max}')

        input_ds = gdal.Open(src_path, gdal.GA_ReadOnly)
        if input_ds is None:
            raise QgsProcessingException(f'Failed to open input raster: {src_path}')

        cols      = input_ds.RasterXSize
        rows      = input_ds.RasterYSize
        num_bands = input_ds.RasterCount

        if num_bands < 2:
            raise QgsProcessingException(
                'Input must have at least 2 bands (Band 1 = wavelength, Band 2 = depth).')

        feedback.pushInfo('Reading input bands...')
        wav_data   = input_ds.GetRasterBand(1).ReadAsArray()
        depth_data = input_ds.GetRasterBand(2).ReadAsArray()

        feedback.pushInfo('Creating wavelength map...')
        wav_stretched   = self.stretch_band(wav_data,   wav_min,   wav_max)
        depth_stretched = self.stretch_band(depth_data, depth_min, depth_max)

        rgb_data = np.zeros((rows, cols, 3), dtype=np.uint8)

        pal_arr = np.array(palette, dtype=np.float32)
        pal_hsv = np.array(
            [colorsys.rgb_to_hsv(pal_arr[i, 0], pal_arr[i, 1], pal_arr[i, 2])
             for i in range(256)],
            dtype=np.float32,
        )

        feedback.setProgress(10)
        valid   = (~np.isnan(wav_data)) & (~np.isnan(depth_data)) & (depth_data != 0)
        wav_idx = np.clip(wav_stretched.astype(np.int32), 0, 255)
        feedback.setProgress(20)

        H = pal_hsv[wav_idx, 0]
        S = pal_hsv[wav_idx, 1]
        V = (depth_stretched / 255.0).astype(np.float32)

        feedback.setProgress(40)
        H6 = H * 6.0
        I  = np.floor(H6).astype(np.int32) % 6
        f  = (H6 - np.floor(H6)).astype(np.float32)
        p  = V * (1.0 - S)
        q  = V * (1.0 - f * S)
        t  = V * (1.0 - (1.0 - f) * S)

        R = np.select([I==0,I==1,I==2,I==3,I==4,I==5],[V,q,p,p,t,V], default=V)
        G = np.select([I==0,I==1,I==2,I==3,I==4,I==5],[t,V,V,q,p,p], default=V)
        B = np.select([I==0,I==1,I==2,I==3,I==4,I==5],[p,p,t,V,V,q], default=V)

        feedback.setProgress(70)
        R8 = np.clip((R * 254).astype(np.int32) + 1, 1, 255).astype(np.uint8)
        G8 = np.clip((G * 254).astype(np.int32) + 1, 1, 255).astype(np.uint8)
        B8 = np.clip((B * 254).astype(np.int32) + 1, 1, 255).astype(np.uint8)

        rgb_data[:, :, 0] = np.where(valid, R8, 0)
        rgb_data[:, :, 1] = np.where(valid, G8, 0)
        rgb_data[:, :, 2] = np.where(valid, B8, 0)

        feedback.setProgress(80)
        if feedback.isCanceled():
            input_ds = None
            return None

        feedback.pushInfo('Writing output...')
        driver    = gdal.GetDriverByName('GTiff')
        output_ds = driver.Create(output_path, cols, rows, 3, gdal.GDT_Byte)
        output_ds.SetGeoTransform(input_ds.GetGeoTransform())
        output_ds.SetProjection(input_ds.GetProjection())
        for b in range(3):
            band = output_ds.GetRasterBand(b + 1)
            band.WriteArray(rgb_data[:, :, b])
            band.SetDescription(['Red', 'Green', 'Blue'][b])
            band.FlushCache()
        output_ds = None
        input_ds  = None

        feedback.pushInfo('Colour mapping complete.')
        feedback.pushInfo(f'  Hue  = Wavelength ({wav_min} - {wav_max} nm)')
        feedback.pushInfo(f'  Value = Depth ({depth_min} - {depth_max})')
        return output_path

    def postProcessAlgorithm(self, context, feedback):
        """
        Called on the main GUI thread after processing completes.
        Safe place to create Qt widgets.
        """
        if getattr(self, '_legend_path', None):
            self._show_legend_dock(self._legend_path, feedback)
        return {}

    def _show_legend_dock(self, legend_path, feedback):
        """
        Display the legend PNG in a floating QDockWidget.
        Called from postProcessAlgorithm which runs on the main GUI thread.
        """
        try:
            from qgis.PyQt.QtWidgets import QDockWidget, QLabel, QSizePolicy
            from qgis.PyQt.QtGui import QPixmap
            from qgis.PyQt.QtCore import Qt
            from qgis.utils import iface

            if iface is None:
                feedback.pushWarning('QGIS interface not available - legend not displayed')
                return

            legend_name = os.path.splitext(os.path.basename(legend_path))[0]

            # Load image
            pixmap = QPixmap(legend_path)
            if pixmap.isNull():
                feedback.pushWarning(f'Could not load legend image: {legend_path}')
                return

            # Build dock
            dock = QDockWidget(legend_name, iface.mainWindow())
            dock.setObjectName('HyppyLegendDock_' + legend_name)
            dock.setAllowedAreas(Qt.AllDockWidgetAreas)

            # Use a label that scales its image to fill available space
            label = QLabel()
            label.setPixmap(pixmap)
            label.setScaledContents(True)
            label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            label.setMinimumSize(100, 150)
            dock.setWidget(label)

            # Add to main window, then float it
            iface.mainWindow().addDockWidget(Qt.RightDockWidgetArea, dock)
            dock.setFloating(True)

            # Initial size: natural image size, positioned top-right
            main_win = iface.mainWindow()
            win_geom = main_win.geometry()
            dock_width = pixmap.width() + 20
            dock_height = pixmap.height() + 40
            dock.resize(dock_width, dock_height)
            dock.move(win_geom.right() - dock_width - 20, win_geom.top() + 60)

            dock.show()
            dock.raise_()

            feedback.pushInfo(f'Legend displayed: {legend_name}')

        except Exception as e:
            feedback.pushWarning(f'Could not display legend: {str(e)}')

    # ── Minimal 5x7 bitmap font (digits, punctuation, letters needed for labels) ──
    _FONT5X7 = {
        '0':[0b01110,0b10001,0b10011,0b10101,0b11001,0b10001,0b01110],
        '1':[0b00100,0b01100,0b00100,0b00100,0b00100,0b00100,0b01110],
        '2':[0b01110,0b10001,0b00001,0b00110,0b01000,0b10000,0b11111],
        '3':[0b11111,0b00010,0b00100,0b00110,0b00001,0b10001,0b01110],
        '4':[0b00010,0b00110,0b01010,0b10010,0b11111,0b00010,0b00010],
        '5':[0b11111,0b10000,0b11110,0b00001,0b00001,0b10001,0b01110],
        '6':[0b00110,0b01000,0b10000,0b11110,0b10001,0b10001,0b01110],
        '7':[0b11111,0b00001,0b00010,0b00100,0b01000,0b01000,0b01000],
        '8':[0b01110,0b10001,0b10001,0b01110,0b10001,0b10001,0b01110],
        '9':[0b01110,0b10001,0b10001,0b01111,0b00001,0b00010,0b01100],
        '.':[0b00000,0b00000,0b00000,0b00000,0b00000,0b01100,0b01100],
        '-':[0b00000,0b00000,0b00000,0b11111,0b00000,0b00000,0b00000],
        ' ':[0b00000,0b00000,0b00000,0b00000,0b00000,0b00000,0b00000],
        '(':[0b00010,0b00100,0b01000,0b01000,0b01000,0b00100,0b00010],
        ')':[0b01000,0b00100,0b00010,0b00010,0b00010,0b00100,0b01000],
        'D':[0b11110,0b10001,0b10001,0b10001,0b10001,0b10001,0b11110],
        'W':[0b10001,0b10001,0b10001,0b10101,0b10101,0b11011,0b10001],
        'a':[0b00000,0b00000,0b01110,0b00001,0b01111,0b10001,0b01111],
        'e':[0b00000,0b00000,0b01110,0b10001,0b11111,0b10000,0b01110],
        'g':[0b00000,0b00000,0b01111,0b10001,0b01111,0b00001,0b01110],
        'h':[0b10000,0b10000,0b10110,0b11001,0b10001,0b10001,0b10001],
        'i':[0b00100,0b00000,0b01100,0b00100,0b00100,0b00100,0b01110],
        'l':[0b01100,0b00100,0b00100,0b00100,0b00100,0b00100,0b01110],
        'm':[0b00000,0b00000,0b11010,0b10101,0b10101,0b10001,0b10001],
        'n':[0b00000,0b00000,0b10110,0b11001,0b10001,0b10001,0b10001],
        'p':[0b00000,0b00000,0b11110,0b10001,0b11110,0b10000,0b10000],
        't':[0b00100,0b00100,0b11111,0b00100,0b00100,0b00101,0b00010],
        'v':[0b00000,0b00000,0b10001,0b10001,0b10001,0b01010,0b00100],
        'x':[0b00000,0b00000,0b10001,0b01010,0b00100,0b01010,0b10001],
    }
    _CW, _CH, _CG = 5, 7, 1  # char width, height, gap

    def _text_width(self, text):
        return len(text) * (self._CW + self._CG) - self._CG

    def _draw_text(self, canvas, text, row, col, color=(0, 0, 0)):
        """Render text horizontally onto canvas at (row, col)."""
        x = col
        for ch in text:
            glyph = self._FONT5X7.get(ch, self._FONT5X7[' '])
            for r, bits in enumerate(glyph):
                for c in range(self._CW):
                    if bits & (1 << (4 - c)):
                        pr, pc = row + r, x + c
                        if 0 <= pr < canvas.shape[0] and 0 <= pc < canvas.shape[1]:
                            canvas[pr, pc] = color
            x += self._CW + self._CG

    def _draw_text_vertical(self, canvas, text, row, col, color=(0, 0, 0)):
        """Render text rotated 90 deg CCW (bottom of string at top of column)."""
        tw = self._text_width(text)
        tmp = np.ones((self._CH, tw, 3), dtype=np.uint8) * 255
        self._draw_text(tmp, text, 0, 0, color)
        rot = np.rot90(tmp, k=1)
        rh, rw = rot.shape[:2]
        r1 = min(row + rh, canvas.shape[0])
        c1 = min(col + rw, canvas.shape[1])
        canvas[row:r1, col:c1] = rot[:r1-row, :c1-col]

    def create_legend(self, legend_path, palette, wav_min, wav_max, depth_min, depth_max, feedback):
        """
        Create a fully annotated 2-D colour legend PNG using only numpy + stdlib.
        Y axis = Wavelength (nm) with tick labels and axis title.
        X axis = Depth with tick labels and axis title.
        No matplotlib or external dependencies.
        """
        import struct, zlib

        SW, SH = 256, 256  # swatch size (depth x wavelength)

        # ── Build colour swatch (vectorised) ─────────────────────────────────
        pal_arr = np.array(palette, dtype=np.float32)
        pal_hsv = np.array(
            [colorsys.rgb_to_hsv(pal_arr[i, 0], pal_arr[i, 1], pal_arr[i, 2])
             for i in range(256)],
            dtype=np.float32,
        )
        wav_norm = np.linspace(1.0, 0.0, SH, dtype=np.float32)  # row 0 = wav_max
        pal_idx  = np.clip((wav_norm * 254).astype(np.int32) + 1, 1, 255)
        H_row = pal_hsv[pal_idx, 0]
        S_row = pal_hsv[pal_idx, 1]
        V_col = np.linspace(0.0, 1.0, SW, dtype=np.float32)

        Hm = H_row[:, np.newaxis] + np.zeros((1, SW), dtype=np.float32)
        Sm = S_row[:, np.newaxis] + np.zeros((1, SW), dtype=np.float32)
        Vm = np.ones((SH, 1), dtype=np.float32) * V_col[np.newaxis, :]

        H6 = Hm * 6.0
        I  = np.floor(H6).astype(np.int32) % 6
        f  = (H6 - np.floor(H6)).astype(np.float32)
        p  = Vm * (1.0 - Sm)
        q  = Vm * (1.0 - f * Sm)
        t  = Vm * (1.0 - (1.0 - f) * Sm)

        R = np.select([I==0,I==1,I==2,I==3,I==4,I==5],[Vm,q,p,p,t,Vm], default=Vm)
        G = np.select([I==0,I==1,I==2,I==3,I==4,I==5],[t,Vm,Vm,q,p,p], default=Vm)
        B = np.select([I==0,I==1,I==2,I==3,I==4,I==5],[p,p,t,Vm,Vm,q], default=Vm)

        swatch = np.stack([
            (R * 255).clip(0, 255).astype(np.uint8),
            (G * 255).clip(0, 255).astype(np.uint8),
            (B * 255).clip(0, 255).astype(np.uint8),
        ], axis=2)

        # ── Canvas layout ─────────────────────────────────────────────────────
        # Left:   axis_title(8) + gap(3) + tick_label(30) + tick(6) + border(1) = LM=48
        # Right:  border(1) + gap(3)                                             = RM=4
        # Top:    border(1) + gap(3)                                             = TM=4
        # Bottom: tick(6) + gap(2) + tick_label(9) + gap(3) + axis_title(8) + gap(4) = BM=32
        LM, RM, TM, BM = 48, 4, 4, 32
        cW = LM + SW + RM
        cH = TM + SH + BM

        canvas = np.ones((cH, cW, 3), dtype=np.uint8) * 255

        # Place swatch and border
        canvas[TM:TM+SH, LM:LM+SW] = swatch
        canvas[TM-1,          LM-1:LM+SW+2] = 0
        canvas[TM+SH,         LM-1:LM+SW+2] = 0
        canvas[TM-1:TM+SH+1,  LM-1]         = 0
        canvas[TM-1:TM+SH+1,  LM+SW]        = 0

        # ── Y axis: wavelength ticks and labels ───────────────────────────────
        N_Y = 5
        for i in range(N_Y):
            frac   = i / (N_Y - 1)
            row    = TM + int(frac * (SH - 1))
            wav_nm = wav_max - frac * (wav_max - wav_min)
            label  = f'{wav_nm:.0f}'
            # Tick line
            canvas[row, LM-6:LM-1] = 0
            # Right-align label before tick
            tw = self._text_width(label)
            self._draw_text(canvas, label, row - self._CH // 2, LM - 7 - tw)

        # Y axis title (vertical, centred on swatch)
        y_title = 'Wavelength (nm)'
        tw_y = self._text_width(y_title)
        self._draw_text_vertical(canvas, y_title, TM + SH // 2 - tw_y // 2, 0)

        # ── X axis: depth ticks and labels ────────────────────────────────────
        N_X = 5
        for i in range(N_X):
            frac    = i / (N_X - 1)
            col     = LM + int(frac * (SW - 1))
            dep_val = depth_min + frac * (depth_max - depth_min)
            label   = f'{dep_val:.2f}'
            # Tick line
            canvas[TM+SH:TM+SH+6, col] = 0
            # Centre label under tick
            tw = self._text_width(label)
            self._draw_text(canvas, label, TM + SH + 8, col - tw // 2)

        # X axis title (centred under tick labels)
        x_title = 'Depth'
        tw_x = self._text_width(x_title)
        self._draw_text(canvas, x_title, TM + SH + 8 + self._CH + 4, LM + SW // 2 - tw_x // 2)

        # ── Write PNG (stdlib struct + zlib only) ─────────────────────────────
        def png_chunk(tag, data):
            c = struct.pack('>I', len(data)) + tag + data
            return c + struct.pack('>I', zlib.crc32(tag + data) & 0xFFFFFFFF)

        def write_png(arr, fpath):
            h_px, w_px = arr.shape[:2]
            raw_rows = b''.join(b'\x00' + arr[r].tobytes() for r in range(h_px))
            compressed = zlib.compress(raw_rows, 6)
            with open(fpath, 'wb') as fh:
                fh.write(b'\x89PNG\r\n\x1a\n')
                fh.write(png_chunk(b'IHDR',
                    struct.pack('>IIBBBBB', w_px, h_px, 8, 2, 0, 0, 0)))
                fh.write(png_chunk(b'IDAT', compressed))
                fh.write(png_chunk(b'IEND', b''))

        if not legend_path.lower().endswith('.png'):
            legend_path = legend_path + '.png'

        write_png(canvas, legend_path)
        return legend_path

    def stretch_band(self, data, min_val, max_val):
        """
        Stretch data to 0-255 range.
        
        Args:
            data: Input array
            min_val: Minimum value for stretch
            max_val: Maximum value for stretch
        
        Returns:
            Stretched array (uint8, 0-255)
        """
        stretched = (255.99 * (data - min_val) / (max_val - min_val))
        stretched = np.clip(stretched, 0, 255)
        return stretched.astype(np.uint8)

    def create_rainbow_palette(self):
        """
        Create rainbow color palette (blue → red).
        
        Returns:
            List of 256 (r, g, b) tuples, values 0-1
        """
        palette = []
        palette.append((1.0, 1.0, 1.0))  # White for index 0
        
        for i in range(1, 255):
            # Rainbow from blue (0.75) to red (0.0)
            h = (0.9 * (1 - i / 255.0) - 0.22) % 1.0
            r, g, b = colorsys.hsv_to_rgb(h, 1, 1)
            # Gamma correction for better visual balance
            r = math.pow(r, 0.7)
            g = math.pow(g, 0.7)
            b = math.pow(b, 0.7)
            palette.append((r, g, b))
        
        palette.append((1.0, 1.0, 1.0))  # White for index 255
        
        return palette

    def create_stepped_palette(self):
        """
        Create rainbow palette with brightness steps.
        
        Returns:
            List of 256 (r, g, b) tuples, values 0-1
        """
        palette = []
        palette.append((1.0, 1.0, 1.0))  # White for index 0
        
        for i in range(1, 255):
            h = (0.9 * (1 - i / 255.0) - 0.2) % 1.0
            # Add brightness steps
            v = 0.3 + 0.4 * ((i % 16) / 15.0)
            s = 1 - 0.5 * math.sqrt(i / 255.0)
            r, g, b = colorsys.hls_to_rgb(h, v, s)
            palette.append((r, g, b))
        
        palette.append((1.0, 1.0, 1.0))  # White for index 255
        
        return palette

    def name(self):
        return 'wavelength_mapping'

    def displayName(self):
        return 'Step 2c - Wavelength Mapping'

    def group(self):
        return '2 - Generate WoM Rasters'

    def groupId(self):
        return '2_generate_wom'

    def shortHelpString(self):
        return """
        <b>Wavelength Mapping</b>
        
        <p>Creates color-coded RGB maps from Wavelength of Minimum outputs. 
        Produces intuitive visualizations where different absorption features 
        are shown in different colors, with brightness indicating feature strength.</p>
        
        <p><b>Process:</b></p>
        <ol>
        <li>Reads Band 1 (wavelength) and Band 2 (depth) from input</li>
        <li>Maps wavelength to hue (color) using rainbow palette</li>
        <li>Maps depth to value (brightness) in HSV color space</li>
        <li>Converts to RGB for display</li>
        </ol>
        
        <p><b>Inputs:</b></p>
        <ul>
        <li><b>Input:</b> MUST be output from "Wavelength of Minimum" tool (Band 1 = wavelength, Band 2 = depth)</li>
        <li><b>Wavelength Range:</b> Min/max wavelength for color mapping
            <ul>
            <li>Example: 2100-2350 nm for clay minerals</li>
            <li>Example: 2000-2500 nm for broader mineral mapping</li>
            </ul>
        </li>
        <li><b>Depth Range:</b> Min/max depth for brightness mapping
            <ul>
            <li>Start at 0.0 usually</li>
            <li>Adjust max based on your data (try 0.1-0.3)</li>
            </ul>
        </li>
        <li><b>Color Scheme:</b>
            <ul>
            <li><b>Rainbow:</b> Smooth blue→red gradient (recommended)</li>
            <li><b>Rainbow with Steps:</b> Discrete brightness levels</li>
            </ul>
        </li>
        </ul>
        
        <p><b>Output:</b></p>
        <ul>
        <li>3-band RGB image suitable for display</li>
        <li><b>Color (Hue):</b> Wavelength position of absorption feature</li>
        <li><b>Brightness (Value):</b> Depth/strength of absorption feature</li>
        </ul>
        
        <p><b>Interpretation:</b></p>
        <ul>
        <li><b>Similar colors:</b> Similar absorption wavelengths (same mineral/material)</li>
        <li><b>Bright pixels:</b> Strong absorption features</li>
        <li><b>Dark/black pixels:</b> Weak or no features</li>
        <li><b>Color changes:</b> Different minerals or material types</li>
        </ul>
        
        <p><b>Applications:</b></p>
        <ul>
        <li>Mineral mapping (clays, carbonates, etc.)</li>
        <li>Vegetation stress visualization</li>
        <li>Material classification</li>
        <li>Rapid qualitative assessment of hyperspectral data</li>
        </ul>
        
        <p><b>Workflow:</b></p>
        <ol>
        <li>Run "Wavelength of Minimum" on your hyperspectral image</li>
        <li>Run "Wavelength Mapping" on the result</li>
        <li>Adjust wavelength/depth ranges for optimal visualization</li>
        <li>Interpret color patterns for material mapping</li>
        </ol>
        
        <p><b>Tips:</b></p>
        <ul>
        <li>Adjust depth max to brighten the image</li>
        <li>Narrow wavelength range to enhance subtle differences</li>
        <li>Use QGIS histogram to find optimal depth range</li>
        <li>Compare with spectral library data to identify materials</li>
        </ul>
        
        <p><i>Ported from HyPy by Wim Bakker, University of Twente</i></p>
        """

    def createInstance(self):
        return WavelengthMappingAlgorithm()
