"""
Band Ratio Algorithm for QGIS Processing

Computes a single band ratio (band1 / band2) from a hyperspectral image.
Bands are specified by wavelength (if available) or band index.

Ported from HyPy ratio.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original Copyright (C) 2010-2022 Wim Bakker

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis
)

from ..core.envi_header import get_wavelengths_from_dataset, get_bbl_from_dataset


class BandRatioAlgorithm(QgsProcessingAlgorithm):
    """
    Band Ratio Algorithm

    Computes a single-band ratio image: Band1 / Band2.
    Bands are specified by wavelength (nm). If no wavelength metadata is present,
    values are treated as 1-based band indices.

    Output is a single-band floating-point image.
    """

    INPUT = 'INPUT'
    WAVELENGTH1 = 'WAVELENGTH1'
    WAVELENGTH2 = 'WAVELENGTH2'
    USE_BBL = 'USE_BBL'
    OUTPUT = 'OUTPUT'

    def initAlgorithm(self, config=None):
        """Define inputs and outputs."""

        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT,
                'Input Hyperspectral Image',
                optional=False
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.WAVELENGTH1,
                'Numerator Band Wavelength (nm) or Band Index',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=0.0,
                minValue=0.0,
                optional=False
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.WAVELENGTH2,
                'Denominator Band Wavelength (nm) or Band Index',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=0.0,
                minValue=0.0,
                optional=False
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.USE_BBL,
                'Use Bad Band List (BBL) from metadata',
                defaultValue=True,
                optional=True
            )
        )

        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                'Output Band Ratio Image'
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """Execute the band ratio algorithm."""

        input_layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        wav1 = self.parameterAsDouble(parameters, self.WAVELENGTH1, context)
        wav2 = self.parameterAsDouble(parameters, self.WAVELENGTH2, context)
        use_bbl = self.parameterAsBoolean(parameters, self.USE_BBL, context)
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if input_layer is None:
            raise QgsProcessingException('Invalid input layer')
        if wav1 <= 0 or wav2 <= 0:
            raise QgsProcessingException('Both wavelength values must be > 0')

        ds = gdal.Open(input_layer.source())
        if ds is None:
            raise QgsProcessingException(f'Cannot open raster: {input_layer.source()}')

        n_bands = ds.RasterCount
        n_rows = ds.RasterYSize
        n_cols = ds.RasterXSize

        raster_path = input_layer.source()
        wavelengths = get_wavelengths_from_dataset(ds, n_bands, raster_path, feedback)

        if wavelengths is not None:
            # Find nearest band to each wavelength
            idx1 = int(np.argmin(np.abs(wavelengths - wav1)))
            idx2 = int(np.argmin(np.abs(wavelengths - wav2)))
            actual_wav1 = wavelengths[idx1]
            actual_wav2 = wavelengths[idx2]
            band_name = f'Ratio {actual_wav1:.2f}nm / {actual_wav2:.2f}nm'
            feedback.pushInfo(f'Numerator: band {idx1+1} ({actual_wav1:.2f} nm)')
            feedback.pushInfo(f'Denominator: band {idx2+1} ({actual_wav2:.2f} nm)')
        else:
            # Treat as 1-based band index
            idx1 = int(wav1) - 1
            idx2 = int(wav2) - 1
            if idx1 < 0 or idx1 >= n_bands or idx2 < 0 or idx2 >= n_bands:
                raise QgsProcessingException(
                    f'Band indices {int(wav1)} and {int(wav2)} are out of range (1-{n_bands})'
                )
            band_name = f'Ratio band {int(wav1)} / band {int(wav2)}'
            feedback.pushInfo(f'No wavelength metadata found. Using band indices: {int(wav1)} / {int(wav2)}')

        # Read the two bands
        band1_data = ds.GetRasterBand(idx1 + 1).ReadAsArray().astype(np.float64)
        band2_data = ds.GetRasterBand(idx2 + 1).ReadAsArray().astype(np.float64)

        nodata = ds.GetRasterBand(1).GetNoDataValue()
        if nodata is not None:
            band1_data[band1_data == nodata] = np.nan
            band2_data[band2_data == nodata] = np.nan

        # Compute ratio (suppress divide-by-zero)
        old_settings = np.seterr(all='ignore')
        ratio = band1_data / band2_data
        np.seterr(**old_settings)

        # Create output
        driver = gdal.GetDriverByName('GTiff')
        out_ds = driver.Create(output_path, n_cols, n_rows, 1, gdal.GDT_Float64)
        out_ds.SetGeoTransform(ds.GetGeoTransform())
        out_ds.SetProjection(ds.GetProjection())

        out_band = out_ds.GetRasterBand(1)
        out_band.WriteArray(ratio)
        out_band.SetDescription(band_name)
        out_band.SetNoDataValue(np.nan)

        metadata = {'band_ratio': band_name}
        if wavelengths is not None:
            metadata['numerator_wavelength'] = str(float(wavelengths[idx1]))
            metadata['denominator_wavelength'] = str(float(wavelengths[idx2]))
        out_ds.SetMetadata(metadata)

        out_ds.FlushCache()
        del ds, out_ds

        feedback.pushInfo('Band ratio completed successfully.')
        return {self.OUTPUT: output_path}

    # _get_wavelengths removed — use get_wavelengths_from_dataset from core.envi_header
    def name(self):
        return 'bandratio'

    def displayName(self):
        return 'Band Ratio'

    def group(self):
        return '5 - Spectral Processing Tools'

    def groupId(self):
        return '5_spectral_processing_tools'

    def shortHelpString(self):
        return (
            'Computes a single band ratio image: Band1 / Band2.\n\n'
            'Specify bands by wavelength in nanometres. The nearest available band '
            'to the requested wavelength will be used.\n\n'
            'If no wavelength metadata is present in the image, values are treated '
            'as 1-based band indices.\n\n'
            'Output is a single-band floating-point image.'
        )

    def createInstance(self):
        return BandRatioAlgorithm()
