"""
Convert Image to ENVI Algorithm for QGIS Processing

Converts a standard image file (TIFF, JPEG, PNG, etc.) to ENVI format.
Preserves georeferencing from GeoTIFF tags or World Files if present.

Ported from HyPy convert.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original HyPy Copyright (C) 2010-2022 Wim Bakker, University of Twente

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import os
import sys
import numpy as np

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterFileDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis,
)


def _guess_units(x, y):
    return 'Degrees' if abs(x) < 200 and abs(y) < 100 else 'Meters'


def _convert_image_to_envi(fin, fout, feedback=None):
    """Convert an image file to ENVI format. Returns (success, message)."""

    def log(msg):
        if feedback:
            feedback.pushInfo(msg)
        else:
            print(msg)

    # ── PIL / Pillow ────────────────────────────────────────────────────
    try:
        from PIL import Image
    except ImportError:
        try:
            import Image
        except ImportError:
            return False, "Pillow (PIL) is required but not installed."

    # ── envi2 ───────────────────────────────────────────────────────────
    try:
        from osgeo import gdal
        gdal.UseExceptions()
    except ImportError:
        return False, "GDAL is required but not available."

    try:
        im = Image.open(fin)
    except Exception as e:
        return False, "Cannot open input image: %s" % str(e)

    samples, lines = im.size

    band_names = None
    default_bands = None

    mode_map = {
        'RGB':  (3, ['R', 'G', 'B'], [1, 2, 3]),
        'RGBA': (4, ['R', 'G', 'B', 'A'], [1, 2, 3]),
        'CMYK': (4, ['C', 'M', 'Y', 'K'], None),
    }

    if im.mode in mode_map:
        bands, band_names, default_bands = mode_map[im.mode]
    elif im.mode == 'P':
        im = im.convert('RGB')
        bands, band_names, default_bands = 3, ['R', 'G', 'B'], [1, 2, 3]
    elif im.mode in ('L', '1') or im.mode.startswith('I') or im.mode.startswith('F'):
        bands = 1
        band_names = [os.path.basename(fin)]
    else:
        return False, "Unsupported image mode '%s'" % im.mode

    ima = np.asarray(im)
    dtype = ima.dtype

    log("Input:   %s" % fin)
    log("Mode:    %s  (%d band%s)" % (im.mode, bands, 's' if bands > 1 else ''))
    log("Size:    %d samples × %d lines" % (samples, lines))
    log("Dtype:   %s" % dtype)

    # ── Georeferencing ──────────────────────────────────────────────────
    map_info = None

    # Try GeoTIFF tags
    if os.path.splitext(fin)[1].lower() in ('.tif', '.tiff'):
        try:
            ifd = im.ifd
            cx = ifd[33922][3]
            cy = ifd[33922][4]
            px = ifd[33550][0]
            py = ifd[33550][1]
            map_info = ['Arbitrary', 1.0, 1.0, cx, cy, px, py, 1,
                        'units=%s' % _guess_units(cx, cy)]
            log("Georeferencing: read from GeoTIFF tags")
        except (KeyError, AttributeError, TypeError):
            map_info = None

    # Try World File
    if not map_info:
        try:
            from ..core import worldfile_reader
            tup = worldfile_reader.worldfile_get(fin)
            if tup:
                A, D, B, E, C, F = tup
                map_info = ['Arbitrary', 1.0, 1.0, C, F, A, -E, 1,
                            'units=%s' % _guess_units(C, F)]
                log("Georeferencing: read from World File")
        except (ImportError, AttributeError):
            pass

    if not map_info:
        log("Georeferencing: none found — output will have no map info")

    # ── Write ENVI output via GDAL ───────────────────────────────────────
    # Map numpy dtype to GDAL type
    gdal_type_map = {
        'uint8':   gdal.GDT_Byte,
        'int16':   gdal.GDT_Int16,
        'uint16':  gdal.GDT_UInt16,
        'int32':   gdal.GDT_Int32,
        'uint32':  gdal.GDT_UInt32,
        'float32': gdal.GDT_Float32,
        'float64': gdal.GDT_Float64,
    }
    gdal_dtype = gdal_type_map.get(str(dtype), gdal.GDT_Float32)

    driver = gdal.GetDriverByName('ENVI')
    if driver is None:
        return False, "GDAL ENVI driver not available."

    try:
        ds_out = driver.Create(fout, samples, lines, bands, gdal_dtype)
    except Exception as e:
        return False, "Cannot create output file: %s" % str(e)

    if len(ima.shape) == 2:
        # Single-band
        ds_out.GetRasterBand(1).WriteArray(ima)
        if band_names:
            ds_out.GetRasterBand(1).SetDescription(band_names[0])
    else:
        for b in range(bands):
            ds_out.GetRasterBand(b + 1).WriteArray(ima[:, :, b])
            if band_names:
                ds_out.GetRasterBand(b + 1).SetDescription(band_names[b])

    if map_info:
        # map_info[3]=upper-left x, map_info[4]=upper-left y,
        # map_info[5]=pixel width,  map_info[6]=pixel height
        try:
            ulx = float(map_info[3])
            uly = float(map_info[4])
            px_w = float(map_info[5])
            px_h = float(map_info[6])
            gt = (ulx, px_w, 0.0, uly, 0.0, -abs(px_h))
            ds_out.SetGeoTransform(gt)
        except (IndexError, ValueError):
            pass

    ds_out.FlushCache()
    del ds_out

    log("Output:  %s" % fout)
    log("Completed.")
    return True, "Conversion completed successfully."


# ── QGIS Algorithm wrapper ─────────────────────────────────────────────────

class ConvertImageToEnviAlgorithm(QgsProcessingAlgorithm):
    """Convert an image (TIFF, JPEG, PNG, etc.) to ENVI flat-binary format."""

    INPUT  = 'INPUT'
    OUTPUT = 'OUTPUT'

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT,
                'Input Image File',
                behavior=QgsProcessingParameterFile.File,
                fileFilter='Image Files (*.tif *.tiff *.jpg *.jpeg *.png *.bmp *.img);;All Files (*)',
                optional=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.OUTPUT,
                'Output ENVI File (no extension)',
                fileFilter='ENVI Files (*.img);;All Files (*)',
                optional=False,
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        fin  = self.parameterAsFile(parameters, self.INPUT, context)
        fout = self.parameterAsFileOutput(parameters, self.OUTPUT, context)

        # Strip .img extension if QGIS added one — ENVI driver adds its own
        if fout.lower().endswith('.img'):
            fout = fout[:-4]

        feedback.pushInfo("=== Convert Image to ENVI ===")
        ok, msg = _convert_image_to_envi(fin, fout, feedback=feedback)
        if not ok:
            raise QgsProcessingException(msg)

        return {self.OUTPUT: fout}

    # ── Metadata ────────────────────────────────────────────────────────

    def name(self):
        return 'convert_image_to_envi'

    def displayName(self):
        return 'G01 - Convert Image to ENVI'

    def group(self):
        return '7 - Convert Tools'

    def groupId(self):
        return 'convert_tools'

    def shortHelpString(self):
        return (
            "Convert a standard image file (TIFF, JPEG, PNG, BMP) to ENVI flat-binary format.\n\n"
            "Georeferencing is preserved from GeoTIFF tags if present.\n\n"
            "Ported from HyPy convert.py (Wim Bakker, University of Twente)."
        )

    def createInstance(self):
        return ConvertImageToEnviAlgorithm()
