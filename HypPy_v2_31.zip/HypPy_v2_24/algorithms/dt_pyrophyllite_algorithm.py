"""
DT Pyrophyllite Classification Algorithm for QGIS Processing

Classifies Al-OH pixels as pyrophyllite or related Al-OH minerals using
the diagnostic spectral features of pyrophyllite from the USGS GMEX
reference spectrum (AusSpec International 2005).

Al4[Si8O20](OH)4 — 2:1 Al-phyllosilicate (pyrophyllite-talc group)

============================  SPECTRAL LOGIC  ================================

Pyrophyllite diagnostic features (GMEX):
  ~2166 nm  — primary diagnostic Al-OH; depth(2166) is the main gate
  ~2066/2078 nm — doublet; "may persist in mixtures" — used as secondary
  ~2319 nm  — "persists in mixtures" — used as supporting evidence
  ~1396 nm  — "Single sharp absorption" — single peak vs kandite doublets

Decision tree:

Step 1 — GATE: Is there a primary Al-OH feature at ~2166 nm?
  depth(2166) <= threshold  ->  aspectral

Step 2 — WAVELENGTH: Is the primary feature in the pyrophyllite window?
  ~2160-2175 nm for pyrophyllite vs:
    ~2197-2215 nm = kandite group (kaolinite/dickite)
    ~2185-2200 nm = illite/muscovite
  wl(2166) in (2158, 2175]:
    Has the ~2066-2078 nm doublet?
      depth(2066) > doublet_threshold:
        doublet_wl <= 2073  ->  pyro_doublet_lo  (short-wave, ~2066 nm)
        doublet_wl <= 2079  ->  pyrophyllite     (centred doublet ~2072 nm)
        doublet_wl >  2079  ->  pyro_doublet_hi  (long-wave, ~2078 nm)
      depth(2066) <= doublet_threshold  ->  possible_pyro  (2166 nm only)
  wl(2166) in (2175, 2200]  ->  possible_illite   (illite/phengite range)
  wl(2166) in (2200, 2220]  ->  possible_kandite  (kaolinite/dickite range)
  else                       ->  not_AlOH

============================  INPUTS  ========================================
  WoM_2166     — WoM over 2155-2180 nm  (Band 1=wl, Band 2=depth of ~2166 nm)
  WoM_2066     — FE17-2066D output      (Band 1=wl doublet, Band 2=depth)

============================  THRESHOLDS  ====================================
  depth_2166_threshold   — min depth for valid Al-OH at 2166 nm (default 0.04)
  doublet_threshold      — min depth(2066) to confirm doublet (default 0.02)

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

import numpy as np
from osgeo import gdal
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

PYRO_CLASSES = [
    (0,  'unclassified',     0,   0,   0  ),
    (1,  'aspectral',        0,   0,   0  ),   # black
    (2,  'not_AlOH',         80,  80,  80 ),   # dark grey
    (3,  'possible_kandite', 0,   200,  50),   # green (kandite group range)
    (4,  'possible_illite',  150, 200, 100),   # yellow-green (illite range)
    (5,  'possible_pyro',    255, 200,  20),   # yellow (2166 nm only, no doublet)
    (6,  'pyro_doublet_lo',  255, 130,   0),   # amber (~2066 nm doublet)
    (7,  'pyrophyllite',     220,  40,  40),   # red (confirmed doublet centred)
    (8,  'pyro_doublet_hi',  180,   0, 120),   # magenta (~2078 nm doublet)
]
NAME_TO_ID = {m[1]: m[0] for m in PYRO_CLASSES}
ID_TO_NAME = {m[0]: m[1] for m in PYRO_CLASSES}

# Wavelength windows (nm)
PYRO_WL_MIN    = 2158.0   # pyrophyllite primary ~2166 nm window
PYRO_WL_MAX    = 2175.0
ILLITE_WL_MIN  = 2175.0
ILLITE_WL_MAX  = 2200.0
KANDITE_WL_MIN = 2200.0
KANDITE_WL_MAX = 2220.0

# Doublet position boundaries (nm)
DOUBLET_LO_MAX = 2073.0   # below = pyro_doublet_lo
DOUBLET_HI_MIN = 2079.0   # above = pyro_doublet_hi


class DtPyrophylliteAlgorithm(QgsProcessingAlgorithm):

    WOM_2166       = 'WOM_2166'
    WOM_2066       = 'WOM_2066'
    DEPTH_2166_THR = 'DEPTH_2166_THR'
    DOUBLET_THR    = 'DOUBLET_THR'
    OUTPUT_CLASS   = 'OUTPUT_CLASS'
    OUTPUT_RGB     = 'OUTPUT_RGB'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2166,
            'WoM 2166 raster — WoM over 2155-2180 nm  '
            '(Band 1=wavelength, Band 2=depth of ~2166 nm primary Al-OH)'))

        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_2066,
            'WoM 2066 raster — FE17-2066D output  '
            '(Band 1=doublet wavelength, Band 2=doublet depth)'))

        self.addParameter(QgsProcessingParameterNumber(
            self.DEPTH_2166_THR,
            'Minimum depth(2166) to classify as Al-OH present',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.04, minValue=0.0, maxValue=1.0))

        self.addParameter(QgsProcessingParameterNumber(
            self.DOUBLET_THR,
            'Minimum depth(2066) to confirm pyrophyllite doublet',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.02, minValue=0.0, maxValue=1.0))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_CLASS, 'Output: Pyrophyllite class raster'))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_RGB, 'Output: Pyrophyllite RGB raster',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        wom_2166_layer = self.parameterAsRasterLayer(parameters, self.WOM_2166,       context)
        wom_2066_layer = self.parameterAsRasterLayer(parameters, self.WOM_2066,       context)
        depth_2166_thr = self.parameterAsDouble    (parameters, self.DEPTH_2166_THR, context)
        doublet_thr    = self.parameterAsDouble    (parameters, self.DOUBLET_THR,    context)
        out_class      = self.parameterAsOutputLayer(parameters, self.OUTPUT_CLASS,   context)
        out_rgb        = self.parameterAsOutputLayer(parameters, self.OUTPUT_RGB,     context) \
                         if self.OUTPUT_RGB in parameters else None

        # ── Open WoM 2166 ─────────────────────────────────────────────────
        ds_2166 = gdal.Open(wom_2166_layer.source(), gdal.GA_ReadOnly)
        if ds_2166 is None:
            raise QgsProcessingException('Cannot open WoM 2166 raster')
        cols, rows = ds_2166.RasterXSize, ds_2166.RasterYSize
        if ds_2166.RasterCount < 2:
            raise QgsProcessingException(
                'WoM 2166 raster needs >= 2 bands (Band1=wavelength, Band2=depth)')
        feedback.pushInfo(f'WoM 2166 raster: {cols} x {rows}, {ds_2166.RasterCount} bands')
        wl_2166    = ds_2166.GetRasterBand(1).ReadAsArray().astype(np.float32)
        depth_2166 = ds_2166.GetRasterBand(2).ReadAsArray().astype(np.float32)

        # ── Open WoM 2066 ─────────────────────────────────────────────────
        ds_2066 = gdal.Open(wom_2066_layer.source(), gdal.GA_ReadOnly)
        if ds_2066 is None:
            raise QgsProcessingException('Cannot open WoM 2066 raster')
        if ds_2066.RasterXSize != cols or ds_2066.RasterYSize != rows:
            raise QgsProcessingException(
                f'WoM 2066 size mismatch ({ds_2066.RasterXSize}x{ds_2066.RasterYSize} '
                f'vs {cols}x{rows})')
        if ds_2066.RasterCount < 2:
            raise QgsProcessingException(
                'WoM 2066 raster needs >= 2 bands (Band1=wavelength, Band2=depth)')
        feedback.pushInfo('Reading WoM 2066 bands...')
        wl_2066    = ds_2066.GetRasterBand(1).ReadAsArray().astype(np.float32)
        depth_2066 = ds_2066.GetRasterBand(2).ReadAsArray().astype(np.float32)
        ds_2066 = None

        # ── Sanitise ──────────────────────────────────────────────────────
        nodata = (np.isnan(wl_2166) | np.isnan(depth_2166) |
                  np.isnan(wl_2066) | np.isnan(depth_2066))

        wl_2166s    = np.nan_to_num(wl_2166,    nan=0.0)
        depth_2166s = np.nan_to_num(depth_2166, nan=0.0)
        wl_2066s    = np.nan_to_num(wl_2066,    nan=0.0)
        depth_2066s = np.nan_to_num(depth_2066, nan=0.0)

        # ── Log thresholds ────────────────────────────────────────────────
        feedback.pushInfo('')
        feedback.pushInfo('Pyrophyllite classification thresholds:')
        feedback.pushInfo(f'  depth(2166) gate:       > {depth_2166_thr}')
        feedback.pushInfo(f'  Pyrophyllite window:    {PYRO_WL_MIN}-{PYRO_WL_MAX} nm')
        feedback.pushInfo(f'  Illite window:          {ILLITE_WL_MIN}-{ILLITE_WL_MAX} nm')
        feedback.pushInfo(f'  Kandite window:         {KANDITE_WL_MIN}-{KANDITE_WL_MAX} nm')
        feedback.pushInfo(f'  Doublet confirmation:   depth(2066) > {doublet_thr}')
        feedback.pushInfo(f'  Doublet lo boundary:    wl(2066) <= {DOUBLET_LO_MAX} nm')
        feedback.pushInfo(f'  Doublet hi boundary:    wl(2066) >= {DOUBLET_HI_MIN} nm')
        feedback.pushInfo('Applying pyrophyllite decision tree...')
        feedback.setProgress(20)

        class_data = np.zeros((rows, cols), dtype=np.uint8)

        # Step 1: aspectral
        mask_asp = depth_2166s <= depth_2166_thr
        class_data[mask_asp] = NAME_TO_ID['aspectral']

        # Active pixels
        mask_act = ~mask_asp

        # Step 2: wavelength routing
        mask_pyro_wl   = mask_act & (wl_2166s > PYRO_WL_MIN)    & (wl_2166s <= PYRO_WL_MAX)
        mask_illite_wl = mask_act & (wl_2166s > ILLITE_WL_MIN)  & (wl_2166s <= ILLITE_WL_MAX)
        mask_kand_wl   = mask_act & (wl_2166s > KANDITE_WL_MIN) & (wl_2166s <= KANDITE_WL_MAX)
        mask_other     = mask_act & (~mask_pyro_wl) & (~mask_illite_wl) & (~mask_kand_wl)

        class_data[mask_illite_wl] = NAME_TO_ID['possible_illite']
        class_data[mask_kand_wl]   = NAME_TO_ID['possible_kandite']
        class_data[mask_other]     = NAME_TO_ID['not_AlOH']

        # Step 3: within pyrophyllite window, check doublet
        mask_has_doublet = mask_pyro_wl & (depth_2066s > doublet_thr)
        mask_no_doublet  = mask_pyro_wl & (depth_2066s <= doublet_thr)

        class_data[mask_no_doublet] = NAME_TO_ID['possible_pyro']

        # Confirmed pyrophyllite: split by doublet wavelength position
        class_data[mask_has_doublet & (wl_2066s <= DOUBLET_LO_MAX)]                                = NAME_TO_ID['pyro_doublet_lo']
        class_data[mask_has_doublet & (wl_2066s >  DOUBLET_LO_MAX) & (wl_2066s < DOUBLET_HI_MIN)] = NAME_TO_ID['pyrophyllite']
        class_data[mask_has_doublet & (wl_2066s >= DOUBLET_HI_MIN)]                                = NAME_TO_ID['pyro_doublet_hi']

        class_data[nodata]        = 0
        class_data[wl_2166s == 0] = 0
        feedback.setProgress(65)

        # ── Summary ───────────────────────────────────────────────────────
        feedback.pushInfo('')
        feedback.pushInfo('Classification summary:')
        unique, counts = np.unique(class_data, return_counts=True)
        total = class_data.size
        for uid, cnt in zip(unique, counts):
            pct = 100.0 * cnt / total
            feedback.pushInfo(
                f'  {ID_TO_NAME.get(int(uid), "?"):22s}  (id={uid:2d})  {cnt:8d} px  {pct:5.1f}%')

        # Doublet depth stats for pyrophyllite pixels
        mask_confirmed = mask_has_doublet
        if mask_confirmed.any():
            d2066_p = depth_2066s[mask_confirmed & (depth_2066s > 0)]
            if d2066_p.size > 0:
                feedback.pushInfo('')
                feedback.pushInfo('Doublet depth(2066) — confirmed pyrophyllite pixels:')
                feedback.pushInfo(f'  min={d2066_p.min():.3f}  max={d2066_p.max():.3f}  '
                                  f'mean={d2066_p.mean():.3f}  median={np.median(d2066_p):.3f}')
            wl2166_p = wl_2166s[mask_pyro_wl & (wl_2166s > 0)]
            if wl2166_p.size > 0:
                feedback.pushInfo('Primary Al-OH wavelength (pyrophyllite window):')
                feedback.pushInfo(f'  min={wl2166_p.min():.1f}  max={wl2166_p.max():.1f}  '
                                  f'mean={wl2166_p.mean():.1f}  median={np.median(wl2166_p):.1f} nm')

        driver = gdal.GetDriverByName('GTiff')

        # ── Class raster ──────────────────────────────────────────────────
        feedback.pushInfo('Writing integer class raster...')
        ct = gdal.ColorTable()
        for mid, name, r, g, bv in PYRO_CLASSES:
            ct.SetColorEntry(mid, (r, g, bv, 255))

        class_ds = driver.Create(out_class, cols, rows, 1, gdal.GDT_Byte,
                                 options=['COMPRESS=LZW', 'TILED=YES'])
        class_ds.SetGeoTransform(ds_2166.GetGeoTransform())
        class_ds.SetProjection(ds_2166.GetProjection())
        b = class_ds.GetRasterBand(1)
        b.SetNoDataValue(0)
        b.SetDescription('Pyrophyllite Class')
        b.SetRasterColorTable(ct)
        b.SetRasterColorInterpretation(gdal.GCI_PaletteIndex)
        b.WriteArray(class_data)
        b.FlushCache()

        rat = gdal.RasterAttributeTable()
        rat.CreateColumn('Value', gdal.GFT_Integer, gdal.GFU_MinMax)
        rat.CreateColumn('Class', gdal.GFT_String,  gdal.GFU_Name)
        rat.CreateColumn('R',     gdal.GFT_Integer, gdal.GFU_Red)
        rat.CreateColumn('G',     gdal.GFT_Integer, gdal.GFU_Green)
        rat.CreateColumn('B',     gdal.GFT_Integer, gdal.GFU_Blue)
        for row_idx, (mid, name, r, g, bv) in enumerate(PYRO_CLASSES):
            rat.SetValueAsInt   (row_idx, 0, mid)
            rat.SetValueAsString(row_idx, 1, name)
            rat.SetValueAsInt   (row_idx, 2, r)
            rat.SetValueAsInt   (row_idx, 3, g)
            rat.SetValueAsInt   (row_idx, 4, bv)
        b.SetDefaultRAT(rat)
        class_ds = None
        result = {self.OUTPUT_CLASS: out_class}

        # ── Optional RGB raster ───────────────────────────────────────────
        if out_rgb:
            feedback.pushInfo('Writing RGB colour raster...')
            rgb_r     = np.zeros((rows, cols), dtype=np.uint8)
            rgb_g     = np.zeros((rows, cols), dtype=np.uint8)
            rgb_b_arr = np.zeros((rows, cols), dtype=np.uint8)
            for mid, name, r, g, bv in PYRO_CLASSES:
                mask = class_data == mid
                rgb_r[mask], rgb_g[mask], rgb_b_arr[mask] = r, g, bv
            rgb_ds = driver.Create(out_rgb, cols, rows, 3, gdal.GDT_Byte,
                                   options=['COMPRESS=LZW', 'TILED=YES'])
            rgb_ds.SetGeoTransform(ds_2166.GetGeoTransform())
            rgb_ds.SetProjection(ds_2166.GetProjection())
            for idx, (arr, lbl) in enumerate(
                    [(rgb_r, 'Red'), (rgb_g, 'Green'), (rgb_b_arr, 'Blue')], 1):
                band = rgb_ds.GetRasterBand(idx)
                band.WriteArray(arr)
                band.SetDescription(lbl)
                band.FlushCache()
            rgb_ds = None
            feedback.setProgress(92)
            result[self.OUTPUT_RGB] = out_rgb

        ds_2166 = None
        feedback.setProgress(100)
        feedback.pushInfo('DT Pyrophyllite classification complete.')
        return result

    def name(self):        return 'dt_pyrophyllite'
    def displayName(self): return 'DT Pyrophyllite Classification'
    def group(self):       return '3 - Decision Tree Classification'
    def groupId(self):     return '3_decision_tree_classification'

    def shortHelpString(self):
        return """
        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required inputs (run these first):</b><br/>
        1. <b>Wavelength of Minimum</b> with range <b>2155-2180 nm</b> — primary Al-OH WoM<br/>
        2. <b>FE17-2066D</b> — pyrophyllite doublet WoM raster
        </p>

        <b>DT Pyrophyllite Classification</b>

        <p>Classifies Al-OH pixels for pyrophyllite using the diagnostic spectral features
        from the USGS GMEX pyrophyllite reference spectrum (AusSpec International 2005).
        Al<sub>4</sub>[Si<sub>8</sub>O<sub>20</sub>](OH)<sub>4</sub> — 2:1 Al-phyllosilicate.</p>

        <p><b>GMEX pyrophyllite diagnostic features:</b></p>
        <ul>
          <li><b>~2166 nm</b> — "Diagnostic absorption" (primary gate)</li>
          <li><b>~2066/2078 nm</b> — doublet; "may persist in mixtures" (secondary confirmation)</li>
          <li><b>~2319 nm</b> — "persists in mixtures"</li>
          <li><b>~1396 nm</b> — "Single sharp absorption"</li>
        </ul>

        <p><b>Decision tree:</b></p>
        <ol>
          <li>depth(2166) &le; threshold &rarr; <b>aspectral</b></li>
          <li>wl(2166) in (2158, 2175] nm — pyrophyllite window:
            <ul>
              <li>depth(2066) &le; doublet_thresh &rarr;
                  <b>possible_pyro</b> <span style="color:#FFC814">&#9632;</span> (yellow)</li>
              <li>depth(2066) &gt; doublet_thresh, wl(2066) &le; 2073 &rarr;
                  <b>pyro_doublet_lo</b> <span style="color:#FF8200">&#9632;</span> (amber)</li>
              <li>depth(2066) &gt; doublet_thresh, wl(2066) 2073-2079 &rarr;
                  <b>pyrophyllite</b> <span style="color:#DC2828">&#9632;</span> (red)</li>
              <li>depth(2066) &gt; doublet_thresh, wl(2066) &ge; 2079 &rarr;
                  <b>pyro_doublet_hi</b> <span style="color:#B40078">&#9632;</span> (magenta)</li>
            </ul>
          </li>
          <li>wl(2166) in (2175, 2200] &rarr;
              <b>possible_illite</b> <span style="color:#96C864">&#9632;</span> (yellow-green)</li>
          <li>wl(2166) in (2200, 2220] &rarr;
              <b>possible_kandite</b> <span style="color:#00C832">&#9632;</span> (green)</li>
          <li>otherwise &rarr; <b>not_AlOH</b></li>
        </ol>

        <p>Processing log reports doublet depth statistics and primary Al-OH wavelength
        statistics for pyrophyllite-window pixels, useful for threshold review.</p>

        <p><i>Feature parameters from USGS GMEX Spectral Library, pyrophyllite entry
        (AusSpec International 2005). Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return DtPyrophylliteAlgorithm()
