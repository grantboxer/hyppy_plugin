"""
Subset Algorithm for QGIS Processing

Extracts a spatial and/or spectral subset from an ENVI hyperspectral image.

Parameters
----------
Spatial:  sample (column) range and line (row) range — pixel coordinates
Spectral: wavelength range in nm, or a comma/space-separated band-index list
          using the same HyPy syntax:  <2  >10  4  6-8  (0-based indices)
Output format: BIP, BIL, or BSQ
Output data type: same as input, or any standard numpy type
Sort wavelengths: reorder bands by ascending wavelength before subsetting
Use BBL: skip bad bands defined in the ENVI header

Ported from HyPy subset.py / tkSubset.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original HyPy Copyright (C) 2010-2022 Wim Bakker, University of Twente

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import os
import sys
import re
import math

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterString,
    QgsProcessingParameterEnum,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterExtent,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    QgsRectangle,
    Qgis,
)

from ..core.envi_header import (
    get_wavelengths_from_dataset,
    get_bbl_from_dataset,
    parse_hdr,
    find_hdr,
)

gdal.UseExceptions()


# ── Band-list parser (mirrors HyPy subset.parse()) ────────────────────────────

def _parse_band_list(s, n_bands):
    """
    Parse a HyPy-style band selection string into a sorted list of 0-based
    band indices.

      4          → [4]
      6-8        → [6, 7, 8]
      <3         → [0, 1, 2, 3]
      >10        → [10, 11, ..., n_bands-1]
      1 4 6-8    → [1, 4, 6, 7, 8]   (space or comma separated)

    Returns a sorted, deduplicated list.  Raises ValueError on bad input.
    """
    s = s.replace(',', ' ')
    result = []
    for term in s.split():
        term = term.strip()
        if not term:
            continue
        if term.startswith('>'):
            start = int(term[1:])
            result.extend(range(start, n_bands))
        elif term.startswith('<'):
            end = int(term[1:])
            result.extend(range(0, min(end + 1, n_bands)))
        elif '-' in term[1:]:          # handle negative-free range e.g. 6-8
            dash = term.index('-', 1)
            a, b = int(term[:dash]), int(term[dash+1:])
            result.extend(range(max(0, a), min(n_bands, b + 1)))
        else:
            idx = int(term)
            if 0 <= idx < n_bands:
                result.append(idx)
    return sorted(set(result))


def _parse_wavelength_range(wav_str, wavelengths):
    """
    Parse a wavelength range string 'min_nm - max_nm' (e.g. '1000-2400') into
    a list of 0-based band indices whose wavelengths fall within that range.
    """
    wav_str = wav_str.strip().replace(' ', '')
    # Accept formats: 1000-2400  or  1000:2400
    m = re.match(r'^([\d.]+)[:\-]([\d.]+)$', wav_str)
    if not m:
        raise ValueError(
            "Wavelength range must be 'min-max' or 'min:max' in nm, "
            "e.g. '1000-2400'.  Got: '%s'" % wav_str
        )
    wmin, wmax = float(m.group(1)), float(m.group(2))
    indices = [i for i, w in enumerate(wavelengths) if wmin <= w <= wmax]
    return indices


# ── ENVI header writer ─────────────────────────────────────────────────────────

_ENVI_DTYPE = {
    'uint8': 1, 'int16': 2, 'int32': 3,
    'float32': 4, 'float64': 5, 'uint16': 12,
    'uint32': 13, 'int64': 14, 'uint64': 15,
}

_GDAL_DTYPE = {
    'uint8':   gdal.GDT_Byte,
    'int16':   gdal.GDT_Int16,
    'uint16':  gdal.GDT_UInt16,
    'int32':   gdal.GDT_Int32,
    'uint32':  gdal.GDT_UInt32,
    'float32': gdal.GDT_Float32,
    'float64': gdal.GDT_Float64,
}


def _write_envi_sidecar(path, lines, samples, bands, dtype_str,
                         interleave='bsq',
                         band_names=None, wavelength=None,
                         fwhm=None, bbl=None,
                         map_info=None, coordinate_system=None,
                         description=''):
    """Write an ENVI .hdr sidecar alongside *path*."""
    dtype_num  = _ENVI_DTYPE.get(dtype_str, 4)
    byte_order = 0 if sys.byteorder == 'little' else 1
    hdr_path   = path + '.hdr'
    with open(hdr_path, 'w') as f:
        f.write("ENVI\n")
        if description:
            f.write("description = { %s }\n" % description)
        f.write("samples = %d\n" % samples)
        f.write("lines = %d\n"   % lines)
        f.write("bands = %d\n"   % bands)
        f.write("header offset = 0\n")
        f.write("file type = ENVI Standard\n")
        f.write("data type = %d\n"  % dtype_num)
        f.write("interleave = %s\n" % interleave)
        f.write("byte order = %d\n" % byte_order)
        if map_info:
            f.write("map info = %s\n" % map_info)
        if coordinate_system:
            f.write("coordinate system string = %s\n" % coordinate_system)
        if band_names:
            f.write("band names = {\n  " +
                    ",\n  ".join(str(n) for n in band_names) + " }\n")
        if wavelength is not None and len(wavelength):
            f.write("wavelength units = Nanometers\n")
            f.write("wavelength = {\n  " +
                    ",\n  ".join("%.4f" % w for w in wavelength) + " }\n")
        if fwhm is not None and len(fwhm):
            f.write("fwhm = {\n  " +
                    ",\n  ".join("%.4f" % v for v in fwhm) + " }\n")
        if bbl is not None and len(bbl):
            f.write("bbl = {\n  " +
                    ", ".join(str(int(v)) for v in bbl) + " }\n")
    return hdr_path


def _map_extent_to_pixels(gt, xmin, xmax, ymin, ymax, n_samps, n_lines):
    """
    Convert a map-coordinate bounding box to pixel (sample, line) indices
    using the GDAL geotransform.

    Returns (sample_start, sample_end, line_start, line_end) as integers,
    clamped to the image dimensions. sample_end and line_end are exclusive
    (i.e. the count, not the last valid index).

    The geotransform maps pixel (col, row) to map coordinates as:
        x = gt[0] + col*gt[1] + row*gt[2]
        y = gt[3] + col*gt[4] + row*gt[5]

    For a standard north-up image (gt[2]=0, gt[4]=0):
        col = (x - gt[0]) / gt[1]
        row = (y - gt[3]) / gt[5]   (gt[5] is negative)
    """
    if gt is None or gt == (0.0, 1.0, 0.0, 0.0, 0.0, 1.0):
        raise QgsProcessingException(
            "Image has no geotransform — cannot use map coordinates. "
            "Use pixel sample/line mode instead."
        )

    px_size_x = gt[1]   # positive
    px_size_y = gt[5]   # negative for north-up

    if px_size_x == 0 or px_size_y == 0:
        raise QgsProcessingException(
            "Degenerate geotransform (zero pixel size) — cannot convert "
            "map coordinates to pixels."
        )

    rot_x = gt[2]
    rot_y = gt[4]

    if rot_x != 0.0 or rot_y != 0.0:
        # Rotated image: use inverse of the 2×2 affine matrix
        # | gt[1]  gt[2] |   | px_size_x  rot_x |
        # | gt[4]  gt[5] |   | rot_y      px_size_y |
        det = px_size_x * px_size_y - rot_x * rot_y
        if det == 0:
            raise QgsProcessingException(
                "Singular geotransform — cannot convert map coordinates to pixels."
            )
        inv11 =  px_size_y / det
        inv12 = -rot_x     / det
        inv21 = -rot_y     / det
        inv22 =  px_size_x / det

        def _to_col_row(x, y):
            dx = x - gt[0]
            dy = y - gt[3]
            return inv11 * dx + inv12 * dy, inv21 * dx + inv22 * dy

        # Get pixel coordinates for all four corners of the bounding box
        corners = [
            _to_col_row(xmin, ymin),
            _to_col_row(xmin, ymax),
            _to_col_row(xmax, ymin),
            _to_col_row(xmax, ymax),
        ]
        cols = [c[0] for c in corners]
        rows = [c[1] for c in corners]
        col_min = min(cols)
        col_max = max(cols)
        row_min = min(rows)
        row_max = max(rows)
    else:
        # Standard north-up (common case)
        col_min = (xmin - gt[0]) / px_size_x
        col_max = (xmax - gt[0]) / px_size_x
        # gt[5] is negative, so ymax gives the smaller row number
        row_min = (ymax - gt[3]) / px_size_y
        row_max = (ymin - gt[3]) / px_size_y

    sample_start = max(0,       int(math.floor(col_min)))
    sample_end   = min(n_samps, int(math.ceil(col_max)))
    line_start   = max(0,       int(math.floor(row_min)))
    line_end     = min(n_lines, int(math.ceil(row_max)))

    return sample_start, sample_end, line_start, line_end


def _update_map_info(map_info_str, sample_start, line_start, gt):
    """
    Return a corrected ENVI map info string for a subset whose upper-left
    pixel is at (sample_start, line_start) in the original image.

    ENVI map info format (all comma-separated inside braces):
      { proj_name, ref_col, ref_row, easting, northing,
        x_pixel_size, y_pixel_size, [zone], [NS], [datum], [units=...], ... }

    ref_col / ref_row are 1-based pixel coordinates of the tie-point.
    For a standard north-up image they are '1, 1' and the easting/northing
    is the centre of that top-left pixel.

    Strategy: keep ref_col=1, ref_row=1 but recalculate the easting/northing
    to be the centre of the new top-left pixel (sample_start, line_start)
    using the GDAL geotransform (which gives the *top-left corner* of each
    pixel, so we add half a pixel to get the centre).
    """
    if not map_info_str or gt is None:
        return map_info_str

    # Parse: strip outer { } and split on commas
    s = map_info_str.strip()
    if s.startswith('{'):
        s = s[1:]
    if s.endswith('}'):
        s = s[:-1]
    parts = [p.strip() for p in s.split(',')]

    if len(parts) < 7:
        return map_info_str   # unexpected format – leave unchanged

    try:
        # Compute new tie-point (centre of new top-left pixel) from geotransform.
        # gt gives top-left corner of pixel (col, row) as:
        #   x = gt[0] + col*gt[1] + row*gt[2]
        #   y = gt[3] + col*gt[4] + row*gt[5]
        # Pixel centre = corner + 0.5*(pixel_size), i.e. add 0.5 pixel offset.
        new_east  = (gt[0] + sample_start * gt[1] + line_start * gt[2]
                     + 0.5 * gt[1] + 0.5 * gt[2])
        new_north = (gt[3] + sample_start * gt[4] + line_start * gt[5]
                     + 0.5 * gt[4] + 0.5 * gt[5])

        # Replace ref_col, ref_row with 1, 1 and update easting/northing
        parts[1] = '1'
        parts[2] = '1'
        parts[3] = '%.6f' % new_east
        parts[4] = '%.6f' % new_north
    except (ValueError, IndexError):
        return map_info_str   # leave unchanged on any parse error

    return '{ ' + ', '.join(parts) + ' }'


# ── Core subset function ────────────────────────────────────────────────────────

def _subset(ds, raster_path, fout, interleave, dtype_str,
            sample_start, sample_end,
            line_start, line_end,
            band_indices,
            wavelengths_all, fwhm_all, bbl_all, band_names_all,
            map_info_str, coord_sys_str,
            feedback):

    def log(msg):
        if feedback:
            feedback.pushInfo(str(msg))

    n_total_bands = ds.RasterCount
    n_total_lines = ds.RasterYSize
    n_total_samps = ds.RasterXSize

    # Clamp spatial bounds
    sample_start = max(0, sample_start)
    sample_end   = min(n_total_samps, sample_end)
    line_start   = max(0, line_start)
    line_end     = min(n_total_lines, line_end)

    if sample_start >= sample_end or line_start >= line_end:
        raise QgsProcessingException(
            "Spatial subset is empty — check sample/line ranges."
        )

    out_samples = sample_end - sample_start
    out_lines   = line_end   - line_start
    out_bands   = len(band_indices)

    log("Spatial:  lines %d–%d (%d), samples %d–%d (%d)" %
        (line_start, line_end, out_lines,
         sample_start, sample_end, out_samples))
    log("Spectral: %d band(s) selected from %d" % (out_bands, n_total_bands))

    # Determine output dtype
    if dtype_str == 'keep':
        gdal_src_type = ds.GetRasterBand(1).DataType
        np_type_name  = gdal.GetDataTypeName(gdal_src_type).lower()
        # Normalise GDAL names to numpy names
        np_type_name = np_type_name.replace('byte', 'uint8').replace('cint16','int16')
        gdal_out_type = gdal_src_type
    else:
        np_type_name  = dtype_str
        gdal_out_type = _GDAL_DTYPE.get(dtype_str, gdal.GDT_Float32)

    log("Data type: %s" % np_type_name)
    log("Interleave: %s" % interleave)

    # ── Subset band metadata ──────────────────────────────────────────────
    sel_wavelengths = ([wavelengths_all[i] for i in band_indices]
                       if (wavelengths_all is not None and len(wavelengths_all)) else None)
    sel_fwhm        = ([fwhm_all[i] for i in band_indices]
                       if (fwhm_all is not None and len(fwhm_all)) else None)
    sel_bbl         = ([bbl_all[i] for i in band_indices]
                       if (bbl_all is not None and len(bbl_all)) else None)
    sel_band_names  = ([band_names_all[i] for i in band_indices]
                       if (band_names_all is not None and len(band_names_all)) else None)

    # ── Create output with GDAL ENVI driver ──────────────────────────────
    driver = gdal.GetDriverByName('ENVI')
    if driver is None:
        raise QgsProcessingException("GDAL ENVI driver not available.")

    # GDAL ENVI driver always writes BSQ; we'll reorder in memory for BIL/BIP
    ds_out = driver.Create(fout, out_samples, out_lines, out_bands, gdal_out_type)
    if ds_out is None:
        raise QgsProcessingException("Cannot create output file: %s" % fout)

    # Copy geotransform adjusted for spatial offset
    gt = ds.GetGeoTransform()
    if gt and gt != (0.0, 1.0, 0.0, 0.0, 0.0, 1.0):
        new_gt = (
            gt[0] + sample_start * gt[1] + line_start * gt[2],
            gt[1], gt[2],
            gt[3] + sample_start * gt[4] + line_start * gt[5],
            gt[4], gt[5],
        )
        ds_out.SetGeoTransform(new_gt)
    else:
        new_gt = gt

    proj = ds.GetProjection()
    if proj:
        ds_out.SetProjection(proj)

    # Update ENVI map info to reflect the new upper-left origin
    updated_map_info = _update_map_info(map_info_str, sample_start, line_start, gt)

    # ── Copy band data ────────────────────────────────────────────────────
    for out_b, src_b in enumerate(band_indices):
        if feedback and feedback.isCanceled():
            del ds_out
            raise QgsProcessingException("Cancelled by user.")
        if feedback:
            feedback.setProgress(int((out_b / out_bands) * 90))

        src_band = ds.GetRasterBand(src_b + 1)   # GDAL is 1-based
        data = src_band.ReadAsArray(
            xoff=sample_start, yoff=line_start,
            win_xsize=out_samples, win_ysize=out_lines
        ).astype(np_type_name)

        out_band = ds_out.GetRasterBand(out_b + 1)
        out_band.WriteArray(data)

        # Copy description
        desc = src_band.GetDescription()
        if not desc and sel_wavelengths:
            desc = "%.4f" % sel_wavelengths[out_b]
        if desc:
            out_band.SetDescription(desc)

        nodata = src_band.GetNoDataValue()
        if nodata is not None:
            out_band.SetNoDataValue(nodata)

    ds_out.FlushCache()
    del ds_out

    # ── Write ENVI sidecar .hdr with full spectral metadata ──────────────
    # The GDAL ENVI driver writes a minimal .hdr; we overwrite it with a
    # complete one that includes wavelengths, fwhm, bbl, and correct interleave.
    _write_envi_sidecar(
        fout,
        lines=out_lines, samples=out_samples, bands=out_bands,
        dtype_str=np_type_name,
        interleave=interleave,
        band_names=sel_band_names,
        wavelength=sel_wavelengths,
        fwhm=sel_fwhm,
        bbl=sel_bbl,
        map_info=updated_map_info,
        coordinate_system=coord_sys_str,
        description=os.path.basename(raster_path) + ' subset',
    )

    if feedback:
        feedback.setProgress(100)

    log("Output:  %s" % fout)
    log("Completed.")


# ── QGIS Algorithm ──────────────────────────────────────────────────────────────

class SubsetAlgorithm(QgsProcessingAlgorithm):
    """
    Extract a spatial and/or spectral subset from an ENVI hyperspectral image.
    """

    INPUT          = 'INPUT'
    USE_MAP_COORDS = 'USE_MAP_COORDS'
    XMIN           = 'XMIN'
    XMAX           = 'XMAX'
    YMIN           = 'YMIN'
    YMAX           = 'YMAX'
    SAMPLE_START   = 'SAMPLE_START'
    SAMPLE_END     = 'SAMPLE_END'
    LINE_START     = 'LINE_START'
    LINE_END       = 'LINE_END'
    BAND_LIST      = 'BAND_LIST'
    WAV_RANGE      = 'WAV_RANGE'
    SORT_WAV       = 'SORT_WAV'
    USE_BBL        = 'USE_BBL'
    OUTPUT_FORMAT  = 'OUTPUT_FORMAT'
    OUTPUT_DTYPE   = 'OUTPUT_DTYPE'
    OUTPUT         = 'OUTPUT'

    FORMAT_OPTIONS = ['bsq', 'bil', 'bip']
    DTYPE_OPTIONS  = [
        'keep (same as input)',
        'uint8', 'int16', 'uint16', 'int32', 'uint32',
        'float32', 'float64',
    ]

    def initAlgorithm(self, config=None):

        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT,
                'Input Hyperspectral Image (ENVI)',
                optional=False,
            )
        )

        # ── Spatial subset mode ──────────────────────────────────────
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.USE_MAP_COORDS,
                'Use map coordinates for spatial subset '
                '(tick = enter map coordinates below; '
                'untick = enter pixel sample/line numbers)',
                defaultValue=False,
            )
        )

        # ── Map coordinate extent (used when USE_MAP_COORDS is True) ─
        self.addParameter(
            QgsProcessingParameterExtent(
                self.XMIN,
                'Spatial Extent (map coordinates) — used when "Use map '
                'coordinates" is ticked',
                optional=True,
            )
        )

        # ── Pixel coordinate subset (used when USE_MAP_COORDS is False) ─
        self.addParameter(
            QgsProcessingParameterNumber(
                self.SAMPLE_START,
                'First Sample (column, 0-based) — used when "Use map '
                'coordinates" is unticked',
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=0,
                minValue=0,
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.SAMPLE_END,
                'Last Sample (exclusive; 0 = full width)',
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=0,
                minValue=0,
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.LINE_START,
                'First Line (row, 0-based)',
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=0,
                minValue=0,
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.LINE_END,
                'Last Line (exclusive; 0 = full height)',
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=0,
                minValue=0,
                optional=True,
            )
        )

        # ── Spectral subset ──────────────────────────────────────────
        self.addParameter(
            QgsProcessingParameterString(
                self.WAV_RANGE,
                'Wavelength Range (nm), e.g. "1000-2400" (leave blank to use all bands)',
                defaultValue='',
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.BAND_LIST,
                'Band Index List (0-based), e.g. "0 5 10-20 >100" (overrides wavelength range)',
                defaultValue='',
                optional=True,
            )
        )

        # ── Options ──────────────────────────────────────────────────
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.SORT_WAV,
                'Sort bands by ascending wavelength before subsetting',
                defaultValue=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.USE_BBL,
                'Exclude bad bands (use Bad Band List from header)',
                defaultValue=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.OUTPUT_FORMAT,
                'Output Interleave Format',
                options=self.FORMAT_OPTIONS,
                defaultValue=0,   # bsq
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.OUTPUT_DTYPE,
                'Output Data Type',
                options=self.DTYPE_OPTIONS,
                defaultValue=0,   # keep
            )
        )

        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                'Output Subset Image',
            )
        )

    # ── processAlgorithm ──────────────────────────────────────────────────

    def processAlgorithm(self, parameters, context, feedback):

        input_layer  = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        raster_path  = input_layer.source()

        use_map_coords = self.parameterAsBoolean(parameters, self.USE_MAP_COORDS, context)
        sample_start = self.parameterAsInt(parameters, self.SAMPLE_START, context)
        sample_end   = self.parameterAsInt(parameters, self.SAMPLE_END,   context)
        line_start   = self.parameterAsInt(parameters, self.LINE_START,   context)
        line_end     = self.parameterAsInt(parameters, self.LINE_END,     context)
        wav_range    = self.parameterAsString(parameters, self.WAV_RANGE,  context).strip()
        band_list    = self.parameterAsString(parameters, self.BAND_LIST,  context).strip()
        sort_wav     = self.parameterAsBoolean(parameters, self.SORT_WAV,  context)
        use_bbl      = self.parameterAsBoolean(parameters, self.USE_BBL,   context)
        fmt_idx      = self.parameterAsEnum(parameters, self.OUTPUT_FORMAT, context)
        dtype_idx    = self.parameterAsEnum(parameters, self.OUTPUT_DTYPE,  context)
        fout         = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        interleave = self.FORMAT_OPTIONS[fmt_idx]
        dtype_str  = self.DTYPE_OPTIONS[dtype_idx]
        if dtype_str.startswith('keep'):
            dtype_str = 'keep'

        feedback.pushInfo("=== HypPy Subset ===")
        feedback.pushInfo("Input: %s" % raster_path)

        # ── Open with GDAL ────────────────────────────────────────────
        ds = gdal.Open(raster_path)
        if ds is None:
            raise QgsProcessingException("Cannot open raster: %s" % raster_path)

        n_bands  = ds.RasterCount
        n_lines  = ds.RasterYSize
        n_samps  = ds.RasterXSize
        feedback.pushInfo("Image: %d bands × %d lines × %d samples" %
                          (n_bands, n_lines, n_samps))

        # ── Resolve spatial bounds ────────────────────────────────────
        if use_map_coords:
            # Read the extent widget (stored under XMIN key)
            extent = self.parameterAsExtent(parameters, self.XMIN, context)
            if extent is None or extent.isEmpty():
                raise QgsProcessingException(
                    "No spatial extent supplied. "
                    "Please draw or enter an extent in the 'Spatial Extent' field."
                )
            gt = ds.GetGeoTransform()
            xmin = extent.xMinimum()
            xmax = extent.xMaximum()
            ymin = extent.yMinimum()
            ymax = extent.yMaximum()
            feedback.pushInfo(
                "Map extent:  X %.6f – %.6f,  Y %.6f – %.6f" %
                (xmin, xmax, ymin, ymax)
            )
            sample_start, sample_end, line_start, line_end = \
                _map_extent_to_pixels(gt, xmin, xmax, ymin, ymax, n_samps, n_lines)
            feedback.pushInfo(
                "Converted to pixels:  samples %d–%d,  lines %d–%d" %
                (sample_start, sample_end, line_start, line_end)
            )

        # ── Wavelengths, FWHM, BBL ────────────────────────────────────
        wavelengths = get_wavelengths_from_dataset(ds, n_bands, raster_path, feedback)
        bbl_raw     = get_bbl_from_dataset(ds, n_bands, raster_path, feedback)

        # Also try to get fwhm and band_names from the .hdr directly
        fwhm_all       = None
        band_names_all = None
        map_info_str   = None
        coord_sys_str  = None

        hdr_path = find_hdr(raster_path)
        if hdr_path:
            hdr = parse_hdr(hdr_path)
            # fwhm
            raw_fwhm = hdr.get('fwhm', '')
            if raw_fwhm:
                try:
                    vals = [float(v) for v in
                            raw_fwhm.strip('{}').replace(',', ' ').split()
                            if v.strip()]
                    if len(vals) == n_bands:
                        fwhm_all = vals
                except ValueError:
                    pass
            # band names
            raw_bn = hdr.get('band names', '')
            if raw_bn:
                parts = [p.strip() for p in
                         raw_bn.strip('{}').split(',') if p.strip()]
                if len(parts) == n_bands:
                    band_names_all = parts
            # map info
            map_info_str = hdr.get('map info', None)
            coord_sys_str = hdr.get('coordinate system string', None)

        # ── Build initial band index list (all bands, 0-based) ────────
        all_indices = list(range(n_bands))

        # Sort by wavelength?
        if sort_wav and wavelengths is not None and len(wavelengths):
            order = sorted(all_indices, key=lambda i: wavelengths[i])
        else:
            order = all_indices

        # Apply BBL filter?
        if use_bbl and bbl_raw is not None:
            order = [i for i in order if bbl_raw[i]]
            feedback.pushInfo("After BBL filter: %d good bands" % len(order))

        # Reindex wavelengths/fwhm/bbl/band_names to sorted+filtered order
        def reindex(lst):
            return [lst[i] for i in order] if (lst is not None and len(lst)) else None

        wavelengths_ord = reindex(wavelengths)
        fwhm_ord        = reindex(fwhm_all)
        bbl_ord         = reindex(bbl_raw)    # all 1 after BBL filter
        band_names_ord  = reindex(band_names_all)

        # ── Spectral selection ────────────────────────────────────────
        if band_list:
            # User supplied explicit band indices (into the sorted+filtered list)
            try:
                selected = _parse_band_list(band_list, len(order))
            except (ValueError, IndexError) as e:
                raise QgsProcessingException(
                    "Invalid band list '%s': %s" % (band_list, str(e))
                )
            band_indices = [order[i] for i in selected]
            feedback.pushInfo("Band list selection: %d bands" % len(band_indices))

        elif wav_range:
            if wavelengths_ord is None:
                raise QgsProcessingException(
                    "Wavelength range requested but no wavelength data found in image header."
                )
            try:
                selected = _parse_wavelength_range(wav_range, wavelengths_ord)
            except ValueError as e:
                raise QgsProcessingException(str(e))
            band_indices = [order[i] for i in selected]
            if not band_indices:
                raise QgsProcessingException(
                    "No bands fall within wavelength range '%s'." % wav_range
                )
            feedback.pushInfo(
                "Wavelength range %s: %d band(s) selected (%.1f–%.1f nm)" %
                (wav_range, len(band_indices),
                 wavelengths_ord[selected[0]], wavelengths_ord[selected[-1]])
            )

        else:
            band_indices = order
            feedback.pushInfo("All %d bands selected" % len(band_indices))

        if not band_indices:
            raise QgsProcessingException("No bands selected — nothing to write.")

        # ── Spatial defaults (0 means full extent) ────────────────────
        if sample_end == 0:
            sample_end = n_samps
        if line_end == 0:
            line_end = n_lines

        # ── Reconstruct per-output-band metadata ─────────────────────
        # band_indices is a list of original (pre-sort) band indices, so we
        # need the corresponding metadata from the sorted+filtered lists.
        # Build a mapping: original index → position in 'order'
        orig_to_ord = {orig: pos for pos, orig in enumerate(order)}

        def pick(lst):
            if lst is None:
                return None
            return [lst[orig_to_ord[i]] for i in band_indices
                    if i in orig_to_ord]

        wav_out       = pick(wavelengths_ord)   # may differ from wavelengths_all order
        fwhm_out      = pick(fwhm_ord)
        bbl_out       = pick(bbl_ord)
        band_names_out = pick(band_names_ord)

        # ── Run ───────────────────────────────────────────────────────
        _subset(
            ds=ds,
            raster_path=raster_path,
            fout=fout,
            interleave=interleave,
            dtype_str=dtype_str,
            sample_start=sample_start,
            sample_end=sample_end,
            line_start=line_start,
            line_end=line_end,
            band_indices=band_indices,
            wavelengths_all=wavelengths_ord,   # full ordered list for fallback
            fwhm_all=fwhm_ord,
            bbl_all=bbl_ord,
            band_names_all=band_names_ord,
            map_info_str=map_info_str,
            coord_sys_str=coord_sys_str,
            feedback=feedback,
        )

        return {self.OUTPUT: fout}

    # ── Metadata ──────────────────────────────────────────────────────────

    def name(self):
        return 'subset'

    def displayName(self):
        return 'E08 - Subset'

    def group(self):
        return '5 - Spectral Processing Tools'

    def groupId(self):
        return 'spectral_processing'

    def shortHelpString(self):
        return (
            "Extract a spatial and/or spectral subset from an ENVI hyperspectral image.\n\n"
            "SPATIAL SUBSET — two modes (choose one):\n\n"
            "  Pixel mode (default — 'Use map coordinates' unticked):\n"
            "    Set First/Last Sample and First/Last Line (0-based pixel coordinates).\n"
            "    Leave Last Sample or Last Line at 0 to use the full image extent.\n\n"
            "  Map coordinate mode ('Use map coordinates' ticked):\n"
            "    Draw or enter an extent rectangle in the 'Spatial Extent' field.\n"
            "    The bounding box is converted to pixel indices using the image\n"
            "    geotransform.  Works with rotated images too.\n\n"
            "SPECTRAL SUBSET\n"
            "• Wavelength Range: enter 'min-max' in nm, e.g. '1000-2400'.\n"
            "• Band Index List: space/comma-separated 0-based indices with HyPy syntax:\n"
            "    4        → band 4 only\n"
            "    6-8      → bands 6, 7, 8\n"
            "    <3       → bands 0, 1, 2, 3\n"
            "    >100     → bands 100 to last\n"
            "    1 4 6-8  → bands 1, 4, 6, 7, 8\n"
            "  Band Index List takes priority over Wavelength Range.\n"
            "  Leave both blank to keep all bands.\n\n"
            "OPTIONS\n"
            "• Sort bands by wavelength: reorders bands ascending before subsetting.\n"
            "• Exclude bad bands (BBL): removes bands flagged in the ENVI header.\n"
            "• Output format: BSQ (default), BIL, or BIP.\n"
            "• Output data type: keep (same as input) or convert to a different type.\n\n"
            "Wavelengths, FWHM, and BBL from the input header are preserved in the "
            "output ENVI .hdr sidecar.\n\n"
            "Ported from HyPy subset.py (Wim Bakker, University of Twente)."
        )

    def createInstance(self):
        return SubsetAlgorithm()
