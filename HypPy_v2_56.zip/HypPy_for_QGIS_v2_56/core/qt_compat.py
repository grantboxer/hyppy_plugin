"""
qt_compat.py — Qt5 / Qt6 compatibility shim for HypPy for QGIS

QGIS 3.x uses PyQt5 (Qt5); QGIS 4.x uses PyQt6 (Qt6).
The main breaking changes between PyQt5 and PyQt6 are:

  1. exec_() renamed to exec()
  2. Enums became scoped (e.g. Qt.LeftButton → Qt.MouseButton.LeftButton)
  3. QFont weight constants moved (QFont.Bold → QFont.Weight.Bold)

This module detects the Qt version at import time and exposes normalised
constants under a single namespace so the rest of the plugin can write:

    from ..core.qt_compat import Enums as E
    widget.setPopupMode(E.ToolButtonInstantPopup)
    if event.button() == E.LeftButton: ...

All constants are prefixed to avoid ambiguity.  The shim never imports
Qt directly — it always goes through qgis.PyQt so QGIS controls the
binding.
"""

from qgis.PyQt.QtCore import QT_VERSION_STR

# ── version detection ─────────────────────────────────────────────────────
QT_MAJOR = int(QT_VERSION_STR.split('.')[0])
IS_QT6   = QT_MAJOR >= 6

# ── import Qt namespaces ──────────────────────────────────────────────────
from qgis.PyQt.QtCore    import Qt
from qgis.PyQt.QtGui     import QFont
from qgis.PyQt.QtWidgets import (
    QAbstractItemView, QDialog, QDialogButtonBox,
    QFrame, QHeaderView, QSizePolicy, QToolButton,
)


class Enums:
    """Unified enum constants that work on both Qt5 and Qt6."""

    if IS_QT6:
        # ── Qt.* ──────────────────────────────────────────────────────────
        AlignCenter             = Qt.AlignmentFlag.AlignCenter
        SolidLine               = Qt.PenStyle.SolidLine
        RoundCap                = Qt.PenCapStyle.RoundCap
        RoundJoin               = Qt.PenJoinStyle.RoundJoin
        CustomContextMenu       = Qt.ContextMenuPolicy.CustomContextMenu
        ToolButtonTextBesideIcon = Qt.ToolButtonStyle.ToolButtonTextBesideIcon
        LeftButton              = Qt.MouseButton.LeftButton
        RightButton             = Qt.MouseButton.RightButton
        Key_Escape              = Qt.Key.Key_Escape
        CrossCursor             = Qt.CursorShape.CrossCursor
        ClosedHandCursor        = Qt.CursorShape.ClosedHandCursor
        OpenHandCursor          = Qt.CursorShape.OpenHandCursor
        ArrowCursor             = Qt.CursorShape.ArrowCursor
        LeftDockWidgetArea      = Qt.DockWidgetArea.LeftDockWidgetArea
        RightDockWidgetArea     = Qt.DockWidgetArea.RightDockWidgetArea
        BottomDockWidgetArea    = Qt.DockWidgetArea.BottomDockWidgetArea
        AllDockWidgetAreas      = Qt.DockWidgetArea.AllDockWidgetAreas

        # ── QFont ─────────────────────────────────────────────────────────
        FontBold                = QFont.Weight.Bold

        # ── QSizePolicy ───────────────────────────────────────────────────
        SizePolicyExpanding     = QSizePolicy.Policy.Expanding
        SizePolicyPreferred     = QSizePolicy.Policy.Preferred
        SizePolicyFixed         = QSizePolicy.Policy.Fixed
        SizePolicyMinimum       = QSizePolicy.Policy.Minimum

        # ── QAbstractItemView ─────────────────────────────────────────────
        ExtendedSelection       = QAbstractItemView.SelectionMode.ExtendedSelection
        NoEditTriggers          = QAbstractItemView.EditTrigger.NoEditTriggers
        SelectRows              = QAbstractItemView.SelectionBehavior.SelectRows

        # ── QHeaderView ───────────────────────────────────────────────────
        HeaderStretch           = QHeaderView.ResizeMode.Stretch
        HeaderResizeToContents  = QHeaderView.ResizeMode.ResizeToContents

        # ── QDialogButtonBox ──────────────────────────────────────────────
        ButtonOk                = QDialogButtonBox.StandardButton.Ok
        ButtonCancel            = QDialogButtonBox.StandardButton.Cancel

        # ── QDialog ───────────────────────────────────────────────────────
        DialogAccepted          = QDialog.DialogCode.Accepted

        # ── QToolButton ───────────────────────────────────────────────────
        ToolButtonInstantPopup  = QToolButton.ToolButtonPopupMode.InstantPopup

        # ── QFrame ────────────────────────────────────────────────────────
        FrameHLine              = QFrame.Shape.HLine
        FrameVLine              = QFrame.Shape.VLine
        FrameNoFrame            = QFrame.Shape.NoFrame
        FrameSunken             = QFrame.Shadow.Sunken
        FrameRaised             = QFrame.Shadow.Raised
        FramePlain              = QFrame.Shadow.Plain

    else:
        # Qt5 — unscoped enums, same as before
        AlignCenter             = Qt.AlignCenter
        SolidLine               = Qt.SolidLine
        RoundCap                = Qt.RoundCap
        RoundJoin               = Qt.RoundJoin
        CustomContextMenu       = Qt.CustomContextMenu
        ToolButtonTextBesideIcon = Qt.ToolButtonTextBesideIcon
        LeftButton              = Qt.LeftButton
        RightButton             = Qt.RightButton
        Key_Escape              = Qt.Key_Escape
        CrossCursor             = Qt.CrossCursor
        ClosedHandCursor        = Qt.ClosedHandCursor
        OpenHandCursor          = Qt.OpenHandCursor
        ArrowCursor             = Qt.ArrowCursor
        LeftDockWidgetArea      = Qt.LeftDockWidgetArea
        RightDockWidgetArea     = Qt.RightDockWidgetArea
        BottomDockWidgetArea    = Qt.BottomDockWidgetArea
        AllDockWidgetAreas      = Qt.AllDockWidgetAreas

        FontBold                = QFont.Bold

        SizePolicyExpanding     = QSizePolicy.Expanding
        SizePolicyPreferred     = QSizePolicy.Preferred
        SizePolicyFixed         = QSizePolicy.Fixed
        SizePolicyMinimum       = QSizePolicy.Minimum

        ExtendedSelection       = QAbstractItemView.ExtendedSelection
        NoEditTriggers          = QAbstractItemView.NoEditTriggers
        SelectRows              = QAbstractItemView.SelectRows

        HeaderStretch           = QHeaderView.Stretch
        HeaderResizeToContents  = QHeaderView.ResizeToContents

        ButtonOk                = QDialogButtonBox.Ok
        ButtonCancel            = QDialogButtonBox.Cancel

        DialogAccepted          = QDialog.Accepted

        ToolButtonInstantPopup  = QToolButton.InstantPopup

        # ── QFrame ────────────────────────────────────────────────────────
        FrameHLine              = QFrame.HLine
        FrameVLine              = QFrame.VLine
        FrameNoFrame            = QFrame.NoFrame
        FrameSunken             = QFrame.Sunken
        FrameRaised             = QFrame.Raised
        FramePlain              = QFrame.Plain


def exec_dialog(dlg):
    """Call exec() or exec_() on a dialog, whichever exists (Qt5/Qt6)."""
    if hasattr(dlg, 'exec') and callable(dlg.exec):
        return dlg.exec()
    return dlg.exec_()


def exec_menu(menu, pos):
    """Call exec() or exec_() on a QMenu at a given position."""
    if hasattr(menu, 'exec') and callable(menu.exec):
        return menu.exec(pos)
    return menu.exec_(pos)
