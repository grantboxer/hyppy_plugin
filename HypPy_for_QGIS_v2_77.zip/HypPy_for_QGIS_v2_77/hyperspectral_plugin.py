"""
Hyperspectral for QGIS — Main Plugin Class

Registers the Processing provider and creates a toolbar with:
  - HypPy dropdown menu button listing all algorithms in hierarchical submenus
    (the Spectrum Viewer toggle lives inside Spectral Processing Tools)

Each leaf algorithm item calls processing.execAlgorithmDialog() with the
correct fully-qualified algorithm ID  (provider_id:algorithm_name).
The Spectrum Viewer item is a checkable QAction that toggles the dock.

Copyright (C) 2025 Grant Boxer
Original HyPy Copyright (C) 2010-2022 Wim Bakker, University of Twente
GPL v3 or later.
"""

import os
from qgis.PyQt.QtCore    import Qt
from qgis.PyQt.QtGui     import QIcon, QFont
from qgis.PyQt.QtWidgets import (
    QAction, QToolBar, QToolButton, QMenu
)

from .core.qt_compat import Enums as E
from qgis.core import QgsApplication

from .hyppy_provider import HyppyProvider


# ── Sentinel for the Spectrum Viewer toggle entry ─────────────────────────────
# Used in _MENU_STRUCTURE so _populate_menu can create the checkable action.
_SPECTRUM_VIEWER = '__spectrum_viewer__'


# ── Menu structure ─────────────────────────────────────────────────────────────
#
# Each element is one of:
#   None                              → separator
#   (label, 'provider:alg_id')        → leaf algorithm item
#   (label, _SPECTRUM_VIEWER)         → Spectrum Viewer toggle (checkable)
#   (label, [ … ])                    → submenu
# ──────────────────────────────────────────────────────────────────────────────

_MENU_STRUCTURE = [

    # ── 1 · Workflow Guide ─────────────────────────────────────────────────
    ('Workflow Guide', [
        ('Open Workflow Guide',                 'hyppy:getting_started'),
    ]),

    None,

    # ── 2 · Data Import ────────────────────────────────────────────────────
    ('Data Import', [
        ('Build Overviews (Fast Display)',       'hyppy:build_overviews'),
        ('Subset',                              'hyppy:subset'),
    ]),

    None,

    # ── 3 · Generate WoM Rasters ──────────────────────────────────────────
    ('Generate WoM Rasters', [
        ('Generate All Three WoM Rasters',      'hyppy:generate_all_wom'),
        None,
        ('Generate WoM-A  (750–1300 nm)',       'hyppy:generate_wom_a'),
        ('Generate WoM-B  (1850–2100 nm)',      'hyppy:generate_wom_b'),
        ('Generate WoM-C  (2100–2400 nm)',      'hyppy:generate_wom_c'),
        None,
        ('Wavelength of Minimum (custom range)','hyppy:wavelength_of_minimum'),
        ('Wavelength Mapping',                  'hyppy:wavelength_mapping'),
    ]),

    None,

    # ── 4 · Decision Tree Classifiers ─────────────────────────────────────
    ('Decision Tree Classifiers', [
        ('DT Mineral Map (full pipeline)',      'hyppy:dt_mineral_map'),
        None,
        ('DT 2100–2400 Mineral',               'hyppy:dt_2100_2400'),
        ('DT Albedo',                           'hyppy:dt_albedo'),
        ('DT Fedrop  (Fe drop)',                'hyppy:dt_fedrop'),
        ('DT Illcryst  (Illite crystallinity)', 'hyppy:dt_illcryst'),
        ('DT Ill-Kaol  (Illite / Kaolinite)',   'hyppy:dt_ill_kaol'),
        ('DT Kaol-Cryst  (Kaolinite cryst.)',   'hyppy:dt_kaol_cryst'),
        ('DT Dick-Kaol  (Dickite / Kaolinite)', 'hyppy:dt_dick_kaol'),
        ('DT Kandite  (Kaolin group)',           'hyppy:dt_kandite'),
        ('DT Pyrophyllite',                     'hyppy:dt_pyrophyllite'),
    ]),

    None,

    # ── 5 · SAM Classifier ────────────────────────────────────────────────
    ('SAM Classifier', [
        ('Spectral Angle Mapper (SAM)',         'hyppy:sam'),
    ]),

    None,

    # ── 6 · Spectral Processing Tools ─────────────────────────────────────
    ('Spectral Processing Tools', [
        ('Spectrum Viewer',                     _SPECTRUM_VIEWER),
        None,
        ('Convex Hull Removal',                 'hyppy:convexhullremoval'),
        ('Band Ratio',                          'hyppy:bandratio'),
        ('Band Ratios  (Sequential)',           'hyppy:bandratios'),
        ('Band Depths',                         'hyppy:banddepths'),
        ('Band Math',                           'hyppy:bandmathfull'),
        ('Spectra Math',                        'hyppy:spectramathfull'),
        ('Log Residuals',                       'hyppy:logresiduals'),
        ('Zonal Statistics',                    'hyppy:zonal_statistics'),
    ]),

    None,

    # ── 7 · Feature Extraction Tools ──────────────────────────────────────
    ('Feature Extraction Tools', [
        ('FE00 - Run All Feature Extractions (FE01-FE18)', 'hyppy:fe_all'),
        None,
        ('FE04 - 1480W', 'hyppy:fe_1480w'),
        ('FE05 - 1550W', 'hyppy:fe_1550w'),
        ('FE06 - 1760W', 'hyppy:fe_1760w'),
        ('FE09 - 2080D', 'hyppy:fe_2080d'),
        ('FE10 - 2160D', 'hyppy:fe_2160d'),
        ('FE12 - 2200W', 'hyppy:fe_2200w'),
        ('FE14 - 2250W', 'hyppy:fe_2250w'),
        ('FE15 - 2290W', 'hyppy:fe_2290w'),
        ('FE16 - 2320W', 'hyppy:fe_2320w'),
        ('FE17 - 2350W', 'hyppy:fe_2350w'),
        ('FE18 - 2390W', 'hyppy:fe_2390w'),
        None,
        ('FE13 - 2206W  (Kaolinite Al-OH)', 'hyppy:fe_2206w'),
        ('FE03 - 1400D  (Kaolinite OH Doublet)', 'hyppy:fe_1400d'),
        ('FE11 - 2178D  (Dickite Al-OH Shoulder)', 'hyppy:fe_2178d'),
        ('FE01 - 1384D  (Dickite OH Doublet)', 'hyppy:fe_1384d'),
        ('FE07 - 1900W  (Halloysite Water Band)', 'hyppy:fe_1900w'),
        ('FE08 - 2066D  (Pyrophyllite Al-OH Doublet)', 'hyppy:fe_2066d'),
        ('FE02 - 1396W  (Pyrophyllite OH)', 'hyppy:fe_1396w'),
        None,
        ('FE-REE  Neodymium VNIR  (580/740/800/870 nm)', 'hyppy:fe_ree_nd'),
    ]),

    None,

    # ── 8 · Convert Tools ─────────────────────────────────────────────────
    ('Convert Tools', [
        ('Convert Image to ENVI',               'hyppy:convert_image_to_envi'),
        ('Convert EOS HDF to ENVI',             'hyppy:convert_eos_hdf'),
        ('Convert ASTER HDF to ENVI',           'hyppy:convert_aster_hdf'),
        ('Convert EMIT L2A to ENVI',            'hyppy:convert_emit_l2a'),
    ]),

]


class HyperspectralPlugin:
    """QGIS Plugin Implementation for HypPy for QGIS."""

    def __init__(self, iface):
        self.iface      = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.provider   = None
        self._dock      = None
        self._toolbar   = None
        self._act_viewer = None   # checkable menu action for the Spectrum Viewer

    # ── Processing provider ───────────────────────────────────────────────────

    def initProcessing(self):
        self.provider = HyppyProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    # ── GUI ───────────────────────────────────────────────────────────────────

    def initGui(self):
        self.initProcessing()

        # Spectrum Viewer dock
        try:
            from .ui.spectrum_viewer_dock import SpectrumViewerDock
            self._dock = SpectrumViewerDock(self.iface)
            self.iface.mainWindow().addDockWidget(
                E.RightDockWidgetArea, self._dock)
            self._dock.hide()
        except Exception as e:
            self.iface.messageBar().pushWarning(
                'HypPy', f'Spectrum Viewer could not be loaded: {e}')

        # Toolbar — single HypPy menu button, no separate Viewer button
        self._toolbar = QToolBar('HypPy', self.iface.mainWindow())
        self._toolbar.setObjectName('HyppyToolbar')
        self.iface.mainWindow().addToolBar(self._toolbar)

        icon_path = os.path.join(self.plugin_dir, 'icon.svg')
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        # ── Single HypPy dropdown menu button ────────────────────────────
        self._menu_btn = QToolButton()
        self._menu_btn.setIcon(icon)
        self._menu_btn.setText(' HypPy ')
        self._menu_btn.setToolTip('Run HypPy algorithms')
        self._menu_btn.setToolButtonStyle(E.ToolButtonTextBesideIcon)
        self._menu_btn.setPopupMode(E.ToolButtonInstantPopup)
        # Build menu now (creates self._act_viewer as a side effect)
        self._menu_btn.setMenu(self._build_menu())
        self._toolbar.addWidget(self._menu_btn)

        # Keep the Spectrum Viewer menu item checked state in sync with the dock
        if self._dock and self._act_viewer:
            self._dock.visibilityChanged.connect(self._act_viewer.setChecked)

    # ── Menu construction ─────────────────────────────────────────────────────

    def _build_menu(self):
        """Build the root dropdown menu with hierarchical submenus."""
        root = QMenu(self.iface.mainWindow())
        self._populate_menu(root, _MENU_STRUCTURE)
        return root

    def _populate_menu(self, menu, items):
        """
        Recursively populate *menu* from *items*.

        items is a list of:
          None                          -> separator
          (label, alg_id_str)           -> leaf algorithm action
          (label, _SPECTRUM_VIEWER)     -> checkable Spectrum Viewer toggle
          (label, list)                 -> submenu
        """
        for item in items:
            if item is None:
                menu.addSeparator()

            elif isinstance(item, tuple):
                label, target = item

                if isinstance(target, list):
                    # ── Submenu ──────────────────────────────────────────
                    sub = QMenu(label, menu)
                    self._populate_menu(sub, target)
                    menu.addMenu(sub)

                elif target is _SPECTRUM_VIEWER:
                    # ── Spectrum Viewer toggle ────────────────────────────
                    act = QAction(label, menu)
                    act.setCheckable(True)
                    act.setChecked(
                        self._dock.isVisible() if self._dock else False
                    )
                    act.setToolTip(
                        'Show / hide the Spectrum Viewer\n'
                        'Click pixels on the map to display and compare spectra.'
                    )
                    act.triggered.connect(self._toggle_viewer)
                    menu.addAction(act)
                    self._act_viewer = act   # store reference for dock sync

                else:
                    # ── Leaf algorithm action ─────────────────────────────
                    alg_id = target
                    act = QAction(label, menu)
                    act.triggered.connect(
                        lambda checked, aid=alg_id: self._run_algorithm(aid)
                    )
                    menu.addAction(act)

    # ── Slots ─────────────────────────────────────────────────────────────────

    def _toggle_viewer(self, checked=None):
        if self._dock is None:
            return
        if checked is None:
            checked = not self._dock.isVisible()
        if checked:
            self._dock.show_and_raise()
        else:
            self._dock.hide()

    def _run_algorithm(self, alg_id):
        try:
            import processing
            processing.execAlgorithmDialog(alg_id)
        except Exception as e:
            self.iface.messageBar().pushWarning(
                'HypPy', f'Could not open "{alg_id}": {e}')

    # ── Public API ────────────────────────────────────────────────────────────

    def show_spectrum_viewer(self):
        """Called from Getting Started algorithm."""
        if self._dock:
            self._dock.show_and_raise()
        if self._act_viewer:
            self._act_viewer.setChecked(True)

    # ── Cleanup ───────────────────────────────────────────────────────────────

    def unload(self):
        if self._dock:
            # Disconnect the visibility sync signal before closing the dock
            # to avoid any callbacks firing during teardown
            if self._act_viewer:
                try:
                    self._dock.visibilityChanged.disconnect(self._act_viewer.setChecked)
                except (RuntimeError, TypeError):
                    pass
            try:
                self._dock.close()
                self.iface.mainWindow().removeDockWidget(self._dock)
                self._dock.deleteLater()
            except RuntimeError:
                pass
            self._dock = None

        if self._toolbar:
            try:
                self.iface.mainWindow().removeToolBar(self._toolbar)
                self._toolbar.deleteLater()
            except RuntimeError:
                pass
            self._toolbar = None

        if self.provider:
            try:
                QgsApplication.processingRegistry().removeProvider(self.provider)
            except RuntimeError:
                # C++ object may already have been deleted by QGIS during
                # registry shutdown (QGIS 4 teardown order issue)
                pass
            self.provider = None
