"""
HyPpy Processing Provider

This provider makes all HyPy algorithms available in QGIS Processing Toolbox.

Copyright (C) 2025 Grant Boxer
Original HyPy Copyright (C) 2010-2022 Wim Bakker, University of Twente

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon
import os

# Step 0 — Getting Started
from .algorithms.getting_started_algorithm import GettingStartedAlgorithm

# Workflow A — Generate WoM Rasters (new in v1.3)
from .algorithms.wom_presets_algorithm import (
    GenerateAllWomAlgorithm,
    GenerateWomAAlgorithm,
    GenerateWomBAlgorithm,
    GenerateWomCAlgorithm,
)

# Workflow B — Wavelength of Minimum
from .algorithms.wavelength_of_minimum_algorithm import WavelengthOfMinimumAlgorithm
from .algorithms.wavelength_mapping_algorithm import WavelengthMappingAlgorithm

# Workflow C — Decision Tree Classification (new in v1.3)
from .algorithms.dt_mineral_map_algorithm import DtMineralMapAlgorithm
from .algorithms.dt_2100_2400_algorithm import Dt2100_2400Algorithm
from .algorithms.dt_albedo_algorithm import DtAlbedoAlgorithm
from .algorithms.dt_fedrop_algorithm import DtFedropAlgorithm
from .algorithms.dt_illcryst_algorithm import DtIllcrystAlgorithm
from .algorithms.dt_ill_kaol_algorithm import DtIllKaolAlgorithm
from .algorithms.dt_kaol_cryst_algorithm import DtKaolCrystAlgorithm
from .algorithms.dt_dick_kaol_algorithm import DtDickKaolAlgorithm
from .algorithms.dt_kandite_algorithm import DtKanditeAlgorithm
from .algorithms.dt_pyrophyllite_algorithm import DtPyrophylliteAlgorithm

# Workflow D — SAM Classification
from .algorithms.sam_algorithm import SpectralAngleMapperAlgorithm

# Workflow E — Spectral Processing Tools (new in v1.1)
from .algorithms.convex_hull_removal_algorithm import ConvexHullRemovalAlgorithm
from .algorithms.band_ratio_algorithm import BandRatioAlgorithm
from .algorithms.band_ratios_algorithm import BandRatiosAlgorithm
from .algorithms.band_depths_algorithm import BandDepthsAlgorithm
from .algorithms.band_math_algorithm import BandMathAlgorithm
from .algorithms.spectra_math_algorithm import SpectraMathAlgorithm
from .algorithms.log_residuals_algorithm import LogResidualsAlgorithm

# Workflow F — Feature Extraction (new in v2.8)
from .algorithms.fe_all_algorithm import FeAllAlgorithm
from .algorithms.fe_1480w_algorithm import Fe1480WAlgorithm
from .algorithms.fe_1550w_algorithm import Fe1550WAlgorithm
from .algorithms.fe_1760w_algorithm import Fe1760WAlgorithm
from .algorithms.fe_2080d_algorithm import Fe2080DAlgorithm
from .algorithms.fe_2160d_algorithm import Fe2160DAlgorithm
from .algorithms.fe_2200w_algorithm import Fe2200WAlgorithm
from .algorithms.fe_2250w_algorithm import Fe2250WAlgorithm
from .algorithms.fe_2290w_algorithm import Fe2290WAlgorithm
from .algorithms.fe_2320w_algorithm import Fe2320WAlgorithm
from .algorithms.fe_2350w_algorithm import Fe2350WAlgorithm
from .algorithms.fe_2390w_algorithm import Fe2390WAlgorithm
from .algorithms.fe_2206w_algorithm import Fe2206WAlgorithm
from .algorithms.fe_1400d_algorithm import Fe1400DAlgorithm
from .algorithms.fe_2178d_algorithm import Fe2178DAlgorithm
from .algorithms.fe_1384d_algorithm import Fe1384DAlgorithm
from .algorithms.fe_1900w_algorithm import Fe1900WAlgorithm
from .algorithms.fe_2066d_algorithm import Fe2066DAlgorithm
from .algorithms.fe_1396w_algorithm import Fe1396WAlgorithm
from .algorithms.fe_ree_algorithm   import FeReeAlgorithm


class HyppyProvider(QgsProcessingProvider):
    """Processing provider for Hyperspectral Analysis Tools"""

    def __init__(self):
        super().__init__()

    def load(self):
        """Called when the provider is first loaded"""
        self.refreshAlgorithms()
        return True

    def unload(self):
        """Called when provider is unloaded"""
        pass

    def loadAlgorithms(self):
        """Load all algorithms belonging to this provider."""

        # ── Step 0 — Getting Started ────────────────────────────────────────
        self.addAlgorithm(GettingStartedAlgorithm())

        # ── Workflow A — Generate WoM Rasters ───────────────────────────────
        self.addAlgorithm(GenerateAllWomAlgorithm())
        self.addAlgorithm(GenerateWomAAlgorithm())
        self.addAlgorithm(GenerateWomBAlgorithm())
        self.addAlgorithm(GenerateWomCAlgorithm())

        # ── Workflow B — Wavelength of Minimum ──────────────────────────────
        self.addAlgorithm(WavelengthOfMinimumAlgorithm())
        self.addAlgorithm(WavelengthMappingAlgorithm())

        # ── Workflow C — Decision Tree Classification ────────────────────────
        self.addAlgorithm(DtMineralMapAlgorithm())
        self.addAlgorithm(Dt2100_2400Algorithm())
        self.addAlgorithm(DtAlbedoAlgorithm())
        self.addAlgorithm(DtFedropAlgorithm())
        self.addAlgorithm(DtIllcrystAlgorithm())
        self.addAlgorithm(DtIllKaolAlgorithm())
        self.addAlgorithm(DtKaolCrystAlgorithm())
        self.addAlgorithm(DtDickKaolAlgorithm())
        self.addAlgorithm(DtKanditeAlgorithm())
        self.addAlgorithm(DtPyrophylliteAlgorithm())

        # ── Workflow D — SAM Classification ─────────────────────────────────
        self.addAlgorithm(SpectralAngleMapperAlgorithm())

        # ── Workflow E — Spectral Processing Tools ───────────────────────────
        self.addAlgorithm(ConvexHullRemovalAlgorithm())
        self.addAlgorithm(BandRatioAlgorithm())
        self.addAlgorithm(BandRatiosAlgorithm())
        self.addAlgorithm(BandDepthsAlgorithm())
        self.addAlgorithm(BandMathAlgorithm())
        self.addAlgorithm(SpectraMathAlgorithm())
        self.addAlgorithm(LogResidualsAlgorithm())

        # ── Workflow F — Feature Extraction ─────────────────────────────────
        self.addAlgorithm(FeAllAlgorithm())
        self.addAlgorithm(Fe1480WAlgorithm())
        self.addAlgorithm(Fe1550WAlgorithm())
        self.addAlgorithm(Fe1760WAlgorithm())
        self.addAlgorithm(Fe2080DAlgorithm())
        self.addAlgorithm(Fe2160DAlgorithm())
        self.addAlgorithm(Fe2200WAlgorithm())
        self.addAlgorithm(Fe2250WAlgorithm())
        self.addAlgorithm(Fe2290WAlgorithm())
        self.addAlgorithm(Fe2320WAlgorithm())
        self.addAlgorithm(Fe2350WAlgorithm())
        self.addAlgorithm(Fe2390WAlgorithm())
        self.addAlgorithm(Fe2206WAlgorithm())
        self.addAlgorithm(Fe1400DAlgorithm())
        self.addAlgorithm(Fe2178DAlgorithm())
        self.addAlgorithm(Fe1384DAlgorithm())
        self.addAlgorithm(Fe1900WAlgorithm())
        self.addAlgorithm(Fe2066DAlgorithm())
        self.addAlgorithm(Fe1396WAlgorithm())
        self.addAlgorithm(FeReeAlgorithm())

    def id(self):
        """Unique provider ID"""
        return 'hyppy'

    def name(self):
        """Human-readable provider name"""
        return 'Hyppy_for_QGIS v2.20'

    def longName(self):
        """Longer version of the provider name"""
        return 'Hyppy_for_QGIS v2.20 (HyPpy)'

    def icon(self):
        """Provider icon"""
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        if os.path.exists(icon_path):
            return QIcon(icon_path)
        return QgsProcessingProvider.icon(self)

    def svgIconPath(self):
        """SVG icon path"""
        return os.path.join(os.path.dirname(__file__), 'icon.svg')
