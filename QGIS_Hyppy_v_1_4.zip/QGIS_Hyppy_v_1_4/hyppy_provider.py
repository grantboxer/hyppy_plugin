"""
HyPpy Processing Provider

This provider makes all HyPy algorithms available in QGIS Processing Toolbox.

Copyright (C) 2025 Grant Boxer
Original HyPy Copyright (C) 2010-2022 Wim Bakker, University of Twente

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon
import os

# Step 0 — Getting Started
from .algorithms.getting_started_algorithm import GettingStartedAlgorithm

# Workflow A — Generate WoM Rasters (new in v1.3)
from .algorithms.wom_presets_algorithm import (
    GenerateAllWomAlgorithm,
    GenerateWomAAlgorithm,
    GenerateWomBAlgorithm,
    GenerateWomCAlgorithm,
)

# Workflow B — Wavelength of Minimum
from .algorithms.wavelength_of_minimum_algorithm import WavelengthOfMinimumAlgorithm
from .algorithms.wavelength_mapping_algorithm import WavelengthMappingAlgorithm

# Workflow C — Decision Tree Classification (new in v1.3)
from .algorithms.dt_mineral_map_algorithm import DtMineralMapAlgorithm
from .algorithms.dt_2100_2400_algorithm import Dt2100_2400Algorithm
from .algorithms.dt_albedo_algorithm import DtAlbedoAlgorithm
from .algorithms.dt_fedrop_algorithm import DtFedropAlgorithm
from .algorithms.dt_illcryst_algorithm import DtIllcrystAlgorithm
from .algorithms.dt_ill_kaol_algorithm import DtIllKaolAlgorithm

# Workflow D — SAM Classification
from .algorithms.sam_algorithm import SpectralAngleMapperAlgorithm

# Workflow E — Spectral Processing Tools (new in v1.1)
from .algorithms.convex_hull_removal_algorithm import ConvexHullRemovalAlgorithm
from .algorithms.band_ratio_algorithm import BandRatioAlgorithm
from .algorithms.band_ratios_algorithm import BandRatiosAlgorithm
from .algorithms.band_depths_algorithm import BandDepthsAlgorithm
from .algorithms.band_math_algorithm import BandMathAlgorithm
from .algorithms.spectra_math_algorithm import SpectraMathAlgorithm


class HyppyProvider(QgsProcessingProvider):
    """Processing provider for Hyperspectral Analysis Tools"""

    def __init__(self):
        super().__init__()

    def load(self):
        """Called when the provider is first loaded"""
        self.refreshAlgorithms()
        return True

    def unload(self):
        """Called when provider is unloaded"""
        pass

    def loadAlgorithms(self):
        """Load all algorithms belonging to this provider."""

        # ── Step 0 — Getting Started ────────────────────────────────────────
        self.addAlgorithm(GettingStartedAlgorithm())

        # ── Workflow A — Generate WoM Rasters ───────────────────────────────
        self.addAlgorithm(GenerateAllWomAlgorithm())
        self.addAlgorithm(GenerateWomAAlgorithm())
        self.addAlgorithm(GenerateWomBAlgorithm())
        self.addAlgorithm(GenerateWomCAlgorithm())

        # ── Workflow B — Wavelength of Minimum ──────────────────────────────
        self.addAlgorithm(WavelengthOfMinimumAlgorithm())
        self.addAlgorithm(WavelengthMappingAlgorithm())

        # ── Workflow C — Decision Tree Classification ────────────────────────
        self.addAlgorithm(DtMineralMapAlgorithm())
        self.addAlgorithm(Dt2100_2400Algorithm())
        self.addAlgorithm(DtAlbedoAlgorithm())
        self.addAlgorithm(DtFedropAlgorithm())
        self.addAlgorithm(DtIllcrystAlgorithm())
        self.addAlgorithm(DtIllKaolAlgorithm())

        # ── Workflow D — SAM Classification ─────────────────────────────────
        self.addAlgorithm(SpectralAngleMapperAlgorithm())

        # ── Workflow E — Spectral Processing Tools ───────────────────────────
        self.addAlgorithm(ConvexHullRemovalAlgorithm())
        self.addAlgorithm(BandRatioAlgorithm())
        self.addAlgorithm(BandRatiosAlgorithm())
        self.addAlgorithm(BandDepthsAlgorithm())
        self.addAlgorithm(BandMathAlgorithm())
        self.addAlgorithm(SpectraMathAlgorithm())

    def id(self):
        """Unique provider ID"""
        return 'hyppy'

    def name(self):
        """Human-readable provider name"""
        return 'QGIS_Hyppy_v_1.4'

    def longName(self):
        """Longer version of the provider name"""
        return 'QGIS_Hyppy_v_1.4 (HyPpy)'

    def icon(self):
        """Provider icon"""
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        if os.path.exists(icon_path):
            return QIcon(icon_path)
        return QgsProcessingProvider.icon(self)

    def svgIconPath(self):
        """SVG icon path"""
        return os.path.join(os.path.dirname(__file__), 'icon.svg')
