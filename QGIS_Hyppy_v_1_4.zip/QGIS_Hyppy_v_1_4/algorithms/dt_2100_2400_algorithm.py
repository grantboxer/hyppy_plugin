"""
Mineral Decision Tree Classification Algorithm for QGIS Processing

Classifies pixels into mineral classes using a spectral decision tree
based on absorption feature positions and depth from the Wavelength of
Minimum tool output.

The decision tree uses three values, all read from the WoM output raster:
  b3  - Depth of the deepest absorption feature (Band 2 from WoM).
        Pixels with b3 <= threshold are labelled 'aspectral'.
  b2  - Primary absorption wavelength in nm, deepest feature (Band 1 from WoM)
  b7  - Secondary absorption wavelength in nm, 2nd feature   (Band 3 from WoM)

Mineral classes produced:
  aspectral, other-1..11, pyrophyll, alu_dick, kaol,
  musc_ill-1, musc_ill-2, phengite, Fe-chlt-1, Fe-chlt-2,
  dolom, Mg-chlt, serp, epid_chlt, prehnite, amp-talc

Copyright (C) 2025 Grant Boxer

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis,
)


# ---------------------------------------------------------------------------
# Mineral class definitions
# ---------------------------------------------------------------------------
# Each entry: (class_id, name, R, G, B)
# Colours match the decision-tree diagram as closely as possible.
MINERAL_CLASSES = [
    (0,  'unclassified', 0,   0,   0  ),
    (1,  'aspectral',    0,   0,   0  ),   # black  (filled oval)
    (2,  'other-1',      0,   0,   255),   # blue
    (3,  'other-2',      180, 180, 255),   # pale blue
    (4,  'pyrophyll',    0,   255, 255),   # cyan
    (5,  'alu_dick',     0,   0,   200),   # dark blue
    (6,  'other-3',      255, 255, 180),   # pale yellow
    (7,  'kaol',         0,   180, 180),   # teal
    (8,  'other-4',      200, 200, 0  ),   # olive/yellow
    (9,  'musc_ill-1',   255, 255, 0  ),   # yellow
    (10, 'other-5',      255, 160, 80 ),   # orange
    (11, 'musc_ill-2',   255, 180, 0  ),   # orange-yellow
    (12, 'phengite',     139, 69,  19 ),   # brown
    (13, 'other-6',      180, 255, 180),   # pale green
    (14, 'Fe-chlt-1',    0,   200, 0  ),   # green
    (15, 'other-7',      0,   255, 100),   # bright green
    (16, 'Fe-chlt-2',    100, 255, 180),   # light green
    (17, 'dolom',        180, 0,   0  ),   # dark red
    (18, 'other-8',      255, 0,   0  ),   # red
    (19, 'amp-talc',     255, 100, 100),   # light red
    (20, 'Mg-chlt',      255, 200, 220),   # pale pink
    (21, 'other-9',      220, 150, 200),   # mauve
    (22, 'serp',         255, 0,   255),   # magenta
    (23, 'epid_chlt',    255, 0,   180),   # hot pink
    (24, 'other-10',     180, 100, 255),   # purple
    (25, 'prehnite',     200, 0,   255),   # violet
    (26, 'other-11',     200, 200, 200),   # grey
]

# Lookup tables
NAME_TO_ID = {m[1]: m[0] for m in MINERAL_CLASSES}
ID_TO_RGB  = {m[0]: (m[2], m[3], m[4]) for m in MINERAL_CLASSES}
ID_TO_NAME = {m[0]: m[1] for m in MINERAL_CLASSES}


# ---------------------------------------------------------------------------
# Decision tree
# ---------------------------------------------------------------------------

def classify_pixel(b3, b2, b7):
    """
    Apply the decision tree to a single pixel.

    Parameters
    ----------
    b3 : float  depth of the deepest absorption feature (WoM Band 2)
    b2 : float  primary absorption wavelength in nm     (WoM Band 1)
    b7 : float  secondary absorption wavelength in nm   (WoM Band 3)

    Returns
    -------
    int  mineral class id
    """
    # Root: spectral quality gate — use feature depth, not reflectance
    if b3 <= 0.05:
        return NAME_TO_ID['aspectral']

    # --- Branch on b2 (primary absorption position) ---
    if b2 <= 2160:
        return NAME_TO_ID['other-1']

    if b2 <= 2180:
        if 2200 < b7 <= 2220:
            return NAME_TO_ID['alu_dick']
        else:
            if 2300 < b7 <= 2320:
                return NAME_TO_ID['pyrophyll']
            else:
                return NAME_TO_ID['other-2']

    if b2 <= 2200:
        if 2200 < b7 <= 2220:
            return NAME_TO_ID['alu_dick']
        else:
            return NAME_TO_ID['other-3']

    if b2 <= 2210:
        if 2160 < b7 <= 2180:
            return NAME_TO_ID['kaol']
        else:
            if 2340 < b7 <= 2400:
                return NAME_TO_ID['musc_ill-1']
            else:
                return NAME_TO_ID['other-4']

    if b2 <= 2220:
        if 2340 < b7 <= 2400:
            return NAME_TO_ID['musc_ill-2']
        else:
            return NAME_TO_ID['other-5']

    if b2 <= 2240:
        return NAME_TO_ID['phengite']

    if b2 <= 2260:
        if 2340 < b7 <= 2400:
            return NAME_TO_ID['Fe-chlt-1']
        else:
            return NAME_TO_ID['other-6']

    if b2 <= 2300:
        if 2340 < b7 <= 2400:
            return NAME_TO_ID['Fe-chlt-2']
        else:
            return NAME_TO_ID['other-7']

    if b2 <= 2320:
        if 2100 < b7 <= 2160:
            return NAME_TO_ID['dolom']
        else:
            if 2240 < b7 <= 2260:
                return NAME_TO_ID['Mg-chlt']
            else:
                if 2260 < b7 <= 2300:
                    return NAME_TO_ID['serp']
                else:
                    if 2340 < b7 <= 2400:
                        return NAME_TO_ID['amp-talc']
                    else:
                        return NAME_TO_ID['other-8']

    # b2 > 2320
    if b2 <= 2340:
        if 2240 < b7 <= 2260:
            return NAME_TO_ID['epid_chlt']
        else:
            if 2220 < b7 <= 2240:
                return NAME_TO_ID['prehnite']
            else:
                return NAME_TO_ID['other-10']

    # b2 > 2340
    if b2 <= 2360:
        if 2240 < b7 <= 2260:
            return NAME_TO_ID['epid_chlt']
        else:
            if 2220 < b7 <= 2240:
                return NAME_TO_ID['prehnite']
            else:
                return NAME_TO_ID['other-10']

    # b2 > 2360
    return NAME_TO_ID['other-11']


# Vectorised version for numpy array processing
_classify_vec = np.vectorize(classify_pixel)


# ---------------------------------------------------------------------------
# QGIS Processing Algorithm
# ---------------------------------------------------------------------------

class Dt2100_2400Algorithm(QgsProcessingAlgorithm):
    """
    Mineral Decision Tree Classification

    Applies a spectral decision tree to classify pixels in a Wavelength of
    Minimum output raster into mineral classes.

    Expected input
    --------------
    Wavelength of Minimum raster (output from Step 1, must have >= 3 bands):
        Band 1 - primary absorption wavelength   (b2 in tree)
        Band 2 - depth of deepest feature        (b3 in tree, threshold test)
        Band 3 - secondary absorption wavelength (b7 in tree)

    Outputs
    -------
    * Classified raster - single band, palette-indexed integer codes (Byte)
    * RGB colour raster - 3-band false-colour mineral map (optional)
    """

    WOM_INPUT    = 'WOM_INPUT'
    B3_THRESHOLD = 'B3_THRESHOLD'
    OUTPUT_CLASS = 'OUTPUT_CLASS'
    OUTPUT_RGB   = 'OUTPUT_RGB'

    def initAlgorithm(self, config=None):

        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.WOM_INPUT,
                'Wavelength of Minimum raster (Step 1 output)',
                optional=False
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.B3_THRESHOLD,
                'Depth threshold — Band 2 (feature depth) must exceed this to be classed as spectral',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=0.05,
                minValue=0.0,
                maxValue=1.0,
                optional=False
            )
        )

        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_CLASS,
                'Output: Mineral class raster (integer codes)',
                optional=False
            )
        )

        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_RGB,
                'Output: Mineral class raster (RGB colour)',
                optional=True
            )
        )

    # ------------------------------------------------------------------
    def processAlgorithm(self, parameters, context, feedback):

        wom_layer = self.parameterAsRasterLayer(parameters, self.WOM_INPUT,    context)
        b3_thresh = self.parameterAsDouble     (parameters, self.B3_THRESHOLD, context)
        out_class = self.parameterAsOutputLayer(parameters, self.OUTPUT_CLASS, context)
        out_rgb   = self.parameterAsOutputLayer(parameters, self.OUTPUT_RGB,   context) \
                    if self.OUTPUT_RGB in parameters else None

        # ---- Open WoM raster ------------------------------------------------
        wom_ds = gdal.Open(wom_layer.source(), gdal.GA_ReadOnly)
        if wom_ds is None:
            raise QgsProcessingException('Cannot open Wavelength of Minimum raster')

        cols    = wom_ds.RasterXSize
        rows    = wom_ds.RasterYSize
        n_bands = wom_ds.RasterCount

        if n_bands < 3:
            raise QgsProcessingException(
                f'Wavelength of Minimum raster has only {n_bands} band(s). '
                'Requires at least 3 bands: '
                'Band 1 = primary wavelength (b2), '
                'Band 2 = feature depth (b3), '
                'Band 3 = secondary wavelength (b7).'
            )

        feedback.pushInfo(f'WoM raster: {cols} x {rows}, {n_bands} bands')

        feedback.pushInfo('Reading Band 1 - primary absorption wavelength (b2)...')
        b2_data = wom_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)

        feedback.pushInfo('Reading Band 2 - deepest feature depth (b3 threshold)...')
        b3_data = wom_ds.GetRasterBand(2).ReadAsArray().astype(np.float32)

        feedback.pushInfo('Reading Band 3 - secondary absorption wavelength (b7)...')
        b7_data = wom_ds.GetRasterBand(3).ReadAsArray().astype(np.float32)

        # ---- Diagnostic statistics ------------------------------------------
        feedback.pushInfo('')
        feedback.pushInfo('Input band statistics (spectral pixels only, b3 > threshold):')
        spectral_mask = b3_data > b3_thresh
        n_spectral = int(np.sum(spectral_mask))
        feedback.pushInfo(f'  Spectral pixels (b3 > {b3_thresh}): {n_spectral} of {b2_data.size} ({100*n_spectral/b2_data.size:.1f}%)')
        if n_spectral > 0:
            feedback.pushInfo(f'  b2 (primary wavelength) : min={float(np.nanmin(b2_data[spectral_mask])):.2f}  '
                              f'max={float(np.nanmax(b2_data[spectral_mask])):.2f}  '
                              f'mean={float(np.nanmean(b2_data[spectral_mask])):.2f}')
            feedback.pushInfo(f'  b3 (feature depth)      : min={float(np.nanmin(b3_data[spectral_mask])):.4f}  '
                              f'max={float(np.nanmax(b3_data[spectral_mask])):.4f}  '
                              f'mean={float(np.nanmean(b3_data[spectral_mask])):.4f}')
            feedback.pushInfo(f'  b7 (2nd wavelength)     : min={float(np.nanmin(b7_data[spectral_mask])):.2f}  '
                              f'max={float(np.nanmax(b7_data[spectral_mask])):.2f}  '
                              f'mean={float(np.nanmean(b7_data[spectral_mask])):.2f}')
        feedback.pushInfo('')
        feedback.pushInfo(f'Depth threshold: b3 > {b3_thresh} = spectral pixel')

        # ---- Apply decision tree --------------------------------------------
        feedback.pushInfo('Applying decision tree...')
        feedback.setProgress(20)

        nodata_mask = np.isnan(b2_data) | np.isnan(b7_data) | np.isnan(b3_data)

        b2_safe = np.nan_to_num(b2_data, nan=0.0)
        b3_safe = np.nan_to_num(b3_data, nan=0.0)
        b7_safe = np.nan_to_num(b7_data, nan=0.0)

        class_data = _classify_vec(b3_safe, b2_safe, b7_safe).astype(np.uint8)

        # Pixels where WoM found no feature (b2 == 0) -> unclassified
        class_data[nodata_mask]  = 0
        class_data[b2_safe == 0] = 0

        feedback.setProgress(70)

        # ---- Classification summary -----------------------------------------
        feedback.pushInfo('')
        feedback.pushInfo('Classification summary:')
        unique, counts = np.unique(class_data, return_counts=True)
        total = class_data.size
        for uid, cnt in zip(unique, counts):
            pct = 100.0 * cnt / total
            feedback.pushInfo(
                f'  {ID_TO_NAME.get(int(uid), "?"):15s}  '
                f'(id={uid:2d})  {cnt:8d} px  {pct:5.1f}%'
            )
        feedback.pushInfo('')

        driver = gdal.GetDriverByName('GTiff')

        # ---- Write class raster (primary output — always written) -----------
        feedback.pushInfo('Writing integer class raster...')
        ct = gdal.ColorTable()
        for mid, name, r, g, bv in MINERAL_CLASSES:
            ct.SetColorEntry(mid, (r, g, bv, 255))

        class_ds = driver.Create(out_class, cols, rows, 1, gdal.GDT_Byte,
                                 options=['COMPRESS=LZW', 'TILED=YES'])
        class_ds.SetGeoTransform(wom_ds.GetGeoTransform())
        class_ds.SetProjection(wom_ds.GetProjection())
        b = class_ds.GetRasterBand(1)
        b.SetNoDataValue(0)
        b.SetDescription('Mineral Class')
        b.SetRasterColorTable(ct)
        b.SetRasterColorInterpretation(gdal.GCI_PaletteIndex)
        b.WriteArray(class_data)
        b.FlushCache()
        # Raster Attribute Table — class names visible in QGIS legend
        rat = gdal.RasterAttributeTable()
        rat.CreateColumn('Value', gdal.GFT_Integer,  gdal.GFU_MinMax)
        rat.CreateColumn('Class', gdal.GFT_String,   gdal.GFU_Name)
        rat.CreateColumn('R',     gdal.GFT_Integer,  gdal.GFU_Red)
        rat.CreateColumn('G',     gdal.GFT_Integer,  gdal.GFU_Green)
        rat.CreateColumn('B',     gdal.GFT_Integer,  gdal.GFU_Blue)
        for row_idx, (mid, name, r, g, bv) in enumerate(MINERAL_CLASSES):
            rat.SetValueAsInt   (row_idx, 0, mid)
            rat.SetValueAsString(row_idx, 1, name)
            rat.SetValueAsInt   (row_idx, 2, r)
            rat.SetValueAsInt   (row_idx, 3, g)
            rat.SetValueAsInt   (row_idx, 4, bv)
        b.SetDefaultRAT(rat)
        class_ds = None

        feedback.setProgress(85)
        result = {self.OUTPUT_CLASS: out_class}

        # ---- Write RGB raster (optional) ------------------------------------
        if out_rgb:
            feedback.pushInfo('Writing RGB colour raster...')
            rgb_r = np.zeros((rows, cols), dtype=np.uint8)
            rgb_g = np.zeros((rows, cols), dtype=np.uint8)
            rgb_b = np.zeros((rows, cols), dtype=np.uint8)

            for mid, name, r, g, bv in MINERAL_CLASSES:
                mask = class_data == mid
                rgb_r[mask] = r
                rgb_g[mask] = g
                rgb_b[mask] = bv

            rgb_ds = driver.Create(out_rgb, cols, rows, 3, gdal.GDT_Byte,
                                   options=['COMPRESS=LZW', 'TILED=YES'])
            rgb_ds.SetGeoTransform(wom_ds.GetGeoTransform())
            rgb_ds.SetProjection(wom_ds.GetProjection())

            for idx, (arr, lbl) in enumerate(
                    [(rgb_r, 'Red'), (rgb_g, 'Green'), (rgb_b, 'Blue')], start=1):
                band = rgb_ds.GetRasterBand(idx)
                band.WriteArray(arr)
                band.SetDescription(lbl)
                band.FlushCache()
            rgb_ds = None
            result[self.OUTPUT_RGB] = out_rgb

        # Cleanup
        wom_ds = None

        feedback.setProgress(100)
        feedback.pushInfo('Mineral Decision Tree classification complete.')

        # Legend in log
        feedback.pushInfo('')
        feedback.pushInfo('Mineral Class Legend:')
        feedback.pushInfo(f'  {"ID":>3}  {"Name":<15}  {"R":>3} {"G":>3} {"B":>3}')
        for mid, name, r, g, bv in MINERAL_CLASSES:
            feedback.pushInfo(f'  {mid:>3}  {name:<15}  {r:>3} {g:>3} {bv:>3}')

        return result

    # ------------------------------------------------------------------
    def name(self):
        return 'dt_2100_2400'

    def displayName(self):
        return 'DT 2100-2400 Mineral Classification'

    def group(self):
        return 'Workflow C - Decision Tree Classification'

    def groupId(self):
        return 'workflow_c'

    def shortHelpString(self):
        class_list = '\n'.join(
            f'          <li><b>{m[1]}</b> (id={m[0]})</li>'
            for m in MINERAL_CLASSES if m[0] > 0
        )
        return f"""
        <b>Mineral Decision Tree Classification</b>

        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> WoM-C (2100–2400 nm) only.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.<br/>Run <i>Workflow A</i> to generate required WoM rasters.
        </p>


        <p>Classifies pixels into mineral classes using a spectral decision tree
        based on absorption feature wavelength positions and depth, all derived
        from the Wavelength of Minimum output raster.</p>

        <p><b>Decision tree variables (all read from the WoM raster):</b></p>
        <ul>
          <li><b>b3</b> - Depth of the deepest absorption feature
              (<b>Band 2</b> of WoM output). Pixels with b3 &le; threshold are
              labelled <i>aspectral</i> (no meaningful spectral signal).</li>
          <li><b>b2</b> - Primary (deepest) absorption wavelength in nm.
              Read from <b>Band 1</b> of the WoM output.</li>
          <li><b>b7</b> - Secondary absorption wavelength in nm.
              Read from <b>Band 3</b> of the WoM output.</li>
        </ul>

        <p><b>Recommended workflow:</b></p>
        <ol>
          <li>Run <i>Step 1 - Wavelength of Minimum v2</i> on your hyperspectral
              image in the SWIR range (~2100-2400 nm) with <b>Features = 2</b>
              (or more). Output bands: 1=wavelength, 2=depth, 3=2nd wavelength,
              4=2nd depth.</li>
          <li>Run <i>Step 3 - Mineral Decision Tree Classification</i> using
              the WoM output raster as the single input.</li>
          <li>Adjust the depth threshold if needed (default 0.05).</li>
        </ol>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>Class raster (integer)</b> - single band, palette-indexed
              GeoTIFF. QGIS will automatically display it in the correct
              mineral colours.</li>
          <li><b>RGB colour raster</b> - optional 3-band false-colour image,
              one colour per mineral class.</li>
        </ul>

        <p><b>Mineral classes produced:</b></p>
        <ul>
{class_list}
        </ul>

        <p><i>Decision tree after Laukamp et al. / van der Meer et al. SWIR
        mineral mapping approach. Implemented for QGIS by Grant Boxer,
        2025.</i></p>
        """

    def createInstance(self):
        return Dt2100_2400Algorithm()
