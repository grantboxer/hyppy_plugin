"""
Feature Extraction — 1400D  (Kaolinite OH Doublet)

Targets the kaolinite OH stretch doublet at ~1400 and ~1412 nm.

From GMEX kaolinite2 (USGS Spectral Library):
  ~1400 + 1412 nm — OH stretch overtone doublet.
  Present in highly crystalline kaolinites.
  Double absorption note: different intensities and wavelength positions
  compared to Dickite and Halloysite.
  Variations in crystallinity affect this doublet.

WoM range:  1385-1430 nm  (captures both peaks of the doublet)
Stretch:    1395-1420 nm  (resolves kaolinite doublet positions)

Note: The 1400 nm region overlaps with atmospheric water vapour absorption.
In airborne data this region may be masked by BBL. In well-corrected data
(EnMAP, PRISMA) the doublet is resolvable.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
)
import processing
import os


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with wavelength metadata.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""

WATER_NOTE = """        <p style="background-color:#e8f4fd; padding:6px; border-left:4px solid #1565c0;">
        <b>Note:</b> The 1400 nm region falls within an atmospheric water vapour absorption
        band. In airborne data it is typically masked by BBL. In satellite data with good
        atmospheric correction (EnMAP, PRISMA) the doublet is often resolvable. If BBL
        masking is active this tool will return no valid pixels in this range.
        </p>
"""


class Fe1400DAlgorithm(QgsProcessingAlgorithm):
    """Feature Extraction — 1400D (Kaolinite OH Doublet)."""

    INPUT         = 'INPUT'
    NUM_FEATURES  = 'NUM_FEATURES'
    OUTPUT_WOM    = 'OUTPUT_WOM'
    OUTPUT_MAP    = 'OUTPUT_MAP'
    LEGEND_OUTPUT = 'LEGEND_OUTPUT'

    WOM_START = 1350.0
    WOM_END   = 1450.0
    MAP_MIN   = 1387.0
    MAP_MAX   = 1445.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.15

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract (1-9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=2, minValue=1, maxValue=9))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_WOM,
            'Output WoM raster (1350-1450 nm)'))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_MAP,
            'Output Wavelength Map RGB (1387-1445 nm stretch)'))
        self.addParameter(QgsProcessingParameterFileDestination(
            self.LEGEND_OUTPUT,
            'Output Colour Legend (PNG)',
            fileFilter='PNG Files (*.png)',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        cube        = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n           = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        out_wom     = self.parameterAsOutputLayer(parameters, self.OUTPUT_WOM, context)
        out_map     = self.parameterAsOutputLayer(parameters, self.OUTPUT_MAP, context)
        legend_path = self.parameterAsFileOutput(parameters, self.LEGEND_OUTPUT, context)

        self._legend_path = None

        # Step 1: Wavelength of Minimum 1350.0-1450.0 nm
        feedback.setProgress(5)
        feedback.pushInfo('Step 1/2  Wavelength of Minimum  1385-1430 nm ...')
        feedback.pushInfo('  (Kaolinite OH stretch doublet ~1400/1412 nm)')
        feedback.pushInfo('  Note: BBL masking active — atmospheric water band may exclude this region.')
        wom_result = processing.run(
            'hyppy:wavelength_of_minimum',
            {
                'INPUT':            cube,
                'START_WAVELENGTH': self.WOM_START,
                'END_WAVELENGTH':   self.WOM_END,
                'MODE':             0,
                'NUM_FEATURES':     n,
                'BROAD':            False,
                'USE_BBL':          True,
                'OUTPUT':           out_wom,
            },
            context=context,
            feedback=feedback,
            is_child_algorithm=True,
        )
        if feedback.isCanceled():
            return {}

        wom_path = wom_result['OUTPUT']
        feedback.pushInfo(f'  WoM raster saved: {wom_path}')

        # Step 2: Wavelength Mapping 1395-1420 nm
        feedback.setProgress(50)
        feedback.pushInfo('Step 2/2  Wavelength Mapping  1395-1420 nm stretch ...')
        feedback.pushInfo('  Blue = ~1395 nm (shorter-wave peak)  Red = ~1420 nm (longer-wave peak)')

        from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
        wma     = WavelengthMappingAlgorithm()
        palette = wma.create_rainbow_palette()

        map_path = wma._run_colour_mapping(
            wom_path, palette,
            self.MAP_MIN, self.MAP_MAX,
            self.DEPTH_MIN, self.DEPTH_MAX,
            out_map, feedback,
        )

        feedback.setProgress(88)
        feedback.pushInfo(f'  Wavelength map saved: {map_path}')

        # Step 3: Legend
        if not legend_path:
            wom_dir     = os.path.dirname(wom_path)
            legend_path = os.path.join(wom_dir, '1400D_legend.png')
        try:
            saved = wma.create_legend(
                legend_path, palette,
                self.MAP_MIN, self.MAP_MAX,
                self.DEPTH_MIN, self.DEPTH_MAX,
                feedback,
            )
            if saved:
                self._legend_path = saved
                feedback.pushInfo(f'  Colour legend saved: {saved}')
        except Exception as e:
            feedback.pushWarning(f'Legend generation failed: {e}')

        feedback.setProgress(100)
        feedback.pushInfo('Feature Extraction 1400D complete.')

        return {
            self.OUTPUT_WOM:    wom_path,
            self.OUTPUT_MAP:    map_path,
            self.LEGEND_OUTPUT: self._legend_path or '',
        }

    def postProcessAlgorithm(self, context, feedback):
        if getattr(self, '_legend_path', None):
            from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
            WavelengthMappingAlgorithm()._show_legend_dock(self._legend_path, feedback)
        return {}

    def name(self):        return 'fe_1400d'
    def displayName(self): return 'FE03 - 1400D  (Kaolinite OH Doublet)'
    def group(self):       return '7 - Feature Extraction'
    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + WATER_NOTE + """
        <b>Feature Extraction — 1400D  (Kaolinite OH Doublet)</b>

        <p>Targets the kaolinite OH stretch overtone doublet at <b>~1400 and ~1412 nm</b>,
        derived from the USGS GMEX kaolinite2 reference spectrum.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>1385-1430 nm</b>
              (captures both peaks of the OH doublet).</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>1395-1420 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>1385-1430 nm</td></tr>
          <tr><td>Colour stretch min</td><td>1395 nm</td></tr>
          <tr><td>Colour stretch max</td><td>1420 nm</td></tr>
          <tr><td>Default features</td><td>2 (to detect both doublet peaks)</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>GMEX kaolinite2 — 1400D doublet characteristics:</b></p>
        <ul>
          <li>Present in <b>highly crystalline kaolinites</b>.</li>
          <li>Different intensities and wavelength positions compared to
              <b>Dickite</b> and <b>Halloysite</b>.</li>
          <li>Variations in crystallinity affect doublet shape and separation.</li>
          <li>Use <b>2 features</b> in WoM to resolve both ~1400 and ~1412 nm peaks.</li>
        </ul>

        <p><b>Mineral discrimination using doublet characteristics:</b></p>
        <ul>
          <li><b>Kaolinite</b> — doublet at ~1400 + 1412 nm, variable intensity ratio</li>
          <li><b>Dickite</b> — doublet at slightly different positions, more equal intensities</li>
          <li><b>Halloysite</b> — weakened or absent doublet due to interlayer water</li>
        </ul>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength of minimum, Band 2: feature depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, kaolinite2 entry.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe1400DAlgorithm()
