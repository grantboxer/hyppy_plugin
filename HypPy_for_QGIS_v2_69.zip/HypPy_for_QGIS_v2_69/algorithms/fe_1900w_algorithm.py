"""
Feature Extraction — 1900W  (Halloysite Interlayer Water)

Targets the broad H2O combination band of halloysite at ~1900 nm.

From GMEX kandite group comparison (USGS Spectral Library):
  Halloysite (hydrated) — deep, broad absorption centred ~1900 nm due to
    interlayer water molecules.  This feature is the primary spectral
    discriminator distinguishing halloysite from all other kandite-group
    minerals (kaolinite, dickite, nacrite) which show little or no 1900 nm
    absorption.
  Halloysite (dehydrated) — reduced but still present ~1900 nm feature,
    weaker than hydrated form.
  Kaolinite, Dickite, Nacrite — essentially absent or very weak ~1900 nm.

The 1900 nm feature is caused by H2O stretch+bend combination (v1+v2)
in interlayer water unique to the halloysite (10Å) polytype.
Dehydration collapses the interlayer to 7Å, reducing the water band.

WoM range:  1850-1960 nm  (full width of the halloysite water band)
Stretch:    1870-1940 nm  (resolves depth and wavelength shift of water band)

Note: Kaolinite also shows a minor ~1830 nm feature (noted in GMEX kaolinite2)
but this is much shallower than halloysite's 1900 nm band and at shorter
wavelengths.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
)
import processing
import os


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with wavelength metadata.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""


class Fe1900WAlgorithm(QgsProcessingAlgorithm):
    """Feature Extraction — 1900W (Halloysite Interlayer Water)."""

    INPUT         = 'INPUT'
    NUM_FEATURES  = 'NUM_FEATURES'
    OUTPUT_WOM    = 'OUTPUT_WOM'
    OUTPUT_MAP    = 'OUTPUT_MAP'
    LEGEND_OUTPUT = 'LEGEND_OUTPUT'

    WOM_START = 1850.0
    WOM_END   = 1960.0
    MAP_MIN   = 1870.0
    MAP_MAX   = 1940.0
    DEPTH_MIN = 0.0
    DEPTH_MAX = 0.35   # halloysite water band can be very deep

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))
        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract (1-9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=1, minValue=1, maxValue=9))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_WOM,
            'Output WoM raster (1850-1960 nm)'))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_MAP,
            'Output Wavelength Map RGB (1870-1940 nm stretch)'))
        self.addParameter(QgsProcessingParameterFileDestination(
            self.LEGEND_OUTPUT,
            'Output Colour Legend (PNG)',
            fileFilter='PNG Files (*.png)',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        cube        = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n           = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        out_wom     = self.parameterAsOutputLayer(parameters, self.OUTPUT_WOM, context)
        out_map     = self.parameterAsOutputLayer(parameters, self.OUTPUT_MAP, context)
        legend_path = self.parameterAsFileOutput(parameters, self.LEGEND_OUTPUT, context)

        self._legend_path = None

        # Step 1: Wavelength of Minimum 1850-1960 nm
        feedback.setProgress(5)
        feedback.pushInfo('Step 1/2  Wavelength of Minimum  1850-1960 nm ...')
        feedback.pushInfo('  (Halloysite interlayer water band ~1900 nm)')
        feedback.pushInfo('  Deep feature = halloysite (hydrated);  absent = kaolinite / dickite / nacrite')
        wom_result = processing.run(
            'hyppy:wavelength_of_minimum',
            {
                'INPUT':            cube,
                'START_WAVELENGTH': self.WOM_START,
                'END_WAVELENGTH':   self.WOM_END,
                'MODE':             0,
                'NUM_FEATURES':     n,
                'BROAD':            True,   # water band is broad — use broad fitting
                'USE_BBL':          True,
                'OUTPUT':           out_wom,
            },
            context=context,
            feedback=feedback,
            is_child_algorithm=True,
        )
        if feedback.isCanceled():
            return {}

        wom_path = wom_result['OUTPUT']
        feedback.pushInfo(f'  WoM raster saved: {wom_path}')

        # Step 2: Wavelength Mapping 1870-1940 nm
        feedback.setProgress(50)
        feedback.pushInfo('Step 2/2  Wavelength Mapping  1870-1940 nm stretch ...')
        feedback.pushInfo('  Colour depth (Band 2) distinguishes halloysite from dry kandite minerals')

        from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
        wma     = WavelengthMappingAlgorithm()
        palette = wma.create_rainbow_palette()

        map_path = wma._run_colour_mapping(
            wom_path, palette,
            self.MAP_MIN, self.MAP_MAX,
            self.DEPTH_MIN, self.DEPTH_MAX,
            out_map, feedback,
        )

        feedback.setProgress(88)
        feedback.pushInfo(f'  Wavelength map saved: {map_path}')

        # Step 3: Legend
        if not legend_path:
            wom_dir     = os.path.dirname(wom_path)
            legend_path = os.path.join(wom_dir, '1900W_legend.png')
        try:
            saved = wma.create_legend(
                legend_path, palette,
                self.MAP_MIN, self.MAP_MAX,
                self.DEPTH_MIN, self.DEPTH_MAX,
                feedback,
            )
            if saved:
                self._legend_path = saved
                feedback.pushInfo(f'  Colour legend saved: {saved}')
        except Exception as e:
            feedback.pushWarning(f'Legend generation failed: {e}')

        feedback.setProgress(100)
        feedback.pushInfo('Feature Extraction 1900W complete.')

        return {
            self.OUTPUT_WOM:    wom_path,
            self.OUTPUT_MAP:    map_path,
            self.LEGEND_OUTPUT: self._legend_path or '',
        }

    def postProcessAlgorithm(self, context, feedback):
        if getattr(self, '_legend_path', None):
            from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
            WavelengthMappingAlgorithm()._show_legend_dock(self._legend_path, feedback)
        return {}

    def name(self):        return 'fe_1900w'
    def displayName(self): return 'FE07 - 1900W  (Halloysite Water Band)'
    def group(self):       return '7 - Feature Extraction'
    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + """
        <b>Feature Extraction — 1900W  (Halloysite Interlayer Water)</b>

        <p>Targets the broad H₂O combination absorption of halloysite at <b>~1900 nm</b>,
        the primary spectral discriminator separating halloysite from all other kandite
        group minerals, derived from the USGS GMEX kandite group comparison spectra.</p>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over <b>1850-1960 nm</b>
              with <b>broad feature fitting</b> (the water band is wide).</li>
          <li>Generates a <b>Wavelength Map</b> with colour stretch <b>1870-1940 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>1850-1960 nm</td></tr>
          <tr><td>Colour stretch min</td><td>1870 nm</td></tr>
          <tr><td>Colour stretch max</td><td>1940 nm</td></tr>
          <tr><td>Feature fitting</td><td>Broad (suited to wide water band)</td></tr>
          <tr><td>Depth max scale</td><td>0.35 (accommodates deep water band)</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>GMEX kandite group — 1900 nm feature by mineral:</b></p>
        <ul>
          <li><b>Halloysite (hydrated)</b> — deep broad ~1900 nm band; primary identifier</li>
          <li><b>Halloysite (dehydrated)</b> — reduced ~1900 nm band, still distinguishable</li>
          <li><b>Kaolinite</b> — essentially absent (minor ~1830 nm feature only)</li>
          <li><b>Dickite</b> — absent</li>
          <li><b>Nacrite</b> — absent</li>
        </ul>

        <p>The Band 2 (depth) output from this tool is the key input for
        <b>DT Kandite Classification</b> — deep 1900 nm = halloysite gate.</p>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Band 1: wavelength ~1900 nm, Band 2: water band depth.</li>
          <li><b>Wavelength Map RGB</b> — colour-coded map ready for display in QGIS.</li>
          <li><b>Colour Legend PNG</b> — 2-D legend; auto-displayed as a floating panel.</li>
        </ul>

        <p><i>Feature parameters from USGS GMEX Spectral Library, kandite group spectra.
        Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return Fe1900WAlgorithm()
