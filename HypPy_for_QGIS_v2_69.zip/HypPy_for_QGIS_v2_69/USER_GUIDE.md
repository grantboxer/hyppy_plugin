# HypPy for QGIS — Complete Workflow Guide

**Hyperspectral Analysis Tools | Version 2.69 | March 2026**

---

## Table of Contents

1. [Overview](#1-overview)
2. [Installation](#2-installation)
3. [Data Import](#3-data-import)
4. [Generate WoM Rasters](#4-generate-wom-rasters)
5. [Wavelength of Minimum (Custom Range)](#5-wavelength-of-minimum-custom-range)
6. [Wavelength Mapping](#6-wavelength-mapping)
7. [Feature Extraction](#7-feature-extraction)
8. [Decision Tree Classification](#8-decision-tree-classification)
9. [SAM Classification](#9-sam-classification)
10. [Spectral Processing Tools](#10-spectral-processing-tools)
11. [Spectrum Viewer](#11-spectrum-viewer)
12. [Convert Tools](#12-convert-tools)
13. [Common Wavelength Ranges](#13-common-wavelength-ranges)
14. [Version History](#14-version-history)
15. [References](#15-references)

---

## 1. Overview

The HypPy for QGIS plugin provides hyperspectral analysis tools accessed via the QGIS Processing Toolbox and the HypPy toolbar dropdown. The toolbox is organised as follows:

- **1 - Workflow Guide** — open this guide in your browser
- **2 - Data Import** — build overviews for fast display; spatial/spectral subset
- **3 - Generate WoM Rasters** — generate WoM rasters and wavelength maps
- **4 - Decision Tree Classification** — classify minerals and physical properties
- **5 - SAM Classification** — Spectral Angle Mapper classification
- **6 - Spectral Processing Tools** — band ratios, depths, convex hull removal, band math
- **7 - Feature Extraction** — one-click WoM + wavelength map + legend for standard absorption features
- **8 - Convert Tools** — format conversion utilities

### Plugin Structure

| Algorithm | Toolbox Group | Purpose |
|-----------|--------------|---------|
| **Step 1 - Open Workflow Guide** | 1 - Workflow Guide | Open this guide in your browser |
| **D01 - Build Overviews (Fast Display)** | 2 - Data Import | Build GDAL overview pyramids for fast display of large images |
| **D02 - Subset** | 2 - Data Import | Extract a spatial and/or spectral subset |
| **Step 2a - Generate All Three WoM Rasters** | 3 - Generate WoM Rasters | Generate WoM-A, WoM-B and WoM-C in one step |
| **Step 2a - Generate WoM-A (750–1300 nm)** | 3 - Generate WoM Rasters | Generate WoM-A individually |
| **Step 2a - Generate WoM-B (1850–2100 nm)** | 3 - Generate WoM Rasters | Generate WoM-B individually |
| **Step 2a - Generate WoM-C (2100–2400 nm)** | 3 - Generate WoM Rasters | Generate WoM-C individually |
| **Step 2b - Wavelength of Minimum (custom range)** | 3 - Generate WoM Rasters | Extract absorption feature wavelengths and depths for any range |
| **Step 2c - Wavelength Mapping** | 3 - Generate WoM Rasters | Create RGB visualisation from absorption features |
| **DT Mineral 2100–2400** | 4 - Decision Tree Classification | Classify minerals in 2100–2400 nm range |
| **DT Albedo** | 4 - Decision Tree Classification | Classify brightness using per-pixel mean reflectance |
| **DT Fedrop** | 4 - Decision Tree Classification | Classify iron drop intensity from R(1600)/R(1310) ratio |
| **DT Illcryst** | 4 - Decision Tree Classification | Classify illite crystallinity and smectite minerals |
| **DT Ill-Kaol** | 4 - Decision Tree Classification | Classify illite vs kaolinite ratio |
| **DT Mineral Map** | 4 - Decision Tree Classification | Classify 17 mineral classes using WoM-B + WoM-C |
| **Spectral Angle Mapper (SAM)** | 5 - SAM Classification | Classify pixels against a spectral library |
| **Convex Hull Removal** | 6 - Spectral Processing Tools | Continuum removal using convex hull fitting |
| **Band Ratio** | 6 - Spectral Processing Tools | Single-band ratio (Band1/Band2) by wavelength |
| **Band Ratios (Sequential)** | 6 - Spectral Processing Tools | All-band sequential ratios with delta |
| **Band Depths** | 6 - Spectral Processing Tools | Per-band absorption feature depths |
| **Band Math** | 6 - Spectral Processing Tools | NumPy expression over image bands (i1, i2...) |
| **Spectra Math** | 6 - Spectral Processing Tools | Per-pixel spectral expression (S1, S2...) |
| **Log Residuals** | 6 - Spectral Processing Tools | Log Residuals / Kwik Residuals normalisation |
| **FE01–FE18, FE-REE** | 7 - Feature Extraction | One-click WoM + wavelength map + legend per absorption feature |
| **Convert Image to ENVI** | 8 - Convert Tools | Convert TIFF/JPEG/PNG to ENVI flat-binary |
| **Convert EOS HDF to ENVI** | 8 - Convert Tools | Extract EOS HDF subdatasets to ENVI |
| **Convert ASTER HDF to ENVI** | 8 - Convert Tools | Extract ASTER HDF bands to ENVI |
| **Convert EMIT L2A to ENVI** | 8 - Convert Tools | Convert EMIT L2A NetCDF4 to ENVI |

---

## 2. Installation

Copy the `HypPy_for_QGIS` folder to your QGIS plugins directory:

- **Windows:** `%APPDATA%\QGIS\QGIS3\profiles\<profile>\python\plugins\`
- **Linux:** `~/.local/share/QGIS/QGIS3/profiles/<profile>/python/plugins/`
- **macOS:** `~/Library/Application Support/QGIS/QGIS3/profiles/<profile>/python/plugins/`

Restart QGIS, then enable the plugin via **Plugins > Manage and Install Plugins**. The HypPy tools will appear in the Processing Toolbox under the HypPy provider.

### Requirements

- QGIS 3.16 or later
- numpy — bundled with QGIS
- GDAL/OGR — bundled with QGIS
- **scipy** — required for Spectra Math and Band Math (convex hull, resampling).
  Bundled with most QGIS installations. If missing, install via:
  - Windows (OSGeo4W Shell): `pip install scipy`
  - Linux / macOS: `pip3 install scipy`

---

## 3. Data Import

The Data Import group contains tools for preparing a hyperspectral image before analysis. The recommended starting workflow for any new dataset is: **Build Overviews first** so QGIS can navigate the image quickly, then **Subset** if you only need to process a portion of the scene or a restricted wavelength range.

### 3.1 D01 — Build Overviews (Fast Display)

Builds GDAL overview pyramids so that QGIS can display large hyperspectral images quickly at any zoom level without loading the full file into memory. On completion the image is automatically loaded into the QGIS map canvas with **-9999 pixel values set to transparent**.

**Why this is needed:** Large hyperspectral files (such as AVIRIS at ~7 GB stored in BIL interleave) can take a very long time to load in QGIS. Without overviews, QGIS reads full-resolution data even when zoomed far out. Building overviews is a one-time operation that makes subsequent loading and navigation fast.

**How it works:** A small `.ovr` sidecar file is written alongside the original image, containing pre-computed lower-resolution versions (pyramids). QGIS automatically selects the appropriate resolution level based on the current zoom. Wavelength metadata is fully preserved — the original image and its ENVI `.hdr` are never modified; all HypPy algorithms continue to work on the original file exactly as before.

| Parameter | Description |
|-----------|-------------|
| **Input Image** | The hyperspectral image — point to the `.hdr` or the binary data file |
| **Overview Levels** | Standard (2–32) suits most images. Extended (2–128) for very large files or small-scale viewing. Coarse (4–64) builds faster with less detail. |
| **Resampling Method** | *average* (default) gives best visual quality for reflectance data. *nearest* is fastest and appropriate for classified outputs. |
| **External overviews** | Recommended (default on). Writes a `.ovr` sidecar; the original file is not modified. Uncheck only for GeoTIFF where internal overviews are preferred. |

**Notes:**
- Building overviews on a 7 GB AVIRIS file typically takes a few minutes — this is a one-time cost.
- The `.ovr` file must remain in the same folder as the image. If moved or deleted, QGIS falls back to slow full-resolution reads; simply run D01 again to rebuild.
- For ENVI BIL files, converting to BSQ interleave with D02 Subset before building overviews gives the best display performance for band-selective RGB composites.

### 3.2 D02 — Subset

Extracts a spatial and/or spectral subset from an ENVI hyperspectral image, writing a new ENVI flat-binary output. Use this tool to clip the scene to your area of interest or to restrict the spectral range before processing — both operations reduce file size and speed up subsequent algorithms significantly.

**Spatial subset — two modes:**

*Pixel mode* (default — "Use map coordinates" unticked): define the region as pixel row/column offsets from the top-left corner of the image.

*Map coordinate mode* ("Use map coordinates" ticked): define the region using the same coordinate system as the image (e.g. UTM eastings and northings). The tool converts map coordinates to the nearest pixel boundary automatically.

**Spectral subset:** Specify start and end wavelengths in nm to retain only the bands within that range. Leave at defaults (0 / 99999) to keep all bands.

**Bad Band List:** If the input image has a BBL entry in its ENVI header, the output header is updated so that excluded bands are also excluded from the subset.

| Parameter | Description |
|-----------|-------------|
| **Input Image** | ENVI hyperspectral image (.hdr or binary) |
| **Use map coordinates** | Tick to enter spatial bounds in map units rather than pixels |
| **Spatial bounds** | Start/end row and column (pixel mode) or X/Y min/max (map mode) |
| **Start / End Wavelength (nm)** | Spectral range to retain (0/99999 = all bands) |
| **Output ENVI image** | Path for the output flat-binary file; a matching `.hdr` is written automatically |

---

## 4. Generate WoM Rasters

This group generates the three Wavelength of Minimum (WoM) rasters required by the decision tree classifiers, and provides tools for custom wavelength range analysis and wavelength mapping. Run the WoM generation step first whenever processing a new hyperspectral dataset.

Use **Step 2a - Generate All Three WoM Rasters** to produce WoM-A, WoM-B, and WoM-C in a single operation, or run the individual Step 2a algorithms if only specific ranges need to be regenerated.

### 4.1 Required Input

The hyperspectral spectral cube — the original reflectance image with full spectral range and wavelength metadata (ENVI format or equivalent). All Step 2a algorithms accept the cube as their only input.

### 4.2 WoM Raster Specifications

| Name | Wavelength Range | Used by | Notes |
|------|-----------------|---------|-------|
| **WoM-A** | 750 – 1300 nm | Future classifiers | Iron oxide and hydroxyl features |
| **WoM-B** | 1850 – 2100 nm | dt_illcryst, dt_ill_kaol, dt_mineral_map | Water and carbonate shoulder; illite crystallinity denominator |
| **WoM-C** | 2100 – 2400 nm | dt_mineral_map, dt_2100_2400, dt_fedrop, dt_illcryst, dt_ill_kaol | Primary clay mineral absorption region |

### 4.3 Step 2a Algorithms

**Generate All Three WoM Rasters**
Runs the Wavelength of Minimum algorithm three times in sequence on a single hyperspectral cube, producing WoM-A, WoM-B, and WoM-C in one operation. This is the recommended starting point for any new dataset.

**Generate WoM-A / WoM-B / WoM-C (individual)**
Three individual algorithms for regenerating a single WoM raster without reprocessing the others. Each is pre-configured with the correct wavelength range; the only inputs required are the hyperspectral cube and an output path.

All Step 2a algorithms use Division continuum removal (recommended), extract 3 features per pixel by default (1–9 selectable), and honour the Bad Band List if present in the ENVI metadata. The output raster has 2 × N bands: wavelength and depth for each feature, sorted deepest first. Decision tree classifiers use Band 1 (primary feature) only.

---

## 5. Wavelength of Minimum (Custom Range)

Analyses each pixel's spectrum within a user-defined wavelength range. Applies convex hull continuum removal, locates local minima, and fits parabolas for sub-band-resolution wavelength and depth values. Use this when you need a WoM raster for a wavelength range other than the three presets in Step 2a.

| Parameter | Typical Value | Notes |
|-----------|--------------|-------|
| **Input Image** | Hyperspectral raster | Must have wavelength metadata |
| **Start Wavelength (nm)** | 2000 | Begin analysis window |
| **End Wavelength (nm)** | 2500 | End analysis window |
| **Continuum Removal** | Division | Division recommended for minerals |
| **Number of features (1–9)** | 1–3 | 1 for single mineral, 3+ for multi-mineral |
| **Broad feature fitting** | Off | On for broad absorption features |
| **Use Bad Band List** | On if available | Excludes noisy bands flagged in ENVI metadata |

**Output:** A multi-band GeoTIFF containing wavelength/depth pairs for each requested feature. Band 1 = interpolated min. wavelength, Band 2 = interpolated depth, and so on for additional features. Features are sorted by depth (deepest first).

---

## 6. Wavelength Mapping

Takes a Wavelength of Minimum output and creates an RGB image. Colour (hue) represents absorption wavelength position and brightness represents absorption depth.

| Parameter | Typical Value | Notes |
|-----------|--------------|-------|
| **Input (Step 2a or 2b output)** | WoM GeoTIFF | Uses Band 1 and Band 2 directly |
| **Min Wavelength for Display (nm)** | 2100 | Blue end of colour stretch |
| **Max Wavelength for Display (nm)** | 2350 | Red end of colour stretch |
| **Min Depth for Display** | 0.0 | Lower bound of brightness stretch |
| **Max Depth for Display** | 0.2 | Adjust for brightness (try 0.05–0.3) |

**Output Wavelength Map (RGB):** A 3-band RGB GeoTIFF. Hue encodes wavelength position (blue→green→yellow→red across the wavelength range) and brightness encodes absorption depth.

**Output Wavelength Map Legend (PNG):** A 2D colour legend image. The Y axis shows wavelength (nm) and the X axis shows absorption depth. The legend uses the same colour scheme as the wavelength map, allowing direct interpretation of map colours. After processing completes, the legend is automatically displayed in a floating dock window inside QGIS.

---

## 7. Feature Extraction

The Feature Extraction tools are one-click pipelines that combine Wavelength of Minimum, Wavelength Mapping, and legend display into a single operation. Each tool targets a specific known absorption feature, with pre-configured wavelength ranges and map stretch values. Running a Feature Extraction tool produces three outputs: a WoM raster, an RGB wavelength map, and a colour legend PNG — and automatically displays the legend in a floating dock window.

Each tool is named after its characteristic absorption wavelength and feature type:
- **W** suffix — water or hydroxyl combination band
- **D** suffix — diagnostic mineral absorption feature

### 7.1 Feature Extraction Tools

| Tool | WoM Search Range | Map Colour Stretch | Characteristic Feature | Reference |
|------|-----------------|-------------------|----------------------|-----------|
| **FE01 - 1384D** | 1350 – 1450 nm | 1375 – 1425 nm | Dickite OH doublet ~1384/1418 nm | Laukamp et al. (2021) Table 5 (1400D/W) |
| **FE02 - 1396W** | 1350 – 1450 nm | 1385 – 1410 nm | Pyrophyllite OH ~1396 nm | Laukamp et al. (2021) Table 5 (1400D/W) |
| **FE03 - 1400D** | 1350 – 1450 nm | 1387 – 1445 nm | Kaolinite / all OH-bearing sheet silicates ~1400 nm | Laukamp et al. (2021) Table 5 (1400D/W) |
| **FE04 - 1480W** | 1440 – 1520 nm | 1471 – 1491 nm | Alunite / jarosite / prehnite ~1480 nm | Laukamp et al. (2021) Table 5 (1480D/W) |
| **FE05 - 1550W** | 1510 – 1610 nm | 1520 – 1563 nm | Epidote 2νOH ~1550 nm | Laukamp et al. (2021) Table 5 (1550D/W) |
| **FE06 - 1760W** | 1730 – 1790 nm | 1751 – 1764 nm | Gypsum / alunite ν+2δOH ~1760 nm | Laukamp et al. (2021) Table 5 (1760D/W) |
| **FE07 - 1900W** | 1850 – 1960 nm | 1870 – 1940 nm | Halloysite H₂O ~1900 nm | GMEX halloysite reference |
| **FE08 - 2066D** | 2050 – 2110 nm | 2055 – 2095 nm | Pyrophyllite Al-OH doublet ~2066/2078 nm | GMEX pyrophyllite reference |
| **FE09 - 2080D** | 2060 – 2100 nm | 2075 – 2090 nm | Talc ν+δM₃OH ~2080 nm | Laukamp et al. (2021) Table 5 (2080D) |
| **FE10 - 2160D** | 2138 – 2179 nm | 2159 – 2166 nm | Kaolin / pyrophyllite outer OH ~2160 nm | Laukamp et al. (2021) Table 5 (2160D) |
| **FE11 - 2178D** | 2138 – 2210 nm | 2162 – 2196 nm | Dickite AlOH shoulder ~2178 nm | GMEX dickite reference |
| **FE12 - 2200W** | 2120 – 2245 nm | 2185 – 2215 nm | AlOH — illite / smectite / kaolinite ~2200 nm | Laukamp et al. (2021) Table 5 (2200D/W) |
| **FE13 - 2206W** | 2120 – 2245 nm | 2197 – 2215 nm | Kaolinite primary AlOH ~2206 nm | GMEX kaolinite reference |
| **FE14 - 2250W** | 2230 – 2280 nm | 2248 – 2268 nm | Chlorite / biotite / epidote MgFeOH ~2250 nm | Laukamp et al. (2021) Table 5 (2250D/W) |
| **FE15 - 2290W** | 2270 – 2320 nm | 2279 – 2338 nm | FeMg-clay / amphibole / talc ~2290 nm | Laukamp et al. (2021) Table 5 (2290D/W) |
| **FE16 - 2320W** | 2295 – 2345 nm | 2300 – 2340 nm | Carbonate 3ν₃CO₃ / Mg-chlorite ~2320 nm | Laukamp et al. (2021) Table 5 (2320D/W) |
| **FE17 - 2350W** | 2310 – 2370 nm | 2320 – 2366 nm | White mica / chlorite / epidote ~2350 nm | Laukamp et al. (2021) Table 5 (2350D/W) |
| **FE18 - 2390W** | 2375 – 2435 nm | 2377 – 2406 nm | Amphibole / biotite / talc ~2390 nm | Laukamp et al. (2021) Table 5 (2390D/W) |
| **FE-REE - Neodymium VNIR** | 530 – 910 nm | 560 – 900 nm | Nd³⁺ absorptions ~580/740/800/870 nm (all four bands) | Turner et al. (2014, 2016, 2018); Boesche et al. (2015) |

### 7.2 Inputs

| Parameter | Description |
|-----------|-------------|
| **Hyperspectral cube** | The original reflectance image with wavelength metadata |
| **Number of features (1–9)** | How many absorption minima to extract per pixel (default 1) |
| **Output WoM raster** | Path for the Wavelength of Minimum output |
| **Output Wavelength Map RGB** | Path for the colour-coded map |
| **Output Colour Legend (PNG)** | Optional — defaults to `<label>_legend.png` beside the WoM output |

### 7.3 Outputs

**WoM raster:** Multi-band GeoTIFF — Band 1 = wavelength of minimum (nm), Band 2 = feature depth. Additional band pairs follow for each requested feature, sorted deepest first.

**Wavelength Map RGB:** 3-band GeoTIFF where hue encodes wavelength position across the map stretch range and brightness encodes absorption depth. Ready for display in QGIS.

**Colour Legend PNG:** A 2D legend image with wavelength (nm) on the Y axis and depth on the X axis, saved as `<label>_legend.png` in the same folder as the WoM raster unless an explicit path is specified. The legend is automatically displayed in a floating dock widget within QGIS after processing.

### 7.4 Workflow Tip

Feature Extraction tools are designed for rapid reconnaissance of a dataset. Run several tools across your scene to identify which absorption features are present and spatially coherent before committing to a full decision tree classification workflow.

---

## 8. Decision Tree Classification

The decision tree classifiers use pre-computed wavelength analysis outputs to assign mineral or physical property classes to each pixel. All classifiers require a minimum set of input data prepared in the Generate WoM Rasters step.

### 8.1 Required Input Data

**1. Hyperspectral spectral cube**
Required by dt_albedo and dt_fedrop to compute internal band ratios.

**2. WoM rasters from Step 2a:**

| WoM | Wavelength Range | Used by |
|-----|-----------------|---------|
| **WoM-A** | 750 – 1300 nm | Future classifiers |
| **WoM-B** | 1850 – 2100 nm | dt_mineral_map, dt_illcryst, dt_ill_kaol (depth denominator) |
| **WoM-C** | 2100 – 2400 nm | dt_mineral_map, dt_2100_2400, dt_fedrop, dt_illcryst, dt_ill_kaol |

### 8.2 Decision Tree Algorithms

**DT Mineral 2100–2400 — Mineral Classification**
Classifies 16 mineral classes including kaolinite, muscovite, illite, pyrophyllite, alunite, and carbonate minerals. Input: WoM-C only. The algorithm uses the primary absorption wavelength (Band 1) and feature depth (Band 2) from the 2100–2400 nm wavelength map.
*Decision tree after van Ruitenbeek et al. (2025), Remote Sensing 17(15), 2555.*

**DT Albedo — Brightness Classification**
Classifies pixels into four brightness classes (dark, med-dark, med-light, light) based on the mean reflectance across all bands. Thresholds are calculated dynamically using quartiles of the valid pixel distribution, so each image is classified relative to its own brightness range. Input: hyperspectral cube only.

**DT Fedrop — Iron Drop Classification**
Classifies iron drop intensity into eight classes (aspectral, no2100-2400, low through very-high). The fedrop value is computed internally as R(1600 nm) / R(1310 nm). Inputs: hyperspectral cube + WoM-C.

**DT Illcryst — Illite Crystallinity Classification**
Classifies illite crystallinity into eight classes ranging from smectite to muscovite (smect3, smect2, smect1, smect-ill, ill-smect, hx-ill, musc1, musc2). The illite crystallinity value (illx) is computed internally as depth(2100–2400 nm) / depth(1850–2100 nm). Inputs: WoM-B + WoM-C.

**DT Ill-Kaol — Illite / Kaolinite Classification**
Classifies the illite-to-kaolinite ratio into nine classes (aspectral, NO-ALOH, kaol4–kaol1, ill1–ill4). Thresholds based on analysis of reflectance spectra of illite and kaolinite mixtures. Inputs: WoM-B + WoM-C.

**DT Mineral Map — Mineral Map Classification**
Classifies pixels into 17 mineral classes covering illite/muscovite variants, kaolinite, phengite, Fe-chlorite, and chlorite. Branches on W1 (wavelength of deepest feature), W2 (wavelength of second deepest feature), and Ix (illite crystallinity). Inputs: WoM-B + WoM-C (WoM-C must have ≥2 features).

### 8.3 Outputs

Each classifier produces a palette-indexed integer class raster (GeoTIFF) as the primary output. Class names are embedded in the raster as a Raster Attribute Table (RAT), which QGIS reads to display class names in the layer legend. An optional RGB colour raster can also be requested for visual display.

---

## 9. SAM Classification

The Spectral Angle Mapper classifies image pixels by measuring the spectral angle between each pixel and a set of reference spectra. SAM is insensitive to illumination variations, making it robust for mineral identification.

### 9.1 Prepare Input Data

- **Hyperspectral image** with wavelength metadata in ENVI header format.
- **Spectral library** in ENVI binary format (.sli + .hdr) or CSV text format (.csv, .txt).

### 9.2 Browse the Spectral Library (Optional)

1. Open SAM from Processing Toolbox > HypPy > 5 - SAM Classification > Spectral Angle Mapper
2. Select your spectral library file
3. Check "List available spectra names (does not run SAM)"
4. Click Run — all spectra will be listed with index numbers in the log.

### 9.3 Configure the Spectra Filter

| Filter Pattern | Effect |
|---------------|--------|
| `Kaolinite*` | All spectra starting with 'Kaolinite' |
| `*alunite*` | Any spectrum containing 'alunite' (case-insensitive) |
| `Kaolinite*,Alunite*,Calcite*` | Multiple mineral groups |
| `1-10` | First 10 spectra by index (1-based) |
| `1,5,42` | Specific spectra by index |
| *(empty)* | Use all spectra in the library |

### 9.4 Select Similarity Measure

| Code | Measure | Notes |
|------|---------|-------|
| **SAM** | Spectral Angle Mapper | Recommended. Insensitive to illumination. |
| **BC** | Bray-Curtis Distance | Quantifies compositional dissimilarity. Range [0,1]. |
| **SID** | Spectral Information Divergence | Information-theoretic. Sensitive to spectral shape. |
| **ED** | Euclidean Distance | Sensitive to shape and magnitude. |
| **ID** | Intensity Difference | Sum of absolute differences. |

### 9.5 Outputs

- **Rule Image:** Multi-band raster with similarity values for each reference spectrum. Lower values indicate better matches.
- **Classification Image:** Single-band raster with class assignments (0 = unclassified, 1+ = class index).

### 9.6 Automatic Processing

The SAM algorithm automatically handles:
- **Wavelength resampling:** Reference spectra are interpolated to match image wavelengths when band counts differ.
- **Unit conversion:** Micrometres and nanometres are auto-detected and converted.
- **ENVI no-data handling:** Values of -1.23e34 are replaced with NaN and excluded from comparisons.

---

## 10. Spectral Processing Tools

The spectral processing tools can be applied independently to any hyperspectral raster. All tools read wavelength metadata from the ENVI domain first, with fallback to the default metadata domain and numeric band descriptions.

### 10.1 Convex Hull Removal (Continuum Removal)

Removes the spectral continuum from each pixel spectrum using a convex hull fit, isolating individual absorption features for analysis.

| Parameter | Description |
|-----------|-------------|
| **Input Image** | Hyperspectral raster with wavelength metadata |
| **Mode** | Divide: spectrum / hull (absorptions < 1.0) \| Subtract: 1 + (spectrum − hull) |
| **Cutoff Wavelength (nm)** | Restrict to bands below this wavelength. Set to 0 to use all bands. |
| **Use Bad Band List** | Exclude bands flagged in ENVI BBL metadata |

### 10.2 Band Ratio

Computes a single-band ratio image: Numerator band / Denominator band. Bands are specified by wavelength in nm; the nearest available band is selected automatically.

### 10.3 Band Ratios (Sequential)

Computes sequential band ratios across the full spectrum: `output[i] = input[i] / input[i + delta]`. Useful for highlighting spectral gradients and transitions.

### 10.4 Band Depths

Computes per-band absorption feature depths. For each centre band i: `top = (band[i-delta] + band[i+delta]) / 2`, `depth = (top - band[i]) / top`. Positive values indicate absorption.

### 10.5 Band Math

Evaluates an arbitrary Python/NumPy expression over one or more input rasters. Input images are referenced as `i1`, `i2`, ... Each image is an `_Image` object that mirrors the HyPy `envi2.Image` interface — all numpy functions are available in the expression namespace.

**Image access — wavelength addressing via `__call__`:**

| Syntax | Returns | Description |
|--------|---------|-------------|
| `i1(2200.0)` | 2D array (rows × cols) | Band nearest to 2200 nm — *wavelength call* |
| `i1[n]` | 2D array (rows × cols) | Band at integer index n (0-based) |
| `i1[j, i]` | 1D array (bands,) | Spectrum at row j, col i |
| `i1[j, i, b]` | scalar | Value at row j, col i, band b |
| `i1[...]` | 3D array (bands × rows × cols) | Entire image cube |
| `i1.wavelength` | 1D array or None | Wavelength array from metadata |
| `i1.bands` | int | Number of (valid) bands |

**Expression examples:**

| Expression | Description |
|------------|-------------|
| `i1(2200.0) / i1(2100.0)` | Wavelength ratio using nm addresses |
| `(i1(2200.0) - i1(2100.0)) / (i1(2200.0) + i1(2100.0))` | NDVI-style normalised difference |
| `i1[10] / i1[20]` | Band ratio using integer indices |
| `log(i1(2200.0)) - log(i1(2100.0))` | Log ratio |
| `i1(2200.0) - i2(2200.0)` | Same-wavelength difference between two images |

> Band Math operates on full 2D band arrays — use Spectra Math for per-pixel spectral operations with wavelength slices and Spectrum objects.

### 10.6 Spectra Math

Applies a per-pixel spectral expression using one or more input images. Each pixel spectrum is wrapped in a full HyPy `Spectrum` object (S1, S2, …). The expression is evaluated once per pixel; the result (a Spectrum, array, or scalar) determines the output band count.

**Spectrum — indexing:**

| Syntax | Returns | Description |
|--------|---------|-------------|
| `S1[2200.0]` | scalar | Value at nearest wavelength to 2200 nm — *float index* |
| `S1(2200.0)` | scalar | Same — callable syntax |
| `S1[2000.0:2400.0]` | Spectrum | Sub-spectrum from 2000 to 2400 nm — *float slice* |
| `S1[5]` | scalar | Value at integer band index 5 |
| `S1.spectrum` | 1D array | Raw reflectance values |
| `S1.wavelength` | 1D array | Wavelength array |

**Spectrum — arithmetic and coercion:**
When two Spectrum objects are combined with `+`, `-`, `*`, `/`, etc., they are automatically resampled onto their overlapping wavelength range before the operation — no manual resampling needed.

**Spectrum — numpy methods:**
`S1.log()`, `S1.log2()`, `S1.log10()`, `S1.exp()`, `S1.sqrt()`, `S1.square()`,
`S1.abs()` / `abs(S1)`, `S1.sin()`, `S1.cos()`, `S1.tan()`,
`S1.mean()`, `S1.min()`, `S1.max()`, `S1.sum()`, `S1.std()`, `S1.var()`,
`S1.clip(a, b)`, `S1.round()`, `S1.cumsum()`, `S1.cumprod()`, `S1.copy()`

**Spectrum — spectral shape methods:**
`S1.hull()`, `S1.nohull()`, `S1.peaks()`, `S1.smooth(n)`,
`S1.gradient()`, `S1.second()`, `S1.localmin(n)`, `S1.localmax(n)`, `S1.minwav(n)`

**Spectrum — resampling:**
`S1.resample(S2.wavelength)` — resample S1 onto S2's wavelengths using linear interpolation.

**Expression examples:**

| Expression | Description |
|------------|-------------|
| `S1 / S2` | Per-band ratio (auto-resamples to overlapping range) |
| `S1[2200.0] / S1[2100.0]` | Two-wavelength ratio — returns scalar per pixel |
| `S1[2000.0:2400.0]` | Sub-spectrum 2000–2400 nm — output has fewer bands |
| `S1.nohull()` | Continuum-removed spectrum |
| `S1.log()` | Natural log of spectrum |
| `(S1 - S2).absolute()` | Absolute spectral difference |
| `S1.smooth(3)` | Smoothed spectrum (3 passes) |

### 10.7 Log Residuals

Computes Log Residuals or Kwik Residuals normalisation, a standard technique for removing scene-wide albedo effects and sensor response variations from hyperspectral data. Optionally outputs an albedo band and/or a residual lower-upper boundary (RLUB) raster.

---

## 11. Spectrum Viewer

The Spectrum Viewer is a dockable panel for interactive pixel spectrum inspection and comparison against a spectral library.

### 11.1 Opening the Viewer

Open via **HypPy → Spectrum Viewer** from the toolbar dropdown. The panel docks to the QGIS interface and can be repositioned or floated.

### 11.2 Picking a Pixel Spectrum

1. Load a hyperspectral raster and make it the active layer.
2. Click **▶ Pick pixel** — the cursor changes to a crosshair.
3. Click any pixel on the map canvas to display its spectrum.
4. Right-click or press **Esc** to stop picking.

The pixel spectrum is normalised 0–1 for display and plotted on the left Y axis. Wavelengths are read from the ENVI header if present; otherwise band numbers are used.

> **Note:** Negative reflectance values (common in noisy detector regions, typically beyond ~2400 nm) are masked and displayed as gaps in the plot rather than pulling the Y axis below zero.

### 11.3 Plotting Library Spectra

1. Select a **Library type** (ENVI Speclib, ASCII file, or ASCII directory).
2. Browse to the library file/folder.
3. Select one or more spectra from the list.
4. Optionally enable **Remove Convex Hull** (divide or subtract mode).
5. Click **Plot** to overlay the library spectra on the right Y axis.

Use **Average** to plot the mean of all selected library spectra. Use **Clear plot** to remove library spectra without clearing the pixel spectrum.

### 11.4 Math Expression

Enter a spectral expression in the **Math Expression** field using `S` to reference the current pixel spectrum (e.g. `S.nohull()`, `S[2200.0]`, `S.mean()`). Click **Go** to evaluate and display the result.

### 11.5 View Values

Click **View Values** to switch to the **Values** tab showing a table of wavelength / reflectance pairs for all plotted spectra.

### 11.6 Export

Right-click the plot area for options to copy the pixel spectrum as CSV or save the plot as an image.

---

## 12. Convert Tools

The Convert Tools group provides format conversion utilities. All tools are available via the Processing Toolbox under **8 - Convert Tools** and via the HypPy toolbar dropdown.

### 12.1 G01 — Convert Image to ENVI

Converts a standard image file (TIFF, JPEG, PNG, BMP) to ENVI flat-binary format. Georeferencing is preserved from GeoTIFF tags if present.

### 12.2 G02 — Convert EOS HDF to ENVI

Extracts every EOS_SWATH subdataset from an EOS HDF file and writes a separate ENVI file and `.hdr` per band. Requires GDAL with HDF4 support.

### 12.3 G03 — Convert ASTER HDF to ENVI

Extracts ImageData/Band/Temperature subdatasets from an ASTER HDF file. Locates GDAL executables automatically from the QGIS/OSGeo4W environment on Windows.

### 12.4 G04 — Convert EMIT L2A to ENVI

Reads an EMIT L2A NetCDF4 reflectance file and writes four ENVI outputs (`_refl`, `_lonlat`, `_elev`, `_glt`). Requires the `netCDF4` Python package.

---

## 13. Common Wavelength Ranges

| Application | Start (nm) | End (nm) | Target Features |
|-------------|-----------|---------|----------------|
| **Clay minerals (AlOH)** | 2100 | 2250 | Kaolinite ~2165, Montmorillonite ~2210 |
| **Broad SWIR survey** | 2000 | 2500 | General mineral mapping |
| **Carbonate minerals** | 2300 | 2400 | Calcite ~2340, Dolomite ~2320 |
| **Iron oxides** | 850 | 1050 | Hematite ~860, Goethite ~920 |
| **Vegetation red edge** | 680 | 750 | Chlorophyll absorption |
| **Vegetation water** | 900 | 1100 | Leaf water content ~970 nm |

---

## 14. Version History

| Ver. | Title | Key Changes |
|------|-------|-------------|
| **2.37** | **Data Import group** | New toolbox group '2 - Data Import' inserted between Workflow Guide and Generate WoM Rasters. Build Overviews moved from Convert Tools and renamed D01. Subset moved from Spectral Processing Tools and renamed D02. All other groups renumbered 3–8. Toolbar and provider updated to match. |
| **2.36** | **D01: auto-load + -9999 transparency** | After building overviews, the image is automatically loaded into the QGIS map canvas with -9999 pixel values set fully transparent via QgsRasterTransparency. Canvas zooms to the image extent on load. |
| **2.35** | **D01: .hdr input fix** | D01 (Build Overviews) now resolves an ENVI .hdr path to the binary data file before opening with GDAL, fixing the "select the data file" error. Resolution order: base name → .img → .dat → .bil → .bip → .bsq. |
| **2.33** | **Build Overviews (Fast Display)** | New tool: builds external GDAL overview pyramids (.ovr sidecar) so QGIS can display large hyperspectral images quickly at any zoom level. Original image and ENVI .hdr are never modified. Three level presets, five resampling methods. Progress bar tracks build. |
| **2.55** | **FE ranges aligned to L21 Table 5** | WoM and stretch ranges for FE01–FE03, FE08, FE11, FE13, FE15 corrected to match Laukamp et al. (2021) Table 5 continuum removal and mineral absorption ranges. FE07 and FE08 reference column updated to GMEX. All Table 1/2/3 citations updated to Table 5. |
| **2.54** | **FE table Reference column** | Added Reference column to Feature Extraction table (§7.1) linking each tool to Laukamp et al. (2021) or Turner et al. (2014/2016/2018). |
| **2.53** | **Laukamp et al. 2021 reference** | Added Laukamp, C. et al., 2021 (Minerals 11(4), 347) to References in USER_GUIDE.md, README.md, getting_started help, and dt_mineral_map help. |
| **2.52** | **HyPy journal reference** | Added Bakker, W. et al., 2024 (Algorithms 17(8), Article 337) to References. |
| **2.23** | **Spectrum Viewer stability fixes** | Fixed RuntimeError when picking pixels or stopping the pick tool after the dock widget has been closed or the plugin reloaded. |
| **2.21** | **Negative reflectance masking** | Pixel spectrum values below zero are masked to NaN and displayed as gaps in the Spectrum Viewer plot. |
| **2.11** | **Full HyPy Spectrum class** | Spectra Math: float wavelength indices, __coerce__ auto-resampling, full numpy method set, spectral shape methods. Band Math: wavelength __call__ syntax. |
| **2.10** | **Wavelength unit normalisation** | All algorithms auto-convert nm / µm / wavenumber regardless of source units. |
| **2.9** | **Log Residuals, SAM improvements** | New Log Residuals tool. SAM vectorised (10–50× speedup), UInt16 output, USGS splib07 parser fix. Polynomial fit order option for WoM-B and custom WoM. |
| **2.8** | **Feature Extraction group** | Added 7 - Feature Extraction with FE01–FE11. Each tool runs WoM, wavelength map, and legend in one click. |
| **2.4** | **Toolbox restructure** | Reorganised into current group scheme. Fixed dt_2100_2400 mineral class bug. |
| **2.3** | **Resizable legend window** | Legend dock is fully resizable by dragging its edges. |
| **2.2** | **Legend display fix** | Legend dock creation moved to postProcessAlgorithm(). |
| **2.0** | **Legend floating dock** | Legend displayed automatically in a floating QDockWidget. |
| **1.8** | **Plugin rename** | Plugin renamed to HypPy_for_QGIS. |
| **1.5** | **Wavelength map legend** | Wavelength Mapping now generates a 2D colour legend PNG. |
| **1.4** | **Workflow A and dt_mineral_map** | New Workflow A generates WoM rasters directly. New 17-class mineral map classifier. |
| **1.3** | **Decision Tree Classifiers** | Added dt_2100_2400, dt_albedo, dt_fedrop, dt_illcryst, dt_ill_kaol. |
| **1.1** | **Spectral Processing Tools** | Added Convex Hull Removal, Band Ratio, Band Ratios, Band Depths, Band Math, Spectra Math. |

---

## 15. References

Kruse, F.A. et al., 1993. The Spectral Image Processing System (SIPS) — Interactive Visualization and Analysis of Imaging Spectrometer Data. *Remote Sensing of Environment*, 44(2-3), pp.145–163.

Kokaly, R.F. et al., 2017. USGS Spectral Library Version 7. *U.S. Geological Survey Data Series* 1035, 61 p.

Bakker, W.H., 2010–2022. HyPy — Hyperspectral Python. University of Twente, Faculty ITC.

Bakker, W. et al., 2024. Hyperspectral Python: HypPy. *Algorithms*, 17(8), Article 337. https://doi.org/10.3390/a17080337

van Ruitenbeek, F.J.A. et al., 2025. A Knowledge-Based Strategy for Interpretation of SWIR Hyperspectral Images of Rocks. *Remote Sensing*, 17(15), 2555. https://doi.org/10.3390/rs17152555

Laukamp, C., Rodger, A., LeGras, M., Lampinen, H., Lau, I.C., Pejcic, B., Stromberg, J., Francis, N. and Ramanaidou, E., 2021. Mineral Physicochemistry Underlying Feature-Based Extraction of Mineral Abundance and Composition from Shortwave, Mid and Thermal Infrared Reflectance Spectra. *Minerals*, 11(4), 347. https://doi.org/10.3390/min11040347

Turner, D.J., Rivard, B. and Groat, L.A., 2014. Visible and Short-Wave Infrared Reflectance Spectroscopy of REE Fluorocarbonates. *American Mineralogist*, 99(7), pp.1335–1346.

Turner, D.J., Rivard, B. and Groat, L.A., 2016. Visible and Short-Wave Infrared Reflectance Spectroscopy of REE Phosphate Minerals. *American Mineralogist*, 101(10), pp.2264–2278.

Turner, D.J., Rivard, B. and Groat, L.A., 2018. Visible and Short-Wave Infrared Reflectance Spectroscopy of Selected REE-Bearing Silicate Minerals. *American Mineralogist*, 103(6), pp.927–943.
