#!/bin/bash
# Package HypPy for QGIS
# Run from inside the plugin folder (where metadata.txt lives).
# Creates HypPy_for_QGIS_v<version>.zip ready for QGIS Install from ZIP.
#
# Usage:
#   cd /path/to/HypPy_for_QGIS
#   bash package.sh

set -e

PLUGIN_NAME="HypPy_for_QGIS"
VERSION=$(grep "^version=" metadata.txt | cut -d'=' -f2 | tr -d '[:space:]')
OUTPUT_FILE="${PLUGIN_NAME}_v${VERSION}.zip"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PARENT_DIR="$(dirname "$SCRIPT_DIR")"

echo "Packaging ${PLUGIN_NAME} v${VERSION} ..."

# Remove old package if it exists
if [ -f "${SCRIPT_DIR}/${OUTPUT_FILE}" ]; then
    rm "${SCRIPT_DIR}/${OUTPUT_FILE}"
    echo "  Removed old ${OUTPUT_FILE}"
fi

# Build the zip from the parent directory so the top-level folder inside
# the zip is exactly PLUGIN_NAME — which must match what QGIS imports.
cd "${PARENT_DIR}"

zip -r "${SCRIPT_DIR}/${OUTPUT_FILE}" "${PLUGIN_NAME}/" \
    --exclude "*/__pycache__/*" \
    --exclude "*/*.pyc" \
    --exclude "*/.git/*" \
    --exclude "*/package.sh" \
    --exclude "*/package.bat" \
    --exclude "*/${PLUGIN_NAME}_v*.zip" \
    -q

echo ""
echo "Package created: ${SCRIPT_DIR}/${OUTPUT_FILE}"
echo ""
echo "To install:"
echo "  1. Open QGIS"
echo "  2. Plugins → Manage and Install Plugins → Install from ZIP"
echo "  3. Select ${OUTPUT_FILE}"
echo ""
