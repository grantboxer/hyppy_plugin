"""
Feature Extraction — Wavelength of Minimum 1440-1520 nm

Runs the Wavelength of Minimum algorithm over the 1440-1520 nm range
(water / hydroxyl combination band), saves the WoM raster, then
generates a wavelength map with a colour stretch of 1471-1491 nm and
displays the colour legend in a floating dock widget.

The colour mapping and legend are performed by calling the helper methods
directly on a WavelengthMappingAlgorithm instance so that postProcessAlgorithm
on THIS algorithm fires the dock — which works correctly when the FE tool
is run from the Processing Toolbox.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
    QgsProcessingException,
)
import processing
import os


WORKFLOW_NOTE = """        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with wavelength metadata.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""

BOUNDARY_NOTE = """        <p style="background-color:#fff3e0; padding:6px; border-left:4px solid #e65100;">
        <b>AVIRIS-NG boundary note:</b> The search range starts at 1440 nm, which sits
        at the edge of the AVIRIS-NG atmospheric water bad band zone (~1340–1445 nm).
        The first few bands (1440–1445 nm) may be excluded by BBL masking; the
        remainder of the range (1445–1520 nm) is valid for AVIRIS-NG data.
        </p>
"""


class FeWom1440_1520Algorithm(QgsProcessingAlgorithm):
    """
    Feature Extraction — Wavelength of Minimum 1440-1520 nm.

    Pipeline:
      1. Wavelength of Minimum  (1440-1520 nm, child algorithm)
      2. Wavelength Mapping     (colour stretch 1471-1491 nm, direct call)
      3. postProcessAlgorithm   displays colour legend dock on GUI thread
    """

    INPUT         = 'INPUT'
    NUM_FEATURES  = 'NUM_FEATURES'
    OUTPUT_WOM    = 'OUTPUT_WOM'
    OUTPUT_MAP    = 'OUTPUT_MAP'
    LEGEND_OUTPUT = 'LEGEND_OUTPUT'

    # Fixed wavelength parameters
    WOM_START  = 1440.0
    WOM_END    = 1520.0
    MAP_MIN    = 1471.0
    MAP_MAX    = 1491.0
    DEPTH_MIN  = 0.0
    DEPTH_MAX  = 0.2

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))

        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract (1-9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=1, minValue=1, maxValue=9))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_WOM,
            'Output WoM raster (1440-1520 nm)'))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_MAP,
            'Output Wavelength Map RGB (1471-1491 nm stretch)'))

        self.addParameter(QgsProcessingParameterFileDestination(
            self.LEGEND_OUTPUT,
            'Output Colour Legend (PNG)',
            fileFilter='PNG Files (*.png)',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        cube        = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n           = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        out_wom     = self.parameterAsOutputLayer(parameters, self.OUTPUT_WOM, context)
        out_map     = self.parameterAsOutputLayer(parameters, self.OUTPUT_MAP, context)
        legend_path = self.parameterAsFileOutput(parameters, self.LEGEND_OUTPUT, context)

        self._legend_path = None  # cleared here; set below if legend succeeds

        # ── Step 1: Wavelength of Minimum 1440-1520 nm ──────────────────────
        feedback.setProgress(5)
        feedback.pushInfo('Step 1/2  Wavelength of Minimum  1440-1520 nm ...')
        wom_result = processing.run(
            'hyppy:wavelength_of_minimum',
            {
                'INPUT':            cube,
                'START_WAVELENGTH': self.WOM_START,
                'END_WAVELENGTH':   self.WOM_END,
                'MODE':             0,
                'NUM_FEATURES':     n,
                'BROAD':            False,
                'USE_BBL':          True,
                'OUTPUT':           out_wom,
            },
            context=context,
            feedback=feedback,
            is_child_algorithm=True,
        )
        if feedback.isCanceled():
            return {}

        wom_path = wom_result['OUTPUT']
        feedback.pushInfo(f'  WoM raster saved: {wom_path}')

        # ── Step 2: Wavelength Mapping 1471-1491 nm ──────────────────────────
        # Import and instantiate WavelengthMappingAlgorithm so we can call its
        # helper methods directly.  This avoids processing.run() which would
        # block postProcessAlgorithm from firing on the legend dock.
        feedback.setProgress(50)
        feedback.pushInfo('Step 2/2  Wavelength Mapping  1471-1491 nm stretch ...')

        from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
        wma = WavelengthMappingAlgorithm()

        # Build colour palette (Rainbow Blue->Red, scheme index 0)
        palette = wma.create_rainbow_palette()

        # Run the raster colour mapping
        wom_layer = context.getMapLayer(wom_path)
        if wom_layer is None:
            # Load it directly via GDAL path
            from qgis.core import QgsRasterLayer
            wom_layer = QgsRasterLayer(wom_path, 'wom_temp')

        map_path = wma._run_colour_mapping(
            wom_layer, palette,
            self.MAP_MIN, self.MAP_MAX,
            self.DEPTH_MIN, self.DEPTH_MAX,
            out_map, feedback
        )

        feedback.setProgress(88)
        feedback.pushInfo(f'  Wavelength map saved: {map_path}')

        # ── Step 3: Generate legend (saved to file; dock shown in postProcess) 
        if not legend_path:
            legend_path = os.path.splitext(out_map)[0] + '_legend.png'

        try:
            saved = wma.create_legend(
                legend_path, palette,
                self.MAP_MIN, self.MAP_MAX,
                self.DEPTH_MIN, self.DEPTH_MAX,
                feedback
            )
            if saved:
                self._legend_path = saved
                feedback.pushInfo(f'  Colour legend saved: {saved}')
        except Exception as e:
            feedback.pushWarning(f'Legend generation failed: {e}')

        feedback.setProgress(100)
        feedback.pushInfo('Feature Extraction 1440-1520 nm complete.')

        return {
            self.OUTPUT_WOM:    wom_path,
            self.OUTPUT_MAP:    map_path,
            self.LEGEND_OUTPUT: self._legend_path or '',
        }

    def postProcessAlgorithm(self, context, feedback):
        """Show the legend dock on the main GUI thread."""
        if getattr(self, '_legend_path', None):
            from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
            WavelengthMappingAlgorithm()._show_legend_dock(self._legend_path, feedback)
        return {}

    # ── Identity ──────────────────────────────────────────────────────────────

    def name(self):        return 'fe_wom_1440_1520'
    def displayName(self): return 'FE1 - Wavelength of Minimum 1440-1520 nm'
    def group(self):       return 'F - Feature Extraction'
    def groupId(self):     return 'f_feature_extraction'

    def shortHelpString(self):
        return WORKFLOW_NOTE + BOUNDARY_NOTE + """
        <b>Feature Extraction — Wavelength of Minimum 1440-1520 nm</b>

        <p>A one-click pipeline that:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over the <b>1440-1520 nm</b>
              range (water / hydroxyl combination band).</li>
          <li>Generates a <b>Wavelength Map</b> with a colour stretch of
              <b>1471-1491 nm</b>.</li>
          <li>Displays the <b>colour legend</b> as a floating dock widget.</li>
        </ol>

        <p><b>Spectral context (1440-1520 nm):</b><br/>
        This region encompasses the 1450 nm water-combination absorption and
        hydroxyl overtone features. It is sensitive to the presence of
        hydrated minerals, vegetation water content, and bound water in
        clay minerals.</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Parameter</th><th>Value</th>
          </tr>
          <tr><td>WoM search range</td><td>1440-1520 nm</td></tr>
          <tr><td>Colour stretch min</td><td>1471 nm</td></tr>
          <tr><td>Colour stretch max</td><td>1491 nm</td></tr>
          <tr><td>Colour scheme</td><td>Rainbow (Blue to Red)</td></tr>
        </table>

        <p><b>Outputs:</b></p>
        <ul>
          <li><b>WoM raster</b> - Band 1: wavelength of minimum,
              Band 2: feature depth (plus additional bands if N > 1).</li>
          <li><b>Wavelength Map RGB</b> - colour-coded map ready for
              display in QGIS.</li>
          <li><b>Colour Legend PNG</b> - 2-D legend showing hue vs depth;
              auto-displayed as a floating panel.</li>
        </ul>
        """

    def createInstance(self): return FeWom1440_1520Algorithm()
