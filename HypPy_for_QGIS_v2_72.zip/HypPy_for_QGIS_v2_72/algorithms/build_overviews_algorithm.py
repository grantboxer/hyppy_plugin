"""
Build GDAL Overviews Algorithm for QGIS Processing

Builds external overview pyramids (.ovr) for a large hyperspectral image so
that QGIS can display it quickly at any zoom level without loading the full
file into memory.  The original image and its ENVI .hdr are not modified.

Copyright (C) 2025 Grant Boxer

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import os

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFile,
    QgsProcessingParameterEnum,
    QgsProcessingParameterBoolean,
    QgsProcessingException,
)


# Overview level sets offered to the user
_LEVEL_PRESETS = {
    'Standard  (2 4 8 16 32)':        [2, 4, 8, 16, 32],
    'Extended  (2 4 8 16 32 64 128)': [2, 4, 8, 16, 32, 64, 128],
    'Coarse    (4 16 64)':            [4, 16, 64],
}

# Resampling methods
_RESAMPLE_METHODS = ['average', 'nearest', 'gauss', 'cubic', 'bilinear']


def _build_overviews(input_path, levels, resample, external, feedback=None):
    """Build GDAL overview pyramids.  Returns (success, message, ovr_path)."""

    def log(msg):
        if feedback:
            feedback.pushInfo(msg)
        else:
            print(msg)

    try:
        from osgeo import gdal
        gdal.UseExceptions()
    except ImportError:
        return False, "GDAL is required but not available.", None

    # ── resolve ENVI .hdr → binary data file ────────────────────────────────
    # GDAL's ENVI driver requires the binary file, not the sidecar .hdr.
    # If the user selects the .hdr, find the matching binary automatically.
    if input_path.lower().endswith('.hdr'):
        base = input_path[:-4]  # strip .hdr
        # Common ENVI binary extensions (in priority order)
        candidates = [base, base + '.img', base + '.dat',
                      base + '.bil', base + '.bip', base + '.bsq']
        resolved = None
        for c in candidates:
            if os.path.exists(c):
                resolved = c
                break
        if resolved is None:
            return (False,
                    "Could not find the ENVI binary data file for: %s\n"
                    "Expected one of: %s (no extension), .img, .dat, .bil, .bip, .bsq"
                    % (input_path, base),
                    None)
        log("Resolved .hdr to binary: %s" % resolved)
        input_path = resolved

    # ── open dataset ────────────────────────────────────────────────────────
    log("Opening: %s" % input_path)
    ds = gdal.Open(input_path, gdal.GA_ReadOnly)
    if ds is None:
        return False, "Cannot open input file: %s" % input_path, None

    bands   = ds.RasterCount
    samples = ds.RasterXSize
    lines   = ds.RasterYSize
    log("  %d samples × %d lines × %d bands" % (samples, lines, bands))

    # ── configure external vs internal ─────────────────────────────────────
    if external:
        gdal.SetConfigOption('USE_RRD', 'NO')
        gdal.SetConfigOption('COMPRESS_OVERVIEW', 'DEFLATE')
        # External overviews are written to <binary_file>.ovr
        ovr_path = input_path + '.ovr'
        log("Overview file: %s" % ovr_path)
    else:
        ovr_path = input_path  # internal — same file

    # ── build ───────────────────────────────────────────────────────────────
    log("Resampling method: %s" % resample)
    log("Overview levels:   %s" % ' '.join(str(l) for l in levels))
    log("Building overviews — this may take several minutes for large files...")

    class _ProgressCB:
        def __init__(self, fb):
            self._fb = fb
            self._last = -1
        def __call__(self, complete, message, data):
            pct = int(complete * 100)
            if self._fb and pct != self._last:
                self._fb.setProgress(pct)
                self._last = pct
            return 1  # non-zero = continue

    cb = _ProgressCB(feedback)
    err = ds.BuildOverviews(resample, levels, callback=cb)
    ds = None  # close

    if err != gdal.CE_None:
        return False, "GDAL BuildOverviews failed (error code %d)" % err, None

    if external and not os.path.exists(ovr_path):
        return False, "Overview file was not created: %s" % ovr_path, None

    size_mb = os.path.getsize(ovr_path) / 1024 / 1024 if os.path.exists(ovr_path) else 0
    log("Overview file size: %.1f MB" % size_mb)
    log("Done.  Open the original .hdr in QGIS — overviews will be used automatically.")
    return True, "Overviews built successfully.", ovr_path


# ── QGIS Algorithm wrapper ─────────────────────────────────────────────────

class BuildOverviewsAlgorithm(QgsProcessingAlgorithm):
    """Build GDAL overview pyramids for fast QGIS display of large images."""

    INPUT    = 'INPUT'
    LEVELS   = 'LEVELS'
    RESAMPLE = 'RESAMPLE'
    EXTERNAL = 'EXTERNAL'

    _level_labels   = list(_LEVEL_PRESETS.keys())
    _resample_labels = _RESAMPLE_METHODS

    def __init__(self):
        super().__init__()
        self._resolved_path = None   # set in processAlgorithm, used in postProcess

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFile(
                self.INPUT,
                'Input Hyperspectral Image (.hdr or binary data file)',
                behavior=QgsProcessingParameterFile.File,
                fileFilter='ENVI / Raster Files (*.hdr *.img *.dat *.bil *.bip *.bsq *.tif *.tiff);;All Files (*)',
                optional=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.LEVELS,
                'Overview Levels',
                options=self._level_labels,
                defaultValue=0,
                optional=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.RESAMPLE,
                'Resampling Method',
                options=self._resample_labels,
                defaultValue=0,   # average
                optional=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.EXTERNAL,
                'Write external overviews (.ovr sidecar — recommended)',
                defaultValue=True,
                optional=False,
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        input_path = self.parameterAsFile(parameters, self.INPUT, context)
        level_idx  = self.parameterAsEnum(parameters, self.LEVELS,   context)
        resamp_idx = self.parameterAsEnum(parameters, self.RESAMPLE, context)
        external   = self.parameterAsBool(parameters, self.EXTERNAL, context)

        levels  = list(_LEVEL_PRESETS.values())[level_idx]
        resample = self._resample_labels[resamp_idx]

        feedback.pushInfo("=== Build GDAL Overviews ===")
        ok, msg, ovr_path = _build_overviews(
            input_path, levels, resample, external, feedback=feedback
        )
        if not ok:
            raise QgsProcessingException(msg)

        # Store resolved binary path for postProcessAlgorithm
        # ovr_path is '<binary>.ovr', so strip the extension to get the binary
        if ovr_path and ovr_path.endswith('.ovr'):
            self._resolved_path = ovr_path[:-4]
        else:
            self._resolved_path = input_path

        return {}

    def postProcessAlgorithm(self, context, feedback):
        """Load the image into the QGIS map canvas with -9999 set transparent.
        Runs on the main GUI thread after processAlgorithm completes."""
        try:
            from qgis.core  import (QgsRasterLayer, QgsProject,
                                     QgsRasterTransparency)
            from qgis.utils import iface

            if iface is None or not self._resolved_path:
                return {}

            load_path  = self._resolved_path
            layer_name = os.path.splitext(os.path.basename(load_path))[0]

            feedback.pushInfo("Loading into map canvas: %s" % layer_name)
            layer = QgsRasterLayer(load_path, layer_name)

            if not layer.isValid():
                feedback.pushWarning(
                    "Layer not valid, cannot load: %s" % load_path)
                return {}

            # ── set -9999 transparent on all bands ───────────────────────────
            n_bands  = layer.dataProvider().bandCount()
            renderer = layer.renderer()

            nodata_entries = []
            for _b in range(n_bands):
                entry = QgsRasterTransparency.TransparentSingleValuePixel()
                entry.min                = -9999.0
                entry.max                = -9999.0
                entry.percentTransparent = 100.0
                nodata_entries.append(entry)

            trans = QgsRasterTransparency()
            trans.setTransparentSingleValuePixelList(nodata_entries)
            renderer.setRasterTransparency(trans)
            feedback.pushInfo(
                "Set -9999 transparent across %d band(s)." % n_bands)

            # ── add to map ───────────────────────────────────────────────────
            QgsProject.instance().addMapLayer(layer)
            iface.mapCanvas().setExtent(layer.extent())
            iface.mapCanvas().refresh()
            feedback.pushInfo("Layer added to map canvas.")

        except Exception as e:
            feedback.pushWarning("Could not load layer into QGIS: %s" % str(e))

        return {}

    # ── Metadata ─────────────────────────────────────────────────────────────

    def name(self):
        return 'build_overviews'

    def displayName(self):
        return 'D01 - Build Overviews (Fast Display)'

    def group(self):
        return '2 - Data Import'

    def groupId(self):
        return '2_data_import'

    def shortHelpString(self):
        return (
            "<h3>G05 — Build Overviews (Fast Display)</h3>"
            "<p>Builds GDAL overview pyramids so that QGIS can display large "
            "hyperspectral images quickly at any zoom level without loading the "
            "entire file into memory. The image is automatically loaded into the "
            "map canvas on completion, with <b>-9999 values set to transparent</b>.</p>"
            "<p><b>How it works:</b> A small <tt>.ovr</tt> sidecar file is written "
            "alongside the original image containing pre-computed lower-resolution "
            "versions (pyramids). QGIS automatically selects the appropriate "
            "resolution level based on the current zoom, so only a fraction of the "
            "data is ever read for display.</p>"
            "<p><b>Wavelength metadata is fully preserved</b> — the original image "
            "and its ENVI <tt>.hdr</tt> are never modified. All HypPy algorithms "
            "will work on the original file exactly as before.</p>"
            "<p><b>Parameters:</b></p>"
            "<ul>"
            "<li><b>Overview Levels</b> — Standard (2–32) suits most images. "
            "Use Extended (2–128) for very large images (&gt;10 GB) or when "
            "viewing at small scales over large areas.</li>"
            "<li><b>Resampling Method</b> — <i>average</i> gives the best visual "
            "quality for continuous data such as reflectance. <i>nearest</i> is "
            "fastest to build and appropriate for classified outputs.</li>"
            "<li><b>External overviews</b> — Recommended. Writes a <tt>.ovr</tt> "
            "sidecar alongside the image so the original file is never modified. "
            "Uncheck only for GeoTIFF files where internal overviews are preferred.</li>"
            "</ul>"
            "<p><b>Tip:</b> Building overviews on a 7 GB AVIRIS file takes a few "
            "minutes but only needs to be done once. The <tt>.ovr</tt> file must "
            "remain in the same folder as the image. You can select either the "
            "<tt>.hdr</tt> or the binary data file — both are accepted.</p>"
        )

    def createInstance(self):
        return BuildOverviewsAlgorithm()
