"""
Feature Extraction — Run All (FE01–FE18)

Runs all eighteen Feature Extraction pipelines in a single step.
Each pipeline produces a WoM raster, a Wavelength Map RGB, and a
colour legend PNG.  All outputs are written to a single user-chosen
output directory, prefixed with the user-supplied prefix string.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

import os
import processing

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterString,
    QgsProcessingParameterFolderDestination,
    QgsRasterLayer,
    QgsProject,
)


WORKFLOW_NOTE = """\
        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube with wavelength metadata.<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.
        </p>
"""

AVIRIS_NOTE = """\
        <p style="background-color:#fff3e0; padding:6px; border-left:4px solid #e65100;">
        <b>AVIRIS-NG users:</b> FE01, FE02, FE03 (1340–1445 nm bad zone) and
        FE07 (1790–1960 nm bad zone) will produce no valid output on AVIRIS-NG data
        when BBL masking is active. Their output files will be written but will contain
        only NaN / fill values. FE04 and FE-WOM-1440 may lose the first few bands
        (1440–1445 nm). All other tools (FE05–FE06, FE08–FE18) are unaffected.
        </p>
"""

# Master table of all 18 FE definitions
# (label, wom_alg_id, wom_start, wom_end, map_min, map_max, depth_min, depth_max)
_FE_DEFS = [
    ('FE01_1384D', 'hyppy:fe_1384d',  1350.0, 1450.0, 1375.0, 1425.0, 0.0, 0.15),
    ('FE02_1396W', 'hyppy:fe_1396w',  1350.0, 1450.0, 1385.0, 1410.0, 0.0, 0.15),
    ('FE03_1400D', 'hyppy:fe_1400d',  1350.0, 1450.0, 1387.0, 1445.0, 0.0, 0.15),
    ('FE04_1480W', 'hyppy:fe_1480w',  1440.0, 1520.0, 1471.0, 1491.0, 0.0, 0.2),
    ('FE05_1550W', 'hyppy:fe_1550w',  1510.0, 1610.0, 1520.0, 1563.0, 0.0, 0.2),
    ('FE06_1760W', 'hyppy:fe_1760w',  1730.0, 1790.0, 1751.0, 1764.0, 0.0, 0.2),
    ('FE07_1900W', 'hyppy:fe_1900w',  1850.0, 1960.0, 1870.0, 1940.0, 0.0, 0.35),
    ('FE08_2066D', 'hyppy:fe_2066d',  2050.0, 2110.0, 2055.0, 2095.0, 0.0, 0.2),
    ('FE09_2080D', 'hyppy:fe_2080d',  2060.0, 2100.0, 2075.0, 2090.0, 0.0, 0.2),
    ('FE10_2160D', 'hyppy:fe_2160d',  2138.0, 2179.0, 2159.0, 2166.0, 0.0, 0.2),
    ('FE11_2178D', 'hyppy:fe_2178d',  2138.0, 2210.0, 2162.0, 2196.0, 0.0, 0.2),
    ('FE12_2200W', 'hyppy:fe_2200w',  2120.0, 2245.0, 2185.0, 2215.0, 0.0, 0.2),
    ('FE13_2206W', 'hyppy:fe_2206w',  2120.0, 2245.0, 2197.0, 2215.0, 0.0, 0.2),
    ('FE14_2250W', 'hyppy:fe_2250w',  2230.0, 2280.0, 2248.0, 2268.0, 0.0, 0.2),
    ('FE15_2290W', 'hyppy:fe_2290w',  2270.0, 2320.0, 2279.0, 2338.0, 0.0, 0.2),
    ('FE16_2320W', 'hyppy:fe_2320w',  2295.0, 2345.0, 2300.0, 2340.0, 0.0, 0.2),
    ('FE17_2350W', 'hyppy:fe_2350w',  2310.0, 2370.0, 2320.0, 2366.0, 0.0, 0.2),
    ('FE18_2390W', 'hyppy:fe_2390w',  2375.0, 2435.0, 2377.0, 2406.0, 0.0, 0.2),
]


class FeAllAlgorithm(QgsProcessingAlgorithm):
    """Run all eighteen Feature Extraction pipelines in one step."""

    INPUT      = 'INPUT'
    NUM_FEATURES = 'NUM_FEATURES'
    OUTPUT_DIR = 'OUTPUT_DIR'
    PREFIX     = 'PREFIX'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, 'Hyperspectral cube'))

        self.addParameter(QgsProcessingParameterNumber(
            self.NUM_FEATURES,
            'Number of features to extract per band (1-9)',
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=1, minValue=1, maxValue=9))

        self.addParameter(QgsProcessingParameterFolderDestination(
            self.OUTPUT_DIR,
            'Output folder for all results'))

        self.addParameter(QgsProcessingParameterString(
            self.PREFIX,
            'Output filename prefix  (e.g. scene name)',
            defaultValue='fe_all',
            optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        cube    = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        n       = self.parameterAsInt(parameters, self.NUM_FEATURES, context)
        out_dir = self.parameterAsString(parameters, self.OUTPUT_DIR, context)
        prefix  = self.parameterAsString(parameters, self.PREFIX, context).strip()
        if not prefix:
            prefix = 'fe_all'

        os.makedirs(out_dir, exist_ok=True)

        total   = len(_FE_DEFS)
        results = {}
        self._legend_paths = []
        self._layers_to_load = []   # list of (path, layer_name) to load on completion

        from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
        wma     = WavelengthMappingAlgorithm()
        palette = wma.create_rainbow_palette()

        feedback.pushWarning(
            'AVIRIS-NG users: FE01/FE02/FE03 (1340-1445 nm) and FE07 (1790-1960 nm) '
            'fall within AVIRIS-NG atmospheric water bad band zones. Those outputs will '
            'contain only NaN/fill values. FE04 may lose the first few bands (1440-1445 nm). '
            'All other tools are unaffected.'
        )

        for idx, (label, alg_id,
                  wom_start, wom_end,
                  map_min, map_max,
                  depth_min, depth_max) in enumerate(_FE_DEFS):

            if feedback.isCanceled():
                return results

            pct_start = int(idx / total * 100)
            pct_end   = int((idx + 1) / total * 100)
            feedback.setProgress(pct_start)
            feedback.pushInfo(
                f'[{idx+1}/{total}]  {label}  '
                f'WoM {wom_start:.0f}-{wom_end:.0f} nm ...'
            )

            # ── Step A: Wavelength of Minimum ────────────────────────────────
            wom_path = os.path.join(out_dir, f'{prefix}_{label}_wom.tif')
            wom_result = processing.run(
                'hyppy:wavelength_of_minimum',
                {
                    'INPUT':            cube,
                    'START_WAVELENGTH': wom_start,
                    'END_WAVELENGTH':   wom_end,
                    'MODE':             0,
                    'NUM_FEATURES':     n,
                    'BROAD':            False,
                    'USE_BBL':          True,
                    'OUTPUT':           wom_path,
                },
                context=context,
                feedback=feedback,
                is_child_algorithm=True,
            )
            if feedback.isCanceled():
                return results

            wom_path = wom_result['OUTPUT']
            feedback.pushInfo(f'    WoM saved: {wom_path}')

            # ── Step B: Wavelength Map ────────────────────────────────────────
            feedback.setProgress(pct_start + (pct_end - pct_start) // 2)
            map_path = os.path.join(out_dir, f'{prefix}_{label}_map.tif')
            map_path = wma._run_colour_mapping(
                wom_path, palette,
                map_min, map_max,
                depth_min, depth_max,
                map_path, feedback,
            )
            feedback.pushInfo(f'    Map saved: {map_path}')

            # ── Step C: Colour Legend ─────────────────────────────────────────
            legend_path = os.path.join(out_dir, f'{prefix}_{label}_legend.png')
            try:
                saved = wma.create_legend(
                    legend_path, palette,
                    map_min, map_max,
                    depth_min, depth_max,
                    feedback,
                )
                if saved:
                    self._legend_paths.append(saved)
                    feedback.pushInfo(f'    Legend saved: {saved}')
            except Exception as e:
                feedback.pushWarning(f'    Legend generation failed for {label}: {e}')

            # Register both rasters for loading into the QGIS canvas
            self._layers_to_load.append((map_path, f'{label} map'))
            self._layers_to_load.append((wom_path, f'{label} WoM'))

            results[f'{label}_WOM'] = wom_path
            results[f'{label}_MAP'] = map_path

        feedback.setProgress(100)
        feedback.pushInfo(
            f'Feature Extraction All complete — '
            f'{total} pipelines written to: {out_dir}'
        )
        return results

    def postProcessAlgorithm(self, context, feedback):
        """Load all WoM and map rasters into the QGIS canvas, then show legend."""
        try:
            for path, name in getattr(self, '_layers_to_load', []):
                layer = QgsRasterLayer(path, name)
                if layer.isValid():
                    QgsProject.instance().addMapLayer(layer)
                else:
                    feedback.pushWarning(f'Could not load layer: {path}')
        except Exception as e:
            feedback.pushWarning(f'Layer loading error: {e}')

        # Show the last legend as a floating dock
        paths = getattr(self, '_legend_paths', [])
        if paths:
            from .wavelength_mapping_algorithm import WavelengthMappingAlgorithm
            WavelengthMappingAlgorithm()._show_legend_dock(paths[-1], feedback)
        return {}

    # ── Metadata ──────────────────────────────────────────────────────────────
    def name(self):        return 'fe_all'
    def displayName(self): return 'FE00 - Run All Feature Extractions (FE01-FE18)'
    def group(self):       return '7 - Feature Extraction'
    def groupId(self):     return 'six_feature_extraction'

    def shortHelpString(self):
        rows = ''.join(
            f'<tr><td>{label}</td>'
            f'<td>{wom_start:.0f}–{wom_end:.0f} nm</td>'
            f'<td>{map_min:.0f}–{map_max:.0f} nm</td></tr>\n'
            for label, _, wom_start, wom_end, map_min, map_max, _, _ in _FE_DEFS
        )
        return WORKFLOW_NOTE + AVIRIS_NOTE + f"""
        <b>Feature Extraction — Run All (FE01–FE18)</b>

        <p>Runs all eighteen Feature Extraction pipelines in a single step.
        For each pipeline the tool:</p>
        <ol>
          <li>Runs <b>Wavelength of Minimum</b> over the pipeline's search range.</li>
          <li>Generates a <b>Wavelength Map RGB</b> with the pipeline's colour stretch.</li>
          <li>Saves a <b>colour legend PNG</b> alongside the map.</li>
        </ol>

        <p>All 54 output files (18 × WoM + 18 × Map + 18 × Legend) are written
        to the chosen <b>Output folder</b>, named
        <code>&lt;prefix&gt;_&lt;FE label&gt;_wom.tif</code>,
        <code>..._map.tif</code>, and <code>..._legend.png</code>.</p>

        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Pipeline</th><th>WoM search range</th><th>Colour stretch</th>
          </tr>
          {rows}
        </table>

        <p><b>Outputs:</b></p>
        <ul>
          <li>One WoM raster per pipeline (Band 1: wavelength of minimum,
              Band 2: feature depth).</li>
          <li>One Wavelength Map RGB per pipeline.</li>
          <li>One colour legend PNG per pipeline.</li>
        </ul>
        """

    def createInstance(self): return FeAllAlgorithm()
