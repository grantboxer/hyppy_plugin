"""
ENVI Header Sidecar Reader
===========================
Reads wavelength, BBL, FWHM and other fields directly from an ENVI .hdr
sidecar file.

This is necessary because gdal.Open('image.tif') opens the file as GeoTIFF
and never reads a companion .hdr — GDAL only parses the .hdr when it opens
the file as ENVI format.  All Hyppy algorithms that accept a GeoTIFF produced
by a previous step (e.g. the Log Residuals output) call these helpers so they
can find the wavelength list even when GDAL's metadata dictionaries are empty.

The lookup order used by get_wavelengths_from_dataset() is:
  1. GDAL 'ENVI' metadata domain  (works for files opened as ENVI format)
  2. GDAL default '' metadata domain
  3. Sidecar .hdr file next to the raster path
  4. Band descriptions (numeric wavelength values stored per-band)

Copyright (C) 2025 Grant Boxer.  GPL v3 or later.
"""

import os
import re
import numpy as np


# ── Sidecar .hdr path resolution ─────────────────────────────────────────────

def find_hdr(raster_path):
    """
    Return the path of the ENVI .hdr sidecar for *raster_path*, or None.

    Checks (in order):
      file.tif.hdr   — ENVI sidecar alongside a GeoTIFF
      file.hdr       — ENVI sidecar with the extension replaced
    """
    for candidate in (raster_path + '.hdr',
                      os.path.splitext(raster_path)[0] + '.hdr'):
        if os.path.isfile(candidate):
            return candidate
    return None


# ── Raw .hdr parser ───────────────────────────────────────────────────────────

def parse_hdr(hdr_path):
    """
    Parse an ENVI .hdr file and return a dict of all key→value pairs.

    Multi-line brace-delimited lists (wavelength, bbl, fwhm, band names …)
    are returned as raw strings including the braces so callers can strip
    and split them as needed.
    """
    with open(hdr_path, 'r', errors='replace') as f:
        content = f.read()

    result = {}

    # ── Multi-line brace-delimited fields ────────────────────────────────
    # Match:  key = { … }   (the value may span multiple lines)
    for m in re.finditer(r'(\w[\w ]*?)\s*=\s*(\{[^}]*\})', content, re.DOTALL):
        key = m.group(1).strip().lower()
        result[key] = m.group(2).strip()

    # ── Simple key = value pairs ─────────────────────────────────────────
    # Only add if not already captured by the brace pattern above
    for m in re.finditer(r'^([\w][\w ]*?)\s*=\s*(.+)$', content, re.MULTILINE):
        key = m.group(1).strip().lower()
        if key not in result:
            result[key] = m.group(2).strip()

    return result


# ── Field extractors ──────────────────────────────────────────────────────────

def _parse_numeric_list(raw, dtype=float):
    """Strip braces and split a comma-separated list to a numpy array."""
    cleaned = raw.strip('{}').strip()
    try:
        return np.array([dtype(v.strip()) for v in cleaned.split(',') if v.strip()])
    except ValueError:
        return None


def wavelengths_from_hdr(hdr_path):
    """
    Return a numpy float64 array of wavelengths from *hdr_path*, or None.
    """
    hdr = parse_hdr(hdr_path)
    for key in ('wavelength', 'wavelengths'):
        if key in hdr:
            arr = _parse_numeric_list(hdr[key], float)
            if arr is not None and len(arr) > 0:
                return arr.astype(np.float64)
    return None


def bbl_from_hdr(hdr_path, n_bands=None):
    """
    Return a boolean numpy array (True = good band) from *hdr_path*, or None.
    """
    hdr = parse_hdr(hdr_path)
    for key in ('bbl', 'bad band list', 'bad_band_multiplier'):
        if key in hdr:
            arr = _parse_numeric_list(hdr[key], float)
            if arr is not None and len(arr) > 0:
                if n_bands is None or len(arr) >= n_bands:
                    result = arr[:n_bands].astype(bool) if n_bands else arr.astype(bool)
                    return result
    return None


def fwhm_from_hdr(hdr_path):
    """Return fwhm array from *hdr_path*, or None."""
    hdr = parse_hdr(hdr_path)
    if 'fwhm' in hdr:
        arr = _parse_numeric_list(hdr['fwhm'], float)
        if arr is not None and len(arr) > 0:
            return arr.astype(np.float64)
    return None


def wavelength_units_from_hdr(hdr_path):
    """Return wavelength units string from *hdr_path*, or None."""
    hdr = parse_hdr(hdr_path)
    return hdr.get('wavelength units') or hdr.get('wavelength_units')


# ── Unit normalisation ────────────────────────────────────────────────────────

def _to_nm(arr, units_str):
    """
    Convert *arr* (numpy float64) to nanometres if necessary.

    Conversion rules (applied in order):
      1. Explicit units string — 'Micrometers' / 'Microns' / 'um'  → × 1000
                                 'Wavenumber'  / 'cm-1'            → 10 000 000 / arr
                                 'Nanometers'  / 'nm' / None       → no change
      2. Heuristic fallback when units_str is None or unrecognised:
           all values < 100  → assume µm → × 1000
           all values > 100  → assume nm → no change

    Returns a new numpy float64 array.
    """
    arr = np.array(arr, dtype=np.float64)
    if units_str is not None:
        u = units_str.strip().lower()
        if u in ('micrometers', 'microns', 'micrometres', 'um', 'μm'):
            return arr * 1000.0
        if u in ('wavenumber', 'wavenumbers', 'cm-1', 'cm^-1'):
            with np.errstate(divide='ignore', invalid='ignore'):
                return np.where(arr != 0, 1e7 / arr, np.nan)
        # 'nanometers', 'nm', or anything else — treat as nm
        return arr

    # Heuristic: if all finite values are below 100, assume µm
    finite = arr[np.isfinite(arr)]
    if len(finite) > 0 and np.all(finite < 100.0):
        return arr * 1000.0
    return arr


# ── Main convenience function used by all algorithms ─────────────────────────

def get_wavelengths_from_dataset(dataset, num_bands, raster_path=None, feedback=None):
    """
    Extract a wavelength array using a four-source lookup cascade.

    Parameters
    ----------
    dataset      : gdal.Dataset — already-opened raster
    num_bands    : int — expected number of bands
    raster_path  : str or None — filesystem path to the raster file;
                   required for sidecar .hdr lookup
    feedback     : QgsProcessingFeedback or None

    Returns
    -------
    numpy float64 array of length num_bands, or None if not found.
    """
    def log(msg):
        if feedback:
            feedback.pushInfo(msg)

    # 1. GDAL 'ENVI' metadata domain
    meta = dataset.GetMetadata('ENVI') or {}
    units = meta.get('wavelength units') or meta.get('wavelength_units')
    for key in ('wavelength', 'Wavelength', 'WAVELENGTH'):
        if key in meta:
            raw = meta[key].strip('{}').strip()
            try:
                arr = np.array([float(v.strip()) for v in raw.split(',') if v.strip()])
                if len(arr) == num_bands:
                    log(f'Wavelengths found in GDAL ENVI metadata domain ({num_bands} bands)')
                    return _to_nm(arr, units)
            except ValueError:
                pass

    # 2. GDAL default '' metadata domain
    meta = dataset.GetMetadata('') or {}
    units = meta.get('wavelength units') or meta.get('wavelength_units')
    for key in ('wavelength', 'Wavelength', 'WAVELENGTH'):
        if key in meta:
            raw = meta[key].strip('{}').strip()
            try:
                arr = np.array([float(v.strip()) for v in raw.split(',') if v.strip()])
                if len(arr) == num_bands:
                    log(f'Wavelengths found in GDAL default metadata domain ({num_bands} bands)')
                    return _to_nm(arr, units)
            except ValueError:
                pass

    # 3. Sidecar .hdr file
    if raster_path:
        hdr_path = find_hdr(raster_path)
        if hdr_path:
            arr = wavelengths_from_hdr(hdr_path)
            if arr is not None:
                if len(arr) == num_bands:
                    units = wavelength_units_from_hdr(hdr_path)
                    log(f'Wavelengths read from sidecar .hdr: {hdr_path} ({num_bands} bands)')
                    return _to_nm(arr, units)
                else:
                    log(f'Sidecar .hdr found ({hdr_path}) but band count mismatch '
                        f'({len(arr)} in hdr vs {num_bands} in raster) — skipping')
        else:
            log(f'No sidecar .hdr found alongside: {raster_path}')

    # 4. Band descriptions (numeric wavelength values stored per-band)
    wavs = []
    for b in range(num_bands):
        desc = dataset.GetRasterBand(b + 1).GetDescription()
        try:
            wavs.append(float(desc))
        except (ValueError, TypeError):
            wavs.append(None)
    if None not in wavs:
        log(f'Wavelengths read from band descriptions ({num_bands} bands)')
        return _to_nm(np.array(wavs, dtype=np.float64), None)

    if feedback:
        feedback.reportError(
            'No wavelength information found. Checked: ENVI metadata, default metadata, '
            'sidecar .hdr, band descriptions.'
        )
    return None


def get_bbl_from_dataset(dataset, num_bands, raster_path=None, feedback=None):
    """
    Extract a Bad Band List using a two-source lookup cascade.

    Returns a boolean numpy array (True = good band) or None.
    """
    def log(msg):
        if feedback:
            feedback.pushInfo(msg)

    # 1. GDAL metadata domains
    for domain in ('ENVI', ''):
        meta = dataset.GetMetadata(domain) or {}
        for key in ('bbl', 'BBL', 'bad band list', 'bad_band_multiplier'):
            if key in meta:
                raw = meta[key].strip('{}').strip()
                try:
                    arr = np.array([int(float(v.strip())) for v in raw.split(',') if v.strip()])
                    if len(arr) >= num_bands:
                        log(f'BBL found in GDAL {domain or "default"} metadata domain')
                        return arr[:num_bands].astype(bool)
                except ValueError:
                    pass

    # 2. Sidecar .hdr
    if raster_path:
        hdr_path = find_hdr(raster_path)
        if hdr_path:
            arr = bbl_from_hdr(hdr_path, num_bands)
            if arr is not None:
                log(f'BBL read from sidecar .hdr: {hdr_path}')
                return arr

    # 3. Sensor-aware fallback — synthesise a BBL when none is present in metadata.
    #
    # If the wavelength array is available we can recognise known airborne sensors
    # by their spectral range and band count, and apply the standard bad-band
    # regions for that sensor.  This protects downstream algorithms when a user
    # loads an AVIRIS-NG GeoTIFF that has been stripped of its .hdr sidecar.
    #
    # Sensors currently handled:
    #   AVIRIS-NG  (~365–2510 nm, ~432 bands)
    #     bad bands: 1340–1445 nm (atmospheric H₂O), 1790–1960 nm (atmospheric H₂O)
    #
    # The function re-uses the wavelengths already found by get_wavelengths_from_dataset
    # via a lightweight call to the GDAL/hdr lookup (no I/O beyond what was already done).
    wavelengths = get_wavelengths_from_dataset(dataset, num_bands, raster_path, feedback=None)
    if wavelengths is not None:
        bbl_synth = _synthesise_bbl(wavelengths, num_bands, feedback)
        if bbl_synth is not None:
            return bbl_synth

    return None


# ── Sensor-aware BBL synthesis ────────────────────────────────────────────────

# Known bad-band regions per sensor, keyed by a (min_wav_nm, max_wav_nm, approx_bands)
# fingerprint.  Each entry is a list of (bad_start_nm, bad_end_nm) inclusive ranges.
_SENSOR_BAD_BANDS = [
    # AVIRIS-NG: 365–2510 nm, ~432 bands
    # Bad band zones: 1340–1445 nm, 1790–1960 nm
    {
        'name':      'AVIRIS-NG',
        'wav_min':   340.0,
        'wav_max':   2530.0,
        'bands_min': 400,
        'bands_max': 480,
        'bad_zones': [(1340.0, 1445.0), (1790.0, 1960.0)],
    },
    # AVIRIS classic: 400–2500 nm, 224 bands
    # Bad band zones: 1340–1445 nm, 1790–1960 nm
    {
        'name':      'AVIRIS Classic',
        'wav_min':   380.0,
        'wav_max':   2520.0,
        'bands_min': 210,
        'bands_max': 240,
        'bad_zones': [(1340.0, 1445.0), (1790.0, 1960.0)],
    },
]


def _synthesise_bbl(wavelengths, num_bands, feedback=None):
    """
    Attempt to synthesise a BBL for a known sensor fingerprint.

    Returns a boolean numpy array (True = good band) if the sensor is
    recognised, or None if it cannot be identified.
    """
    def log(msg):
        if feedback:
            feedback.pushInfo(msg)

    if wavelengths is None or len(wavelengths) != num_bands:
        return None

    wav_min = float(np.nanmin(wavelengths))
    wav_max = float(np.nanmax(wavelengths))

    for sensor in _SENSOR_BAD_BANDS:
        if (sensor['wav_min'] <= wav_min <= sensor['wav_min'] + 80 and
                sensor['wav_max'] - 80 <= wav_max <= sensor['wav_max'] and
                sensor['bands_min'] <= num_bands <= sensor['bands_max']):
            # Build the BBL: start with all good, then mask bad zones
            bbl = np.ones(num_bands, dtype=bool)
            for bad_start, bad_end in sensor['bad_zones']:
                mask = (wavelengths >= bad_start) & (wavelengths <= bad_end)
                bbl[mask] = False
            good = int(np.sum(bbl))
            bad  = num_bands - good
            log(
                f"BBL synthesised for {sensor['name']} "
                f"(no BBL in metadata): {good} good, {bad} bad bands masked "
                f"({', '.join(f'{s:.0f}–{e:.0f} nm' for s, e in sensor['bad_zones'])})"
            )
            return bbl

    return None
