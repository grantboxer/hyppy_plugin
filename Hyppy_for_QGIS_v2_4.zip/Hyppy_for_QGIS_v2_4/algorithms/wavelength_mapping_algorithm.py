"""
Wavelength Mapping Algorithm for QGIS Processing

Creates RGB color-coded maps of absorption feature wavelength and depth.

Ported from HyPy wavemap.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original Copyright (C) 2010-2022 Wim Bakker

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import numpy as np
import colorsys
import math
import os
from osgeo import gdal

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterEnum,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingException,
)


class WavelengthMappingAlgorithm(QgsProcessingAlgorithm):
    """
    Wavelength Mapping Algorithm
    
    Creates color-coded RGB maps from wavelength-of-minimum outputs.
    Uses HSV color space where:
    - Hue represents wavelength position
    - Value (brightness) represents feature depth
    
    This creates intuitive visualizations where different absorption 
    features are shown in different colors, with brightness indicating 
    feature strength.
    """

    INPUT = 'INPUT'
    WAVELENGTH_MIN = 'WAVELENGTH_MIN'
    WAVELENGTH_MAX = 'WAVELENGTH_MAX'
    DEPTH_MIN = 'DEPTH_MIN'
    DEPTH_MAX = 'DEPTH_MAX'
    COLOR_SCHEME = 'COLOR_SCHEME'
    OUTPUT = 'OUTPUT'
    LEGEND_OUTPUT = 'LEGEND_OUTPUT'

    def initAlgorithm(self, config=None):
        """Define inputs and outputs."""
        
        # Input must be output from Wavelength of Minimum
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT,
                'Input Wavelength Features (from Wavelength of Minimum)',
                optional=False
            )
        )
        
        # Wavelength stretch range
        self.addParameter(
            QgsProcessingParameterNumber(
                self.WAVELENGTH_MIN,
                'Minimum Wavelength for Display (nm)',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=2100.0,
                optional=False
            )
        )
        
        self.addParameter(
            QgsProcessingParameterNumber(
                self.WAVELENGTH_MAX,
                'Maximum Wavelength for Display (nm)',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=2350.0,
                optional=False
            )
        )
        
        # Depth stretch range
        self.addParameter(
            QgsProcessingParameterNumber(
                self.DEPTH_MIN,
                'Minimum Depth for Display',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=0.0,
                minValue=0.0,
                maxValue=1.0,
                optional=False
            )
        )
        
        self.addParameter(
            QgsProcessingParameterNumber(
                self.DEPTH_MAX,
                'Maximum Depth for Display',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=0.2,
                minValue=0.0,
                maxValue=1.0,
                optional=False
            )
        )
        
        # Color scheme
        self.addParameter(
            QgsProcessingParameterEnum(
                self.COLOR_SCHEME,
                'Color Scheme',
                options=[
                    'Rainbow (Blue → Red)',
                    'Rainbow with Steps'
                ],
                defaultValue=0,
                optional=False
            )
        )
        
        # Output RGB image
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                'Output Wavelength Map (RGB)',
                optional=False
            )
        )

        # Output legend PNG
        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.LEGEND_OUTPUT,
                'Output Wavelength Map Legend (PNG)',
                fileFilter='PNG Files (*.png)',
                optional=False
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """Execute the algorithm."""
        
        # Get parameters
        input_layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        wav_min = self.parameterAsDouble(parameters, self.WAVELENGTH_MIN, context)
        wav_max = self.parameterAsDouble(parameters, self.WAVELENGTH_MAX, context)
        depth_min = self.parameterAsDouble(parameters, self.DEPTH_MIN, context)
        depth_max = self.parameterAsDouble(parameters, self.DEPTH_MAX, context)
        color_scheme = self.parameterAsEnum(parameters, self.COLOR_SCHEME, context)
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        legend_output_path = self.parameterAsFileOutput(parameters, self.LEGEND_OUTPUT, context)
        
        feedback.pushInfo(f'Wavelength range: {wav_min} - {wav_max} nm')
        feedback.pushInfo(f'Depth range: {depth_min} - {depth_max}')
        
        # Open input
        input_ds = gdal.Open(input_layer.source(), gdal.GA_ReadOnly)
        if input_ds is None:
            raise QgsProcessingException('Failed to open input raster')
        
        cols = input_ds.RasterXSize
        rows = input_ds.RasterYSize
        num_bands = input_ds.RasterCount
        
        # Use bands 1 and 2 directly from Wavelength of Minimum output
        # Band 1 = interpolated minimum wavelength (deepest feature)
        # Band 2 = interpolated depth (deepest feature)
        if num_bands < 2:
            raise QgsProcessingException(
                'Input must have at least 2 bands. '
                'Expected output from Wavelength of Minimum tool '
                '(Band 1 = wavelength, Band 2 = depth).'
            )
        
        wav_band_idx = 0   # Band 1: interpolated min. wavelength
        depth_band_idx = 1  # Band 2: interpolated depth
        
        feedback.pushInfo(f'Using band {wav_band_idx+1} for wavelength')
        feedback.pushInfo(f'Using band {depth_band_idx+1} for depth')
        
        # Read wavelength and depth bands
        feedback.pushInfo('Reading input bands...')
        wav_data = input_ds.GetRasterBand(wav_band_idx + 1).ReadAsArray()
        depth_data = input_ds.GetRasterBand(depth_band_idx + 1).ReadAsArray()
        
        # Create color palette
        if color_scheme == 0:
            palette = self.create_rainbow_palette()
            feedback.pushInfo('Using rainbow color scheme')
        else:
            palette = self.create_stepped_palette()
            feedback.pushInfo('Using stepped rainbow color scheme')
        
        # Stretch wavelength to 0-255 range
        feedback.pushInfo('Creating wavelength map...')
        wav_stretched = self.stretch_band(wav_data, wav_min, wav_max)
        
        # Stretch depth to 0-255 range
        depth_stretched = self.stretch_band(depth_data, depth_min, depth_max)
        
        # Create RGB output
        rgb_data = np.zeros((rows, cols, 3), dtype=np.uint8)
        
        total_pixels = rows * cols
        processed = 0
        
        for row in range(rows):
            if feedback.isCanceled():
                return {}
            
            for col in range(cols):
                if np.isnan(wav_data[row, col]) or np.isnan(depth_data[row, col]):
                    # Set to black for NaN
                    rgb_data[row, col, :] = [0, 0, 0]
                elif depth_data[row, col] == 0:
                    # Set to black for zero depth
                    rgb_data[row, col, :] = [0, 0, 0]
                else:
                    # Get color from palette based on wavelength
                    wav_idx = int(wav_stretched[row, col])
                    r, g, b = palette[wav_idx]
                    
                    # Convert to HSV
                    h, s, v = colorsys.rgb_to_hsv(r, g, b)
                    
                    # Replace value with depth
                    v = depth_stretched[row, col] / 255.0
                    
                    # Convert back to RGB
                    r, g, b = colorsys.hsv_to_rgb(h, s, v)
                    
                    # Store as 1-255 (avoid 0 which might be nodata)
                    rgb_data[row, col, 0] = max(1, int(254 * r) + 1)
                    rgb_data[row, col, 1] = max(1, int(254 * g) + 1)
                    rgb_data[row, col, 2] = max(1, int(254 * b) + 1)
                
                processed += 1
                if processed % 10000 == 0:
                    feedback.setProgress(int((processed / total_pixels) * 100))
        
        # Create output
        feedback.pushInfo('Writing output...')
        driver = gdal.GetDriverByName('GTiff')
        output_ds = driver.Create(output_path, cols, rows, 3, gdal.GDT_Byte)
        
        output_ds.SetGeoTransform(input_ds.GetGeoTransform())
        output_ds.SetProjection(input_ds.GetProjection())
        
        # Write RGB bands
        for b in range(3):
            band = output_ds.GetRasterBand(b + 1)
            band.WriteArray(rgb_data[:, :, b])
            band.SetDescription(['Red', 'Green', 'Blue'][b])
            band.FlushCache()
        
        # Cleanup
        output_ds = None
        input_ds = None
        
        feedback.pushInfo('Complete!')
        feedback.pushInfo('')
        feedback.pushInfo('Color Interpretation:')
        feedback.pushInfo(f'  Hue (color) = Wavelength ({wav_min} - {wav_max} nm)')
        feedback.pushInfo(f'  Brightness = Depth ({depth_min} - {depth_max})')

        # Generate legend image
        try:
            legend_path = self.create_legend(
                legend_output_path, palette, wav_min, wav_max, depth_min, depth_max, feedback
            )
            if legend_path:
                feedback.pushInfo(f'Legend saved to: {legend_path}')
                # Store path for postProcessAlgorithm (runs on main GUI thread)
                self._legend_path = legend_path
            else:
                self._legend_path = None
        except Exception as e:
            self._legend_path = None
            feedback.pushWarning(f'Legend generation failed: {str(e)}')

        return {self.OUTPUT: output_path}

    def postProcessAlgorithm(self, context, feedback):
        """
        Called on the main GUI thread after processing completes.
        Safe place to create Qt widgets.
        """
        if getattr(self, '_legend_path', None):
            self._show_legend_dock(self._legend_path, feedback)
        return {}

    def _show_legend_dock(self, legend_path, feedback):
        """
        Display the legend PNG in a floating QDockWidget.
        Called from postProcessAlgorithm which runs on the main GUI thread.
        """
        try:
            from qgis.PyQt.QtWidgets import QDockWidget, QLabel, QSizePolicy
            from qgis.PyQt.QtGui import QPixmap
            from qgis.PyQt.QtCore import Qt
            from qgis.utils import iface

            if iface is None:
                feedback.pushWarning('QGIS interface not available - legend not displayed')
                return

            legend_name = os.path.splitext(os.path.basename(legend_path))[0]

            # Load image
            pixmap = QPixmap(legend_path)
            if pixmap.isNull():
                feedback.pushWarning(f'Could not load legend image: {legend_path}')
                return

            # Build dock
            dock = QDockWidget(legend_name, iface.mainWindow())
            dock.setObjectName('HyppyLegendDock_' + legend_name)
            dock.setAllowedAreas(Qt.AllDockWidgetAreas)

            # Use a label that scales its image to fill available space
            label = QLabel()
            label.setPixmap(pixmap)
            label.setScaledContents(True)
            label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            label.setMinimumSize(100, 150)
            dock.setWidget(label)

            # Add to main window, then float it
            iface.mainWindow().addDockWidget(Qt.RightDockWidgetArea, dock)
            dock.setFloating(True)

            # Initial size: natural image size, positioned top-right
            main_win = iface.mainWindow()
            win_geom = main_win.geometry()
            dock_width = pixmap.width() + 20
            dock_height = pixmap.height() + 40
            dock.resize(dock_width, dock_height)
            dock.move(win_geom.right() - dock_width - 20, win_geom.top() + 60)

            dock.show()
            dock.raise_()

            feedback.pushInfo(f'Legend displayed: {legend_name}')

        except Exception as e:
            feedback.pushWarning(f'Could not display legend: {str(e)}')

    def create_legend(self, legend_path, palette, wav_min, wav_max, depth_min, depth_max, feedback):
        """
        Create a 2D colour legend image matching the wavelength map colour scheme.
        Y axis = Wavelength (nm), X axis = Depth (%).
        Saved to the user-supplied legend_path.
        """
        try:
            import matplotlib
            matplotlib.use('Agg')
            import matplotlib.pyplot as plt
        except ImportError:
            feedback.pushWarning('matplotlib not available - legend not generated')
            return None

        legend_width = 256   # depth steps
        legend_height = 256  # wavelength steps

        # Build the legend image array
        img = np.zeros((legend_height, legend_width, 3), dtype=np.uint8)

        for wav_i in range(legend_height):
            # wav_i = 0 → wav_max (top of image), wav_i = height-1 → wav_min (bottom)
            wav_norm = (legend_height - 1 - wav_i) / (legend_height - 1)  # 1.0 at top
            wav_idx = int(wav_norm * 254) + 1  # map to palette indices 1-255
            wav_idx = max(1, min(255, wav_idx))
            r, g, b = palette[wav_idx]

            for dep_i in range(legend_width):
                depth_norm = dep_i / (legend_width - 1)  # 0 → 1
                h, s, v = colorsys.rgb_to_hsv(r, g, b)
                v_scaled = depth_norm  # brightness scales with depth
                rc, gc, bc = colorsys.hsv_to_rgb(h, s, v_scaled)
                img[wav_i, dep_i, 0] = int(255 * rc)
                img[wav_i, dep_i, 1] = int(255 * gc)
                img[wav_i, dep_i, 2] = int(255 * bc)

        depth_pct_min = depth_min * 100
        depth_pct_max = depth_max * 100

        fig, ax = plt.subplots(figsize=(3.5, 5))
        ax.imshow(img, aspect='auto', origin='upper',
                  extent=[depth_pct_min, depth_pct_max, wav_min, wav_max])

        ax.set_xlabel('Depth (%)', fontsize=11)
        ax.set_ylabel('Wavelength (nm)', fontsize=11)
        ax.set_ylim(wav_min, wav_max)

        plt.tight_layout()

        # Ensure .png extension
        if not legend_path.lower().endswith('.png'):
            legend_path = legend_path + '.png'

        plt.savefig(legend_path, dpi=150, bbox_inches='tight')
        plt.close(fig)

        return legend_path

    def stretch_band(self, data, min_val, max_val):
        """
        Stretch data to 0-255 range.
        
        Args:
            data: Input array
            min_val: Minimum value for stretch
            max_val: Maximum value for stretch
        
        Returns:
            Stretched array (uint8, 0-255)
        """
        stretched = (255.99 * (data - min_val) / (max_val - min_val))
        stretched = np.clip(stretched, 0, 255)
        return stretched.astype(np.uint8)

    def create_rainbow_palette(self):
        """
        Create rainbow color palette (blue → red).
        
        Returns:
            List of 256 (r, g, b) tuples, values 0-1
        """
        palette = []
        palette.append((1.0, 1.0, 1.0))  # White for index 0
        
        for i in range(1, 255):
            # Rainbow from blue (0.75) to red (0.0)
            h = (0.9 * (1 - i / 255.0) - 0.22) % 1.0
            r, g, b = colorsys.hsv_to_rgb(h, 1, 1)
            # Gamma correction for better visual balance
            r = math.pow(r, 0.7)
            g = math.pow(g, 0.7)
            b = math.pow(b, 0.7)
            palette.append((r, g, b))
        
        palette.append((1.0, 1.0, 1.0))  # White for index 255
        
        return palette

    def create_stepped_palette(self):
        """
        Create rainbow palette with brightness steps.
        
        Returns:
            List of 256 (r, g, b) tuples, values 0-1
        """
        palette = []
        palette.append((1.0, 1.0, 1.0))  # White for index 0
        
        for i in range(1, 255):
            h = (0.9 * (1 - i / 255.0) - 0.2) % 1.0
            # Add brightness steps
            v = 0.3 + 0.4 * ((i % 16) / 15.0)
            s = 1 - 0.5 * math.sqrt(i / 255.0)
            r, g, b = colorsys.hls_to_rgb(h, v, s)
            palette.append((r, g, b))
        
        palette.append((1.0, 1.0, 1.0))  # White for index 255
        
        return palette

    def name(self):
        return 'wavelength_mapping'

    def displayName(self):
        return 'Step 2c - Wavelength Mapping'

    def group(self):
        return '2 - Generate WoM Rasters'

    def groupId(self):
        return '2_generate_wom'

    def shortHelpString(self):
        return """
        <b>Wavelength Mapping</b>
        
        <p>Creates color-coded RGB maps from Wavelength of Minimum outputs. 
        Produces intuitive visualizations where different absorption features 
        are shown in different colors, with brightness indicating feature strength.</p>
        
        <p><b>Process:</b></p>
        <ol>
        <li>Reads Band 1 (wavelength) and Band 2 (depth) from input</li>
        <li>Maps wavelength to hue (color) using rainbow palette</li>
        <li>Maps depth to value (brightness) in HSV color space</li>
        <li>Converts to RGB for display</li>
        </ol>
        
        <p><b>Inputs:</b></p>
        <ul>
        <li><b>Input:</b> MUST be output from "Wavelength of Minimum" tool (Band 1 = wavelength, Band 2 = depth)</li>
        <li><b>Wavelength Range:</b> Min/max wavelength for color mapping
            <ul>
            <li>Example: 2100-2350 nm for clay minerals</li>
            <li>Example: 2000-2500 nm for broader mineral mapping</li>
            </ul>
        </li>
        <li><b>Depth Range:</b> Min/max depth for brightness mapping
            <ul>
            <li>Start at 0.0 usually</li>
            <li>Adjust max based on your data (try 0.1-0.3)</li>
            </ul>
        </li>
        <li><b>Color Scheme:</b>
            <ul>
            <li><b>Rainbow:</b> Smooth blue→red gradient (recommended)</li>
            <li><b>Rainbow with Steps:</b> Discrete brightness levels</li>
            </ul>
        </li>
        </ul>
        
        <p><b>Output:</b></p>
        <ul>
        <li>3-band RGB image suitable for display</li>
        <li><b>Color (Hue):</b> Wavelength position of absorption feature</li>
        <li><b>Brightness (Value):</b> Depth/strength of absorption feature</li>
        </ul>
        
        <p><b>Interpretation:</b></p>
        <ul>
        <li><b>Similar colors:</b> Similar absorption wavelengths (same mineral/material)</li>
        <li><b>Bright pixels:</b> Strong absorption features</li>
        <li><b>Dark/black pixels:</b> Weak or no features</li>
        <li><b>Color changes:</b> Different minerals or material types</li>
        </ul>
        
        <p><b>Applications:</b></p>
        <ul>
        <li>Mineral mapping (clays, carbonates, etc.)</li>
        <li>Vegetation stress visualization</li>
        <li>Material classification</li>
        <li>Rapid qualitative assessment of hyperspectral data</li>
        </ul>
        
        <p><b>Workflow:</b></p>
        <ol>
        <li>Run "Wavelength of Minimum" on your hyperspectral image</li>
        <li>Run "Wavelength Mapping" on the result</li>
        <li>Adjust wavelength/depth ranges for optimal visualization</li>
        <li>Interpret color patterns for material mapping</li>
        </ol>
        
        <p><b>Tips:</b></p>
        <ul>
        <li>Adjust depth max to brighten the image</li>
        <li>Narrow wavelength range to enhance subtle differences</li>
        <li>Use QGIS histogram to find optimal depth range</li>
        <li>Compare with spectral library data to identify materials</li>
        </ul>
        
        <p><i>Ported from HyPy by Wim Bakker, University of Twente</i></p>
        """

    def createInstance(self):
        return WavelengthMappingAlgorithm()
