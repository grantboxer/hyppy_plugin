"""
DT Ill-Kaol Decision Tree Classification Algorithm for QGIS Processing

Classifies pixels into illite/kaolinite sub-classes.

Input bands:
  b1 - Illkaol image (separate single-band raster)
  b2 - Primary absorption wavelength in nm (WoM Band 1)
  b3 - Depth of deepest feature            (WoM Band 2, threshold gate)

Decision tree (dt_ill_kaol.jpg):
  b3 <= 0.05                             -> aspectral
  b3 > 0.05, NOT (2185 < b2 <= 2225)    -> NO-ALOH
  b3 > 0.05, (2185 < b2 <= 2225):
    b1 <= 0.95 -> kaol4
    b1 <= 0.97 -> kaol3
    b1 <= 0.99 -> kaol2
    b1 <= 1.0  -> kaol1
    b1 <= 1.01 -> ill1
    b1 <= 1.03 -> ill2
    b1 <= 1.05 -> ill3
    b1 >  1.05 -> ill4

kaol = kaolinite, ill = illite.
Thresholds based on analysis of reflectance spectra of illite and
kaolinite mixtures.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

import numpy as np
from osgeo import gdal
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterBand,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
)

ILL_KAOL_CLASSES = [
    (0,  'unclassified', 0,   0,   0  ),
    (1,  'aspectral',    0,   0,   0  ),
    (2,  'NO-ALOH',      128, 128, 128),  # grey
    (3,  'kaol4',        180, 140, 0  ),  # dark yellow-green
    (4,  'kaol3',        0,   160, 0  ),  # dark green
    (5,  'kaol2',        0,   210, 0  ),  # mid green
    (6,  'kaol1',        180, 255, 180),  # pale green
    (7,  'ill1',         255, 180, 180),  # pale pink
    (8,  'ill2',         180, 200, 255),  # pale blue
    (9,  'ill3',         80,  120, 220),  # medium blue
    (10, 'ill4',         0,   0,   200),  # dark blue
]
NAME_TO_ID = {m[1]: m[0] for m in ILL_KAOL_CLASSES}
ID_TO_NAME = {m[0]: m[1] for m in ILL_KAOL_CLASSES}


def classify_pixel(b3, b2, b1):
    if b3 <= 0.05:
        return NAME_TO_ID['aspectral']
    if not (2185 < b2 <= 2225):
        return NAME_TO_ID['NO-ALOH']
    if b1 <= 0.95:
        return NAME_TO_ID['kaol4']
    if b1 <= 0.97:
        return NAME_TO_ID['kaol3']
    if b1 <= 0.99:
        return NAME_TO_ID['kaol2']
    if b1 <= 1.0:
        return NAME_TO_ID['kaol1']
    if b1 <= 1.01:
        return NAME_TO_ID['ill1']
    if b1 <= 1.03:
        return NAME_TO_ID['ill2']
    if b1 <= 1.05:
        return NAME_TO_ID['ill3']
    return NAME_TO_ID['ill4']


_classify_vec = np.vectorize(classify_pixel)


class DtIllKaolAlgorithm(QgsProcessingAlgorithm):

    WOM_INPUT    = 'WOM_INPUT'
    B1_INPUT     = 'B1_INPUT'
    B1_BAND      = 'B1_BAND'
    B3_THRESHOLD = 'B3_THRESHOLD'
    OUTPUT_CLASS = 'OUTPUT_CLASS'
    OUTPUT_RGB   = 'OUTPUT_RGB'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.WOM_INPUT,
            'Wavelength of Minimum raster (Step 1 output — provides b2 and b3)'))

        self.addParameter(QgsProcessingParameterRasterLayer(
            self.B1_INPUT,
            'Illkaol raster (b1 — illite/kaolinite image)'))

        self.addParameter(QgsProcessingParameterBand(
            self.B1_BAND,
            'Band number in illkaol raster',
            parentLayerParameterName=self.B1_INPUT,
            defaultValue=1))

        self.addParameter(QgsProcessingParameterNumber(
            self.B3_THRESHOLD,
            'Depth threshold — WoM Band 2 (b3) must exceed this to be classed as spectral',
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.05, minValue=0.0, maxValue=1.0))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_RGB, 'Output: Ill-Kaol RGB raster', optional=True))

        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT_CLASS, 'Output: Ill-Kaol class raster', optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        wom_layer = self.parameterAsRasterLayer(parameters, self.WOM_INPUT,    context)
        b1_layer  = self.parameterAsRasterLayer(parameters, self.B1_INPUT,     context)
        b1_band   = self.parameterAsInt        (parameters, self.B1_BAND,      context)
        b3_thresh = self.parameterAsDouble     (parameters, self.B3_THRESHOLD, context)
        out_class = self.parameterAsOutputLayer(parameters, self.OUTPUT_CLASS, context)
        out_rgb   = self.parameterAsOutputLayer(parameters, self.OUTPUT_RGB,   context) \
                    if self.OUTPUT_RGB in parameters else None

        wom_ds = gdal.Open(wom_layer.source(), gdal.GA_ReadOnly)
        if wom_ds is None:
            raise QgsProcessingException('Cannot open WoM raster')
        cols, rows = wom_ds.RasterXSize, wom_ds.RasterYSize
        if wom_ds.RasterCount < 2:
            raise QgsProcessingException('WoM raster needs >= 2 bands (Band1=wavelength, Band2=depth)')

        feedback.pushInfo(f'WoM raster: {cols} x {rows}, {wom_ds.RasterCount} bands')
        feedback.pushInfo('Reading WoM Band 1 - primary wavelength (b2)...')
        b2 = wom_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        feedback.pushInfo('Reading WoM Band 2 - deepest feature depth (b3)...')
        b3 = wom_ds.GetRasterBand(2).ReadAsArray().astype(np.float32)

        b1_ds = gdal.Open(b1_layer.source(), gdal.GA_ReadOnly)
        if b1_ds is None:
            raise QgsProcessingException('Cannot open illkaol raster')
        if b1_ds.RasterXSize != cols or b1_ds.RasterYSize != rows:
            raise QgsProcessingException(
                f'Illkaol raster size ({b1_ds.RasterXSize}x{b1_ds.RasterYSize}) '
                f'does not match WoM raster size ({cols}x{rows})')
        feedback.pushInfo(f'Reading illkaol band {b1_band} (b1)...')
        b1 = b1_ds.GetRasterBand(b1_band).ReadAsArray().astype(np.float32)
        b1_ds = None

        feedback.pushInfo(f'Depth threshold: b3 > {b3_thresh} = spectral pixel')
        feedback.pushInfo('Applying dt_ill_kaol decision tree...')
        feedback.setProgress(20)

        nodata = np.isnan(b2) | np.isnan(b3) | np.isnan(b1)
        b2s = np.nan_to_num(b2, nan=0.0)
        b3s = np.nan_to_num(b3, nan=0.0)
        b1s = np.nan_to_num(b1, nan=0.0)

        class_data = _classify_vec(b3s, b2s, b1s).astype(np.uint8)
        class_data[nodata]   = 0
        class_data[b2s == 0] = 0
        feedback.setProgress(70)

        feedback.pushInfo('')
        feedback.pushInfo('Classification summary:')
        unique, counts = np.unique(class_data, return_counts=True)
        total = class_data.size
        for uid, cnt in zip(unique, counts):
            pct = 100.0 * cnt / total
            feedback.pushInfo(
                f'  {ID_TO_NAME.get(int(uid),"?"):15s}  (id={uid:2d})  {cnt:8d} px  {pct:5.1f}%')

        driver = gdal.GetDriverByName('GTiff')

        # ── Class raster (primary — always written) ──────────────────────
        feedback.pushInfo('Writing integer class raster...')
        ct = gdal.ColorTable()
        for mid, name, r, g, bv in ILL_KAOL_CLASSES:
            ct.SetColorEntry(mid, (r, g, bv, 255))
        class_ds = driver.Create(out_class, cols, rows, 1, gdal.GDT_Byte,
                                 options=['COMPRESS=LZW', 'TILED=YES'])
        class_ds.SetGeoTransform(wom_ds.GetGeoTransform())
        class_ds.SetProjection(wom_ds.GetProjection())
        b = class_ds.GetRasterBand(1)
        b.SetNoDataValue(0)
        b.SetDescription('Ill-Kaol Class')
        b.SetRasterColorTable(ct)
        b.SetRasterColorInterpretation(gdal.GCI_PaletteIndex)
        b.WriteArray(class_data)
        b.FlushCache()
        # Raster Attribute Table — class names visible in QGIS legend
        rat = gdal.RasterAttributeTable()
        rat.CreateColumn('Value', gdal.GFT_Integer,  gdal.GFU_MinMax)
        rat.CreateColumn('Class', gdal.GFT_String,   gdal.GFU_Name)
        rat.CreateColumn('R',     gdal.GFT_Integer,  gdal.GFU_Red)
        rat.CreateColumn('G',     gdal.GFT_Integer,  gdal.GFU_Green)
        rat.CreateColumn('B',     gdal.GFT_Integer,  gdal.GFU_Blue)
        for row_idx, (mid, name, r, g, bv) in enumerate(ILL_KAOL_CLASSES):
            rat.SetValueAsInt   (row_idx, 0, mid)
            rat.SetValueAsString(row_idx, 1, name)
            rat.SetValueAsInt   (row_idx, 2, r)
            rat.SetValueAsInt   (row_idx, 3, g)
            rat.SetValueAsInt   (row_idx, 4, bv)
        b.SetDefaultRAT(rat)
        class_ds = None
        result = {self.OUTPUT_CLASS: out_class}
        # ── RGB raster (optional) ────────────────────────────────────────
        if out_rgb:
            feedback.pushInfo('Writing RGB colour raster...')
            rgb_r = np.zeros((rows, cols), dtype=np.uint8)
            rgb_g = np.zeros((rows, cols), dtype=np.uint8)
            rgb_b = np.zeros((rows, cols), dtype=np.uint8)
            for mid, name, r, g, bv in ILL_KAOL_CLASSES:
                mask = class_data == mid
                rgb_r[mask], rgb_g[mask], rgb_b[mask] = r, g, bv
            rgb_ds = driver.Create(out_rgb, cols, rows, 3, gdal.GDT_Byte,
                                   options=['COMPRESS=LZW', 'TILED=YES'])
            rgb_ds.SetGeoTransform(wom_ds.GetGeoTransform())
            rgb_ds.SetProjection(wom_ds.GetProjection())
            for idx, (arr, lbl) in enumerate(
                    [(rgb_r, 'Red'), (rgb_g, 'Green'), (rgb_b, 'Blue')], 1):
                band = rgb_ds.GetRasterBand(idx)
                band.WriteArray(arr)
                band.SetDescription(lbl)
                band.FlushCache()
            rgb_ds = None
            feedback.setProgress(85)

            result[self.OUTPUT_RGB] = out_rgb

        wom_ds = None
        feedback.setProgress(100)
        feedback.pushInfo('dt_ill_kaol classification complete.')
        return result

    def name(self):        return 'dt_ill_kaol'
    def displayName(self): return 'DT Ill-Kaol Classification'
    def group(self):       return 'Workflow C - Decision Tree Classification'
    def groupId(self):     return 'workflow_c'

    def shortHelpString(self):
        return """
        <b>DT Ill-Kaol Classification</b>

        <p style="background-color:#fff8e1; padding:6px; border-left:4px solid #f9a825;">
        <b>Required data:</b> Hyperspectral cube +
        WoM-B (1850–2100 nm) + WoM-C (2100–2400 nm).<br/>
        See <i>Step 0 — Getting Started</i> for the full workflow guide.<br/>Run <i>Workflow A</i> to generate required WoM rasters.
        </p>


        <p>Classifies pixels into illite/kaolinite sub-classes using a spectral
        decision tree. Thresholds based on analysis of reflectance spectra of
        illite and kaolinite mixtures.</p>

        <p>kaol = kaolinite, ill = illite.</p>

        <p><b>Inputs:</b></p>
        <ul>
          <li><b>WoM raster</b> — Wavelength of Minimum output (Step 1).
              Provides b2 (Band 1, primary wavelength) and b3 (Band 2, feature depth).</li>
          <li><b>Illkaol raster (b1)</b> — separate illite/kaolinite image, single band.</li>
        </ul>

        <p><b>Decision tree:</b></p>
        <ul>
          <li>b3 &le; 0.05 &rarr; <b>aspectral</b></li>
          <li>b2 not in (2185, 2225] nm &rarr; <b>NO-ALOH</b></li>
          <li>b1 &le; 0.95 &rarr; <b>kaol4</b></li>
          <li>b1 &le; 0.97 &rarr; <b>kaol3</b></li>
          <li>b1 &le; 0.99 &rarr; <b>kaol2</b></li>
          <li>b1 &le; 1.0  &rarr; <b>kaol1</b></li>
          <li>b1 &le; 1.01 &rarr; <b>ill1</b></li>
          <li>b1 &le; 1.03 &rarr; <b>ill2</b></li>
          <li>b1 &le; 1.05 &rarr; <b>ill3</b></li>
          <li>b1 &gt; 1.05 &rarr; <b>ill4</b></li>
        </ul>

        <p><i>Implemented for QGIS by Grant Boxer, 2025.</i></p>
        """

    def createInstance(self): return DtIllKaolAlgorithm()
