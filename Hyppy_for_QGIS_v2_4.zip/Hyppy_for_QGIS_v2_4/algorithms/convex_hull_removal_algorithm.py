"""
Convex Hull Removal Algorithm for QGIS Processing

Performs continuum removal (convex hull removal) on hyperspectral imagery.
Supports both divide and subtract modes.

Ported from HyPy hull.py and quickhull2d.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original Copyright (C) 2010-2022 Wim Bakker

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterEnum,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis
)

from ..core.convex_hull import hull_resampled


class ConvexHullRemovalAlgorithm(QgsProcessingAlgorithm):
    """
    Convex Hull Removal (Continuum Removal) Algorithm

    Removes the continuum from spectral data using convex hull fitting.
    Two modes are supported:
    - Divide: result = spectrum / hull  (values around 1.0, absorptions < 1.0)
    - Subtract: result = 1 + (spectrum - hull)  (values around 1.0)

    Requires wavelength information in the raster metadata.
    """

    INPUT = 'INPUT'
    MODE = 'MODE'
    CUTOFF_WAVELENGTH = 'CUTOFF_WAVELENGTH'
    USE_BBL = 'USE_BBL'
    OUTPUT = 'OUTPUT'

    MODES = ['Divide (spectrum / hull)', 'Subtract (1 + spectrum - hull)']

    def initAlgorithm(self, config=None):
        """Define inputs and outputs."""

        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT,
                'Input Hyperspectral Image',
                optional=False
            )
        )

        self.addParameter(
            QgsProcessingParameterEnum(
                self.MODE,
                'Continuum Removal Mode',
                options=self.MODES,
                defaultValue=0,
                optional=False
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.CUTOFF_WAVELENGTH,
                'Cutoff Wavelength (nm, 0 = use all bands)',
                type=QgsProcessingParameterNumber.Double,
                defaultValue=0.0,
                minValue=0.0,
                optional=True
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.USE_BBL,
                'Use Bad Band List (BBL) from metadata',
                defaultValue=True,
                optional=True
            )
        )

        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                'Output Continuum-Removed Image'
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """Execute the convex hull removal algorithm."""

        # Get parameters
        input_layer = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        mode = self.parameterAsEnum(parameters, self.MODE, context)
        cutoff_wavelength = self.parameterAsDouble(parameters, self.CUTOFF_WAVELENGTH, context)
        use_bbl = self.parameterAsBoolean(parameters, self.USE_BBL, context)
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if input_layer is None:
            raise QgsProcessingException('Invalid input layer')

        # Open with GDAL
        ds = gdal.Open(input_layer.source())
        if ds is None:
            raise QgsProcessingException(f'Cannot open raster: {input_layer.source()}')

        n_bands = ds.RasterCount
        n_rows = ds.RasterYSize
        n_cols = ds.RasterXSize

        # Extract wavelength information from metadata
        wavelengths = self._get_wavelengths(ds, n_bands, feedback)
        if wavelengths is None:
            raise QgsProcessingException(
                'No wavelength information found in raster metadata. '
                'Convex hull removal requires wavelength data.'
            )

        # Get bad band list if requested
        bbl = self._get_bbl(ds, n_bands, use_bbl, feedback)

        # Determine cutoff band index
        if cutoff_wavelength > 0:
            # Find band index closest to cutoff wavelength
            n_cutoff = np.searchsorted(wavelengths, cutoff_wavelength)
            n_cutoff = min(n_cutoff, n_bands)
            feedback.pushInfo(f'Using bands up to cutoff wavelength {cutoff_wavelength} nm (band {n_cutoff})')
        else:
            n_cutoff = n_bands

        # Filter wavelengths and bbl to cutoff
        wav = wavelengths[:n_cutoff]
        if bbl is not None:
            bbl = bbl[:n_cutoff]

        # Find valid (non-bad) band indices
        if bbl is not None:
            valid_bands = [i for i in range(n_cutoff) if bbl[i]]
        else:
            valid_bands = list(range(n_cutoff))

        if len(valid_bands) < 2:
            raise QgsProcessingException('Not enough valid bands for convex hull removal')

        feedback.pushInfo(f'Processing {n_cutoff} bands, {len(valid_bands)} valid bands')
        feedback.pushInfo(f'Wavelength range: {wav[valid_bands[0]]:.1f} - {wav[valid_bands[-1]]:.1f} nm')

        # Create output raster
        driver = gdal.GetDriverByName('GTiff')
        out_ds = driver.Create(
            output_path,
            n_cols, n_rows, n_cutoff,
            gdal.GDT_Float64
        )
        out_ds.SetGeoTransform(ds.GetGeoTransform())
        out_ds.SetProjection(ds.GetProjection())

        # Read all bands into memory (as float64)
        feedback.pushInfo('Reading input bands...')
        data = np.zeros((n_cutoff, n_rows, n_cols), dtype=np.float64)
        nodata_value = None
        for i in range(n_cutoff):
            band = ds.GetRasterBand(i + 1)
            if nodata_value is None:
                nodata_value = band.GetNoDataValue()
            arr = band.ReadAsArray().astype(np.float64)
            if nodata_value is not None:
                arr[arr == nodata_value] = np.nan
            data[i] = arr

        # Process pixel by pixel
        feedback.pushInfo('Applying convex hull removal...')
        result = np.full_like(data, np.nan)

        old_settings = np.seterr(all='ignore')

        total_pixels = n_rows * n_cols
        step = max(1, n_rows // 100)

        for j in range(n_rows):
            if feedback.isCanceled():
                break
            if j % step == 0:
                feedback.setProgress(int(j * 100 / n_rows))

            for i in range(n_cols):
                spec = data[:, j, i].copy()

                # Skip if all NaN or invalid
                if np.all(np.isnan(spec)):
                    result[:, j, i] = spec
                    continue

                # Get valid band values for hull computation
                valid_spec = spec[valid_bands]
                valid_wav = wav[valid_bands]

                # Replace NaNs with 0 for hull computation
                nan_mask = np.isnan(valid_spec)
                valid_spec_clean = valid_spec.copy()
                valid_spec_clean[nan_mask] = 0.0

                # Compute convex hull
                pts = np.column_stack((valid_wav, valid_spec_clean))
                hull_pts = hull_resampled(pts)[:, 1]

                # Compute result for valid bands
                if mode == 0:  # Divide
                    res = valid_spec / hull_pts
                else:  # Subtract
                    res = 1.0 + (valid_spec - hull_pts)

                res[nan_mask] = np.nan

                # Assign back to full output (valid bands only)
                for idx, band_idx in enumerate(valid_bands):
                    result[band_idx, j, i] = res[idx]

        np.seterr(**old_settings)

        # Write output bands
        feedback.pushInfo('Writing output...')
        mode_str = 'divide' if mode == 0 else 'subtract'
        for i in range(n_cutoff):
            out_band = out_ds.GetRasterBand(i + 1)
            out_band.WriteArray(result[i])
            out_band.SetDescription(f'CR_{mode_str}_band_{i+1}_{wav[i]:.2f}nm')
            if nodata_value is not None:
                out_band.SetNoDataValue(np.nan)

        # Write wavelength metadata
        metadata = {}
        wav_str = '{' + ', '.join([f'{w:.4f}' for w in wav]) + '}'
        metadata['wavelength'] = wav_str
        metadata['wavelength_units'] = 'Nanometers'
        metadata['convex_hull_mode'] = 'divide' if mode == 0 else 'subtract'
        out_ds.SetMetadata(metadata)

        out_ds.FlushCache()
        del ds, out_ds

        feedback.pushInfo('Convex hull removal completed successfully.')
        return {self.OUTPUT: output_path}

    def _get_wavelengths(self, ds, n_bands, feedback):
        """Extract wavelength array from GDAL ENVI metadata or band descriptions."""
        # Try ENVI metadata domain first (works for ENVI-format rasters)
        metadata = ds.GetMetadata('ENVI')
        if metadata:
            for key in ['wavelength', 'Wavelength', 'WAVELENGTH']:
                if key in metadata:
                    wav_str = metadata[key].strip('{}').strip()
                    try:
                        wavs = [float(w.strip()) for w in wav_str.split(',') if w.strip()]
                        if len(wavs) >= n_bands:
                            return np.array(wavs[:n_bands])
                        elif len(wavs) > 0:
                            return np.array(wavs)
                    except ValueError:
                        pass
        # Fallback: default metadata domain
        metadata = ds.GetMetadata()
        for key in ['wavelength', 'Wavelength', 'WAVELENGTH']:
            if key in metadata:
                wav_str = metadata[key].strip('{}').strip()
                try:
                    wavs = [float(w.strip()) for w in wav_str.split(',') if w.strip()]
                    if len(wavs) >= n_bands:
                        return np.array(wavs[:n_bands])
                    elif len(wavs) > 0:
                        return np.array(wavs)
                except ValueError:
                    pass
        # Fallback: band descriptions (numeric wavelength values)
        wavs = []
        for b in range(n_bands):
            band = ds.GetRasterBand(b + 1)
            desc = band.GetDescription()
            try:
                wavs.append(float(desc))
            except (ValueError, TypeError):
                wavs.append(None)
        if None not in wavs and len(wavs) == n_bands:
            feedback.pushInfo('Found wavelengths in band descriptions')
            return np.array(wavs, dtype=float)
        return None
    def _get_bbl(self, ds, n_bands, use_bbl, feedback):
        """Extract bad band list from metadata."""
        if not use_bbl:
            return None

        metadata = ds.GetMetadata('ENVI')
        for key in ['bbl', 'BBL', 'bad_band_multiplier']:
            if key in metadata:
                bbl_str = metadata[key].strip('{}').strip()
                try:
                    bbl = [int(float(b.strip())) for b in bbl_str.split(',') if b.strip()]
                    if len(bbl) >= n_bands:
                        return [bool(b) for b in bbl[:n_bands]]
                except ValueError:
                    pass
        return None

    def name(self):
        return 'convexhullremoval'

    def displayName(self):
        return 'Convex Hull Removal (Continuum Removal)'

    def group(self):
        return 'Workflow E - Spectral Processing Tools'

    def groupId(self):
        return 'workflow_e'

    def shortHelpString(self):
        return (
            'Performs continuum removal on hyperspectral imagery using convex hull fitting.\n\n'
            'The convex hull is computed for each pixel spectrum and the spectrum is '
            'normalised relative to the hull.\n\n'
            'Two modes are available:\n'
            '  Divide: result = spectrum / hull (absorption features < 1.0)\n'
            '  Subtract: result = 1 + (spectrum - hull) (absorption features < 1.0)\n\n'
            'Requires wavelength information in the raster metadata (ENVI format).\n\n'
            'Optionally specify a cutoff wavelength to restrict processing to a spectral range.\n'
            'Bad bands can be excluded using the Bad Band List (BBL) from the metadata.'
        )

    def createInstance(self):
        return ConvexHullRemovalAlgorithm()
