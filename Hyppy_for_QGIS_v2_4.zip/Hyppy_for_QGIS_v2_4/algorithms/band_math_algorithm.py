"""
Band Math Algorithm for QGIS Processing

Applies a user-defined mathematical expression to one or more input images.
Input images are referenced as i1, i2, ... i20 in the expression.
Band access: i1.get_band(n) returns a 2D numpy array for band n.
Full image access: i1[:,:,n] or i1[row,col,band].

Ported from HyPy bandmath.py / tkBandMath.py
Original Author: Wim Bakker, University of Twente

Copyright (C) 2025 Grant Boxer
Original Copyright (C) 2010-2022 Wim Bakker

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
"""

import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterString,
    QgsProcessingParameterEnum,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingException,
    QgsMessageLog,
    Qgis
)


# ── lightweight band-array helper ──────────────────────────────────────────────

class _ImageProxy:
    """
    Thin wrapper around a GDAL dataset that provides band access compatible
    with the Band Math expression syntax.

    Usage in expressions:
        i1.get_band(0)          -> 2-D float64 array for band index 0 (0-based)
        i1.band(1)              -> same as get_band(0) but 1-based
        i1[band_index]          -> same as get_band(band_index)
        i1.bands                -> number of bands
        i1.wavelength           -> 1-D wavelength array (or None)
        i1.wavelength2index(w)  -> nearest band index for wavelength w
    """

    def __init__(self, ds):
        self._ds = ds
        self.bands = ds.RasterCount
        self.lines = ds.RasterYSize
        self.samples = ds.RasterXSize
        self._nodata = ds.GetRasterBand(1).GetNoDataValue()
        self.wavelength = self._load_wavelengths()

    def _load_wavelengths(self):
        """Extract wavelengths from ENVI domain, default domain, or band descriptions."""
        for domain in ['ENVI', None]:
            meta = self._ds.GetMetadata(domain) if domain else self._ds.GetMetadata()
            if not meta:
                continue
            for key in ['wavelength', 'Wavelength', 'WAVELENGTH']:
                if key in meta:
                    try:
                        wavs = [float(w) for w in meta[key].strip('{}').split(',') if w.strip()]
                        if wavs:
                            return np.array(wavs)
                    except ValueError:
                        pass
        # Fallback: band descriptions
        wavs = []
        for b in range(self.bands):
            desc = self._ds.GetRasterBand(b + 1).GetDescription()
            try:
                wavs.append(float(desc))
            except (ValueError, TypeError):
                return None
        return np.array(wavs) if wavs else None

    def wavelength2index(self, w):
        if self.wavelength is None:
            return int(w)
        return int(np.argmin(np.abs(self.wavelength - w)))

    def get_band(self, index):
        """Return band as float64 array (0-based index)."""
        arr = self._ds.GetRasterBand(int(index) + 1).ReadAsArray().astype(np.float64)
        if self._nodata is not None:
            arr[arr == self._nodata] = np.nan
        return arr

    def band(self, index):
        """Return band as float64 array (1-based index)."""
        return self.get_band(index - 1)

    def __getitem__(self, index):
        return self.get_band(index)


# ── algorithm ──────────────────────────────────────────────────────────────────

class BandMathAlgorithm(QgsProcessingAlgorithm):
    """
    Band Math Algorithm

    Evaluates a Python/NumPy expression over one or more input raster images
    to produce a single-band output raster.

    Input images are available in the expression as i1, i2, ... (up to 20).

    Band access helpers:
        i1.get_band(n)  - returns band n as a 2D numpy array (0-based)
        i1.band(n)      - returns band n as a 2D numpy array (1-based)
        i1[n]           - same as get_band(n)
        i1.bands        - number of bands
        i1.wavelength   - wavelength array (or None)

    NumPy functions are available directly (sin, cos, log, sqrt, …).

    Examples:
        Single band ratio:
            i1.get_band(10) / i1.get_band(20)

        Normalised Difference (NDVI-style):
            (i1.get_band(30) - i1.get_band(20)) / (i1.get_band(30) + i1.get_band(20))

        Two-image difference (band 0):
            i1.get_band(0) - i2.get_band(0)

        Log of band 5:
            log(i1.get_band(4))
    """

    INPUT_LAYERS = 'INPUT_LAYERS'
    EXPRESSION = 'EXPRESSION'
    OUTPUT = 'OUTPUT'

    def initAlgorithm(self, config=None):
        """Define inputs and outputs."""

        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT_LAYERS,
                'Input Raster Layer(s)  (i1, i2, ... in expression)',
                layerType=QgsProcessing.TypeRaster,
                optional=False
            )
        )

        self.addParameter(
            QgsProcessingParameterString(
                self.EXPRESSION,
                'Band Math Expression (Python/NumPy)',
                defaultValue='i1.get_band(0) / i1.get_band(1)',
                multiLine=True,
                optional=False
            )
        )

        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT,
                'Output Band Math Image'
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """Execute the band math algorithm."""

        layers = self.parameterAsLayerList(parameters, self.INPUT_LAYERS, context)
        expression = self.parameterAsString(parameters, self.EXPRESSION, context).strip()
        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if not layers:
            raise QgsProcessingException('No input layers provided')
        if not expression:
            raise QgsProcessingException('No expression provided')

        feedback.pushInfo(f'Expression: {expression}')
        feedback.pushInfo(f'Input layers: {len(layers)}')

        # Open all datasets and wrap in proxy objects
        proxies = {}
        ds_list = []
        for k, layer in enumerate(layers[:20]):
            ds = gdal.Open(layer.source())
            if ds is None:
                raise QgsProcessingException(f'Cannot open raster: {layer.source()}')
            ds_list.append(ds)
            proxy = _ImageProxy(ds)
            var_name = f'i{k+1}'
            proxies[var_name] = proxy
            feedback.pushInfo(
                f'  {var_name}: {layer.name()} '
                f'({proxy.samples}x{proxy.lines}, {proxy.bands} bands)'
            )

        # Evaluate expression in a namespace with proxies + numpy
        from numpy import (
            sqrt, log, log2, log10, exp, sin, cos, tan,
            arcsin, arccos, arctan, arctan2,
            abs, minimum, maximum, clip, where,
            isnan, isinf, nan, inf, pi,
            zeros, ones, full, linspace, arange
        )
        namespace = {k: v for k, v in locals().items()}
        namespace.update(proxies)

        old_settings = np.seterr(all='ignore')
        try:
            result = eval(expression, {"__builtins__": {}}, namespace)
        except Exception as exc:
            np.seterr(**old_settings)
            raise QgsProcessingException(f'Expression evaluation failed: {exc}')
        np.seterr(**old_settings)

        result = np.array(result, dtype=np.float64)
        if result.ndim == 0:
            raise QgsProcessingException('Expression returned a scalar. It must return a 2D array.')
        if result.ndim == 1:
            raise QgsProcessingException('Expression returned a 1D array. It must return a 2D array.')

        ref_ds = ds_list[0]
        n_rows = ref_ds.RasterYSize
        n_cols = ref_ds.RasterXSize

        if result.shape != (n_rows, n_cols):
            raise QgsProcessingException(
                f'Result shape {result.shape} does not match input shape ({n_rows}, {n_cols})'
            )

        # Write output
        driver = gdal.GetDriverByName('GTiff')
        out_ds = driver.Create(output_path, n_cols, n_rows, 1, gdal.GDT_Float64)
        out_ds.SetGeoTransform(ref_ds.GetGeoTransform())
        out_ds.SetProjection(ref_ds.GetProjection())

        out_band = out_ds.GetRasterBand(1)
        out_band.WriteArray(result)
        out_band.SetDescription(f'Band Math: {expression}')
        out_band.SetNoDataValue(np.nan)

        out_ds.SetMetadata({'band_math_expression': expression})
        out_ds.FlushCache()

        for ds in ds_list:
            del ds
        del out_ds

        feedback.pushInfo('Band math completed successfully.')
        return {self.OUTPUT: output_path}

    def name(self):
        return 'bandmath'

    def displayName(self):
        return 'Band Math'

    def group(self):
        return '5 - Spectral Processing Tools'

    def groupId(self):
        return '5_spectral_processing_tools'

    def shortHelpString(self):
        return (
            'Evaluates a Python/NumPy expression over one or more input raster '
            'images to produce a single-band output raster.\n\n'
            'Input images are available as i1, i2, ... in the expression.\n\n'
            'Band access:\n'
            '  i1.get_band(n)  - 0-based band index\n'
            '  i1.band(n)      - 1-based band index\n'
            '  i1[n]           - same as get_band(n)\n'
            '  i1.bands        - number of bands\n'
            '  i1.wavelength   - wavelength array\n\n'
            'NumPy functions (sqrt, log, sin, cos, abs, ...) are available.\n\n'
            'Examples:\n'
            '  Band ratio:  i1.get_band(10) / i1.get_band(20)\n'
            '  NDVI-style:  (i1.get_band(30) - i1.get_band(20)) / (i1.get_band(30) + i1.get_band(20))\n'
            '  Two images:  i1.get_band(0) - i2.get_band(0)\n'
        )

    def createInstance(self):
        return BandMathAlgorithm()
