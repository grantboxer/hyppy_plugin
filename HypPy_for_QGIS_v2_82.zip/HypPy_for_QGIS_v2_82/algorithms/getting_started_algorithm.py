"""
Getting Started / Workflow Guide for the HypPy for QGIS plugin.

Copyright (C) 2025 Grant Boxer. GPL v3 or later.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterBoolean,
)
from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtGui import QDesktopServices

GUIDE_URL = 'https://github.com/grantboxer/hyperspectral_for_qgis/blob/main/USER_GUIDE.md'


class GettingStartedAlgorithm(QgsProcessingAlgorithm):

    CONFIRM    = 'CONFIRM'
    OPEN_GUIDE = 'OPEN_GUIDE'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterBoolean(
            self.OPEN_GUIDE,
            'Open user guide in browser (recommended for new users)',
            defaultValue=True))
        self.addParameter(QgsProcessingParameterBoolean(
            self.CONFIRM,
            'I have read the workflow guide (tick to acknowledge)',
            defaultValue=False))

    def processAlgorithm(self, parameters, context, feedback):
        open_guide = self.parameterAsBool(parameters, self.OPEN_GUIDE, context)

        if open_guide:
            feedback.pushInfo('Opening HypPy for QGIS user guide in your web browser...')
            feedback.pushInfo(f'  {GUIDE_URL}')
            QDesktopServices.openUrl(QUrl(GUIDE_URL))
            feedback.pushInfo('')

        feedback.pushInfo('')
        feedback.pushInfo('══════════════════════════════════════════════════')
        feedback.pushInfo('  HypPy for QGIS — Workflow Guide')
        feedback.pushInfo('══════════════════════════════════════════════════')
        feedback.pushInfo('')
        feedback.pushInfo('OVERVIEW')
        feedback.pushInfo('────────')
        feedback.pushInfo('  HypPy for QGIS provides hyperspectral analysis algorithms')
        feedback.pushInfo('  organised into ten groups:')
        feedback.pushInfo('')
        feedback.pushInfo('  Group 1   Workflow Guide          (this tool)')
        feedback.pushInfo('  Group 2   Data Import             (D01 Overviews, D02 Subset, CTIC)')
        feedback.pushInfo('  Group 3   Generate WoM Rasters    (Workflow A)')
        feedback.pushInfo('  Group 4   Decision Tree           (Workflow C — DT classifiers)')
        feedback.pushInfo('  Group 5   SAM Classification      (Workflow D)')
        feedback.pushInfo('  Group 6   Spectral Processing     (Workflow E + Hist Equalise + Feature Space)')
        feedback.pushInfo('  Group 7   Feature Extraction      (Workflow F — FE tools)')
        feedback.pushInfo('  Group 8   Convert Tools           (Workflow G)')
        feedback.pushInfo('  Group 9   GSWA Mineral Map Indices (Table 5)')
        feedback.pushInfo('  Group 10  Convert Tools           (format utilities)')
        feedback.pushInfo('')
        feedback.pushInfo('NEW IN v2.82 — GSWA REPORT 261 HIGH-PRIORITY FEATURES')
        feedback.pushInfo('──────────────────────────────────────────────────────')
        feedback.pushInfo('  Three new tools implement the high-priority recommendations')
        feedback.pushInfo('  from Laukamp et al. (2025) GSWA Report 261:')
        feedback.pushInfo('')
        feedback.pushInfo('  1. CTIC — Cross-Track Illumination Correction  (Group 2)')
        feedback.pushInfo('     Removes scan-direction brightness gradients before FE.')
        feedback.pushInfo('     Run BEFORE any Feature Extraction or GSWA index tool.')
        feedback.pushInfo('     Method: column median + polynomial fit (order 1–6).')
        feedback.pushInfo('     Equivalent to ENVI built-in CTIC module.')
        feedback.pushInfo('')
        feedback.pushInfo('  2. Histogram Equalisation  (Group 6)')
        feedback.pushInfo('     Converts any FE depth or GSWA index raster to uniform')
        feedback.pushInfo('     (flat) distribution for improved visual contrast.')
        feedback.pushInfo('     Output is DISPLAY ONLY — not suitable for ML/chemometrics.')
        feedback.pushInfo('     See GSWA Report 261 §3.5.1, Figures 19c, 26b, 27c etc.')
        feedback.pushInfo('')
        feedback.pushInfo('  3. 2D Feature Space  (Group 6)')
        feedback.pushInfo('     Interactive HTML scatter plot of two single-band rasters.')
        feedback.pushInfo('     Primary use: plot 2160D vs 2200D to identify mineral clusters')
        feedback.pushInfo('     (white mica, kaolinite, pyrophyllite) and derive scene-')
        feedback.pushInfo('     specific Y/X ratio thresholds for GSWA masking conditions.')
        feedback.pushInfo('     Optional ratio threshold line (default 3.0 for 2160D/2200D).')
        feedback.pushInfo('     See GSWA Report 261 §3.5.2, Figures 24 and 25.')
        feedback.pushInfo('')
        feedback.pushInfo('NEW IN v2.82 — MEDIUM-PRIORITY FEATURES (5 tools)')
        feedback.pushInfo('─────────────────────────────────────────────────')
        feedback.pushInfo('  4. Savitzky-Golay Spectral Filter  (Group 6)')
        feedback.pushInfo('     Smooths each pixel spectrum spectrally (not spatially).')
        feedback.pushInfo('     Recommended: window=7, poly=2 for PRISMA; 5,2 for EnMAP/EMIT.')
        feedback.pushInfo('     Run BEFORE CTIC and FE tools for noisy VNIR/SWIR regions.')
        feedback.pushInfo('')
        feedback.pushInfo('  5. GSWA Table 3 Band Ratio Basic Products  (Group 6)')
        feedback.pushInfo('     Five band ratio products from GSWA Report 261 Table 3:')
        feedback.pushInfo('     2160D, 2200D, 2250D, 2250D/2200D ratio, Mineral Groups RGB.')
        feedback.pushInfo('     Faster than polynomial fit; reproducible in any GIS.')
        feedback.pushInfo('')
        feedback.pushInfo('  6. FE-2320D  Amphibole / Talc  (Group 7)')
        feedback.pushInfo('     2295-2400 nm; targets the ~2320/2380 nm Mg-OH doublet.')
        feedback.pushInfo('     EnMAP/EMIT recommended — PRISMA has insufficient SNR.')
        feedback.pushInfo('     Maps mafic/ultramafic rocks, amphibolites, pegmatite hosts.')
        feedback.pushInfo('')
        feedback.pushInfo('  7. FE-2108D  Dry Vegetation / Cellulose  (Group 7)')
        feedback.pushInfo('     2078-2143 nm; cellulose absorption ~2108 nm (Kokaly & Clark).')
        feedback.pushInfo('     Use to map dry veg cover and assess mineral map contamination.')
        feedback.pushInfo('     Combine output depth band with MertonNDVI as dual veg mask.')
        feedback.pushInfo('')
        feedback.pushInfo('  8. Multi-Index RGB Composite  (Group 6)')
        feedback.pushInfo('     Combines any three single-band rasters into a false-colour RGB.')
        feedback.pushInfo('     Per-channel linear or histogram-equalised stretch.')
        feedback.pushInfo('     Pre-wired GSWA combinations: WMai/CBEai/KLNai, FOai/WMai/KLNai,')
        feedback.pushInfo('     PPHai/WMai/KLNai, K-radiometrics/WMai/KLNai.')
        feedback.pushInfo('')
        feedback.pushInfo('NEW IN v2.82 — LOW-PRIORITY FEATURES (2 items)')
        feedback.pushInfo('──────────────────────────────────────────────')
        feedback.pushInfo('  9. WMci Composition Stretch  (GSWA-WMci, Group 9)')
        feedback.pushInfo('     Composition maps must use LINEAR stretch — NOT histogram-equalised.')
        feedback.pushInfo('     QGIS display: Layer Properties → Singleband pseudocolor')
        feedback.pushInfo('     Min=2185, Max=2215, Rainbow colour ramp.')
        feedback.pushInfo('     Blue=Al-rich muscovite/illite; Red=phengite.')
        feedback.pushInfo('     Processing log now includes step-by-step QGIS display guide.')
        feedback.pushInfo('')
        feedback.pushInfo(' 10. Sensor-Aware SNR Warnings  (FE15/16/17/18, FE-2320D)')
        feedback.pushInfo('     PRISMA, EnMAP, and EMIT are now recognised from wavelength')
        feedback.pushInfo('     fingerprint (band count + spectral range).')
        feedback.pushInfo('     FE tools targeting 2300-2450 nm push a pushWarning if PRISMA')
        feedback.pushInfo('     is detected, recommending EnMAP/EMIT for that range.')
        feedback.pushInfo('     Sensor profiles also carry bad-zone and poor-SNR metadata')
        feedback.pushInfo('     accessible via envi_header.get_sensor_info().')
        feedback.pushInfo('')
        feedback.pushInfo('RECOMMENDED SATELLITE PREPROCESSING WORKFLOW (v2.82)')
        feedback.pushInfo('──────────────────────────────────────────────────────')
        feedback.pushInfo('  For PRISMA, EnMAP, EMIT or other spaceborne hyperspectral:')
        feedback.pushInfo('  1. D01 — Build Overviews   (fast display)')
        feedback.pushInfo('  2. CTIC — Cross-Track Illumination Correction  ← NEW')
        feedback.pushInfo('  3. FE tools — Feature Extraction on CTIC-corrected cube')
        feedback.pushInfo('  4. 2D Feature Space — derive scene-specific thresholds  ← NEW')
        feedback.pushInfo('  5. GSWA Mineral Map Indices (Group 9)')
        feedback.pushInfo('  6. Histogram Equalisation — for visual display  ← NEW')
        feedback.pushInfo('')
        feedback.pushInfo('REQUIRED INPUT DATA')
        feedback.pushInfo('───────────────────')
        feedback.pushInfo('  1. Hyperspectral spectral cube')
        feedback.pushInfo('     Reflectance image with wavelength metadata')
        feedback.pushInfo('     (ENVI format or equivalent).')
        feedback.pushInfo('')
        feedback.pushInfo('  2. Three Wavelength of Minimum (WoM) rasters')
        feedback.pushInfo('     Generated by Group 3 (Workflow A):')
        feedback.pushInfo('')
        feedback.pushInfo('     WoM-A:   750 – 1300 nm  (VNIR iron oxides)')
        feedback.pushInfo('     WoM-B:  1850 – 2100 nm  (illite crystallinity)')
        feedback.pushInfo('     WoM-C:  2100 – 2400 nm  (SWIR minerals)')
        feedback.pushInfo('')
        feedback.pushInfo('RECOMMENDED WORKFLOW')
        feedback.pushInfo('────────────────────')
        feedback.pushInfo('  Step 1  Group 3 — Generate WoM rasters')
        feedback.pushInfo('          Run "Generate All Three WoM Rasters" or')
        feedback.pushInfo('          run WoM-A, WoM-B, WoM-C individually.')
        feedback.pushInfo('')
        feedback.pushInfo('  Step 2  Group 7 — Feature Extraction (Workflow F)')
        feedback.pushInfo('          Run individual FE tools for targeted minerals,')
        feedback.pushInfo('          or FE00 Run All for a complete scene survey.')
        feedback.pushInfo('')
        feedback.pushInfo('  Step 3  Group 4 — Decision Tree classifiers')
        feedback.pushInfo('          Use WoM and FE outputs as inputs.')
        feedback.pushInfo('')
        feedback.pushInfo('  Optional: Group 5 (SAM) or Group 6 (Spectral Processing).')
        feedback.pushInfo('')
        feedback.pushInfo('FEATURE EXTRACTION TOOLS (Group 7 — Workflow F)')
        feedback.pushInfo('────────────────────────────────────────────────')
        feedback.pushInfo('  Each FE tool runs a one-click pipeline: Wavelength of Minimum')
        feedback.pushInfo('  → Wavelength Map RGB → Colour Legend.')
        feedback.pushInfo('')
        feedback.pushInfo('  FE00          Run All FE tools (FE01–FE18) in one pass')
        feedback.pushInfo('  FE-WOM-1440   Sulphate WoM survey (1440–1550 nm)')
        feedback.pushInfo('')
        feedback.pushInfo('  FE-900D       Iron oxide depth — poly₂ fit, 776–1050 nm')
        feedback.pushInfo('                GSWA Rpt261 Table 4; targets hematite (~890 nm)')
        feedback.pushInfo('                and goethite (~940 nm)')
        feedback.pushInfo('')
        feedback.pushInfo('  FE01–FE18     SWIR absorption features (wavelength positions):')
        feedback.pushInfo('    FE01  1384D  Dickite OH doublet')
        feedback.pushInfo('    FE02  1396W  Pyrophyllite OH')
        feedback.pushInfo('    FE03  1400D  Kaolinite / OH-bearing sheet silicates')
        feedback.pushInfo('    FE04  1480W  Alunite / jarosite / prehnite')
        feedback.pushInfo('    FE05  1550W  Epidote 2νOH')
        feedback.pushInfo('    FE06  1760W  Gypsum / alunite ν+2δOH')
        feedback.pushInfo('    FE07  1900W  Halloysite H₂O')
        feedback.pushInfo('    FE08  2066D  Pyrophyllite Al-OH doublet')
        feedback.pushInfo('    FE09  2080D  Talc ν+δM₃OH')
        feedback.pushInfo('    FE10  2160D  Kaolin / pyrophyllite outer OH')
        feedback.pushInfo('    FE11  2178D  Dickite Al-OH shoulder')
        feedback.pushInfo('    FE12  2200W  AlOH — illite / smectite / kaolinite')
        feedback.pushInfo('    FE13  2206W  Kaolinite primary Al-OH')
        feedback.pushInfo('    FE14  2250W  Chlorite / biotite / epidote Fe/Mg-OH')
        feedback.pushInfo('    FE15  2290W  FeMg-clay / amphibole / talc')
        feedback.pushInfo('    FE16  2320W  Carbonates (magnesite/dolomite/ankerite/calcite)')
        feedback.pushInfo('    FE17  2350W  Carbonates / pyrophyllite secondary')
        feedback.pushInfo('    FE18  2390W  Amphibole / biotite / talc')
        feedback.pushInfo('')
        feedback.pushInfo('  FE-REE        Neodymium VNIR (580/740/800/870 nm)')
        feedback.pushInfo('')
        feedback.pushInfo('  FE-GSWA-RGB   Mineral Groups False Colour RGB composite')
        feedback.pushInfo('                R=2200D / G=2250D / B=2160D')
        feedback.pushInfo('                GSWA Rpt261 Table 4 stretch pre-loaded')
        feedback.pushInfo('                (all channels min=0.02, max=0.15)')
        feedback.pushInfo('')
        feedback.pushInfo('GSWA REPORT 261 TABLE 4 — POLYNOMIAL FIT PRODUCTS')
        feedback.pushInfo('──────────────────────────────────────────────────')
        feedback.pushInfo('  FE-900D, FE-GSWA-RGB and the stretch notes on FE10/FE12/FE14')
        feedback.pushInfo('  are based on Laukamp et al. (2025) GSWA Report 261, Table 4,')
        feedback.pushInfo('  which describes polynomial fit-based PRISMA hyperspectral')
        feedback.pushInfo('  products for the Gascoyne and Pilbara, WA.')
        feedback.pushInfo('')
        feedback.pushInfo('  Recommended GSWA display stretches (rainbow colour scheme):')
        feedback.pushInfo('    900D   Gascoyne/Pilbara  min=0.16, max=0.29')
        feedback.pushInfo('    2160D  Gascoyne          min=0.04, max=0.15')
        feedback.pushInfo('    2160D  Pilbara           min=0.02, max=0.15')
        feedback.pushInfo('    2200D  Gascoyne/Pilbara  min=0.04, max=0.16')
        feedback.pushInfo('    2250D  Gascoyne          min=0.01, max=0.04')
        feedback.pushInfo('    2250D  Pilbara           min=0.02, max=0.65')
        feedback.pushInfo('    RGB    All channels      min=0.02, max=0.15')
        feedback.pushInfo('')
        feedback.pushInfo('DECISION TREE CLASSIFIERS (Group 4 — Workflow C)')
        feedback.pushInfo('─────────────────────────────────────────────────')
        feedback.pushInfo('  dt_2100_2400   WoM-C only')
        feedback.pushInfo('  dt_albedo      Hyperspectral cube only')
        feedback.pushInfo('  dt_fedrop      Hyperspectral cube + WoM-C')
        feedback.pushInfo('  dt_illcryst    WoM-B + WoM-C')
        feedback.pushInfo('  dt_ill_kaol    WoM-B + WoM-C')
        feedback.pushInfo('  dt_kandite     FE12-2206W + WoM 2138–2196 nm + FE07-1900W')
        feedback.pushInfo('  dt_kaol_cryst  FE10-2160D + FE13-2206W')
        feedback.pushInfo('  dt_dick_kaol   FE12-2206W + WoM 2138–2196 nm')
        feedback.pushInfo('  dt_pyrophyl    WoM 2155–2180 nm + FE08-2066D')
        feedback.pushInfo('  dt_sulphate    FE-WOM-1440 + FE06-1760W + FE07-1900W + FE14/FE15')
        feedback.pushInfo('')
        feedback.pushInfo('══════════════════════════════════════════════════')
        feedback.pushInfo('')
        feedback.pushInfo(f'Full guide: {GUIDE_URL}')
        feedback.pushInfo('')
        feedback.pushInfo('REFERENCES')
        feedback.pushInfo('──────────')
        feedback.pushInfo('  Bakker, W.H., 2010-2022. HyPy - Hyperspectral Python.')
        feedback.pushInfo('    University of Twente, Faculty ITC.')
        feedback.pushInfo('  Bakker, W. et al., 2024. Hyperspectral Python: HypPy.')
        feedback.pushInfo('    Algorithms, 17(8), 337. https://doi.org/10.3390/a17080337')
        feedback.pushInfo('  Laukamp, C. et al., 2021. Mineral Physicochemistry Underlying')
        feedback.pushInfo('    Feature-Based Extraction of Mineral Abundance and Composition')
        feedback.pushInfo('    from Shortwave, Mid and Thermal Infrared Reflectance Spectra.')
        feedback.pushInfo('    Minerals, 11(4), 347. https://doi.org/10.3390/min11040347')
        feedback.pushInfo('  Laukamp, C. et al., 2025. Spaceborne Mineral Maps for Critical')
        feedback.pushInfo('    Metals Exploration in the Gascoyne and Pilbara.')
        feedback.pushInfo('    Geological Survey of Western Australia, Report 261.')
        feedback.pushInfo('  Kruse, F.A. et al., 1993. The Spectral Image Processing System')
        feedback.pushInfo('    (SIPS). Remote Sensing of Environment, 44(2-3), pp.145-163.')
        return {}

    def name(self):        return 'getting_started'
    def displayName(self): return 'Step 1 - Open Workflow Guide'
    def group(self):       return '1 - Workflow Guide'
    def groupId(self):     return '1_workflow_guide'

    def shortHelpString(self):
        return f"""
        <b>HypPy for QGIS — Workflow Guide  (v2.82)</b>

        <p>Run this algorithm to open the full user guide in your web browser,
        or read the workflow summary in the processing log.</p>

        <p style="background-color:#e8f4fd; padding:6px; border-left:4px solid #2196F3;">
        <b>User Guide:</b>
        <a href="{GUIDE_URL}">{GUIDE_URL}</a>
        </p>

        <hr/>
        <b>Plugin Groups</b>
        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Group</th><th>Purpose</th>
          </tr>
          <tr><td><b>1 — Workflow Guide</b></td>
              <td>This tool</td></tr>
          <tr><td><b>2 — Data Import</b></td>
              <td>D01 Build Overviews, D02 Subset</td></tr>
          <tr><td><b>3 — Generate WoM Rasters</b></td>
              <td>Workflow A — WoM-A / WoM-B / WoM-C from the cube</td></tr>
          <tr><td><b>4 — Decision Tree</b></td>
              <td>Workflow C — mineral and physical property classifiers</td></tr>
          <tr><td><b>5 — SAM Classification</b></td>
              <td>Workflow D — Spectral Angle Mapper</td></tr>
          <tr><td><b>6 — Spectral Processing</b></td>
              <td>Workflow E — band ratios, depths, convex hull, PCA, filters</td></tr>
          <tr><td><b>7 — Feature Extraction</b></td>
              <td>Workflow F — FE tools (WoM + wavelength map per absorption feature)</td></tr>
          <tr><td><b>8 — Convert Tools</b></td>
              <td>Workflow G — ENVI, HDF, ASTER, EMIT converters</td></tr>
        </table>

        <hr/>
        <b>Required Input Data</b>

        <p><b>1. Hyperspectral spectral cube</b><br/>
        Reflectance image with wavelength metadata (ENVI format or equivalent).</p>

        <p><b>2. Three WoM rasters</b> — generated by Group 3 (Workflow A):</p>
        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>WoM</th><th>Range</th><th>Used by</th>
          </tr>
          <tr><td><b>WoM-A</b></td><td>750 – 1300 nm</td>
              <td>dt_fedrop (iron oxide), future classifiers</td></tr>
          <tr><td><b>WoM-B</b></td><td>1850 – 2100 nm</td>
              <td>dt_illcryst, dt_ill_kaol</td></tr>
          <tr><td><b>WoM-C</b></td><td>2100 – 2400 nm</td>
              <td>dt_2100_2400, dt_fedrop, dt_illcryst, dt_ill_kaol</td></tr>
        </table>

        <hr/>
        <b>Recommended Workflow</b>
        <ol>
          <li>Run <b>Group 3</b> to generate WoM-A/B/C rasters from your cube</li>
          <li>Run <b>Group 7 Feature Extraction</b> tools for targeted mineral surveys<br/>
              (FE00 runs all 18 tools in one pass; individual tools for specific minerals)</li>
          <li>Run <b>Group 4 Decision Tree</b> classifiers using WoM and FE outputs</li>
          <li>Optionally run <b>Group 5</b> (SAM) or <b>Group 6</b> (spectral processing)</li>
        </ol>

        <hr/>
        <b>Feature Extraction Tools (Group 7 — Workflow F)</b>
        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Tool</th><th>Range (nm)</th><th>Targeted minerals</th>
          </tr>
          <tr style="background:#fff3e0"><td><b>FE-900D</b></td>
              <td>776–1050 (poly₂)</td>
              <td>Iron oxides — hematite (~890 nm), goethite (~940 nm)<br/>
              <i>GSWA Rpt261 Table 4; stretch Gascoyne/Pilbara min=0.16, max=0.29</i></td></tr>
          <tr><td>FE01 1384D</td><td>1350–1450</td><td>Dickite OH doublet</td></tr>
          <tr><td>FE02 1396W</td><td>1350–1450</td><td>Pyrophyllite OH</td></tr>
          <tr><td>FE03 1400D</td><td>1350–1450</td><td>Kaolinite / OH-bearing sheet silicates</td></tr>
          <tr><td>FE04 1480W</td><td>1440–1520</td><td>Alunite / jarosite / prehnite</td></tr>
          <tr><td>FE05 1550W</td><td>1510–1610</td><td>Epidote 2νOH</td></tr>
          <tr><td>FE06 1760W</td><td>1730–1790</td><td>Gypsum / alunite ν+2δOH</td></tr>
          <tr><td>FE07 1900W</td><td>1850–1960</td><td>Halloysite H₂O</td></tr>
          <tr><td>FE08 2066D</td><td>2050–2110</td><td>Pyrophyllite Al-OH doublet</td></tr>
          <tr><td>FE09 2080D</td><td>2060–2100</td><td>Talc ν+δM₃OH</td></tr>
          <tr><td>FE10 2160D</td><td>2138–2179</td>
              <td>Kaolin / pyrophyllite outer OH<br/>
              <i>GSWA: Gascoyne min=0.04, max=0.15 | Pilbara min=0.02, max=0.15</i></td></tr>
          <tr><td>FE11 2178D</td><td>2138–2210</td><td>Dickite Al-OH shoulder</td></tr>
          <tr><td>FE12 2200W</td><td>2120–2245</td>
              <td>AlOH — illite / smectite / kaolinite<br/>
              <i>GSWA: Gascoyne/Pilbara min=0.04, max=0.16</i></td></tr>
          <tr><td>FE13 2206W</td><td>2120–2245</td><td>Kaolinite primary Al-OH</td></tr>
          <tr><td>FE14 2250W</td><td>2230–2280</td>
              <td>Chlorite / biotite / epidote Fe/Mg-OH<br/>
              <i>GSWA: Gascoyne min=0.01, max=0.04 | Pilbara min=0.02, max=0.65</i></td></tr>
          <tr><td>FE15 2290W</td><td>2270–2320</td><td>FeMg-clay / amphibole / talc</td></tr>
          <tr><td>FE16 2320W</td><td>2295–2345</td><td>Carbonates (magnesite/dolomite/ankerite/calcite)</td></tr>
          <tr><td>FE17 2350W</td><td>2310–2370</td><td>Carbonates / pyrophyllite secondary</td></tr>
          <tr><td>FE18 2390W</td><td>2375–2435</td><td>Amphibole / biotite / talc</td></tr>
          <tr><td>FE-REE</td><td>530–910</td><td>Neodymium Nd³⁺ (580/740/800/870 nm)</td></tr>
          <tr style="background:#fff3e0"><td><b>FE-GSWA-RGB</b></td>
              <td>Composite</td>
              <td><b>R=2200D / G=2250D / B=2160D</b> false-colour composite<br/>
              <i>GSWA Rpt261 Table 4; all channels min=0.02, max=0.15 pre-loaded</i></td></tr>
        </table>

        <hr/>
        <b>Decision Tree Classifiers (Group 4 — Workflow C)</b>
        <table border="1" cellpadding="4" cellspacing="0" width="100%">
          <tr style="background:#1B3A5C; color:white">
            <th>Classifier</th><th>Inputs</th>
          </tr>
          <tr><td>dt_2100_2400</td><td>WoM-C only</td></tr>
          <tr><td>dt_albedo</td><td>Hyperspectral cube only</td></tr>
          <tr><td>dt_fedrop</td><td>Hyperspectral cube + WoM-C</td></tr>
          <tr><td>dt_illcryst</td><td>WoM-B + WoM-C</td></tr>
          <tr><td>dt_ill_kaol</td><td>WoM-B + WoM-C</td></tr>
          <tr><td>dt_kandite</td><td>FE12-2206W + WoM 2138–2196 nm + FE07-1900W</td></tr>
          <tr><td>dt_kaol_cryst</td><td>FE10-2160D + FE13-2206W</td></tr>
          <tr><td>dt_dick_kaol</td><td>FE12-2206W + WoM 2138–2196 nm</td></tr>
          <tr><td>dt_pyrophyl</td><td>WoM 2155–2180 nm + FE08-2066D</td></tr>
          <tr><td>dt_sulphate</td><td>FE-WOM-1440 + FE06-1760W + FE07-1900W + FE14 or FE15</td></tr>
        </table>

        <p><i>HypPy for QGIS v2.82 by Grant Boxer, 2025.</i></p>

        <hr/>
        <b>References</b>
        <p style="font-size:90%; color:#555;">
        Bakker, W.H., 2010&#x2013;2022. HyPy &#x2014; Hyperspectral Python. University of Twente, Faculty ITC.<br/>
        Bakker, W. et al., 2024. Hyperspectral Python: HypPy. <i>Algorithms</i>, 17(8), 337.
        https://doi.org/10.3390/a17080337<br/>
        Laukamp, C. et al., 2021. Mineral Physicochemistry Underlying Feature-Based
        Extraction of Mineral Abundance and Composition from Shortwave, Mid and Thermal Infrared
        Reflectance Spectra. <i>Minerals</i>, 11(4), 347.
        https://doi.org/10.3390/min11040347<br/>
        Laukamp, C. et al., 2025. Spaceborne Mineral Maps for Critical Metals Exploration
        in the Gascoyne and Pilbara. <i>Geological Survey of Western Australia, Report 261</i>.<br/>
        Kruse, F.A. et al., 1993. The Spectral Image Processing System (SIPS).
        <i>Remote Sensing of Environment</i>, 44(2&#x2013;3), pp.145&#x2013;163.
        </p>
        """

    def flags(self):
        return super().flags() | QgsProcessingAlgorithm.FlagNoThreading

    def createInstance(self): return GettingStartedAlgorithm()
